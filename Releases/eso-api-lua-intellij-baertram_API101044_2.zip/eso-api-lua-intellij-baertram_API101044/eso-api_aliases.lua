
--- @alias id64 integer
--- @alias integer53 integer
--- @alias ItemSetCollectionSlot_id64 integer
--- @alias layout_measurement integer
--- @alias luaindex integer

--- @alias textureName string
