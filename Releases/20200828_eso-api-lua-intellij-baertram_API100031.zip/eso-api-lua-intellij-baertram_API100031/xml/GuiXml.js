var GuiXml =
		/* copy the complete GuiXml.json file contents here to make this work. */
        
;
