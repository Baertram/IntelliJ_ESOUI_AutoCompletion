﻿AddOnManager = {}
function AddOnManager:AddRelevantFilter(relevantFilter) end
function AddOnManager:GetAddOnDependencyInfo(addOnIndex, addOnDependencyIndex) end
---Returns: name, active
function AddOnManager:GetAddOnFilter() end
---Returns: settingFilter
function AddOnManager:GetAddOnInfo(addOnIndex) end
---Returns: name, title, author, description, enabled, AddOnLoadState state, isOutOfDate
function AddOnManager:GetAddOnNumDependencies(addOnIndex) end
---Returns: numDependencies
function AddOnManager:GetLoadOutOfDateAddOns() end
---Returns: loadOutOfDateAddons
function AddOnManager:GetNumAddOns() end
---Returns: numAddOns
function AddOnManager:RemoveAddOnFilter() end
function AddOnManager:ResetRelevantFilters() end
function AddOnManager:SetAddOnEnabled(addOnIndex, enabled) end
function AddOnManager:SetAddOnFilter(settingFilter) end
function AddOnManager:SetLoadOutOfDateAddOns(loadOutOfDateAddons) end

AnimationManager = {}
function AnimationManager:CreateTimeline() end
---Returns: timeline
function AnimationManager:CreateTimelineFromVirtual(timelineName, animatedControl) end
---Returns: timeline

AnimationObject = {}
--AnimationObject3DRotate,
--AnimationObject3DTranslate,
--AnimationObjectAlpha,
--AnimationObjectColor,
--AnimationObjectCustom,
--AnimationObjectScale,
--AnimationObjectScroll,
--AnimationObjectSize,
--AnimationObjectTexture,
--AnimationObjectTextureRotate,
--AnimationObjectTextureSlide,
--AnimationObjectTranslate
function AnimationObject:GetAnimatedControl() end
---Returns: animatedControl
function AnimationObject:GetDuration() end
---Returns: durationMs
function AnimationObject:GetEasingFunction() end
---Returns: function
function AnimationObject:GetHandler(EventName) end
---Returns: function
function AnimationObject:GetTimeline() end
---Returns: owningTimeline
function AnimationObject:IsPlaying() end
---Returns: isPlaying
function AnimationObject:SetAnimatedControl(animatedControl) end
function AnimationObject:SetDuration(durationMs) end
function AnimationObject:SetEasingFunction(func) end
function AnimationObject:SetHandler(EventName, func) end

AnimationObject3DRotate = {}
function AnimationObject3DRotate:GetEndPitch() end
---Returns: endPitchRadians
function AnimationObject3DRotate:GetEndRoll() end
---Returns: endRollRadians
function AnimationObject3DRotate:GetEndYaw() end
---Returns: endYawRadians
function AnimationObject3DRotate:GetStartPitch() end
---Returns: startPitchRadians
function AnimationObject3DRotate:GetStartRoll() end
---Returns: startRollRadians
function AnimationObject3DRotate:GetStartYaw() end
---Returns: startYawRadians
function AnimationObject3DRotate:SetEndPitch(endPitchRadians) end
function AnimationObject3DRotate:SetEndRoll(endRollRadians) end
function AnimationObject3DRotate:SetEndYaw(endYawRadians) end
function AnimationObject3DRotate:SetRotationValues(startPitchRadians, startYawRadians, startRollRadians, endPitchRadians, endYawRadians, endRollRadians) end
function AnimationObject3DRotate:SetStartPitch(startPitchRadians) end
function AnimationObject3DRotate:SetStartRoll(startRollRadians) end
function AnimationObject3DRotate:SetStartYaw(startYawRadians) end

AnimationObject3DTranslate = {}
function AnimationObject3DTranslate:ClearBezierControlPoints() end
function AnimationObject3DTranslate:GetDeltaOffsetX() end
---Returns: deltaX
function AnimationObject3DTranslate:GetDeltaOffsetY() end
---Returns: deltaY
function AnimationObject3DTranslate:GetDeltaOffsetZ() end
---Returns: deltaZ
function AnimationObject3DTranslate:GetEndOffsetX() end
---Returns: endX
function AnimationObject3DTranslate:GetEndOffsetY() end
---Returns: endY
function AnimationObject3DTranslate:GetEndOffsetZ() end
---Returns: endZ
function AnimationObject3DTranslate:GetStartOffsetX() end
---Returns: startX
function AnimationObject3DTranslate:GetStartOffsetY() end
---Returns: startY
function AnimationObject3DTranslate:GetStartOffsetZ() end
---Returns: startZ
function AnimationObject3DTranslate:GetTranslateDeltas() end
---Returns: deltaX, deltaY, deltaZ
function AnimationObject3DTranslate:SetBezierControlPoint(index, x, y, z) end
function AnimationObject3DTranslate:SetDeltaOffsetX(deltaX,translateAnimationDeltaType) end
function AnimationObject3DTranslate:SetDeltaOffsetY(deltaY,translateAnimationDeltaType) end
function AnimationObject3DTranslate:SetDeltaOffsetZ(deltaZ,translateAnimationDeltaType) end
function AnimationObject3DTranslate:SetEndOffsetX(endX) end
function AnimationObject3DTranslate:SetEndOffsetY(endY) end
function AnimationObject3DTranslate:SetEndOffsetZ(endZ) end
function AnimationObject3DTranslate:SetStartOffsetX(startX) end
function AnimationObject3DTranslate:SetStartOffsetY(startY) end
function AnimationObject3DTranslate:SetStartOffsetZ(startZ) end
function AnimationObject3DTranslate:SetTranslateDeltas(deltaX, deltaY, deltaZ, translateAnimationDeltaType) end
function AnimationObject3DTranslate:SetTranslateOffsets(startX, startY, startZ, endX, endY, endZ) end

AnimationObjectAlpha = {}
function AnimationObjectAlpha:GetEndAlpha() end
---Returns: endAlpha
function AnimationObjectAlpha:GetStartAlpha() end
---Returns: startAlpha
function AnimationObjectAlpha:SetAlphaValues(startAlpha, endAlpha) end
function AnimationObjectAlpha:SetEndAlpha(endAlpha) end
function AnimationObjectAlpha:SetStartAlpha(startAlpha) end

AnimationObjectColor = {}
function AnimationObjectColor:GetEndColor() end
---Returns: endR, endG, endB, endA
function AnimationObjectColor:GetStartColor() end
---Returns: startR, startG, startB, startA
function AnimationObjectColor:SetColorValues(startR, startG, startB, startA, endR, endG, endB, endA) end
function AnimationObjectColor:SetEndColor(endR, endG, endB, endA) end
function AnimationObjectColor:SetStartColor(startR, startG, startB, startA) end

AnimationObjectCustom = {}
function AnimationObjectCustom:SetUpdateFunction(func) end

AnimationObjectScale = {}
function AnimationObjectScale:GetEndScale() end
---Returns: endScale
function AnimationObjectScale:GetStartScale() end
---Returns: startScale
function AnimationObjectScale:SetEndScale(endScale) end
function AnimationObjectScale:SetScaleValues(startScale, endScale) end
function AnimationObjectScale:SetStartScale(startScale) end

AnimationObjectScroll = {}
function AnimationObjectScroll:SetHorizontalEnd(endX) end
function AnimationObjectScroll:SetHorizontalRelative(offsetX) end
function AnimationObjectScroll:SetHorizontalStartAndEnd(startX, endX) end
function AnimationObjectScroll:SetVerticalEnd(endY) end
function AnimationObjectScroll:SetVerticalRelative(offsetY) end
function AnimationObjectScroll:SetVerticalStartAndEnd(startY, endY) end

AnimationObjectSize = {}
function AnimationObjectSize:SetEndHeight(endHeight) end
function AnimationObjectSize:SetEndWidth(endWidth) end
function AnimationObjectSize:SetStartAndEndHeight(startHeight, endHeight) end
function AnimationObjectSize:SetStartAndEndWidth(startWidth, endWidth) end
function AnimationObjectSize:SetStartHeight(startHeight) end
function AnimationObjectSize:SetStartWidth(startWidth) end

AnimationObjectTexture = {}
function AnimationObjectTexture:GetCellsHigh() end
---Returns: aNumCellsHigh
function AnimationObjectTexture:GetCellsWide() end
---Returns: aNumCellsWide
function AnimationObjectTexture:IsMirroringAlongX() end
---Returns: mirroring
function AnimationObjectTexture:IsMirroringAlongY() end
---Returns: mirroring
function AnimationObjectTexture:SetCellsHigh(aNumCellsHigh) end
function AnimationObjectTexture:SetCellsWide(aNumCellsWide) end
function AnimationObjectTexture:SetFramerate(framesPerSecond) end
function AnimationObjectTexture:SetImageData(aNumCellsWide, aNumCellsHigh) end
function AnimationObjectTexture:SetMirrorAlongX(mirroring) end
function AnimationObjectTexture:SetMirrorAlongY(mirroring) end

AnimationObjectTextureRotate = {}
function AnimationObjectTextureRotate:GetEndRotation() end
---Returns: endRadians
function AnimationObjectTextureRotate:GetStartRotation() end
---Returns: startRadians
function AnimationObjectTextureRotate:SetEndRotation(endRadians) end
function AnimationObjectTextureRotate:SetRotationValues(startRadians, endRadians) end
function AnimationObjectTextureRotate:SetStartRotation(startRadians) end

AnimationObjectTextureSlide = {}
function AnimationObjectTextureSlide:SetSlideDistances(slideDistanceU, slideDistanceV) end

AnimationObjectTranslate = {}
function AnimationObjectTranslate:GetAnchorIndex() end
---Returns: anchorIndex
function AnimationObjectTranslate:GetDeltaOffsetX() end
---Returns: deltaX
function AnimationObjectTranslate:GetDeltaOffsetY() end
---Returns: deltaY
function AnimationObjectTranslate:GetEndOffsetX() end
---Returns: endX
function AnimationObjectTranslate:GetEndOffsetY() end
---Returns: endY
function AnimationObjectTranslate:GetStartOffsetX() end
---Returns: startX
function AnimationObjectTranslate:GetStartOffsetY() end
---Returns: startY
function AnimationObjectTranslate:GetTranslateDeltas() end
---Returns: deltaX, deltaY
function AnimationObjectTranslate:SetAnchorIndex(anchorIndex) end
function AnimationObjectTranslate:SetDeltaOffsetX(deltaX,translateAnimationDeltaType) end
function AnimationObjectTranslate:SetDeltaOffsetY(deltaY,translateAnimationDeltaType) end
function AnimationObjectTranslate:SetEndOffsetX(endX) end
function AnimationObjectTranslate:SetEndOffsetY(endY) end
function AnimationObjectTranslate:SetStartOffsetX(startX) end
function AnimationObjectTranslate:SetStartOffsetY(startY) end
function AnimationObjectTranslate:SetTranslateDeltas(deltaX, deltaY,translateAnimationDeltaType) end
function AnimationObjectTranslate:SetTranslateOffsets(startX, startY, endX, endY) end

AnimationTimeline = {}
function AnimationTimeline:ApplyAllAnimationsToControl(animatedControl) end
function AnimationTimeline:ClearAllCallbacks() end
function AnimationTimeline:GetAnimation(animationIndex) end
---Returns: animation
function AnimationTimeline:GetAnimationOffset(animation) end
---Returns: offset
function AnimationTimeline:GetAnimationTimeline(timelineIndex) end
---Returns: timeline
function AnimationTimeline:GetAnimationTimelineOffset(animation) end
---Returns: offset
function AnimationTimeline:GetDuration() end
---Returns: duration
function AnimationTimeline:GetFirstAnimation() end
---Returns: animation
function AnimationTimeline:GetFirstAnimationTimeline() end
---Returns: timeline
function AnimationTimeline:GetFullProgress() end
---Returns: progress
function AnimationTimeline:GetHandler(EventName) end
---Returns: function
function AnimationTimeline:GetLastAnimation() end
---Returns: animation
function AnimationTimeline:GetLastAnimationTimeline() end
---Returns: timeline
function AnimationTimeline:GetNumAnimationTimelines() end
---Returns: numTimelines
function AnimationTimeline:GetNumAnimations() end
---Returns: numAnimations
function AnimationTimeline:GetParent() end
---Returns: timeline
function AnimationTimeline:GetPlaybackLoopsRemaining() end
---Returns: loopsRemaining
function AnimationTimeline:GetProgress() end
---Returns: progress
function AnimationTimeline:GetSkipAnimationsBehindPlayheadOnInitialPlay() end
---Returns: skipAnimations
function AnimationTimeline:InsertAnimation(animationType, animatedControl, offset) end
---Returns: animation
function AnimationTimeline:InsertAnimationFromVirtual(animationVirtualName, animatedControl) end
---Returns: animation
function AnimationTimeline:InsertAnimationTimeline(offset, animatedControl) end
---Returns: animation
function AnimationTimeline:InsertAnimationTimelineFromVirtual(animationVirtualName, animatedControl) end
---Returns: animation
function AnimationTimeline:InsertCallback(func, offset) end
---Returns: function Ret
function AnimationTimeline:IsPlaying() end
---Returns: isPlaying
function AnimationTimeline:IsPlayingBackward() end
---Returns: reversed
function AnimationTimeline:PlayBackward() end
function AnimationTimeline:PlayForward() end
function AnimationTimeline:PlayFromEnd(offsetMs) end
function AnimationTimeline:PlayFromStart(offsetMs) end
function AnimationTimeline:PlayInstantlyToEnd() end
function AnimationTimeline:PlayInstantlyToStart() end
function AnimationTimeline:SetAnimationOffset(animation, offset) end
function AnimationTimeline:SetAnimationTimelineOffset(animation, offset) end
function AnimationTimeline:SetCallbackOffset(callback, offset) end
function AnimationTimeline:SetHandler(EventName, func) end
function AnimationTimeline:SetPlaybackLoopCount(maxLoopCount) end
function AnimationTimeline:SetPlaybackLoopsRemaining(loopsRemaining) end
function AnimationTimeline:SetPlaybackType(playbackType, maxLoopCount) end
function AnimationTimeline:SetProgress(progress) end
function AnimationTimeline:SetSkipAnimationsBehindPlayheadOnInitialPlay(skipAnimations) end
function AnimationTimeline:Stop() end

BackdropControl = {}
function BackdropControl:GetCenterColor() end
---Returns: r, g, b, a
function BackdropControl:IsPixelRoundingEnabled() end
---Returns: pixelRoundingEnabled
function BackdropControl:SetCenterColor(r, g, b, a) end
function BackdropControl:SetCenterTexture(filename, tileSize, addressMode) end
function BackdropControl:SetEdgeColor(r, g, b, a) end
function BackdropControl:SetEdgeTexture(filename, edgeFileWidth, edgeFileHeight, edgeSize, edgeFilePadding) end
function BackdropControl:SetInsets(left, top, right, bottom) end
function BackdropControl:SetIntegralWrapping(integralWrappingEnabled) end
function BackdropControl:SetPixelRoundingEnabled(enabled) end
function BackdropControl:SetTextureReleaseOption(releaseOption) end

ButtonControl = {}
function ButtonControl:EnableMouseButton(buttonNum, enabled) end
function ButtonControl:GetLabelControl() end
---Returns: labelControl
function ButtonControl:GetState() end
---Returns: state
function ButtonControl:IsPixelRoundingEnabled() end
---Returns: pixelRoundingEnabled
function ButtonControl:SetClickSound(clickSound) end
function ButtonControl:SetDesaturation(desaturation) end
function ButtonControl:SetDisabledFontColor(r, g, b, a) end
function ButtonControl:SetDisabledPressedFontColor(r, g, b, a) end
function ButtonControl:SetDisabledPressedTexture(textureFilename) end
function ButtonControl:SetDisabledTexture(textureFilename) end
function ButtonControl:SetEnabled(enabled) end
function ButtonControl:SetEndCapWidth(endCapWidth) end
function ButtonControl:SetFont(text) end
function ButtonControl:SetHorizontalAlignment(horizontalAlign) end
function ButtonControl:SetMouseOverBlendMode(blendMode) end
function ButtonControl:SetMouseOverFontColor(r, g, b, a) end
function ButtonControl:SetMouseOverTexture(textureFilename) end
function ButtonControl:SetNormalFontColor(r, g, b, a) end
function ButtonControl:SetNormalOffset(x, y) end
function ButtonControl:SetNormalTexture(textureFilename) end
function ButtonControl:SetPixelRoundingEnabled(pixelRoundingEnabled) end
function ButtonControl:SetPressedFontColor(r, g, b, a) end
function ButtonControl:SetPressedMouseOverTexture(textureFilename) end
function ButtonControl:SetPressedOffset(x, y) end
function ButtonControl:SetPressedTexture(textureFilename) end
function ButtonControl:SetShowingHighlight(showingHighlight) end
function ButtonControl:SetState(newState, locked) end
function ButtonControl:SetText(text) end
function ButtonControl:SetTextureCoords(left, right, top, bottom) end
function ButtonControl:SetTextureReleaseOption(releaseOption) end
function ButtonControl:SetVerticalAlignment(verticalAlign) end

ColorSelectControl = {}
function ColorSelectControl:GetColorAsHSV() end
---Returns: hue, saturation, value
function ColorSelectControl:GetColorAsRGB() end
---Returns: red, green, blue
function ColorSelectControl:GetColorWheelTextureControl() end
---Returns: textureControl
function ColorSelectControl:GetColorWheelThumbTextureControl() end
---Returns: textureControl
function ColorSelectControl:GetFullValuedColorAsRGB() end
---Returns: red, green, blue
function ColorSelectControl:GetValue() end
---Returns: value
function ColorSelectControl:SetColorAsHSV(hue, saturation, value) end
function ColorSelectControl:SetColorAsRGB(red, green, blue) end
function ColorSelectControl:SetColorWheelThumbTextureControl(textureControl) end
function ColorSelectControl:SetValue(value) end

CompassDisplayControl = {}
function CompassDisplayControl:GetAlphaCoefficients(pinType) end
---Returns: leadingCoefficient, coefficient, constant
function CompassDisplayControl:GetCenterOveredPinDescription(centerOveredPinIndex) end
---Returns: description
function CompassDisplayControl:GetCenterOveredPinDistance(centerOveredPinIndex) end
---Returns: distance
function CompassDisplayControl:GetCenterOveredPinInfo(centerOveredPinIndex) end
---Returns: description, pinType, distance,  drawLayer, drawLevel, suppressed
function CompassDisplayControl:GetCenterOveredPinLayerAndLevel(centerOveredPinIndex) end
---Returns:  drawLayer, drawLevel
function CompassDisplayControl:GetCenterOveredPinType(centerOveredPinIndex) end
---Returns: pinType
function CompassDisplayControl:GetMinVisibleAlpha(pinType) end
---Returns: minVisibleAlpha
function CompassDisplayControl:GetMinVisibleScale(pinType) end
---Returns: minVisibleScale
function CompassDisplayControl:GetNumCenterOveredPins() end
---Returns: numCenterOveredPins
function CompassDisplayControl:GetScaleCoefficients(pinType) end
---Returns: leadingCoefficient, coefficient, constant
function CompassDisplayControl:IsCenterOveredPinSuppressed(centerOveredPinIndex) end
---Returns: suppressed
function CompassDisplayControl:SetAlphaCoefficients(pinType, leadingCoefficient, coefficient, constant) end
function CompassDisplayControl:SetCardinalDirection(directionName, font, cardinalDirection) end
function CompassDisplayControl:SetMinVisibleAlpha(pinType, minVisibleAlpha) end
function CompassDisplayControl:SetMinVisibleScale(pinType, minVisibleScale) end
function CompassDisplayControl:SetScaleCoefficients(pinType, leadingCoefficient, coefficient, constant) end

Control = {}
--BackdropControl,
--ButtonControl,
--ColorSelectControl,
--CompassDisplayControl,
--CooldownControl,
--DebugTextControl,
--EditControl,
--LabelControl,
--LineControl,
--MapDisplayControl,
--RootWindow,
--ScrollControl,
--SliderControl,
--StatusBarControl,
--TextBufferControl,
--TextureCompositeControl,
--TextureControl,
--TooltipControl,
--TopLevelWindow
function Control:AddFilterForEvent(event) end
---Returns: success
function Control:ClearAnchors() end
function Control:Convert3DLocalOrientationToWorldOrientation(localPitch, localYaw, localRoll) end
---Returns: worldPitch, worldYaw, worldRoll
function Control:Convert3DLocalPositionToWorldPosition(localX, localY, localZ) end
---Returns: worldX, worldY, worldZ
function Control:Convert3DWorldOrientationToLocalOrientation(worldPitch, worldYaw, worldRoll) end
---Returns: localPitch, localYaw, localRoll
function Control:Convert3DWorldPositionToLocalPosition(worldX, worldY, worldZ) end
---Returns: localX, localY, localZ
function Control:Create3DRenderSpace() end
function Control:CreateControl(arg1, type) end
---Returns: apRet
function Control:Destroy3DRenderSpace() end
function Control:Does3DRenderSpaceUseDepthBuffer() end
---Returns: usesDepthBuffer
function Control:Get3DRenderSpaceForward() end
---Returns: x, y, z
function Control:Get3DRenderSpaceOrientation() end
---Returns: pitchRadians, yawRadians, rollRadians
function Control:Get3DRenderSpaceOrigin() end
---Returns: x, y, z
function Control:Get3DRenderSpaceRight() end
---Returns: x, y, z
function Control:Get3DRenderSpaceSystem() end
---Returns: GuiRender3DSpaceSystem system
function Control:Get3DRenderSpaceUp() end
---Returns: x, y, z
function Control:GetAlpha() end
---Returns: alpha
function Control:GetAnchor(anchorIndex) end
---Returns: isValidAnchor, point, relativeTo, relativePoint, offsetX, offsetY, anchorConstrains
function Control:GetBottom() end
---Returns: bottom
function Control:GetCenter() end
---Returns: centerX, centerY
function Control:GetChild(childIndex) end
---Returns: childControl
function Control:GetClampedToScreen() end
---Returns: clamped
function Control:GetClampedToScreenInsets() end
---Returns: left, top, right, bottom
function Control:GetControlAlpha() end
---Returns: alpha
function Control:GetControlScale() end
---Returns: scale
function Control:GetDesiredHeight() end
---Returns: height
function Control:GetDesiredWidth() end
---Returns: width
function Control:GetDimensionConstraints() end
---Returns: minWidth, minHeight, maxWidth, maxHeight
function Control:GetDimensions() end
---Returns: width, height
function Control:Get() end
---Returns: layer
function Control:GetDrawLevel() end
---Returns: level
function Control:GetDrawTier() end
---Returns: tier
function Control:GetExcludeFromResizeToFitExtents() end
---Returns: excludes
function Control:GetHandler(handlerName) end
---Returns: function
function Control:GetHeight() end
---Returns: height
function Control:GetHitInsets() end
---Returns: left, top, right, bottom
function Control:GetId() end
---Returns: id
function Control:GetInheritsAlpha() end
---Returns: inheritAlpha
function Control:GetInheritsScale() end
---Returns: inheritScale
function Control:GetLeft() end
---Returns: left
function Control:GetName() end
---Returns: name
function Control:GetNamedChild(childName) end
---Returns: returnedControl
function Control:GetNumChildren() end
---Returns: numChildren
function Control:GetOwningWindow() end
---Returns: OwningTopLevelWindow
function Control:GetParent() end
---Returns: ret1
function Control:GetResizeToFitDescendents() end
---Returns: resizes
function Control:GetResizeToFitPadding() end
---Returns: width, height
function Control:GetRight() end
---Returns: right
function Control:GetScale() end
---Returns: scale
function Control:GetScreenRect() end
---Returns: left, top, right, bottom
function Control:GetTop() end
---Returns: top
function Control:GetType() end
---Returns: type
function Control:GetWidth() end
---Returns: width
function Control:Has3DRenderSpace() end
---Returns: has3DRenderSpace
function Control:IsChildOf(desiredParent) end
---Returns: isChild
function Control:IsControlHidden() end
---Returns: hidden
function Control:IsHandlerSet(handlerName) end
---Returns: isSet
function Control:IsHidden() end
---Returns: hidden
function Control:IsKeyboardEnabled() end
---Returns: enabled
function Control:IsMouseEnabled() end
---Returns: enabled
function Control:IsPointInside(x, y, leftOffset, topOffset, rightOffset, bottomOffset) end
---Returns: isInside
function Control:RegisterForEvent(event, callback) end
---Returns: success
function Control:Set3DRenderSpaceForward(x, y, z) end
function Control:Set3DRenderSpaceOrientation(pitchRadians, yawRadians, rollRadians) end
function Control:Set3DRenderSpaceOrigin(x, y, z) end
function Control:Set3DRenderSpaceRight(x, y, z) end
function Control:Set3DRenderSpaceSystem(GuiRender3DSpaceSystem) end
function Control:Set3DRenderSpaceUp(x, y, z) end
function Control:Set3DRenderSpaceUsesDepthBuffer(usesDepthBuffer) end
function Control:SetAlpha(alpha) end
function Control:SetAnchor(whereOnMe, anchorTargetControl, whereOnTarget, offsetX, offsetY, anchorConstrains) end
function Control:SetAnchorFill(anchorTargetControl) end
function Control:SetClampedToScreen(clamped) end
function Control:SetClampedToScreenInsets(left, top, right, bottom) end
function Control:SetDimensionConstraints(minWidth, minHeight, maxWidth, maxHeight) end
function Control:SetDimensions(width, height) end
function Control:Set(layer) end
function Control:SetDrawLevel(level) end
function Control:SetDrawTier(tier) end
function Control:SetExcludeFromResizeToFitExtents(exclude) end
function Control:SetHandler(handlerName, func) end
function Control:SetHeight(height) end
function Control:SetHidden(aHidden) end
function Control:SetHitInsets(left, top, right, bottom) end
function Control:SetId(id) end
function Control:SetInheritAlpha(inheritAlpha) end
function Control:SetInheritScale(inheritScale) end
function Control:SetKeyboardEnabled(enabled) end
function Control:SetMouseEnabled(enabled) end
function Control:SetMovable(isMovable) end
function Control:SetParent(newParent) end
function Control:SetResizeHandleSize(handleSize) end
function Control:SetResizeToFitDescendents(resize) end
function Control:SetResizeToFitPadding(width, height) end
function Control:SetScale(scale) end
function Control:SetShapeType (shapeType) end
function Control:SetSimpleAnchor(anchorTargetControl, offsetX, offsetY) end
function Control:SetSimpleAnchorParent(offsetX, offsetY) end
function Control:SetWidth(width) end
function Control:StartMoving() end
---Returns: isMoving
function Control:StopMovingOrResizing() end
function Control:ToggleHidden() end
function Control:UnregisterForEvent(event) end
---Returns: success

CooldownControl = {}
function CooldownControl:GetDuration() end
---Returns: duration
function CooldownControl:GetPercentCompleteFixed() end
---Returns: percentComplete
function CooldownControl:GetTimeLeft() end
---Returns: time
function CooldownControl:ResetCooldown() end
function CooldownControl:SetBlendMode(blendMode) end
function CooldownControl:SetCooldownRemainTime(remain) end
function CooldownControl:SetDesaturation(desaturation) end
function CooldownControl:SetFillColor(r, g, b, a) end
function CooldownControl:SetLeadingEdgeTexture(filename) end
function CooldownControl:SetPercentCompleteFixed(percentComplete) end
function CooldownControl:SetRadialCooldownClockwise(clockwise) end
function CooldownControl:SetRadialCooldownGradient(startAlpha, angularDistance) end
function CooldownControl:SetRadialCooldownOriginAngle(originAngle) end
function CooldownControl:SetTexture(filename) end
function CooldownControl:SetTextureReleaseOption(releaseOption) end
function CooldownControl:SetVerticalCooldownLeadingEdgeHeight(leadingEdgeHeight) end
function CooldownControl:StartCooldown(remain, duration, cooldownType, cooldownTimeType, drawLeadingEdge) end
function CooldownControl:StartFixedCooldown(percentComplete, cooldownType, cooldownTimeType, drawLeadingEdge) end

DebugTextControl = {}
function DebugTextControl:Clear() end
function DebugTextControl:SetFont(fontStr) end

EditControl = {}
function EditControl:AddValidCharacter(validCharacter) end
function EditControl:Clear() end
function EditControl:ClearSelection() end
function EditControl:CopyAllTextToClipboard() end
function EditControl:GetCopyEnabled() end
---Returns: enabled
function EditControl:GetCursorPosition() end
---Returns: cursorPosition
function EditControl:GetEditEnabled() end
---Returns: enabled
function EditControl:GetFontHeight() end
---Returns: fontHeightUIUnits
function EditControl:GetNewLineEnabled() end
---Returns: enabled
function EditControl:GetPasteEnabled() end
---Returns: enabled
function EditControl:GetScrollExtents() end
---Returns: numLines
function EditControl:GetText() end
---Returns: apRet
function EditControl:GetTopLineIndex() end
---Returns: index
function EditControl:HasFocus() end
---Returns: aRet
function EditControl:HasSelection() end
---Returns: hasSelection
function EditControl:InsertText(aText) end
function EditControl:IsComposingIMEText() end
---Returns: isComposing
function EditControl:IsMultiLine() end
---Returns: isMultiLine
function EditControl:LoseFocus() end
function EditControl:RemoveAllValidCharacters() end
function EditControl:SelectAll() end
function EditControl:SetColor(r, g, b, a) end
function EditControl:SetCopyEnabled(enabled) end
function EditControl:SetCursorPosition(cursorPosition) end
function EditControl:SetEditEnabled(enabled) end
function EditControl:SetFont(font) end
function EditControl:SetMaxInputChars(maxChars) end
function EditControl:SetMultiLine(isMultiLine) end
function EditControl:SetNewLineEnabled(enabled) end
function EditControl:SetPasteEnabled(enabled) end
function EditControl:SetSelection(selectionStartIndex, selectionEndIndex) end
function EditControl:SetSelectionColor(r, g, b, a) end
function EditControl:SetText(aText) end
function EditControl:SetTextType(textType) end
function EditControl:SetTopLineIndex(index) end
function EditControl:Set( aKeyboardType) end
function EditControl:TakeFocus() end
function EditControl:WasLastChangeVirtualKeyboard() end
---Returns: aRet

FontObject = {}
function FontObject:GetFontInfo() end
---Returns: face, size, option
function FontObject:SetFont(fontDescriptor) end

LabelControl = {}
function LabelControl:AnchorToBaseline(toLabel, offsetX, anchorSide) end
function LabelControl:ClearAnchorToBaseline(toLabel) end
function LabelControl:DidLineWrap() end
---Returns: didLineWrap
function LabelControl:GetColor() end
---Returns: r, g, b, a
function LabelControl:GetFontHeight() end
---Returns: fontHeightUIUnits
function LabelControl:GetHorizontalAlignment() end
---Returns: align
function LabelControl:Get() end
---Returns:  modifyTextType
function LabelControl:GetNumLines() end
---Returns: numLines
function LabelControl:GetStringWidth(text) end
---Returns: pixelWidth
function LabelControl:GetStyleColor() end
---Returns: r, g, b, a
function LabelControl:GetText() end
---Returns: apRet
function LabelControl:GetTextDimensions() end
---Returns: stringWidth, stringHeight
function LabelControl:GetTextHeight() end
---Returns: stringHeight
function LabelControl:GetTextWidth() end
---Returns: stringWidth
function LabelControl:GetVerticalAlignment() end
---Returns: align
function LabelControl:SetColor(r, g, b, a) end
function LabelControl:SetDesaturation(desaturation) end
function LabelControl:SetFont(fontString) end
function LabelControl:SetHorizontalAlignment(align) end
function LabelControl:SetLineSpacing(lineSpacing) end
function LabelControl:SetMaxLineCount(maxLineCount) end
function LabelControl:Set( modifyTextType) end
function LabelControl:SetNewLineX(newLineX) end
function LabelControl:SetPixelRoundingEnabled(pixelRoundingEnabled) end
function LabelControl:SetStyleColor(r, g, b, a) end
function LabelControl:SetText(aText) end
function LabelControl:SetVerticalAlignment(verticalAlign) end
function LabelControl:SetWrapMode(wrapMode) end
function LabelControl:WasTruncated() end
---Returns: wasTruncated

LineControl = {}
function LineControl:GetBlendMode() end
---Returns: TextureBlendMode blendMode
function LineControl:GetColor() end
---Returns: r, g, b, a
function LineControl:GetDesaturation() end
---Returns: desaturation
function LineControl:GetTextureCoords() end
---Returns: left, right, top, bottom
function LineControl:GetTextureFileDimensions() end
---Returns: pixelWidth, pixelHeight
function LineControl:GetTextureFileName() end
---Returns: filename
function LineControl:IsPixelRoundingEnabled() end
---Returns: pixelRoundingEnabled
function LineControl:IsTextureLoaded() end
---Returns: loaded
function LineControl:SetBlendMode(TextureBlendMode) end
function LineControl:SetColor(r, g, b, a) end
function LineControl:SetDesaturation(desaturation) end
function LineControl:SetGradientColors( orientation, startR, startG, startB, startA, endR, endG, endB, endA) end
function LineControl:SetPixelRoundingEnabled(pixelRoundingEnabled) end
function LineControl:SetTexture(filename) end
function LineControl:SetTextureCoords(left, right, top, bottom) end
function LineControl:SetThickness(thickness) end
function LineControl:SetVertexColors(vertexPoints, red, green, blue, alpha) end

MapDisplayControl = {}
function MapDisplayControl:GetZoom() end
---Returns: normalizedRadius
function MapDisplayControl:SetPinFont(pinFont) end
function MapDisplayControl:SetZoom(normalizedRadius) end

RootWindow = {}

ScrollControl = {}
function ScrollControl:GetScrollExtents() end
---Returns: horizontal, vertical
function ScrollControl:GetScrollOffsets() end
---Returns: horizontal, vertical
function ScrollControl:RestoreToExtents(duration) end
function ScrollControl:SetFadeGradient(gradientIndex, normalX, normalY, gradientLength) end
function ScrollControl:SetHorizontalScroll(offset) end
function ScrollControl:SetScrollBounding(bounding) end
function ScrollControl:SetVerticalScroll(offset) end

SliderControl = {}
function SliderControl:DoesAllowDraggingFromThumb() end
---Returns: allow
function SliderControl:GetEnabled() end
---Returns: isEnabled
function SliderControl:GetMinMax() end
---Returns: min, max
function SliderControl:GetOrientation() end
---Returns: orientation
function SliderControl:GetThumbTextureControl() end
---Returns: textureControl
function SliderControl:GetValue() end
---Returns: value
function SliderControl:GetValueStep() end
---Returns: step
function SliderControl:IsThumbFlushWithExtents() end
---Returns: flush
function SliderControl:SetAllowDraggingFromThumb(allow) end
function SliderControl:SetBackgroundBottomTexture(fileName, texTop, texLeft, texBottom, texRight) end
function SliderControl:SetBackgroundMiddleTexture(fileName, texTop, texLeft, texBottom, texRight) end
function SliderControl:SetBackgroundTopTexture(fileName, texTop, texLeft, texBottom, texRight) end
function SliderControl:SetColor(r, g, b, a) end
function SliderControl:SetEnabled(enable) end
function SliderControl:SetMinMax(min, max) end
function SliderControl:SetOrientation(orientation) end
function SliderControl:SetThumbFlushWithExtents(flush) end
function SliderControl:SetThumbTexture(filename, disabledFilename, highlightedFilename, thumbWidth, thumbHeight, texTop, texLeft, texBottom, texRight) end
function SliderControl:SetThumbTextureHeight(height) end
function SliderControl:SetValue(value) end
function SliderControl:SetValueStep(step) end

StatusBarControl = {}
function StatusBarControl:ClearFadeOutLossAdjustedTopValue() end
function StatusBarControl:EnableFadeOut(enabled) end
function StatusBarControl:EnableLeadingEdge(enabled) end
function StatusBarControl:EnableScrollingOverlay(enabled) end
function StatusBarControl:GetMinMax() end
---Returns: min, max
function StatusBarControl:GetValue() end
---Returns: value
function StatusBarControl:SetBarAlignment(barAlignment) end
function StatusBarControl:SetColor(r, g, b, a) end
function StatusBarControl:SetFadeOutGainColor(r, g, b, a) end
function StatusBarControl:SetFadeOutLossAdjustedTopValue(topValue) end
function StatusBarControl:SetFadeOutLossColor(r, g, b, a) end
function StatusBarControl:SetFadeOutLossSetValueToAdjust(adjustValue) end
function StatusBarControl:SetFadeOutTexture(filename) end
function StatusBarControl:SetFadeOutTime(fadeOutSeconds, fadeOutDelaySeconds) end
function StatusBarControl:SetGradientColors(startR, startG, startB, startA, endR, endG, endB, endA) end
function StatusBarControl:SetLeadingEdge(textureFile, width, height) end
function StatusBarControl:SetLeadingEdgeTextureCoords(left, right, top, bottom) end
function StatusBarControl:SetMinMax(aMin, aMax) end
function StatusBarControl:SetOrientation(orientation) end
function StatusBarControl:SetTexture(filename) end
function StatusBarControl:SetTextureCoords(left, right, top, bottom) end
function StatusBarControl:SetValue(aValue) end
function StatusBarControl:SetupScrollingOverlay(textureFile, width, height, duration) end

TextBufferControl = {}
function TextBufferControl:AddMessage(aText, r, g, b, colorId) end
function TextBufferControl:Clear() end
function TextBufferControl:GetDrawLastEntryIfOutOfRoom() end
---Returns: drawLastIfOutOfRoom
function TextBufferControl:GetLineFade() end
---Returns: timeBeforeLineBeginsToFade, timeItTakesLineToFade
function TextBufferControl:GetLinkEnabled() end
---Returns: linkEnabed
function TextBufferControl:GetMaxHistoryLines() end
---Returns: numLines
function TextBufferControl:GetNumHistoryLines() end
---Returns: numLines
function TextBufferControl:GetNumVisibleLines() end
---Returns: numLines
function TextBufferControl:GetScrollPosition() end
---Returns: scrollPosition
function TextBufferControl:IsSplittingLongMessages() end
---Returns: isSplitting
function TextBufferControl:MoveScrollPosition(numLines) end
function TextBufferControl:SetClearBufferAfterFadeout(clearAfterFade) end
function TextBufferControl:SetColorById(colorId, r, g, b) end
function TextBufferControl:SetDrawLastEntryIfOutOfRoom(drawLastIfOutOfRoom) end
function TextBufferControl:SetFont(fontString) end
function TextBufferControl:SetHorizontalAlignment(align) end
function TextBufferControl:SetLineFade(timeBeforeLineFadeBegins, timeForLineToFade) end
function TextBufferControl:SetLinesInheritAlpha(linesInheritAlpha) end
function TextBufferControl:SetLinkEnabled(linkEnabed) end
function TextBufferControl:SetMaxHistoryLines(numLines) end
function TextBufferControl:SetScrollPosition(line) end
function TextBufferControl:SetSplitLongMessages(splitLongMessages) end
function TextBufferControl:ShowFadedLines() end

TextureCompositeControl = {}
function TextureCompositeControl:AddSurface(left, right, top, bottom) end
function TextureCompositeControl:ClearAllSurfaces() end
function TextureCompositeControl:GetBlendMode() end
---Returns: TextureBlendMode blendMode
function TextureCompositeControl:GetColor(surfaceIndex) end
---Returns: r, g, b, a
function TextureCompositeControl:GetDesaturation() end
---Returns: desaturation
function TextureCompositeControl:GetInsets(surfaceIndex) end
---Returns: left, right, top, bottom
function TextureCompositeControl:GetNumSurfaces() end
---Returns: surfaces
function TextureCompositeControl:GetSurfaceAlpha(surfaceIndex) end
---Returns: a
function TextureCompositeControl:GetTextureCoords(surfaceIndex) end
---Returns: left, right, top, bottom
function TextureCompositeControl:GetTextureFileDimensions() end
---Returns: pixelWidth, pixelHeight
function TextureCompositeControl:GetTextureFileName() end
---Returns: filename
function TextureCompositeControl:IsPixelRoundingEnabled() end
---Returns: pixelRoundingEnabled
function TextureCompositeControl:IsSurfaceHidden(surfaceIndex) end
---Returns: hidden
function TextureCompositeControl:IsTextureLoaded() end
---Returns: loaded
function TextureCompositeControl:RemoveSurface(surfaceIndex) end
function TextureCompositeControl:SetBlendMode(TextureBlendMode) end
function TextureCompositeControl:SetColor(surfaceIndex, r, g, b, a) end
function TextureCompositeControl:SetDesaturation(desaturation) end
function TextureCompositeControl:SetInsets(surfaceIndex, left, right, top, bottom) end
function TextureCompositeControl:SetPixelRoundingEnabled(pixelRoundingEnabled) end
function TextureCompositeControl:SetSurfaceAlpha(surfaceIndex, a) end
function TextureCompositeControl:SetSurfaceHidden(surfaceIndex, hidden) end
function TextureCompositeControl:SetTexture(filename) end
function TextureCompositeControl:SetTextureCoords(surfaceIndex, left, right, top, bottom) end
function TextureCompositeControl:SetTextureReleaseOption(releaseOption) end

TextureControl = {}
function TextureControl:Get3DLocalDimensions() end
---Returns: width, height
function TextureControl:GetAddressMode() end
---Returns: TextureAddressMode addressMode
function TextureControl:GetBlendMode() end
---Returns: TextureBlendMode blendMode
function TextureControl:GetColor() end
---Returns: r, g, b, a
function TextureControl:GetDesaturation() end
---Returns: desaturation
function TextureControl:GetResizeToFitFile() end
---Returns: resizesToFitFile
function TextureControl:GetTextureCoords() end
---Returns: left, right, top, bottom
function TextureControl:GetTextureFileDimensions() end
---Returns: pixelWidth, pixelHeight
function TextureControl:GetTextureFileName() end
---Returns: filename
function TextureControl:GetVertexUV(VERTEX_POINTS) end
---Returns: u, v
function TextureControl:Is3DQuadFacingCamera() end
---Returns: isFacing
function TextureControl:IsPixelRoundingEnabled() end
---Returns: pixelRoundingEnabled
function TextureControl:IsTextureLoaded() end
---Returns: loaded
function TextureControl:Set3DLocalDimensions(width, height) end
function TextureControl:SetAddressMode(TextureAddressMode) end
function TextureControl:SetAutoAdjustWrappedCoords(enabled) end
function TextureControl:SetBlendMode(TextureBlendMode) end
function TextureControl:SetColor(r, g, b, a) end
function TextureControl:SetDesaturation(desaturation) end
function TextureControl:SetGradientColors( orientation, startR, startG, startB, startA, endR, endG, endB, endA) end
function TextureControl:SetPixelRoundingEnabled(pixelRoundingEnabled) end
function TextureControl:SetResizeToFitFile(resizesToFitFile) end
function TextureControl:SetTexture(filename) end
function TextureControl:SetTextureCoords(left, right, top, bottom) end
function TextureControl:SetTextureCoordsRotation(angleInRadians) end
function TextureControl:SetTextureReleaseOption(releaseOption) end
function TextureControl:SetTextureRotation(angleInRadians, normalizedRotationPointX, normalizedRotationPointY) end
function TextureControl:SetVertexColors(vertexPoints, red, green, blue, alpha) end
function TextureControl:SetVertexUV(VERTEX_POINTS, u, v) end

TooltipControl = {}
function TooltipControl:AddControl(control, cell, useLastRow) end
function TooltipControl:AddHeaderControl(control, headerRow, TooltipHeaderSide) end
function TooltipControl:AddHeaderLine(text, font, headerRow, TooltipHeaderSide, r, g, b) end
function TooltipControl:AddLine(text, font, r, g, b, lineAnchor,  modifyTextType,  textAlignment, setToFullSize) end
function TooltipControl:AddVerticalPadding(paddingY) end
function TooltipControl:AppendAvAObjective(queryType, keepId, objectiveId, isSpawnPosition) end
function TooltipControl:AppendMapPing(pingType, unitTag) end
function TooltipControl:AppendQuestCondition(questIndex, stepIndex, conditionIndex) end
function TooltipControl:AppendQuestEnding(questIndex) end
function TooltipControl:AppendUnitName(unitTag) end
function TooltipControl:ClearLines() end
function TooltipControl:GetOwner() end
---Returns: owner
function TooltipControl:HideComparativeTooltips() end
function TooltipControl:SetAbility(aAbilityIndex, aShowBase) end
function TooltipControl:SetAbilityId(abilityId) end
function TooltipControl:SetAchievement(aAchievementId) end
function TooltipControl:SetAchievementRewardItem(aAchievementId) end
function TooltipControl:SetAction(aSlotId) end
function TooltipControl:SetAsComparativeTooltip1() end
function TooltipControl:SetAsComparativeTooltip2() end
function TooltipControl:SetAttachedMailItem(id64, aAttachSlot) end
function TooltipControl:SetBagItem(bagIndex, slotIndex) end
function TooltipControl:SetBook(categoryIndex, collectionIndex, bookIndex) end
function TooltipControl:SetBuff(aBuffSlotId, unitTag) end
function TooltipControl:SetBuybackItem(entryIndex) end
function TooltipControl:SetChampionSkillAbility(disiplineIndex, skillIndex, numPendingPoints) end
function TooltipControl:SetCollectible(collectibleId, addNickname, showHint, showBlockReason) end
function TooltipControl:SetEmperorBonusAbility(campaignId, alliance) end
function TooltipControl:SetFont(fontStr) end
function TooltipControl:SetForceTooltipNotStolen(forceNotStolen) end
function TooltipControl:SetGuildSpecificItem(guildSpecificItemIndex) end
function TooltipControl:SetHeaderRowSpacing(spacing) end
function TooltipControl:SetHeaderVerticalOffset(verticalOffset) end
function TooltipControl:SetItemUsingEnchantment(itemBagIndex, itemSlotIndex, enchantmentBagIndex, enchantmentSlotIndex) end
function TooltipControl:SetKeepBonusAbility(bonusIndex) end
function TooltipControl:SetKeepUpgrade(keepId, BattlegroundQueryContextType, upgradeLine, level, index) end
function TooltipControl:SetLastCraftingResultItem(resultIndex) end
function TooltipControl:SetLink(aLink) end
function TooltipControl:SetLootItem(lootId) end
function TooltipControl:SetMarketProduct(marketProductId) end
function TooltipControl:SetMinHeaderRowHeight(minRowHeight) end
function TooltipControl:SetMinHeaderRows(minRows) end
function TooltipControl:SetOwner(owner, position, offsetX, offsetY, relativePoint) end
function TooltipControl:SetPendingAlchemyItem(solventBagId, solventSlotIndex, reagent1BagId, reagent1SlotIndex, reagent2BagId, reagent2SlotIndex, reagent3BagId, reagent3SlotIndex) end
function TooltipControl:SetPendingEnchantingItem(potencyRuneBagId, potencyRuneSlotIndex, essenceRuneBagId, essenceRuneSlotIndex, aspectRuneBagId, aspectRuneSlotIndex) end
function TooltipControl:SetPendingSmithingItem(patternIndex, materialIndex, materialQuantity, styleIndex, traitIndex) end
function TooltipControl:SetProgressionAbility(aProgressionIndex, aMorph, aRank) end
function TooltipControl:SetProvisionerIngredientItem(recipeListIndex, recipeIndex, ingredientIndex) end
function TooltipControl:SetProvisionerResultItem(recipeListIndex, recipeIndex) end
function TooltipControl:SetQuestItem(questIndex, stepIndex, conditionIndex) end
function TooltipControl:SetQuestReward(aPerkIndex) end
function TooltipControl:SetQuestTool(questIndex, toolIndex) end
function TooltipControl:SetScrollBonusAbility(alliance, artifactType, bonusIndex) end
function TooltipControl:SetSkillAbility(skillType, skillIndex, abilityIndex) end
function TooltipControl:SetSkillLine(skillType, skillIndex) end
function TooltipControl:SetSkillUpgradeAbility(skillType, skillIndex, abilityIndex) end
function TooltipControl:SetSmithingImprovementItem(craftingSkillType, improvementItemIndex) end
function TooltipControl:SetSmithingImprovementResult(itemToImproveBagId, itemToImproveSlotIndex, craftingSkillType) end
function TooltipControl:SetSmithingMaterialItem(patternIndex, materialIndex) end
function TooltipControl:SetSmithingStyleItem(styleItemIndex) end
function TooltipControl:SetSmithingTraitItem(traitItemIndex) end
function TooltipControl:SetStoreItem(entryIndex) end
function TooltipControl:SetTradeItem(aWho, aTradeIndex) end
function TooltipControl:SetTradingHouseItem(tradingHouseIndex) end
function TooltipControl:SetTradingHouseListing(tradingHouseIndex) end
function TooltipControl:SetWornItem(equipSlot) end
function TooltipControl:ShowComparativeTooltips() end

TopLevelWindow = {}
function TopLevelWindow:AllowBringToTop() end
---Returns: allow
function TopLevelWindow:BringWindowToTop() end
function TopLevelWindow:SetAllowBringToTop(allow) end
function TopLevelWindow:SetDrawWhenGuiHidden(drawWhenHidden) end
function TopLevelWindow:SetTopmost(isTopmost) end

WindowManager = {}
function WindowManager:ApplyTemplateToControl(control, virtualName) end
function WindowManager:CompareControlVisualOrder(controlA, controlB) end
---Returns: order
function WindowManager:CreateControl(arg1, parent, type) end
---Returns: apRet
function WindowManager:CreateControlFromVirtual(controlName, parent, virtualName) end
---Returns: apRet
function WindowManager:CreateTopLevelWindow(arg1) end
---Returns: apRet
function WindowManager:GetControlByName(name, suffix) end
---Returns: ret
function WindowManager:GetFocusControl() end
---Returns: focusControl
function WindowManager:GetMouseOverControl() end
---Returns: mouseOverControl
function WindowManager:IsHandlingHardwareEvent() end
---Returns: isHandlingHardwareEvent
function WindowManager:IsMouseOverWorld() end
---Returns: isMouseOverWorld
function WindowManager:IsSecureRenderModeEnabled() end
---Returns: secureRenderModeEnabled
function WindowManager:SetFocusByName(name) end
function WindowManager:SetMouseCursor(cursorType) end
function WindowManager:SetMouseFocusByName(name) end
