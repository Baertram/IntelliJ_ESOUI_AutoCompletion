﻿function GetCVar(CVarName) end
--Returns: *string value

function SetCVar(CVarName, value) end

function GetSetting(system, settingId) end
--Returns: *string value

function GetSettingBool(system, settingId) end
--Returns: *bool value

function SetSetting(system, settingId, value, setOptions) end

function ApplySettings() end

function ResetSettingToDefault(system, settingId) end

function ResetToDefaultSettings(system) end

function RefreshSettings() end

function GetString(stringVariablePrefix, contextId) end
--Returns: *string stringValue

function IsShiftKeyDown() end
--Returns: *bool isShiftDown

function IsControlKeyDown() end
--Returns: *bool isCtrlDown

function IsAltKeyDown() end
--Returns: *bool isAltDown

function IsCommandKeyDown() end
--Returns: *bool isCommandDown

function IsCapsLockOn() end
--Returns: *bool isCapsLockOn

function GetKeyName(keyCode) end
--Returns: *string keyName

function GetKeyboardLayout() end
--Returns: *string keyboardLayout

function PlaySound(soundName) end

function SetGuiHidden(guiName, hidden) end

function GetGuiHidden(guiName) end
--Returns: *bool hidden

function ToggleFullScreen() end

function IsMouseWithinClientArea() end
--Returns: *bool insideClient

function IsUserAdjustingClientWindow() end
--Returns: *bool isAdjusting

function GetInterfaceColor(interfaceColorType, fieldValue) end
--Returns: *number red, green, blue, alpha

function GetErrorString(errorStringId) end
--Returns: *string stringValue

function GetAllianceName(alliance) end
--Returns: *string name

function GetNumClasses() end
--Returns: *integer classCount

function GetClassInfo(index) end
--Returns: *integer defId, lore, normalIconKeyboard, pressedIconKeyboard, mouseoverIconKeyboard, isSelectable, ingameIconKeyboard, ingameIconGamepad, normalIconGamepad, pressedIconGamepad

function GetClassName(gender, classId) end
--Returns: *string className

function GetRaceName(gender, raceId) end
--Returns: *string raceName

function GetLocationName(worldId) end
--Returns: *string worldName

function GetGenderFromNameDescriptor(nameDescriptor) end
--Returns: *[Gender|#Gender] gender

function PlainStringFind(string, searchFor) end
--Returns: *bool found, startIndex, endIndex

function SplitString(delims, stringToSplit) end
--Returns: *string strings

function LocaleAwareToUpper(stringToUppercase) end
--Returns: *string upperCasedString

function LocaleAwareToLower(stringToLowercase) end
--Returns: *string lowerCasedString

function GetDisplayModes() end
--Returns: *integer width, height

function IsMinSpecMachine() end
--Returns: *bool minspec

function IsPrivateFunction(functionName) end
--Returns: *bool isPrivate

function IsProtectedFunction(functionName) end
--Returns: *bool isProtected

function GetAPIVersion() end
--Returns: *integer version

function Id64ToString(id) end
--Returns: *string stringDesc

function HideMouse(onlyConsiderWhileMoving) end

function ShowMouse(onlyConsiderWhileMoving) end

function IsInternalBuild() end
--Returns: *bool isInternalBuild

function SaveLoadDialogResult(errorType, result) end

function GetSecondsSinceMidnight() end
--Returns: *integer secondsSinceMidnight

function GetFrameTimeSeconds() end
--Returns: *number frameTimeInSeconds

function GetFrameDeltaTimeSeconds() end
--Returns: *number frameDeltaTimeInSeconds

function GetFrameTimeMilliseconds() end
--Returns: *integer frameTimeInMilliseconds

function GetFrameDeltaTimeMilliseconds() end
--Returns: *integer frameDeltaTimeInMilliseconds

function GetDateStringFromTimestamp(timestamp) end
--Returns: *string dateString

function GetGameTimeMilliseconds() end
--Returns: *integer gameTimeInMilliseconds

function GetFramerate() end
--Returns: *number currentFramerate

function GetTimeString() end
--Returns: *string currentTimeString

function GetDate() end
--Returns: *integer currentTime

function GetTimeStamp() end
--Returns: *id64 timestamp

function GetDiffBetweenTimeStamps(laterTime, earlierTime) end
--Returns: *number difference

function GetFormattedTime() end
--Returns: *integer formattedTime

function FormatTimeSeconds(timeValueInSeconds, formatType, precisionType, direction) end
--Returns: *string formattedTimeString, nextUpdateTimeInSec

function FormatTimeMilliseconds(timeValueInMilliseconds, formatType, precisionType, direction) end
--Returns: *string formattedTimeString, nextUpdateTimeInMilliseconds

function SetGameCameraUIMode(active) end

function IsGameCameraUIModeActive() end
--Returns: *bool active

function LockCameraRotation(locked) end

function SetCameraOptionsPreviewModeEnabled(enabled, option) end

function GetGuildId(index) end
--Returns: *integer guildId

function GetNumGuildPermissions() end
--Returns: *integer numPermissions

function GetNumGuildHistoryCategories() end
--Returns: *integer numCategories

function GetNumGuildMembersRequiredForPrivilege(privilege) end
--Returns: *integer numGuildMembers

function GetAvARankName(gender, rank) end
--Returns: *string rankName

function GetAvARankIcon(rank) end
--Returns: *textureName rankIcon

function CalculateCubicBezierEase(progress, x1, y1, x2, y2) end
--Returns: *number result

function GetGamepadIconPathForKeyCode(key) end
--Returns: *string:nilable gamepadIcon, width, height

function GetMouseIconPathForKeyCode(key) end
--Returns: *string:nilable mouseIcon, width, height

function FormatIntegerWithDigitGrouping(number, delimiter, digitGroupSize) end
--Returns: *string formattedNumber

function DoesCurrentLanguageRequireIME() end
--Returns: *bool requiresIME

function IsVirtualKeyboardOnscreen() end
--Returns: *bool vkeyboardShowing

function HashString(text) end
--Returns: *integer hashValue

function Set3DRenderSpaceToCurrentCamera(controlName) end

function ComputeDepthAtWhichWorldWidthRendersAsUIWidth(worldWidth, UIWidth) end
--Returns: *number depth

function GetWorldDimensionsOfViewFrustumAtDepth(depth) end
--Returns: *number frustumWidth, frustumHeight

function GetESOVersionString() end
--Returns: *string versionString

function Is64BitClient() end
--Returns: *bool is64Bit

function DoesSystemSupportConsoleEnhancedRenderQuality(consoleEnhancedRenderQuality) end
--Returns: *bool hasSupport

function GetEULADetails(eulaType) end
--Returns: *string message, agreeText, disagreeText, hasAgreed, dialogText

function HasAgreedToEULA(eulaType) end
--Returns: *bool hasAgreed

function AgreeToEULA(eulaType) end

function HasViewedEULA(eulaType) end
--Returns: *bool hasViewed

function MarkEULAAsViewed(eulaType) end

function OpenURLByType(urlType) end

function GetURLTextByType(urlType) end
--Returns: *string urlText

function ShouldOpenURLTypeInOverlay(urlType) end
--Returns: *bool urlOpensInOverlay

function SetCurrentVideoPlaybackVolume(volume, lerpTime) end

function GetFrameDeltaNormalizedForTargetFramerate(targetFramesPerSecond) end
--Returns: *number frameDeltaNormalizedForTargetFramerate

function GetDisplayName() end
--Returns: *string displayName

function DecorateDisplayName(displayName) end
--Returns: *string decoratedDisplayName

function IsDecoratedDisplayName(displayName) end
--Returns: *bool isDecorated

function UndecorateDisplayName(displayName) end
--Returns: *string undecoratedDisplayName

function GetNumFriends() end
--Returns: *integer numFriends

function GetFriendInfo(friendIndex) end
--Returns: *string displayName, note, playerStatus, secsSinceLogoff

function GetFriendCharacterInfo(friendIndex) end
--Returns: *bool hasCharacter, characterName, zoneName, classType, alliance, level, championRank, zoneId

function GetNumIgnored() end
--Returns: *integer numIgnored

function GetIgnoredInfo(index) end
--Returns: *string displayName, note

function IsIgnored(characterName) end
--Returns: *bool isIgnored

function RequestFriend(charOrDisplayName, message) end

function RemoveFriend(displayName) end

function SetFriendNote(friendIndex, note) end

function AddIgnore(charOrDisplayName) end

function RemoveIgnore(displayName) end

function SetIgnoreNote(ignoreIndex, note) end

function IsFriend(charOrDisplayName) end
--Returns: *bool isFriend

function GetNumIncomingFriendRequests() end
--Returns: *integer numRequests

function GetIncomingFriendRequestInfo(index) end
--Returns: *string displayName, secsSinceRequest, message

function GetNumOutgoingFriendRequests() end
--Returns: *integer numRequests

function GetOutgoingFriendRequestInfo(index) end
--Returns: *string displayName, secsSinceRequest, note

function AcceptFriendRequest(displayName) end

function RejectFriendRequest(displayName) end

function CancelFriendRequest(index) end

function GetNumGuilds() end
--Returns: *integer numGuilds

function GetGuildName(guildId) end
--Returns: *string name

function GetGuildDescription(guildId) end
--Returns: *string description

function GetGuildMotD(guildId) end
--Returns: *string motd

function GetGuildFoundedDate(guildId) end
--Returns: *string foundedDate

function GetGuildAlliance(guildId) end
--Returns: *integer alliance

function GetNumGuildMembers(guildId) end
--Returns: *integer numGuildMembers

function GetGuildInfo(guildId) end
--Returns: *integer numMembers, numOnline, leaderName

function GetGuildMemberInfo(guildId, memberIndex) end
--Returns: *string name, note, rankIndex, playerStatus, secsSinceLogoff

function GetGuildMemberCharacterInfo(guildId, memberIndex) end
--Returns: *bool hasCharacter, characterName, zoneName, classType, alliance, level, championRank, zoneId

function GetGuildMemberIndexFromDisplayName(guildId, displayName) end
--Returns: *luaindex:nilable memberIndex

function GetPlayerGuildMemberIndex(guildId) end
--Returns: *luaindex memberIndex

function GuildInvite(guildId, displayName) end

function IsValidGuildName(guildName) end
--Returns: *integer violationCode

function GuildCreate(guildName, guildAlliance) end

function GuildRemove(guildId, displayName) end

function GuildLeave(guildId) end

function GuildPromote(guildId, displayName) end

function GuildDemote(guildId, displayName) end

function ShouldDisplayGuildMemberRemoveAlert(characterName) end
--Returns: *bool shouldDisplay

function ShouldDisplaySelfKickedFromGuildAlert(guildId) end
--Returns: *bool shouldDisplay

function SetGuildDescription(guildId, description) end

function SetGuildMotD(guildId, motd) end

function DoesGuildRankHavePermission(guildId, rankIndex, permission) end
--Returns: *bool hasPermission

function DoesPlayerHaveGuildPermission(guildId, permission) end
--Returns: *bool hasPermission

function CanEditGuildRankPermission(rankId, permission) end
--Returns: *bool hasPermission

function DoesGuildHavePrivilege(guildId, privilege) end
--Returns: *bool hasPrivilege

function GetNumGuildRanks(guildId) end
--Returns: *integer numRanks

function GetGuildRankIconIndex(guildId, rankIndex) end
--Returns: *luaindex iconIndex

function GetNumGuildRankIcons() end
--Returns: *integer numGuildRankIcons

function GetGuildRankSmallIcon(iconIndex) end
--Returns: *textureName icon

function GetGuildRankLargeIcon(iconIndex) end
--Returns: *textureName icon

function GetGuildRankListHighlightIcon(iconIndex) end
--Returns: *textureName icon

function GetGuildRankListUpIcon(iconIndex) end
--Returns: *textureName icon

function GetGuildRankListDownIcon(iconIndex) end
--Returns: *textureName icon

function GetGuildRankId(guildId, rankIndex) end
--Returns: *integer rankId

function IsGuildRankGuildMaster(guildId, rankIndex) end
--Returns: *bool isGuildMaster

function InitializePendingGuildRanks(guildId) end

function AddPendingGuildRank(rankId, name, permissions, iconIndex) end

function SavePendingGuildRanks() end
--Returns: *bool success

function ComposeGuildRankPermissions(permissions, permission, enabled) end
--Returns: *integer newPermissions

function RequestOfflineGuildMembers(guildId) end

function DoesGuildHistoryCategoryHaveMoreEvents(guildId, category) end
--Returns: *bool hasMoreEvents

function RequestGuildHistoryCategoryNewest(guildId, category) end
--Returns: *bool requested

function RequestGuildHistoryCategoryOlder(guildId, category) end
--Returns: *bool requested

function GetNumGuildEvents(guildId, category) end
--Returns: *integer numEvents

function GetGuildEventInfo(guildId, category, eventIndex) end
--Returns: *integer eventType, secsSinceEvent, param1, param2, param3, param4, param5, param6

function GetGuildEventId(guildId, category, eventIndex) end
--Returns: *id64 guildEventId

function SetGuildMemberNote(guildId, memberIndex, note) end

function GetGuildRankCustomName(guildId, rankIndex) end
--Returns: *string rankName

function GetNumGuildInvites() end
--Returns: *integer numGuildInvites

function GetGuildInviteInfo(index) end
--Returns: *integer guildId, guildName, guildAlliance, inviterDisplayName, note

function AcceptGuildInvite(guildId) end

function RejectGuildInvite(guildId) end

function JumpToGuildMember(name) end

function GetGuildClaimedKeep(guildLuaId) end
--Returns: *integer claimedKeepId, claimedKeepCampaignId

function DoesGuildHaveClaimedKeep(guildLuaId) end
--Returns: *bool hasClaimedKeep

function CheckGuildKeepClaim(guildLuaId, keepId) end
--Returns: *integer result

function CheckGuildKeepRelease(guildLuaId) end
--Returns: *integer result

function ReleaseKeepForGuild(guildLuaId) end

function ClaimInteractionKeepForGuild(guildLuaId) end

function ReleaseInteractionKeepForGuild() end

function GetGuildOwnedKioskInfo(guildId) end
--Returns: *string:nilable ownedKioskName

function GetNumGuildSpecificItems() end
--Returns: *integer numItems

function GetGuildSpecificItemInfo(index) end
--Returns: *textureName icon, itemName, quality, stackCount, requiredLevel, requiredChampionRank, purchasePrice, currencyType

function BuyGuildSpecificItem(slotIndex) end

function GetGuildSpecificItemLink(index, linkStyle) end
--Returns: *string link

function SetGamepadVibration(durationMs, firstMotor, secondMotor, thirdMotor, fourthMotor, debugSourceInfo) end

function GetGamepadLeftStickX(includeDeadzone) end
--Returns: *number x

function GetGamepadLeftStickY(includeDeadzone) end
--Returns: *number y

function GetGamepadLeftStickDeltaX(includeDeadzone) end
--Returns: *number deltaX

function GetGamepadLeftStickDeltaY(includeDeadzone) end
--Returns: *number deltaY

function GetGamepadRightStickX(includeDeadzone) end
--Returns: *number x

function GetGamepadRightStickY(includeDeadzone) end
--Returns: *number y

function GetGamepadRightStickDeltaX(includeDeadzone) end
--Returns: *number deltaX

function GetGamepadRightStickDeltaY(includeDeadzone) end
--Returns: *number deltaY

function GetGamepadLeftTriggerMagnitude() end
--Returns: *number magnitude

function GetGamepadRightTriggerMagnitude() end
--Returns: *number magnitude

function SetGamepadLeftStickConsumedByUI(consumed) end

function SetGamepadRightStickConsumedByUI(consumed) end

function GetGamepadTouchpadX() end
--Returns: *number gamepadTouchpadX

function GetGamepadTouchpadY() end
--Returns: *number gamepadTouchpadY

function IsGamepadTouchpadActive() end
--Returns: *bool gamepadTouchpadActive

function GetGamepadType() end
--Returns: *[GamepadType|#GamepadType] gamepadType

function IsConsoleUI() end
--Returns: *bool isConsoleUI

function IsInGamepadPreferredMode() end
--Returns: *bool inGamepadPreferredMode

function IsKeyCodeGamepadKey(key) end
--Returns: *bool isGamepadKey

function IsKeyCodeMouseKey(key) end
--Returns: *bool isMouseKey

function IsKeyCodeKeyboardKey(key) end
--Returns: *bool isKeyboardKey

function IsKeyCodeChordKey(key) end
--Returns: *bool isKeyChord

function IsKeyCodeHoldKey(key) end
--Returns: *bool isKeyHold

function IsKeyDown(key) end
--Returns: *bool isKeyDown

function ConvertKeyPressToHold(key) end
--Returns: *[KeyCode|#KeyCode] holdKey

function ConvertHoldKeyPressToNonHold(holdKey) end
--Returns: *[KeyCode|#KeyCode] key

function GetKeyChordsFromSingleKey(key) end
--Returns: *[KeyCode|#KeyCode] keyChord

function GetUIPlatform() end
--Returns: *[UIPlatform|#UIPlatform] platform

function SetOverscanOffsets(offsetX, offsetY, offsetWidth, offsetHeight) end

function GetOverscanOffsets() end
--Returns: *integer offsetX, offsetY, offsetWidth, offsetHeight

function IsGUIResizing() end
--Returns: *bool isGUIResizing

function UpdatePlayerPresenceInformation() end

function UpdatePlayerPresenceName() end

function ChangeRemoteSceneVisibility(sceneName, sceneChangeType, sceneChangeOrigin) end

function ShowRemoteBaseScene() end

function IsValidName(name) end
--Returns: *bool isValid

function GetDigitGroupingSize() end
--Returns: *integer digitGroupingSize

function AbbreviateNumber(number, precision, useUppercaseSuffix) end
--Returns: *number abbreviatedValue, suffix

function IsESOPlusSubscriber() end
--Returns: *bool isESOPlusSubscriber

function GetTrialInfo() end
--Returns: *integer accountTypeId, title, description, version

function GetPlayerCrowns() end
--Returns: *integer currentCrowns

function GetPlayerCrownGems() end
--Returns: *integer currentCrownGems

function GetPlayerMarketCurrency(type) end
--Returns: *integer currencyAmount


function ComputeStringDistance(source, target, maxDistance) end
--Returns: *integer distance

function ExecuteChatCommand(text) end

function ToggleShowIngameGui() end

function ReloadUI(guiName) end

function SendPlayerStuck() end

function GetPlayerStatus() end
--Returns: *integer status

function SelectPlayerStatus(status) end

function GetNumPlayerStatuses() end
--Returns: *integer numStatuses

function GetCriticalStrikeChance(statValue) end
--Returns: *number chance

function TakeScreenshot() end

function SetFullscreenEffect(effectType, param1, param2, immediateUpdate) end

function DoesGameHaveFocus() end
--Returns: *bool hasFocus

function IsPlayerActivated() end
--Returns: *bool activated

function GetSecondsPlayed() end
--Returns: *integer secondsPlayed

function GetLatency() end
--Returns: *integer latencyMS

function PlaceInTradeWindow(tradeIndex) end

function PlaceInUnitFrame(target) end

function ConvertMouseButtonToKeyCode(mouseButton) end
--Returns: *[KeyCode|#KeyCode] key

function ResetAllBindsToDefault() end

function ResetKeyboardBindsToDefault() end

function ResetGamepadBindsToDefault() end

function DoesUnitExist(unitTag) end
--Returns: *bool exists

function GetUnitName(unitTag) end
--Returns: *string name

function GetRawUnitName(unitTag) end
--Returns: *string rawName

function GetUnitDisplayName(unitTag) end
--Returns: *string displayName

function GetUnitGender(unitTag) end
--Returns: *[Gender|#Gender] gender

function GetUnitNameHighlightedByReticle() end
--Returns: *string name

function GetUnitClass(unitTag) end
--Returns: *string className

function GetUnitClassId(unitTag) end
--Returns: *integer classId

function GetUnitLevel(unitTag) end
--Returns: *integer level

function GetUnitChampionPoints(unitTag) end
--Returns: *integer championPoints

function GetUnitEffectiveChampionPoints(unitTag) end
--Returns: *integer championPoints

function CanUnitGainChampionPoints(unitTag) end
--Returns: *bool canGainChampionPoints

function GetUnitEffectiveLevel(unitTag) end
--Returns: *integer level

function GetUnitZone(unitTag) end
--Returns: *string zoneName

function GetUnitZoneIndex(unitTag) end
--Returns: *luaindex:nilable zoneIndex

function GetUnitXP(unitTag) end
--Returns: *integer exp

function GetUnitXPMax(unitTag) end
--Returns: *integer maxExp

function IsUnitChampion(unitTag) end
--Returns: *bool isChampion

function IsUnitUsingVeteranDifficulty(unitTag) end
--Returns: *bool isVeteranDifficulty

function GetPlayerChampionXP() end
--Returns: *integer championExp

function GetPlayerChampionPointsEarned() end
--Returns: *integer points

function IsUnitBattleLeveled(unitTag) end
--Returns: *bool isBattleLeveled

function IsUnitChampionBattleLeveled(unitTag) end
--Returns: *bool isChampBattleLeveled

function GetUnitBattleLevel(unitTag) end
--Returns: *integer battleLevel

function GetUnitChampionBattleLevel(unitTag) end
--Returns: *integer champBattleLevel

function GetUnitDrownTime(unitTag) end
--Returns: *number startTime, endTime

function GetUnitEquipmentBonusRatingRelativeToLevel(unitTag, rawEquipmentBonusRating) end
--Returns: *number relativeEquipmentBonusRating

function IsUnitInGroupSupportRange(unitTag) end
--Returns: *bool result

function GetUnitType(unitTag) end
--Returns: *integer type

function CanUnitTrade(unitTag) end
--Returns: *bool canTrade

function AreUnitsEqual(unitTag, secondUnitTag) end
--Returns: *bool areEqual

function IsUnitGrouped(unitTag) end
--Returns: *bool isGrouped

function IsUnitGroupLeader(unitTag) end
--Returns: *bool isGroupLeader

function IsUnitSoloOrGroupLeader(unitTag) end
--Returns: *bool isSoloOrGroupLeader

function GetGroupLeaderUnitTag() end
--Returns: *string leaderUnitTag

function IsUnitFriend(unitTag) end
--Returns: *bool isOnFriendList

function IsUnitIgnored(unitTag) end
--Returns: *bool isIgnored

function IsUnitPlayer(unitTag) end
--Returns: *bool isPlayer

function IsUnitPvPFlagged(unitTag) end
--Returns: *bool isPvPFlagged

function IsUnitAttackable(unitTag) end
--Returns: *bool attackable

function IsUnitJusticeGuard(unitTag) end
--Returns: *bool isJusticeGuard

function IsUnitInvulnerableGuard(unitTag) end
--Returns: *bool isInvulnerableGuard

function GetUnitAlliance(unitTag) end
--Returns: *integer alliance

function AreUnitsCurrentlyAllied(unitTag1, unitTag2) end
--Returns: *bool allied

function GetUnitRace(unitTag) end
--Returns: *string race

function GetUnitRaceId(unitTag) end
--Returns: *integer raceId

function IsUnitFriendlyFollower(unitTag) end
--Returns: *bool isFollowing

function GetUnitReaction(unitTag) end
--Returns: *[UnitReactionType|#UnitReactionType] unitReaction

function GetUnitAvARankPoints(unitTag) end
--Returns: *integer AvARankPoints

function GetUnitAvARank(unitTag) end
--Returns: *integer rank, subRank

function GetLargeAvARankIcon(rank) end
--Returns: *textureName largeRankIcon

function GetAvARankProgress(currentRankPoints) end
--Returns: *integer subRankStartsAt, nextSubRankAt, rankStartsAt, nextRankAt

function GetNumPointsNeededForAvARank(rank) end
--Returns: *integer numPointsRequired

function GetUnitReactionColor(unitTag) end
--Returns: *number red, green, blue

function IsUnitInCombat(unitTag) end
--Returns: *bool isInCombat

function IsUnitDead(unitTag) end
--Returns: *bool isDead

function IsUnitReincarnating(unitTag) end
--Returns: *bool isReincarnating

function IsUnitDeadOrReincarnating(unitTag) end
--Returns: *bool isDead

function IsUnitSwimming(unitTag) end
--Returns: *bool isSwimming

function IsUnitResurrectableByPlayer(unitTag) end
--Returns: *bool isResurrectable

function IsUnitBeingResurrected(unitTag) end
--Returns: *bool isBeingResurrected

function DoesUnitHaveResurrectPending(unitTag) end
--Returns: *bool hasResurrectPending

function GetUnitStealthState(unitTag) end
--Returns: *integer stealthState

function GetUnitDisguiseState(unitTag) end
--Returns: *integer disguiseState

function GetUnitHidingEndTime(unitTag) end
--Returns: *number endTime

function IsUnitOnline(unitTag) end
--Returns: *bool isOnline

function IsUnitInspectableSiege(unitTag) end
--Returns: *bool isInspectableSiege

function IsUnitInDungeon(unitTag) end
--Returns: *bool isInDungeon

function GetUnitCaption(unitTag) end
--Returns: *string caption

function GetUnitSilhouetteTexture(unitTag) end
--Returns: *string icon

function GetUnitPowerInfo(unitTag, poolIndex) end
--Returns: *integer:nilable type, current, max, effectiveMax

function GetUnitPower(unitTag, powerType) end
--Returns: *integer current, max, effectiveMax

function GetCurrentCharacterId() end
--Returns: *string id

function GetPlayerStat(derivedStat, statBonusOption) end
--Returns: *integer value

function GetAllUnitAttributeVisualizerEffectInfo(unitTag) end
--Returns: *[UnitAttributeVisual|#UnitAttributeVisual] unitAttributeVisual, statType, attributeType, powerType, value, maxValue

function GetUnitAttributeVisualizerEffectInfo(unitTag, unitAttributeVisual, statType, attributeType, powerType) end
--Returns: *number:nilable value, maxValue

function GetUnitDifficulty(unitTag) end
--Returns: *[UIMonsterDifficulty|#UIMonsterDifficulty] difficult

function GetUnitTitle(unitTag) end
--Returns: *string title

function CancelCast() end
--Returns: *bool cancelled

function IsTargetSameAsLastValidTarget() end
--Returns: *bool same

function TogglePlayerWield() end

function IsPlayerMoving() end
--Returns: *bool moving

function IsPlayerGroundTargeting() end
--Returns: *bool isGroundTargeting

function IsPlayerEmoteOverridden(emoteId) end
--Returns: *bool isOverridden

function GetGroundTargetingError() end
--Returns: *integer:nilable error

function StartSoulGemResurrection() end

function CancelSoulGemResurrection() end

function GetPlayerCameraHeading() end
--Returns: *number heading

function GetUnitBuffInfo(unitTag, buffIndex) end
--Returns: *string buffName, timeStarted, timeEnding, buffSlot, stackCount, iconFilename, buffType, effectType, abilityType, statusEffectType, abilityId, canClickOff

function GetNumBuffs(unitTag) end
--Returns: *integer numBuffs

function GroupInvite(unitTag) end

function GroupKick(unitTag) end

function GroupPromote(unitTag) end

function GetGroupMemberRoles(unitTag) end
--Returns: *bool isDps, isHealer, isTank

function CancelBuff(buffIndex) end

function ActivateSynergy() end

function GetWeaponSwapUnlockedLevel() end
--Returns: *integer level

function GetSlotType(slotIndex) end
--Returns: *integer type

function GetSlotAbilityCost(slotIndex) end
--Returns: *integer abilityCost, mechanicType

function GetSlotBoundId(slotIndex) end
--Returns: *integer id

function GetSlotTexture(slotIndex) end
--Returns: *string texture, weapontexture, activationAnimation

function GetSlotName(slotIndex) end
--Returns: *string name

function GetSlotItemQuality(slotIndex) end
--Returns: *integer:nilable quality

function GetSlotCooldownInfo(slotIndex) end
--Returns: *integer remain, duration, global, globalSlotType

function IsSlotToggled(slotIndex) end
--Returns: *bool toggledOn

function IsSlotUsed(slotIndex) end
--Returns: *bool used

function IsSlotUsable(slotIndex) end
--Returns: *bool useable

function HasCostFailure(slotIndex) end
--Returns: *bool status

function HasRequirementFailure(slotIndex) end
--Returns: *bool status

function HasWeaponSlotFailure(slotIndex) end
--Returns: *bool status

function HasTargetFailure(slotIndex) end
--Returns: *bool status

function HasRangeFailure(slotIndex) end
--Returns: *bool status

function HasStatusEffectFailure(slotIndex) end
--Returns: *bool status

function HasFallingFailure(slotIndex) end
--Returns: *bool status

function HasSwimmingFailure(slotIndex) end
--Returns: *bool status

function HasMountedFailure(slotIndex) end
--Returns: *bool status

function HasReincarnatingFailure(slotIndex) end
--Returns: *bool status

function HasActivationHighlight(slotIndex) end
--Returns: *bool status

function OnSlotDownAndUp(slotIndex) end

function OnSlotDown(slotIndex) end

function OnSlotUp(slotIndex) end

function OnSpecialMoveKeyPressed(slotIndex) end

function OnSpecialMoveKeyDown(moveIndex) end

function OnSpecialMoveKeyUp(moveIndex) end

function GetSlotItemCount(slotIndex) end
--Returns: *integer:nilable count

function GetSlotItemSound(slotIndex) end
--Returns: *integer itemSoundCategory

function IsSlotItemConsumable(slotIndex) end
--Returns: *bool consumable

function DoesInventoryContainEmptySoulGem() end
--Returns: *bool hasEmptyGem

function IsSlotSoulTrap(slotIndex) end
--Returns: *bool isSoulTrap

function SelectSlotSkillAbility(skillType, skillLineIndex, abilityIndex, slotIndex) end

function SlotSkillAbilityInSlot(skillType, skillLineIndex, abilityIndex, slotIndex) end

function GetFirstFreeValidSlotForSkillAbility(skillType, skillLineIndex, abilityIndex) end
--Returns: *luaindex:nilable freeSlot

function GetAssignedSlotFromSkillAbility(skillType, skillLineIndex, abilityIndex) end
--Returns: *luaindex:nilable slotIndex

function GetNumAbilities() end
--Returns: *integer num

function GetAbilityInfoByIndex(abilityIndex) end
--Returns: *string name, texture, rank, actionSlotType, passive, showInSpellbook

function IsValidAbilityForSlot(abilityIndex, slotIndex) end
--Returns: *bool valid

function IsValidItemForSlot(bagId, bagSlotId, actionSlotIndex) end
--Returns: *bool valid

function IsValidItemForSlotByItemInfo(itemId, itemQualityDefId, itemRequiredLevel, itemInstanceData, actionSlotIndex) end
--Returns: *bool valid

function IsValidCollectibleForSlot(collectibleId, actionSlotIndex) end
--Returns: *bool valid

function CompleteQuest() end

function AbandonQuest(journalQuestIndex) end

function GetIsQuestSharable(journalQuestIndex) end
--Returns: *bool isSharable

function ShareQuest(journalQuestIndex) end

function GetJournalQuestStepInfo(journalQuestIndex, stepIndex) end
--Returns: *string stepText, visibility, stepType, trackerOverrideText, numConditions

function GetJournalQuestLocationInfo(journalQuestIndex) end
--Returns: *string zoneName, objectiveName, zoneIndex, poiIndex

function GetJournalQuestEnding(journalQuestIndex) end
--Returns: *string goal, dialog, confirmComplete, declineComplete, backgroundText, journalStepText

function GetJournalQuestNumConditions(journalQuestIndex, stepIndex) end
--Returns: *integer conditionCount

function RequestJournalQuestConditionAssistance(journalQuestIndex, stepIndex, conditionIndex, assisted) end
--Returns: *integer:nilable taskId

function GetNearestQuestCondition(considerType) end
--Returns: *bool foundValidCondition, journalQuestIndex, stepIndex, conditionIndex

function GetJournalQuestTimerInfo(journalQuestIndex) end
--Returns: *number timerStart, timerEnd, isVisible, isPaused

function GetJournalQuestTimerCaption(journalQuestIndex) end
--Returns: *string caption

function GetJournalQuestNumSteps(journalQuestIndex) end
--Returns: *integer numSteps

function GetQuestToolCount(journalQuestIndex) end
--Returns: *integer toolCount

function SendChatMessage(message, channelId, target) end

function MoveForwardStart() end

function MoveForwardStop() end

function MoveBackwardStart() end

function MoveBackwardStop() end

function StopAllMovement() end

function ToggleWalk() end

function TurnLeftStart() end

function TurnLeftStop() end

function TurnRightStart() end

function TurnRightStop() end

function StrafeLeftStart() end

function StrafeLeftStop() end

function StrafeRightStart() end

function StrafeRightStop() end

function JumpAscendStart() end

function AscendStop() end

function DescendStart() end

function DescendStop() end

function LeftMouseDownInWorld() end

function LeftMouseUpInWorld() end

function LeftAndRightMouseDownInWorld() end

function LeftAndRightMouseUpInWorld() end

function RightMouseDownInWorld() end

function RightMouseUpInWorld() end

function CameraZoomIn() end

function CameraZoomOut() end

function ToggleAutoRun() end

function RollDodgeStart() end

function RollDodgeStop() end

function PrepareAttack() end

function PerformAttack() end

function StartBlock() end

function StopBlock() end

function ToggleGameCameraPadlockTarget() end

function PerformInterrupt() end

function StartCommandPet() end

function StopCommandPet() end

function GameCameraGamepadZoomDown() end

function GameCameraGamepadZoomUp() end

function OnWeaponSwap() end

function OnWeaponSwapToSet1() end

function OnWeaponSwapToSet2() end

function EndInteraction(interactionType) end

function GetChatterGreeting() end
--Returns: *string optionString

function GetChatterData() end
--Returns: *string text, numOptions, atGreeting

function GetMaxBags() end
--Returns: *integer maxBags

function GetItemInstanceId(bagId1, slotIndex1) end
--Returns: *integer:nilable id

function GetItemTotalCount(bagId, slotIndex) end
--Returns: *integer count

function IsItemConsumable(bagId, slotIndex) end
--Returns: *bool consumable

function GetItemLink(bagId, slotIndex, linkStyle) end
--Returns: *string link

function GetQuestToolLink(aQuestIndex, aToolIndex, linkStyle) end
--Returns: *string link

function GetQuestItemLink(aQuestIndex, aStepIndex, aConditionIndex, linkStyle) end
--Returns: *string link

function GetQuestItemNameFromLink(link) end
--Returns: *string name

function GetComparisonEquipSlotsFromItemLink(itemLink) end
--Returns: *integer:nilable comparisonSlot1, comparisonSlot2

function GetComparisonEquipSlotsFromBagItem(bagId, slotIndex) end
--Returns: *integer:nilable comparisonSlot1, comparisonSlot2

function GetItemName(bagId, slotIndex) end
--Returns: *string name

function IsItemUsable(bagId, slotIndex) end
--Returns: *bool usable, usableOnlyFromActionSlot

function GetSlotStackSize(bagId, slotIndex) end
--Returns: *integer stack, maxStack

function GetEquippedItemInfo(equipSlot) end
--Returns: *string icon, slotHasItem, sellPrice, isHeldSlot, isHeldNow, locked

function GetHeldSlots() end
--Returns: *integer heldMain, heldOff, lastHeldMain, lastHeldOff

function CheckInventorySpaceAndWarn(numItems) end
--Returns: *bool haveSpace

function CheckInventorySpaceSilently(numItems) end
--Returns: *bool haveSpace

function EquipItem(bagId, slotIndex, equipSlotIndex) end

function IsEquipable(bagId, slotIndex) end
--Returns: *bool isEquipable, resultErrorCodeIfFailed

function GetItemLinkInfo(itemLink) end
--Returns: *string icon, sellPrice, meetsUsageRequirement, equipType, itemStyle

function IsBankUpgradeAvailable() end
--Returns: *bool isAvailable

function GetFirstFreeValidSlotForItem(bagId, slotIndex) end
--Returns: *luaindex:nilable freeSlot

function GetFirstFreeValidSlotForCollectible(collectibleId) end
--Returns: *luaindex:nilable freeSlot

function GetItemCurrentActionBarSlot(bagId, slotIndex) end
--Returns: *luaindex:nilable currentSlot

function GetCollectibleCurrentActionBarSlot(collectibleId) end
--Returns: *luaindex:nilable currentSlot

function GetItemSoundCategoryFromLink(link) end
--Returns: *integer itemSoundCategory

function IsLockedWeaponSlot(equipSlot) end
--Returns: *bool locked

function GetSelectedGuildBankId() end
--Returns: *integer:nilable guildId

function GetMapPlayerPosition(unitTag) end
--Returns: *number normalizedX, normalizedZ, heading

function GetMapPing(unitTag) end
--Returns: *number normalizedX, normalizedY

function GetMapRallyPoint() end
--Returns: *number normalizedX, normalizedY

function GetMapPlayerWaypoint() end
--Returns: *number normalizedX, normalizedY

function GetNumKeepTravelNetworkNodes(bgContext) end
--Returns: *integer numNodes

function GetNumKeepTravelNetworkLinks(bgContext) end
--Returns: *integer numLinks

function GetKeepTravelNetworkNodeInfo(nodeIndex, bgContext) end
--Returns: *integer keepId, accessible, normalizedX, normalizedY

function GetKeepTravelNetworkLinkInfo(linkIndex, bgContext) end
--Returns: *integer linkType, linkOwner, restricedToAlliance, startX, startY, endX, endY

function GetKeepTravelNetworkLinkEndpoints(linkIndex, bgContext) end
--Returns: *luaindex keepAIndex, keepBIndex

function GetKeepAccessible(keepId, bgContext) end
--Returns: *bool accessible

function GetKeepHasResourcesForTravel(keepId, bgContext) end
--Returns: *bool hasResources

function GetKeepFastTravelInteraction() end
--Returns: *integer:nilable startKeepId

function TravelToKeep(destinationKeepId) end

function GetRecallCooldown() end
--Returns: *integer remain, duration

function GetNumScoreEntries() end
--Returns: *integer numItems

function GetGameType() end
--Returns: *integer type

function GetGameName() end
--Returns: *string name

function GetGameDescription() end
--Returns: *string description

function GetGameInfoTexture() end
--Returns: *string path

function GetSharedScoreEntryInfo(slotIndex) end
--Returns: *string name, classId, alliance, kills, deaths, assists, healing, damage, score, seconds, numMedals

function GetCTFScoreEntryInfo(slotIndex) end
--Returns: *integer flags

function GetNumScoreboardMedals(index) end
--Returns: *integer numMedals

function GetScoreboardMedalInfo(scoreIndex, medalIndex) end
--Returns: *string name, iconTexture, condition

function GetNumBattlegroundMedals() end
--Returns: *integer numMedals

function GetBattlegroundMedalInfo(medalIndex) end
--Returns: *string name, iconTexture, condition

function RefreshScoreBoard() end

function SendScoreBoardClosed() end

function GetShowScoreButton() end
--Returns: *bool result

function GetNumTeams() end
--Returns: *integer result

function GetScoringTeam() end
--Returns: *integer result

function GetGameScore(alliance) end
--Returns: *integer value

function GetNumObjectivesOwnedByAlliance(alliance) end
--Returns: *integer objectives

function GetGameState() end
--Returns: *integer result

function GetGameStateIsTimed() end
--Returns: *bool isTimed

function GetGameStateIsPaused() end
--Returns: *bool result

function GetScoreToWin() end
--Returns: *integer result

function GetGameTimeRemaining() end
--Returns: *integer result

function GetNumAvAObjectives() end
--Returns: *integer num

function GetAvAObjectiveKeysByIndex(index) end
--Returns: *integer keepId, objectiveId, battlegroundContext

function GetAvAObjectivePvPSystem(keepId, objectiveId, battlegroundContext) end
--Returns: *integer AvASystem

function GetAvAObjectiveRelatedUnitName(keepId, objectiveId, battlegroundContext) end
--Returns: *string unitName

function GetAvAObjectiveInfo(keepId, objectiveId, battlegroundContext) end
--Returns: *string objectiveName, objectiveType, objectiveState, allianceParam1, allianceParam2

function GetAvAObjectivePinInfo(keepId, objectiveId, battlegroundContext) end
--Returns: *integer pinType, currentNormalizedX, currentNormalizedY, continuousUpdate

function GetAvAObjectiveSpawnPinInfo(keepId, objectiveId, battlegroundContext) end
--Returns: *integer pinType, spawnNormalizedX, spawnNormalizedY

function IsAvAObjectiveInBattleground(keepId, objectiveId, battlegroundContext) end
--Returns: *bool isInBattleground

function GetAvAArtifactScore(campaignId, alliance, artifactType) end
--Returns: *bool allOwnHeld, enemyHeld

function GetNumArtifactScoreBonuses(alliance, artifactType) end
--Returns: *integer numBonuses

function GetArtifactScoreBonusInfo(alliance, artifactType, index) end
--Returns: *string name, icon, description

function GetNumKillLocations() end
--Returns: *integer numLocations

function GetKillLocationPinInfo(index) end
--Returns: *integer pinType, normalizedX, normalizedY

function IsPlayerInAvAWorld() end
--Returns: *bool isInAvAWorld

function GetCampaignAllianceScore(campaignId, alliance) end
--Returns: *integer score

function GetSecondsUntilCampaignScoreReevaluation(campaignId) end
--Returns: *integer seconds

function GetSecondsUntilCampaignStart(campaignId) end
--Returns: *integer seconds

function GetSecondsUntilCampaignEnd(campaignId) end
--Returns: *integer seconds

function GetCampaignUnderdogLeaderAlliance(campaignId) end
--Returns: *integer alliance

function GetSecondsUntilCampaignUnderdogReevaluation(campaignId) end
--Returns: *integer seconds

function GetCampaignHoldings(campaignId, elementType, alliance, targetAlliance) end
--Returns: *integer elementsControlled

function GetTotalCampaignHoldings(campaignId, elementType, alliance) end
--Returns: *integer elementsControlled

function GetCampaignAlliancePotentialScore(campaignId, alliance) end
--Returns: *integer potentialScore

function GetCampaignHoldingScoreValues(campaignId) end
--Returns: *integer keepValue, resourceValue, outpostValue, defensiveArtifactValue, offensiveArtifactValue

function GetCampaignName(campaignId) end
--Returns: *string campaignName

function GetPendingAssignedCampaign() end
--Returns: *integer campaignId

function GetNumCampaignRulesetTypes() end
--Returns: *integer numRulesetTypes

function GetCampaignSocialConnectionInfo(connectionIndex) end
--Returns: *integer accountId, alliance, assignedCampaignId, currentCampaignId, isFriend, isGuildMate

function SwitchGuestCampaign(campaignId) end

function GetMinLevelForCampaignTutorial() end
--Returns: *integer minLevelForCampaignTutorial

function GetNumLootItems() end
--Returns: *integer count

function GetNumKeepResourceTypes() end
--Returns: *integer numTypes

function GetNumKeepUpgradePaths() end
--Returns: *integer numPaths

function GetNumUpgradesForKeepAtResourceLevel(keepId, battlegroundContext, resourceType, level) end
--Returns: *integer numUpgrades

function GetKeepUpgradeDetails(keepId, battlegroundContext, resourceType, level, index) end
--Returns: *string upgradeName, upgradeDetails, upgradeIcon, upgradeAtPercent, active

function GetKeepUpgradeLineFromResourceType(resourceType) end
--Returns: *[KeepUpgradeLine|#KeepUpgradeLine] upgradeLine

function GetKeepUpgradeLineFromUpgradePath(upgradePath) end
--Returns: *[KeepUpgradeLine|#KeepUpgradeLine] upgradeLine

function GetNumUpgradesForKeepAtPathLevel(keepId, battlegroundContext, upgradePath, level) end
--Returns: *integer numUpgrades

function GetKeepUpgradePathDetails(keepId, battlegroundContext, upgradePath, level, index) end
--Returns: *string upgradeName, upgradeDetails, icon, upgradeAtPercent, active

function CanRespawnAtKeep(keepId) end
--Returns: *bool canRespawn

function GetIsTracked(trackType, param1, param2) end
--Returns: *bool tracked

function GetIsTrackedForContentId(trackType, contentId) end
--Returns: *bool tracked

function SetTracked(trackType, tracked, param1, param2) end
--Returns: *bool success

function GetNumTracked() end
--Returns: *integer numTracked

function GetTrackedByIndex(index) end
--Returns: *integer trackType, param1, param2

function GetTrackedIsAssisted(trackType, param1, param2) end
--Returns: *bool assisted

function SetTrackedIsAssisted(trackType, assisted, param1, param2) end

function AddMapPin(pinType, param1, param2, param3) end

function RemoveMapPin(pinType, param1, param2, param3) end

function StopMapPinAnimation(pinType, param1, param2, param3) end

function RemoveMapPinsByType(pinType) end

function SetMapPinAssisted(pinType, assisted, param1, param2, param3) end

function SetMapPinContinuousPositionUpdate(pinType, continuousUpdate, param1, param2, param3) end

function AddMapQuestPins(journalQuestIndex) end

function RemoveMapQuestPins(journalQuestIndex) end

function SetMapQuestPinsAssisted(journalQuestIndex, assisted) end

function StartMouseSiegeWeaponAim() end

function StopMouseSiegeWeaponAim() end

function SiegeWeaponPackUp() end

function SiegeWeaponRelease() end

function SiegeWeaponFire() end

function CanSiegeWeaponPackUp() end
--Returns: *bool canPackup

function CanSiegeWeaponFire() end
--Returns: *bool canFire

function CanSiegeWeaponAim() end
--Returns: *bool canAim

function IsPlayerControllingSiegeWeapon() end
--Returns: *bool isPlayerControlling

function IsPlayerEscortingRam() end
--Returns: *bool isPlayerEscorting

function GetNumPlayersEscortingRam() end
--Returns: *integer numPlayersEscorting

function GetMinMaxRamEscorts() end
--Returns: *integer minEscorts, maxEscorts

function SetHealthWarningStage(stage) end

function FlashHealthWarningStage(stage, flashTimeMs) end

function ClearHealthWarnings() end

function SetFlashWaitTime(waitTimeMs) end

function GetMaxMailItems() end
--Returns: *integer maxMail

function QueueItemAttachment(bagId, slotIndex, attachmentSlot) end
--Returns: *integer itemAttachmentResult

function FormatAchievementLinkTimestamp(timestamp) end
--Returns: *string date, time

function GetNumStats() end
--Returns: *integer numStats

function GetNumAbilitiesLearnedForLevel(level, progression) end
--Returns: *integer abilitiesLearned

function GetLearnedAbilityInfoForLevel(level, learnedIndex, progression) end
--Returns: *string name, texture, abilityIndex, progressionIndex

function PlayerHasAttributeUpgrades() end
--Returns: *bool hasLevelUpgrades

function ChooseAbilityProgressionMorph(progressionIndex, morph) end

function GetAbilityProgressionInfo(progressionIndex) end
--Returns: *string name, morph, rank

function GetAbilityProgressionXPInfo(progressionIndex) end
--Returns: *integer lastRankXp, nextRankXP, currentXP, atMorph

function GetAbilityProgressionAbilityInfo(progressionIndex, morph, rank) end
--Returns: *string name, texture, abilityIndex

function GetAbilityProgressionRankFromAbilityId(abilityId) end
--Returns: *integer:nilable rank

function GetAbilityProgressionXPInfoFromAbilityId(abilityId) end
--Returns: *bool hasProgression, progressionIndex, lastRankXp, nextRankXP, currentXP, atMorph

function GetAttributeDerivedStatPerPointValue(attribute, stat) end
--Returns: *number amountPerPoint

function GetActiveCombatTipInfo(activeCombatTipId) end
--Returns: *string name, tipText, iconPath

function IsGameCameraActive() end
--Returns: *bool isActive

function IsInteractionCameraActive() end
--Returns: *bool isActive

function BeginInteractCameraSpin() end

function EndInteractCameraSpin() end

function GameCameraInteractStart() end

function IsReticleHidden() end
--Returns: *bool isHidden

function IsGameCameraUnitHighlightedAttackable() end
--Returns: *bool attackable

function GameCameraMouseFreeLookStart() end

function GameCameraMouseFreeLookStop() end

function CycleGameCameraPreferredEnemyTarget() end

function IsGameCameraPreferredTargetValid() end
--Returns: *bool valid

function ClearGameCameraPreferredTarget() end

function GetGameCameraInteractableActionInfo() end
--Returns: *string:nilable action, name, interactBlocked, isOwned, additionalInfo, contextualInfo, contextualLink, isCriminalInteract

function GetNameOfGameCameraQuestToolTarget() end
--Returns: *string name

function ToggleGameCameraFirstPerson() end

function IsGameCameraSiegeControlled() end
--Returns: *bool valid

function ReleaseGameCameraSiegeControlled() end

function StopSettingChamber() end

function GetSettingChamberStress() end
--Returns: *number stress

function AttemptForceLock() end

function GetLockpickingTimeLeft() end
--Returns: *integer timeLeftMs

function GetChanceToForceLock() end
--Returns: *integer chance

function GetNumLockpicksLeft() end
--Returns: *integer picksLeft

function GetLockQuality() end
--Returns: *integer lockQuality

function GetChamberState(chamberIndex) end
--Returns: *integer chamberState, chamberProgress

function IsChamberSolved(chamberIndex) end
--Returns: *bool solved

function StartSettingChamber(chamberIndex) end
--Returns: *bool succesfullyStarted

function GetNumPendingFeedback() end
--Returns: *integer pendingFeedback

function GetFeedbackIdByIndex(feedbackIndex) end
--Returns: *integer:nilable feedbackId

function GetFeedbackType(feedbackId) end
--Returns: *integer feedbackType

function RemovePendingFeedback(feedbackId) end

function IsFeedbackGatheringEnabled() end
--Returns: *bool enabled

function RequestOpenUnsafeURL(URL) end

function Logout() end

function Quit() end

function ConfirmLogout(quitGame, option, initialResult) end

function CancelLogout() end

function GetIsNewCharacter() end
--Returns: *bool isNewCharacter

function GetUniqueNameForCharacter(characterName) end
--Returns: *string uniqueName

function GetWorldName() end
--Returns: *string worldName

function GetTrialChatRestriction(channel, target) end
--Returns: *[TrialAccountRestrictionType|#TrialAccountRestrictionType] restrictionType

function GetTrialChatIsRestrictedAndWarn(channel, target) end
--Returns: *bool handled

function CanChangeBattleLevelPreference() end
--Returns: *bool canChangeBattleLevelPreference

function ClearCursor() end
--Returns: *bool clearedSomething

function SetCursorItemSoundsEnabled(enabled) end

function GetCursorContentType() end
--Returns: *integer cursorType

function GetCursorBagId() end
--Returns: *integer:nilable originatingBag

function GetCursorSlotIndex() end
--Returns: *integer:nilable slotIndex

function PlaceInActionBar(actionSlot) end

function PlaceInInventory(bagId, slotIndex) end

function RequestMoveItem(sourceBag, sourceSlot, destBag, destSlot, stackCount) end

function PlaceInEquipSlot(slot) end

function PlaceInStoreWindow() end

function PlaceInTransfer() end

function PlaceInWorldLeftClick() end

function PlaceInAttachmentSlot(attachmentSlot) end

function PickupAction(actionSlot) end

function PickupAbility(abilityIndex) end

function PickupAbilityBySkillLine(skillType, skillLineIndex, abilityIndex) end

function PickupInventoryItem(bagId, slotIndex, count) end

function PickupEquippedItem(slot) end

function PickupTradeItem(tradeIndex) end

function PickupQuestTool(journalQuestIndex, toolIndex) end

function PickupQuestItem(journalQuestIndex, stepIndex, conditionIndex) end

function PickupStoreItem(entryIndex) end

function PickupStoreBuybackItem(entryIndex) end

function PickupCollectible(collectibleId) end

function RespondToDestroyRequest(choice) end

function PlaceInTradingHouse() end

function GetNumActionLayers() end
--Returns: *integer actionLayers

function GetActionLayerInfo(layerIndex) end
--Returns: *string layerName, numLayerCategories

function GetActionLayerCategoryInfo(layerIndex, categoryIndex) end
--Returns: *string categoryName, numActions

function GetActionInfo(layerIndex, categoryIndex, actionIndex) end
--Returns: *string actionName, isRebindable, isHidden

function GetActionBindingInfo(layerIndex, categoryIndex, actionIndex, bindingIndex) end
--Returns: *[KeyCode|#KeyCode] keyCode, mod1, mod2, mod3, mod4

function GetMaxBindingsPerAction() end
--Returns: *integer maxNumBindings

function CreateDefaultActionBind(actionName, key, modifier1, modifier2, modifier3, modifier4) end

function BindKeyToAction(layerIndex, categoryIndex, actionIndex, bindingIndex, key, modifier1, modifier2, modifier3, modifier4) end

function UnbindKeyFromAction(layerIndex, categoryIndex, actionIndex, bindingIndex) end

function UnbindAllKeysFromAction(layerIndex, categoryIndex, actionIndex) end

function GetActionIndicesFromName(actionName) end
--Returns: *luaindex:nilable layerIndex, categoryIndex, actionIndex

function GetBindingIndicesFromKeys(layerIndex, keyCode, mod1, mod2, mod3, mod4) end
--Returns: *luaindex:nilable categoryIndex, actionIndex, bindingIndex

function GetActionNameFromKey(layerName, keyCode) end
--Returns: *string actionName

function PushActionLayerByName(layerName) end

function InsertActionLayerByName(layerName, activeLayerIndex) end

function InsertNamedActionLayerAbove(layerName, existingLayerName) end

function RemoveActionLayerByName(layerName) end

function IsActionLayerActiveByName(layerName) end
--Returns: *bool active

function PopActionLayer() end

function GetNumActiveActionLayers() end
--Returns: *integer numActiveActionLayers

function GetActiveActionLayerIndex(activeActionLayerIndex) end
--Returns: *luaindex:nilable layerIndex

function GetNumCharacters() end
--Returns: *integer numCharacters

function GetCharacterInfo(index) end
--Returns: *string name, gender, level, classId, raceId, alliance, id, locationId

function GetNumAttributes() end
--Returns: *integer numAttributes

function IsPlayerTryingToMove() end
--Returns: *bool tryingToMove

function GetCon(otherLevel, playerLevel) end
--Returns: *[DifficultyCon|#DifficultyCon] con

function IsWerewolf() end
--Returns: *bool isWerewolf

function IsPlayerStunned() end
--Returns: *bool isStunned

function GetSynergyInfo() end
--Returns: *string:nilable synergyName, iconFilename

function HasSynergyEffects() end
--Returns: *bool hasSynergy

function GetGroupInviteInfo() end
--Returns: *string characterName, millisecondsSinceRequest, displayName

function AcceptGroupInvite() end

function DeclineGroupInvite() end

function HasPendingGroupElectionVote() end
--Returns: *bool hasPendingVote

function CastGroupVote(vote) end

function GroupLeave() end

function GroupInviteByName(name) end

function GroupKickByName(name) end

function GroupDisband() end

function IsPlayerInGroup(name) end
--Returns: *bool inGroup

function GetGroupSize() end
--Returns: *integer groupSize

function JumpToGroupLeader() end

function JumpToGroupMember(name) end

function CanJumpToGroupMember(unitTag) end
--Returns: *bool canJump, result

function SetVeteranDifficulty(isVeteranDifficulty) end

function GetGroupUnitTagByIndex(sortIndex) end
--Returns: *string:nilable unitTag

function GetGroupIndexByUnitTag(unitTag) end
--Returns: *luaindex sortIndex

function GetInstanceKickTime() end
--Returns: *integer:nilable remainingTimeMs, totalTimeMs

function IsGroupMemberInRemoteRegion(unitTag) end
--Returns: *bool inRemoteRegion

function IsAnyGroupMemberInDungeon() end
--Returns: *bool isAnyGroupMemberInDungeon

function IsGroupCrossAlliance() end
--Returns: *bool isGroupCrossAlliance

function IsInLFGGroup() end
--Returns: *bool isInLFGGroup

function GetCurrentLFGActivity() end
--Returns: *[LFGActivity|#LFGActivity]:nilable activityType, activityIndex

function IsCurrentLFGActivityComplete() end
--Returns: *bool isComplete

function GetGroupMemberAssignedRole(unitTag) end
--Returns: *[LFGRole|#LFGRole] assignedRole

function IsGroupUsingVeteranDifficulty() end
--Returns: *bool isVeteran

function DoesGroupModificationRequireVote() end
--Returns: *bool doesRequireVote

function CanPlayerChangeGroupDifficulty() end
--Returns: *bool canChange, reason

function GetGroupElectionInfo() end
--Returns: *[GroupElectionType|#GroupElectionType] electionType, timeRemainingSeconds, electionDescriptor, targetUnitTag

function BeginGroupElection(electionType, electionDescriptor, targetUnitTag) end
--Returns: *bool sentSuccessfully

function GetRaidReviveCountersRemaining() end
--Returns: *integer:nilable currentCounter

function GetCurrentRaidScore() end
--Returns: *integer score

function GetCurrentRaidDeaths() end
--Returns: *integer:nilable deaths

function GetCurrentRaidStartingReviveCounters() end
--Returns: *integer:nilable startingReviveCounters

function GetCurrentRaidLifeScoreBonus() end
--Returns: *integer:nilable currentLifeScoreBonus

function GetRaidBonusMultiplier() end
--Returns: *integer currentLifeScoreBonus

function IsRaidInProgress() end
--Returns: *bool inProgress

function HasRaidEnded() end
--Returns: *bool ended

function WasRaidSuccessful() end
--Returns: *bool:nilable successful

function IsPlayerInRaid() end
--Returns: *bool inRaid

function IsPlayerInReviveCounterRaid() end
--Returns: *bool isInReviveCounterRaid

function IsPlayerInRaidStagingArea() end
--Returns: *bool isInRaidStagingArea

function GetRaidName(raidId) end
--Returns: *string name

function GetCurrentParticipatingRaidId() end
--Returns: *integer currentRaidId

function GetRaidTargetTime() end
--Returns: *integer raidTargetTime

function GetRaidDuration() end
--Returns: *integer raidTime

function QueryRaidLeaderboardData() end

function GetNumRaidLeaderboards(raidCategory) end
--Returns: *integer count, hasWeekly

function GetRaidOfTheWeekLeaderboardInfo(raidCategory) end
--Returns: *string name, raidId

function GetRaidLeaderboardInfo(raidCategory, raidIndex) end
--Returns: *string name, raidId

function GetRaidOfTheWeekLeaderboardLocalPlayerInfo(raidCategory) end
--Returns: *integer rank, bestScore

function GetRaidLeaderboardLocalPlayerInfo(raidCategory, raidIndex) end
--Returns: *integer rank, bestScore

function GetNumTrialOfTheWeekLeaderboardEntries() end
--Returns: *integer count

function GetNumTrialLeaderboardEntries(raidIndex) end
--Returns: *integer count

function GetNumChallengeOfTheWeekLeaderboardEntries(classId) end
--Returns: *integer count

function GetNumChallengeLeaderboardEntries(raidIndex, classId) end
--Returns: *integer count

function GetTrialOfTheWeekLeaderboardEntryInfo(entryIndex) end
--Returns: *integer ranking, charName, time, classId, allianceId, displayName

function GetTrialLeaderboardEntryInfo(raidIndex, entryIndex) end
--Returns: *integer ranking, charName, time, classId, allianceId, displayName

function GetChallengeOfTheWeekLeaderboardEntryInfo(classId, entryIndex) end
--Returns: *integer ranking, charName, time, retClassId, allianceId, displayName

function GetChallengeLeaderboardEntryInfo(raidIndex, classId, entryIndex) end
--Returns: *integer ranking, charName, time, retClassId, allianceId, displayName

function GetRaidOfTheWeekTimes() end
--Returns: *integer secondsUntilEnd, secondsUntilNextStart

function GetPlayerRaidOfTheWeekParticipationInfo(raidCategory) end
--Returns: *bool isParticipating, isCredited

function GetPlayerRaidParticipationInfo(raidCategory, raidIndex) end
--Returns: *bool isParticipating, isCredited

function GetPlayerRaidOfTheWeekProgressInfo(raidCategory) end
--Returns: *bool inProgress, complete

function GetPlayerRaidProgressInfo(raidCategory, raidIndex) end
--Returns: *bool inProgress, complete

function JumpToFriend(name) end

function GetNumRaidScoreNotifications() end
--Returns: *integer numNotifications

function GetRaidScoreNotificationId(notificationIndex) end
--Returns: *integer notificationId

function GetRaidScoreNotificationInfo(notificationId) end
--Returns: *integer raidId, raidScore, millisecondsSinceRequest

function GetNumRaidScoreNotificationMembers(notificationId) end
--Returns: *integer numMembers

function GetRaidScoreNotificationMemberInfo(notificationId, memberIndex) end
--Returns: *string displayName, characterName, isFriend, isGuildMember, isPlayer

function RemoveRaidScoreNotification(notificationId) end

function IsSlotLocked(slotIndex) end
--Returns: *bool locked

function IsActionBarSlottingAllowed() end
--Returns: *bool isAllowed

function GetActionBarPage(physicalPageId) end
--Returns: *luaindex logicalPageId

function SetActionBarPage(physicalPageId, logicalPageId) end

function ClearSlot(slotIndex) end

function SelectSlotAbility(abilityIndex, slotIndex) end

function SelectSlotItem(bagId, bagSlotId, slotIndex) end

function SelectSlotCollectible(collectibleId, slotIndex) end

function SelectSlotEmote(emoteIndex, slotIndex) end

function SelectSlotQuickChat(quickChatId, slotIndex) end

function SelectLastSlottedItem(slotIndex) end

function ClearLastSlottedItem() end

function GetLastSlottedItemLink() end
--Returns: *string itemLink

function GetSlotItemLink(slotIndex) end
--Returns: *string itemLink

function GetCurrentQuickslot() end
--Returns: *integer slotId

function SetCurrentQuickslot(slotId) end

function HasMountSkin() end
--Returns: *bool result

function GetMountSkinId() end
--Returns: *integer skinId

function GetRidingStats() end
--Returns: *integer inventoryBonus, maxInventoryBonus, staminaBonus, maxStaminaBonus, speedBonus, maxSpeedBonus

function GetMaxRidingTraining(trainTypeIndex) end
--Returns: *integer maxValue

function GetTimeUntilCanBeTrained() end
--Returns: *integer timeMs, totalDurationMs

function GetTrainingCost() end
--Returns: *integer cost

function TrainRiding(trainTypeIndex) end

function IsMounted() end
--Returns: *bool mounted

function ToggleMount() end

function GetAbilityIdByIndex(abilityIndex) end
--Returns: *integer abilityId

function DoesAbilityExist(abilityId) end
--Returns: *bool exists

function GetAbilityName(abilityId) end
--Returns: *string abilityName

function IsAbilityPassive(abilityId) end
--Returns: *bool isPassive

function GetAbilityCastInfo(abilityId) end
--Returns: *bool channeled, castTime, channelTime

function GetAbilityTargetDescription(abilityId) end
--Returns: *string:nilable targetDescription

function GetAbilityRange(abilityId) end
--Returns: *integer minRangeCM, maxRangeCM

function GetAbilityRadius(abilityId) end
--Returns: *integer radius

function GetAbilityAngleDistance(abilityId) end
--Returns: *integer angleDistance

function GetAbilityDuration(abilityId) end
--Returns: *integer duration

function GetAbilityIcon(abilityId) end
--Returns: *textureName icon

function GetAbilityCost(abilityId) end
--Returns: *integer cost, mechanic

function GetAbilityRoles(abilityId) end
--Returns: *bool isTankRoleAbility, isHealerRoleAbility, isDamageRoleAbility

function GetAbilityDescriptionHeader(abilityId) end
--Returns: *string header

function GetAbilityDescription(abilityId) end
--Returns: *string description

function GetAbilityEffectDescription(effectSlotId) end
--Returns: *string description

function GetAbilityUpgradeLines(abilityId) end
--Returns: *string label, oldValue, newValue

function GetAbilityNewEffectLines(abilityId) end
--Returns: *string newEffect

function IsBlockActive() end
--Returns: *bool active

function FormatFloatRelevantFraction(num) end
--Returns: *string formattedString

function GetOfferedQuestInfo() end
--Returns: *string dialogue, response

function GetOfferedQuestShareInfo(questId) end
--Returns: *string questName, characterName, millisecondsSinceRequest, displayName

function GetOfferedQuestShareIds() end

--Returns: *integer questId

function AcceptOfferedQuest() end

function AcceptSharedQuest(questId) end

function DeclineSharedQuest(questId) end

function GetNumJournalQuests() end
--Returns: *integer numQuests

function IsValidQuestIndex(journalQuestIndex) end
--Returns: *bool isValid

function GetJournalQuestType(journalQuestIndex) end
--Returns: *integer type

function GetJournalQuestRepeatType(journalQuestIndex) end
--Returns: *integer repeatType

function GetJournalQuestInstanceDisplayType(journalQuestIndex) end
--Returns: *[InstanceDisplayType|#InstanceDisplayType] instanceDisplayType

function GetJournalQuestInfo(journalQuestIndex) end
--Returns: *string questName, backgroundText, activeStepText, activeStepType, activeStepTrackerOverrideText, completed, tracked, questLevel, pushed, questType, instanceDisplayType

function GetJournalQuestIsComplete(journalQuestIndex) end
--Returns: *bool completed

function GetJournalQuestName(journalQuestIndex) end
--Returns: *string questName

function GetJournalQuestLevel(journalQuestIndex) end
--Returns: *integer level

function GetJournalQuestConditionType(journalQuestIndex, stepIndex, conditionIndex, assisted) end
--Returns: *integer pinType

function GetJournalQuestConditionInfo(journalQuestIndex, stepIndex, conditionIndex) end
--Returns: *string conditionText, current, max, isFailCondition, isComplete, isCreditShared, isVisible

function GetJournalQuestConditionValues(journalQuestIndex, stepIndex, conditionIndex) end
--Returns: *integer current, max, isFailCondition, isComplete, isCreditShared, isVisible

function GetQuestToolCooldownInfo(journalQuestIndex, toolIndex) end
--Returns: *integer remain, duration

function GetQuestItemCooldownInfo(journalQuestIndex, stepIndex, conditionIndex) end
--Returns: *integer remain, duration

function UseQuestItem(journalQuestIndex, stepIndex, conditionIndex) end

function UseQuestTool(journalQuestIndex, toolIndex) end

function CanUseQuestItem(journalQuestIndex, stepIndex, conditionIndex) end
--Returns: *bool canUse

function CanUseQuestTool(journalQuestIndex, toolIndex) end
--Returns: *bool canUse

function IsJournalQuestInCurrentMapZone(questIndex) end
--Returns: *bool isInCurrentZone

function DoesJournalQuestConditionHavePosition(journalQuestIndex, stepIndex, conditionIndex) end
--Returns: *bool hasPosition

function SetMapToQuestCondition(journalQuestIndex, stepIndex, conditionIndex) end
--Returns: *[SetMapResultCode|#SetMapResultCode] setMapResult

function SetMapToQuestZone(questIndex) end
--Returns: *[SetMapResultCode|#SetMapResultCode] setMapResult

function GetJournalQuestNumRewards(journalQuestIndex) end
--Returns: *integer count

function GetQuestRewardItemLink(rewardIndex, linkStyle) end
--Returns: *string link

function GetNextCompletedQuestId(lastQuestId) end
--Returns: *integer:nilable nextQuestId

function GetCompletedQuestInfo(questId) end
--Returns: *string name, questType

function GetCompletedQuestLocationInfo(questId) end
--Returns: *string zoneName, objectiveName, zoneIndex, poiIndex

function GetJournalQuestRewardInfo(journalQuestIndex, rewardIndex) end
--Returns: *[RewardType|#RewardType] type, name, amount, iconFile, meetsUsageRequirement, itemQuality, itemType

function GetJournalQuestRewardItemId(journalQuestIndex, rewardIndex) end
--Returns: *integer rewardItemDefId

function GetJournalQuestRewardCollectibleId(journalQuestIndex, rewardIndex) end
--Returns: *integer rewardCollectibleDefId

function GetJournalQuestStartingZone(journalQuestIndex) end
--Returns: *luaindex zoneIndex

function GetQuestToolInfo(journalQuestIndex, toolIndex) end
--Returns: *textureName iconFilename, stackCount, isUsable, name, questItemId

function GetQuestItemInfo(journalQuestIndex, stepIndex, conditionIndex) end
--Returns: *textureName iconFilename, stackCount, name, questItemId

function GetQuestToolTooltipInfo(journalQuestIndex, toolIndex) end
--Returns: *string header, itemName, tooltipText

function GetQuestItemTooltipInfo(journalQuestIndex, stepIndex, conditionIndex) end
--Returns: *string header, itemName, tooltipText

function CancelRequestJournalQuestConditionAssistance(taskId) end

function GetDynamicChatChannelName(channelId) end
--Returns: *string name

function GetChatChannelId(name) end
--Returns: *integer channelId

function CanWriteGuildChannel(channelId) end
--Returns: *bool canWrite

function GetNumChatContainers() end
--Returns: *integer numContainers

function GetNumChatContainerTabs(chatContainerIndex) end
--Returns: *integer numContainerTabs

function GetChatContainerTabInfo(chatContainerIndex, tabIndex) end
--Returns: *string name, isLocked, isInteractable, isCombatLog, areTimestampsEnabled

function GetNumChatCategories() end
--Returns: *integer numCategories

function IsChatContainerTabCategoryEnabled(chatContainerIndex, tabIndex, chatCategory) end
--Returns: *bool enabled

function SetChatContainerTabCategoryEnabled(chatContainerIndex, tabIndex, chatCategory, enabled) end

function SetChatContainerTabInfo(chatContainerIndex, tabIndex, name, isLocked, isInteractable, areTimestampsEnabled) end

function ResetChatContainerTabToDefault(chatContainerIndex, tabIndex) end

function GetChatContainerColors(chatContainerIndex) end
--Returns: *number bgRed, bgGreen, bgBlue, bgMinAlpha, bgMaxAlpha

function SetChatContainerColors(chatContainerIndex, bgRed, bgGreen, bgBlue, bgMinAlpha, bgMaxAlpha) end

function ResetChatContainerColorsToDefault(chatContainerIndex) end

function AddChatContainer() end

function RemoveChatContainer(chatContainerIndex) end

function AddChatContainerTab(chatContainerIndex, name, isCombatLog) end

function RemoveChatContainerTab(chatContainerIndex, tabIndex) end

function TransferChatContainerTab(fromChatContainerIndex, fromTabIndex, toChatContainerIndex, toTabIndex) end

function GetChatFontSize() end
--Returns: *integer fontSize

function SetChatFontSize(fontSize) end

function GetGamepadChatFontSize() end
--Returns: *integer gamepadFontSize

function SetGamepadChatFontSize(gamepadFontSize) end

function ResetChatFontSizeToDefault() end

function GetChatCategoryColor(category) end
--Returns: *number red, green, blue

function SetChatCategoryColor(category, red, green, blue) end

function ResetChatCategoryColorToDefault(category) end

function GetChannelCategoryFromChannel(channel) end
--Returns: *[ChatChannelCategories|#ChatChannelCategories] category

function IsChatBubbleCategoryEnabled(category) end
--Returns: *bool enabled

function SetChatBubbleCategoryEnabled(category, enabled) end

function IsChatSystemAvailableForCurrentPlatform() end
--Returns: *bool enabled

function SetSessionIgnore(userName, isIgnoredThisSession) end

function ClearSessionIgnores() end

function SubmitSpamReport(userName, reason) end

function SetChatLogEnabled(isEnabled) end

function IsChatLogEnabled() end
--Returns: *bool isEnabled

function SetPendingInteractionConfirmed(isConfirmed) end

function IsUnderArrest() end
--Returns: *bool beingArrested

function GetGameCameraInteractableUnitAudioInfo() end
--Returns: *integer audioModelType, audioModelMaterial, audioModelSize

function IsGameCameraInteractableUnitMonster() end
--Returns: *bool isUnitMonster

function GetGameCameraInteractableInfo() end
--Returns: *bool interactionExists, interactionAvailableNow, questInteraction, questTargetBased, questJournalIndex, questToolIndex, questToolOnCooldown

function GetGameCameraPickpocketingBonusInfo() end
--Returns: *bool inBonus, isHostile, percentChance, difficulty, isEmpty, prospectiveResult, monsterSocialClass

function GetChatterOption(optionIndex) end
--Returns: *string optionString, optionType, optionalArgument, isImportant, chosenBefore

function SelectChatterOption(optionIndex) end

function IsInteractionPending() end
--Returns: *bool isPending

function EndPendingInteraction() end

function GetChatterOptionCount() end
--Returns: *integer optionCount

function ResetChatter() end

function GetChatterFarewell() end
--Returns: *string backToTOCString, farewellString, isImportant

function IsPlayerInteractingWithObject() end
--Returns: *bool areThey

function IsInteractingWithMyAssistant() end
--Returns: *bool isAssistant

function GetInteractionType() end
--Returns: *integer interactMode

function SetFrameLocalPlayerInGameCamera(enabled) end

function SetFrameLocalPlayerTarget(normalizedScreenX, normalizedScreenY) end

function SetFramingScreenType(sreenType) end

function IsGuildBankOpen() end
--Returns: *bool isGuildBankOpen

function GetCurrentMoney() end
--Returns: *integer money

function GetAlliancePoints() end
--Returns: *integer alliancePoints

function GetCarriedCurrencyAmount(type) end
--Returns: *integer currencyAmount

function GetMaxCarriedCurrencyAmount(type) end
--Returns: *integer currencyAmount

function GetBankedMoney() end
--Returns: *integer money

function GetBankedCurrencyAmount(type) end
--Returns: *integer currencyAmount

function DepositCurrencyIntoBank(type, currencyAmount) end

function WithdrawCurrencyFromBank(type, currencyAmount) end

function GetMaxBankWithdrawal(type) end
--Returns: *integer maxWithdrawal

function GetMaxBankDeposit(type) end
--Returns: *integer maxDeposit

function DepositMoneyIntoBank(money) end

function WithdrawMoneyFromBank(money) end

function GetBankedTelvarStones() end
--Returns: *integer telvarStones

function DepositTelvarStonesIntoBank(telvarStones) end

function WithdrawTelvarStonesFromBank(telvarStones) end

function GetMaxBankCurrencyAmount(type) end
--Returns: *integer currencyAmount

function GetGuildBankedMoney() end
--Returns: *integer money

function GetGuildBankedCurrencyAmount(type) end
--Returns: *integer currencyAmount

function DepositMoneyIntoGuildBank(money) end

function WithdrawMoneyFromGuildBank(money) end

function DepositCurrencyIntoGuildBank(type, currencyAmount) end

function WithdrawCurrencyFromGuildBank(type, currencyAmount) end

function GetMaxGuildBankWithdrawal(type) end
--Returns: *integer maxWithdrawal

function GetMaxGuildBankDeposit(type) end
--Returns: *integer maxDeposit

function GetMaxGuildBankCurrencyAmount(type) end
--Returns: *integer currencyAmount

function GetTelvarStoneBankingFee() end
--Returns: *integer bankingFee

function GetTelvarStoneMinimumDeposit() end
--Returns: *integer minDeposit

function GetTelvarStonePercentLossOnPvpDeath() end
--Returns: *number percentLoss

function GetTelvarStonePercentLossOnNonPvpDeath() end
--Returns: *number percentLoss

function UseItem(bagId, slotIndex) end

function CanInteractWithItem(bagId, slotIndex) end
--Returns: *bool canInteract

function UnequipItem(equipSlot) end

function DestroyItem(bagId, slotIndex) end

function GetNextBankUpgradePrice() end
--Returns: *integer cost

function GetNextBackpackUpgradePrice() end
--Returns: *integer cost

function BuyBankSpace() end

function BuyBagSpace() end

function DisplayBankUpgrade() end

function GetBagSize(bagId) end
--Returns: *integer bagSlots

function IsArmorEffectivenessReduced(bagId, slotIndex) end
--Returns: *bool effectivenessReduced

function GetNumBagUsedSlots(bagId) end
--Returns: *integer usedSlots

function GetNumBagFreeSlots(bagId) end
--Returns: *integer freeSlots

function FindFirstEmptySlotInBag(bagId) end
--Returns: *integer:nilable slotIndex

function GetItemFilterTypeInfo(bagId, slotIndex) end

--Returns: *[ItemFilterType|#ItemFilterType] itemFilterType

function GetItemCooldownInfo(bagId, slotIndex) end
--Returns: *integer remain, duration

function GetItemStatValue(bagId, slotIndex) end
--Returns: *integer statValue

function GetItemSoundCategory(bagId, slotIndex) end
--Returns: *integer itemSoundCategory

function IsItemBound(bagId, slotIndex) end
--Returns: *bool isBound

function IsItemEnchantable(bagId, slotIndex) end
--Returns: *bool enchantable

function IsItemEnchantment(bagId, slotIndex) end
--Returns: *bool enchantment

function CanItemTakeEnchantment(itemToEnchantBagId, itemToEnchantSlotIndex, enchantmentToUseBagId, enchantmentToUseSlotIndex) end
--Returns: *bool canEnchant

function EnchantItem(itemToEnchantBagId, itemToEnchantSlotIndex, enchantmentToUseBagId, enchantmentToUseSlotIndex) end

function CanConvertItemStyleToImperial(itemToBagId, itemToSlotIndex) end
--Returns: *bool canConvert

function ConvertItemStyleToImperial(itemToBagId, itemToSlotIndex) end

function IsItemChargeable(bagId, slotIndex) end
--Returns: *bool rechargeable

function GetAmountSoulGemWouldChargeItem(itemToChargeBagId, itemToChargeSlotIndex, soulGemToConsumeBagId, soulGemToConsumeSlotIndex) end
--Returns: *integer chargeAmount

function ChargeItemWithSoulGem(itemToChargeBagId, itemToChargeSlotIndex, soulGemToConsumeBagId, soulGemToConsumeSlotIndex) end

function IsItemSoulGem(soulGemType, bagId, slotIndex) end
--Returns: *bool isSoulGem

function GetChargeInfoForItem(bagId, slotIndex) end
--Returns: *integer charges, maxCharges

function DoesItemHaveDurability(bagId, slotIndex) end
--Returns: *bool hasDurability

function GetItemCondition(bagId, slotIndex) end
--Returns: *integer condition

function GetItemRepairCost(bagId, slotIndex) end
--Returns: *integer repairCost

function GetRepairAllCost() end
--Returns: *integer repairCost

function GetItemLaunderPrice(bagId, slotIndex) end
--Returns: *integer launderCost

function IsItemRepairKit(bagId, slotIndex) end
--Returns: *bool isRepairKit

function IsItemNonCrownRepairKit(bagId, slotIndex) end
--Returns: *bool isNonCrownRepairKit

function GetRepairKitTier(bagId, slotIndex) end
--Returns: *integer tier

function GetAmountRepairKitWouldRepairItem(itemToRepairBagId, itemToRepairSlotIndex, repairKitToConsumeBagId, repairKitToConsumeSlotIndex) end
--Returns: *integer amountRepaired

function RepairItemWithRepairKit(itemToRepairBagId, itemToRepairSlotIndex, repairKitToConsumeBagId, repairKitToConsumeSlotIndex) end

function HasActivatableSwapWeaponsEquipped() end
--Returns: *bool canSwapWeaponSets

function GetActiveWeaponPairInfo() end
--Returns: *[ActiveWeaponPair|#ActiveWeaponPair] activeWeaponPair, locked

function GetItemLevel(bagId, slotIndex) end
--Returns: *integer level

function GetItemRequiredLevel(bagId, slotIndex) end
--Returns: *integer requiredLevel

function GetItemRequiredChampionPoints(bagId, slotIndex) end
--Returns: *integer requiredChampionPoints

function GetItemTrait(bagId, slotIndex) end
--Returns: *[ItemTraitType|#ItemTraitType] trait

function GetItemCreatorName(bagId, slotIndex) end
--Returns: *string creatorName

function GetItemInfo(bagId, slotIndex) end
--Returns: *textureName icon, stack, sellPrice, meetsUsageRequirement, locked, equipType, itemStyle, quality

function GetItemSellValueWithBonuses(bagId, slotIndex) end
--Returns: *integer sellPrice

function GetItemCraftingInfo(bagId, slotIndex) end
--Returns: *[TradeskillType|#TradeskillType] usedInCraftingType, itemType, extraInfo1, extraInfo2, extraInfo3

function GetItemType(bagId, slotIndex) end
--Returns: *[ItemType|#ItemType] itemType, specializedItemType

function GetItemArmorType(bagId, slotIndex) end
--Returns: *[ArmorType|#ArmorType] armorType

function GetItemWeaponType(bagId, slotIndex) end
--Returns: *[WeaponType|#WeaponType] weaponType

function GetItemUniqueId(bagId1, slotIndex1) end
--Returns: *id64:nilable id

function GetSoulGemItemInfo(bagId, slotIndex) end
--Returns: *integer tier, soulGemType

function GetSoulGemInfo(soulGemType, targetLevel, onlyInInventory) end
--Returns: *string name, icon, stackCount, quality

function GetNextGuildBankSlotId(lastSlotId) end
--Returns: *integer:nilable nextSlotId

function GetNextVirtualBagSlotId(lastSlotId) end
--Returns: *integer:nilable nextSlotId

function CanItemBeVirtual(bagId, slotIndex) end
--Returns: *bool canBeVirtualItem

function IsItemPlaceableFurniture(bagId, slotIndex) end
--Returns: *bool isPlaceable

function IsDisplayNameInItemBoPAccountTable(bagId, slotIndex, displayName) end
--Returns: *bool isInTable

function IsItemBoPAndTradeable(bagId, slotIndex) end
--Returns: *bool isBoPAndTradeable

function GetItemBoPTimeRemainingSeconds(bagId, slotIndex) end
--Returns: *integer timeRemainingS

function GetItemBoPTradeableDisplayNamesString(bagId, slotIndex) end
--Returns: *string namesString

function GetItemBoPTradeableNumEligibleNames(bagId, slotIndex) end
--Returns: *integer numNames

function GetItemBoPTradeableEligibleNameByIndex(bagId, slotIndex, nameIndex) end
--Returns: *string name

function HasCraftBagAccess() end
--Returns: *bool hasAccess

function SelectGuildBank(guildId) end

function TransferToGuildBank(sourceBag, sourceSlot) end

function TransferFromGuildBank(slotId) end

function HasAnyJunk(bagId, excludeStolenItems) end
--Returns: *bool hasJunk

function DestroyAllJunk() end

function CanAnyItemsBeStoredInCraftBag(bagId) end
--Returns: *bool canBeStoredInCraftBag

function StowAllVirtualItems() end

function DoesBagHaveSpaceFor(destinationBagId, sourceBagId, sourceSlot) end
--Returns: *bool hasSpace

function DoesBagHaveSpaceForItemLink(destinationBagId, itemLink) end
--Returns: *bool hasSpace

function CanItemBePlayerLocked(bagId, slotIndex) end
--Returns: *bool canBePlayerLocked

function IsItemPlayerLocked(bagId, slotIndex) end
--Returns: *bool playerLocked

function SetItemIsPlayerLocked(bagId, slotIndex, playerLocked) end

function CanItemBeMarkedAsJunk(bagId, slotIndex) end
--Returns: *bool canBeMarkedAsJunk

function IsItemJunk(bagId, slotIndex) end
--Returns: *bool junk

function SetItemIsJunk(bagId, slotIndex, junk) end

function IsItemDyeable(bagId, slotIndex) end
--Returns: *bool dyeable

function AreItemDyeChannelsDyeable(bagId, slotIndex) end
--Returns: *bool primary, secondary, accent

function HasItemInSlot(bagId, slotIndex) end
--Returns: *bool hasItemInSlot

function GetItemLinkName(itemLink) end
--Returns: *string itemName

function GetItemLinkItemType(itemLink) end
--Returns: *[ItemType|#ItemType] itemType, specializedItemType

function GetItemLinkItemUseType(itemLink) end
--Returns: *[ItemUseType|#ItemUseType] onUseType

function GetItemLinkArmorType(itemLink) end
--Returns: *[ArmorType|#ArmorType] armorType

function GetItemLinkWeaponType(itemLink) end
--Returns: *[WeaponType|#WeaponType] weaponType

function GetItemLinkWeaponPower(itemLink) end
--Returns: *integer weaponPower

function GetItemLinkArmorRating(itemLink, considerCondition) end
--Returns: *integer armorRating

function GetItemLinkRequiredLevel(itemLink) end
--Returns: *integer requiredLevel

function GetItemLinkRequiredChampionPoints(itemLink) end
--Returns: *integer requiredChampionPoints

function GetItemLinkValue(itemLink, considerCondition) end
--Returns: *integer value

function GetItemLinkCondition(itemLink) end
--Returns: *integer conditionPercent

function DoesItemLinkHaveArmorDecay(itemLink) end
--Returns: *bool hasArmorDecay

function GetItemLinkMaxEnchantCharges(itemLink) end
--Returns: *integer maxCharges

function GetItemLinkNumEnchantCharges(itemLink) end
--Returns: *integer numCharges

function DoesItemLinkHaveEnchantCharges(itemLink) end
--Returns: *bool hasCharges

function GetItemLinkEnchantInfo(itemLink) end
--Returns: *bool hasCharges, enchantHeader, enchantDescription

function IsItemAffectedByPairedPoison(equipSlot) end
--Returns: *bool hasPairedPoison

function GetItemPairedPoisonInfo(equipSlot) end
--Returns: *bool hasPoison, poisonCount, poisonHeader, poisonItemLink

function GetItemLinkOnUseAbilityInfo(itemLink) end
--Returns: *bool hasAbility, abilityHeader, abilityDescription, cooldown, hasScaling, minLevel, maxLevel, isChampionPoints

function GetItemLinkTraitOnUseAbilityInfo(itemLink, index) end
--Returns: *bool hasAbility, abilityDescription, cooldown, hasScaling, minLevel, maxLevel, isChampionPoints

function GetItemLinkTraitInfo(itemLink) end
--Returns: *[ItemTraitType|#ItemTraitType] traitType, traitDescription, traitSubtype, traitSubtypeName, traitSubtypeDescription

function GetItemLinkSetInfo(itemLink, equipped) end
--Returns: *bool hasSet, setName, numBonuses, numEquipped, maxEquipped

function GetItemLinkSetBonusInfo(itemLink, equipped, index) end
--Returns: *integer numRequired, bonusDescription

function GetItemLinkFlavorText(itemLink) end
--Returns: *string flavorText

function IsItemLinkCrafted(itemLink) end
--Returns: *bool isCrafted

function IsItemLinkVendorTrash(itemLink) end
--Returns: *bool isVendorTrash

function GetItemLinkSiegeMaxHP(itemLink) end
--Returns: *integer maxHP

function GetItemLinkQuality(itemLink) end
--Returns: *[ItemQuality|#ItemQuality] quality

function GetItemLinkSiegeType(itemLink) end
--Returns: *[SiegeType|#SiegeType] siegeType

function IsItemLinkUnique(itemLink) end
--Returns: *bool isUnique

function IsItemLinkUniqueEquipped(itemLink) end
--Returns: *bool isUniqueEquipped

function GetItemLinkEquipType(itemLink) end
--Returns: *[EquipType|#EquipType] equipType

function IsItemLinkConsumable(itemLink) end
--Returns: *bool isConsumable

function GetItemLinkCraftingSkillType(itemLink) end
--Returns: *[TradeskillType|#TradeskillType] tradeskillType

function IsItemLinkEnchantingRune(itemLink) end
--Returns: *bool isEnchantingRune

function GetItemLinkEnchantingRuneName(itemLink) end
--Returns: *bool:nilable known, name

function GetItemLinkEnchantingRuneClassification(itemLink) end
--Returns: *[EnchantingRuneClassification|#EnchantingRuneClassification] runeClassification

function GetItemLinkRequiredCraftingSkillRank(itemLink) end
--Returns: *integer requiredRank

function IsItemLinkBound(itemLink) end
--Returns: *bool isBound

function GetItemLinkBindType(itemLink) end
--Returns: *[BindType|#BindType] bindType

function GetItemLinkGlyphMinLevels(itemLink) end
--Returns: *integer:nilable minLevel, minChampionPoints

function IsItemLinkBook(itemLink) end
--Returns: *bool isBook

function GetItemLinkBookTitle(itemLink) end
--Returns: *string:nilable bookTitle

function IsItemLinkBookKnown(itemLink) end
--Returns: *bool isKnown

function DoesItemLinkStartQuest(itemLink) end
--Returns: *bool startsQuest

function DoesItemLinkFinishQuest(itemLink) end
--Returns: *bool finishesQuest

function IsItemLinkRecipeKnown(itemLink) end
--Returns: *bool isRecipeKnown

function GetItemLinkRecipeResultItemLink(itemLink, linkStyle) end
--Returns: *string link

function GetItemLinkRecipeNumIngredients(itemLink) end
--Returns: *integer numIngredients

function GetItemLinkRecipeIngredientInfo(itemLink, index) end
--Returns: *string ingredientName, amoutInInventoryAndBank

function GetItemLinkRecipeRankRequirement(itemLink) end
--Returns: *integer rankRequirement

function GetItemLinkRecipeQualityRequirement(itemLink) end
--Returns: *integer qualityRequirement

function GetItemLinkReagentTraitInfo(itemLink, index) end
--Returns: *bool:nilable known, name

function GetItemLinkItemStyle(itemLink) end
--Returns: *[ItemStyle|#ItemStyle] style

function GetItemLinkRefinedMaterialItemLink(itemLink, linkStyle) end
--Returns: *string refinedItemLink

function GetItemLinkMaterialLevelDescription(itemLink) end
--Returns: *string levelsDescription

function IsItemLinkOnlyUsableFromQuickslot(itemLink) end
--Returns: *bool onlyUsableFromQuickslot

function IsItemLinkStolen(itemLink) end
--Returns: *bool itemStolen

function IsItemLinkStackable(itemLink) end
--Returns: *bool itemStackable

function GetItemLinkStacks(itemLink) end
--Returns: *integer stackCountBackpack, stackCountBank, stackCountCraftBag

function CanItemLinkBeVirtual(itemLink) end
--Returns: *bool canBeVirtual

function GetItemLinkDyeIds(itemLink) end
--Returns: *integer primaryDefId, secondaryDefId, accentDefId

function GetItemLinkDyeStampId(itemLink) end
--Returns: *integer dyeStampId

function ShouldHideTooltipRequiredLevel(itemLink) end
--Returns: *bool shouldHideLevel

function GetMaxTraits() end
--Returns: *integer maxTraits

function IsItemStolen(bagId, slotIndex) end
--Returns: *bool itemStolen

function AreAnyItemsStolen(bagId) end
--Returns: *bool anyItemsStolen

function GetTelvarStoneMultiplierThresholdIndex() end
--Returns: *luaindex:nilable thresholdIndex

function GetTelvarStoneThresholdAmount(thresholdIndex) end
--Returns: *integer minimumAmount

function GetTelvarStoneMultiplier(thresholdIndex) end
--Returns: *number telvarStoneMultiplier

function IsMaxTelvarStoneMultiplierThreshold(thresholdIndex) end
--Returns: *bool isAtMaxThreshold

function StackBag(bag) end

function CompareBagItemToCurrentlyEquipped(bagId, slotIndex, equipSlot) end

--Returns: *[DerivedStats|#DerivedStats] derivedStat, statDelta

function CompareItemLinkToCurrentlyEquipped(itemLink, equipSlot) end

--Returns: *[DerivedStats|#DerivedStats] derivedStat, statDelta

function GetItemLinkNumItemTags(itemLink) end
--Returns: *integer numItemTags

function GetItemLinkItemTagDescription(itemLink, itemTagIndex) end
--Returns: *string itemTagDescription

function HasCraftBagAutoTransferNotification() end
--Returns: *bool hasTransferNotification

function ClearCraftBagAutoTransferNotification() end

function IsActiveCombatRelatedEquipmentSlot(equipSlot) end
--Returns: *bool isActiveCombatRelatedEquipSlot

function GetEquipmentBonusRating(bagId, equipSlot) end
--Returns: *number equipmentBonusRating

function GetEquipmentBonusThreshold(unitLevel, unitChampionPoints, index) end
--Returns: *number thresholdValue

function PlayItemSound(itemSoundCategory, itemSoundAction) end

function PlayLootSound(audioModelType, closeLootWindow) end

function WhatIsVisualSlotShowing(visualSlot) end
--Returns: *[VisualLayer|#VisualLayer] highestPriorityVisualLayerThatIsShowing

function GetHiddenByStringForVisualLayer(visualLayer) end
--Returns: *string hiddenByString

function WouldEquipmentBeHidden(equipSlot) end
--Returns: *bool isHidden, highestPriorityVisualLayerThatIsShowing

function IsEquipSlotVisualCategoryHidden(equipSlotVisualCategory) end
--Returns: *bool isHidden

function WouldCollectibleBeHidden(collectibleId) end
--Returns: *bool isHidden, highestPriorityVisualLayerThatIsShowing

function DoesCollectibleHaveVisibleAppearance(collectibleId) end
--Returns: *bool hasVisibleAppearance

function GetKioskBidWindowSecondsRemaining() end
--Returns: *integer secondsRemaining

function GetKioskGuildInfo(guildId) end
--Returns: *integer:nilable bankedMoney, existingBidAmount, existingBidIsOnThisKiosk, existingBidKioskName, queryResult

function GetKioskPurchaseCost() end
--Returns: *integer cost

function GuildKioskBid(guildId, bidAmount) end

function GuildKioskPurchase(guildId) end

function GetNumTradingHouseGuilds() end
--Returns: *integer numGuilds

function GetTradingHouseGuildDetails(index) end
--Returns: *integer guildId, guildName, guildAlliance

function GetCurrentTradingHouseGuildDetails() end
--Returns: *integer guildId, guildName, guildAlliance

function CanBuyFromTradingHouse(guildId) end
--Returns: *bool canBuy

function CanSellOnTradingHouse(guildId) end
--Returns: *bool canSell

function GetSelectedTradingHouseGuildId() end
--Returns: *integer:nilable guildId

function SelectTradingHouseGuildId(guildId) end
--Returns: *bool success

function GetTradingHouseListingCounts() end
--Returns: *integer currentListingCount, maxListingCount

function GetTradingHousePostPriceInfo(desiredPostPrice) end
--Returns: *integer listingFee, tradingHouseCut, expectedProfit

function GetTradingHouseListingPercentage() end
--Returns: *number listingPercentage

function GetTradingHouseCutPercentage() end
--Returns: *number cutPercentage

function SetPendingItemPost(bag, slot, quantity) end

function GetPendingItemPost() end
--Returns: *[Bag|#Bag] bag, slot, quantity

function RequestPostItemOnTradingHouse(bag, slot, quantity, postingPrice) end

function SetPendingItemPurchase(index) end

function ClearPendingItemPurchase() end

function ConfirmPendingItemPurchase() end

function ClearAllTradingHouseSearchTerms() end

function SetTradingHouseFilter(filterType, data1, data2, data3, data4, data5, data6, data7, data8) end

function SetTradingHouseFilterRange(filterType, minOrExactValue, maxValue) end

function ExecuteTradingHouseSearch(page, sortField, sortAscending) end

function GetTradingHouseSearchResultItemInfo(index) end
--Returns: *textureName icon, itemName, quality, stackCount, sellerName, timeRemaining, purchasePrice, currencyType

function GetTradingHouseSearchResultItemLink(index, linkStyle) end
--Returns: *string link

function RequestTradingHouseListings() end

function GetNumTradingHouseListings() end
--Returns: *integer numListings

function CancelTradingHouseListing(index) end

function GetTradingHouseListingItemInfo(index) end
--Returns: *textureName icon, itemName, quality, stackCount, sellerName, timeRemaining, purchasePrice

function GetTradingHouseListingItemLink(index, linkStyle) end
--Returns: *string link

function GetEnchantmentSearchCategories(itemType) end

--Returns: *integer category

function GetTradingHouseCooldownRemaining() end
--Returns: *integer cooldownMilliseconds

function SetMapToPlayerLocation() end
--Returns: *[SetMapResultCode|#SetMapResultCode] setMapResult

function DoesCurrentMapMatchMapForPlayerLocation() end
--Returns: *bool matches

function SetMapToMapListIndex(index) end
--Returns: *[SetMapResultCode|#SetMapResultCode] setMapResult

function GetCurrentMapIndex() end
--Returns: *luaindex:nilable index

function GetCyrodiilMapIndex() end
--Returns: *luaindex:nilable index

function GetImperialCityMapIndex() end
--Returns: *luaindex:nilable index

function GetCurrentMapZoneIndex() end
--Returns: *luaindex zoneIndex

function GetZoneNameByIndex(zoneIndex) end
--Returns: *string zoneName

function GetMapNameByIndex(mapIndex) end
--Returns: *string mapName

function GetNumMaps() end
--Returns: *integer numMaps

function MapZoomOut() end
--Returns: *[SetMapResultCode|#SetMapResultCode] setMapResult

function WouldProcessMapClick(normalizedClickX, normalizedClickY) end
--Returns: *bool wouldProcess, resultingMapIndex

function ProcessMapClick(normalizedClickX, normalizedClickY) end
--Returns: *[SetMapResultCode|#SetMapResultCode] setMapResult

function GetMapInfo(index) end
--Returns: *string name, mapType, mapContentType, zoneId, description

function GetZoneDescription(zoneId) end
--Returns: *string description

function GetMapParentCategories(index) end

--Returns: *string categoryName, categoryIndex

function GetMapNumTiles() end
--Returns: *integer numHorizontalTiles, numVerticalTiles

function GetMapTileTexture(tileIndex) end
--Returns: *string tileFilename

function GetMapName() end
--Returns: *string mapName

function GetMapType() end
--Returns: *[UIMapType|#UIMapType] mapType

function GetMapContentType() end
--Returns: *[MapContentType|#MapContentType] mapContentType

function GetMapFilterType() end
--Returns: *[MapFilterType|#MapFilterType] mapFilterType

function GetNumMapLocations() end
--Returns: *integer numMapLocations

function IsMapLocationVisible(locationIndex) end
--Returns: *bool isVisible

function GetMapLocation(locationIndex) end

--Returns: *string locationName, fontSize, colorR, colorG, colorB, normalizedX, normalizedZ

function GetMapLocationIcon(locationIndex) end
--Returns: *string icon, normalizedX, normalizedZ

function GetNumMapLocationTooltipLines(locationIndex) end
--Returns: *integer numLines

function IsMapLocationTooltipLineVisible(locationIndex, tooltipLineIndex) end
--Returns: *bool isVisible

function GetMapLocationTooltipLineInfo(locationIndex, tooltipLineIndex) end
--Returns: *textureName icon, name, grouping, categoryName

function GetMapLocationTooltipHeader(locationIndex) end
--Returns: *string header

function GetMapMouseoverInfo(normalizedMouseX, normalizedMouseY) end
--Returns: *string locationName, textureFile, textureWidthNormalized, textureHeightNormalized, textureXOffsetNormalized, textureYOffsetNormalized

function GetNumMapKeySections() end
--Returns: *integer numSections

function GetMapKeySectionName(sectionIndex) end
--Returns: *string sectionName

function GetNumMapKeySectionSymbols(sectionIndex) end
--Returns: *integer numSymbols

function GetMapKeySectionSymbolInfo(sectionIndex, symbolIndex) end
--Returns: *string name, icon, tooltip

function GetMapFloorInfo() end
--Returns: *luaindex currentFloor, numFloors

function SetMapFloor(desiredFloorIndex) end
--Returns: *[SetMapResultCode|#SetMapResultCode] setMapResult

function PingMap(pingType, mapDisplayType, normalizedX, normalizedZ) end

function RemovePlayerWaypoint() end

function RemoveRallyPoint() end

function GenerateUnitNameTooltipLine(unitTag) end
--Returns: *string text, interfaceColorType, color

function GenerateQuestEndingTooltipLine(questIndex) end
--Returns: *string text, interfaceColorType, color

function GenerateQuestConditionTooltipLine(questIndex, stepIndex, conditionIndex) end
--Returns: *string text, interfaceColorType, color

function GenerateMapPingTooltipLine(mapPingType, unitTag) end
--Returns: *string text, interfaceColorType, color

function GenerateAvAObjectiveConditionTooltipLine(bgQueryType, keepId, objectiveId, isSpawnPosition) end
--Returns: *string text, interfaceColorType, color

function GetNumPOIs(zoneIndex) end
--Returns: *integer numPOIs

function GetPOIInfo(zoneIndex, poiIndex) end
--Returns: *string objectiveName, objectiveLevel, startDescription, finishedDescription

function IsPOIWayshrine(zoneIndex, poiIndex) end
--Returns: *bool isWayshrine

function IsPOIPublicDungeon(zoneIndex, poiIndex) end
--Returns: *bool isPublicDungeon

function IsPOIGroupDungeon(zoneIndex, poiIndex) end
--Returns: *bool isGroupDungeon

function GetPOIMapInfo(zoneIndex, poiIndex) end
--Returns: *number normalizedX, normalizedZ, poiType, icon, isShownInCurrentMap, linkedCollectibleIsLocked

function GetCurrentSubZonePOIIndices() end
--Returns: *luaindex:nilable zoneIndex, poiIndex

function IsInCyrodiil() end
--Returns: *bool isInCyrodiil

function IsInImperialCity() end
--Returns: *bool isInImperialCity

function IsInAvAZone() end
--Returns: *bool isInAvAZone

function IsInOutlawZone() end
--Returns: *bool isInOutlawZone

function IsInJusticeEnabledZone() end
--Returns: *bool isInJusticeZone

function IsInTutorialZone() end
--Returns: *bool isInTutorialZone

function CanLeaveCurrentLocationViaTeleport() end
--Returns: *bool canLeaveCurrentLocationViaTeleport

function DoesCurrentZoneAllowScalingByLevel() end
--Returns: *bool allowsScaling

function DoesCurrentZoneHaveTelvarStoneBehavior() end
--Returns: *bool telvarBehaviorEnabled

function DoesCurrentZoneAllowBattleLevelScaling() end
--Returns: *bool allowsBattleLevelScaling

function GetCurrentZoneLevelScalingConstraints() end
--Returns: *[ScaleLevelConstraintType|#ScaleLevelConstraintType] scaleLevelContraintType, minScaleLevel, maxScaleLevel

function GetCollectibleIdForZone(zoneIndex) end
--Returns: *integer collectibleId

function GetZoneId(zoneIndex) end
--Returns: *integer zoneId

function GetZoneIndex(zoneId) end
--Returns: *luaindex zoneIndex

function GetCadwellProgressionLevel() end
--Returns: *[CadwellProgressionLevel|#CadwellProgressionLevel] cadwellProgressionLevel

function GetNumZonesForCadwellProgressionLevel(cadwellProgressionLevel) end
--Returns: *integer numZones

function GetCadwellZoneInfo(cadwellProgressionLevel, zoneIndex) end
--Returns: *string zoneName, zoneDescription, zoneOrder

function GetNumPOIsForCadwellProgressionLevelAndZone(cadwellProgressionLevel, zoneIndex) end
--Returns: *integer numPOIs

function GetCadwellZonePOIInfo(cadwellProgressionLevel, zoneIndex, poiIndex) end
--Returns: *string poiName, poiOpeningText, poiClosingText, poiOrder, discovered, completed

function GetPlayerActiveSubzoneName() end
--Returns: *string subzoneName

function GetPlayerActiveZoneName() end
--Returns: *string zoneName

function GetPlayerLocationName() end
--Returns: *string mapName

function CanJumpToPlayerInZone(zoneId) end
--Returns: *bool canJump, result

function GetHistoricalKeepTravelNetworkLinkInfo(linkIndex, bgContext, historyPercent) end
--Returns: *integer linkType, linkOwner, restricedToAlliance, startX, startY, endX, endY

function GetNumFastTravelNodes() end
--Returns: *integer numFastTravelNodes

function GetFastTravelNodeInfo(nodeIndex) end
--Returns: *bool known, name, normalizedX, normalizedY, icon, glowIcon, poiType, isShownInCurrentMap, linkedCollectibleIsLocked

function GetFastTravelNodeOutboundOnlyInfo(nodeIndex) end
--Returns: *bool isOutboundOnly, errorStringId

function GetFastTravelNodeDrawLevelOffset(nodeIndex) end
--Returns: *integer drawLevelOffset

function GetFastTravelNodeLinkedCollectibleId(nodeIndex) end
--Returns: *integer collectibleId

function FastTravelToNode(nodeIndex) end

function GetRecallCost(nodeIndex) end
--Returns: *integer cost

function GetRecallCurrency(nodeIndex) end
--Returns: *[CurrencyType|#CurrencyType] currency

function GetKeepArtifactObjectiveId(keepId) end
--Returns: *integer objectiveId

function GetHistoricalAvAObjectivePinInfo(keepId, objectiveId, battlegroundContext, historyPercent) end
--Returns: *integer pinType, currentNormalizedX, currentNormalizedY, continuousUpdate

function IsInCampaign() end
--Returns: *bool inCampaign

function DoesCampaignHaveEmperor(campaignId) end
--Returns: *bool hasEmperor

function GetCampaignEmperorInfo(campaignId) end
--Returns: *integer emperorAlliance, emperorCharacterName, emperorDisplayName

function GetCampaignEmperorReignDuration(campaignId) end
--Returns: *integer durationInSeconds

function GetCampaignAbdicationStatus(campaignId) end
--Returns: *integer abdicatedAlliance, abdicatedCharacterName, abdicatedDisplayName

function GetEmperorAllianceBonusInfo(campaignId, alliance) end
--Returns: *string name, icon, description

function GetCampaignReassignCooldown() end
--Returns: *integer cooldownSeconds

function GetCampaignGuestCooldown() end
--Returns: *integer cooldownSeconds

function GetCampaignReassignCost(reassignType) end
--Returns: *integer cost

function GetCurrentCampaignId() end
--Returns: *integer currentCampaignId

function GetAssignedCampaignId() end
--Returns: *integer assignedCampaignId

function GetGuestCampaignId() end
--Returns: *integer campaignId

function GetNumFreeAnytimeCampaignReassigns() end
--Returns: *integer reassignCount

function GetNumFreeEndCampaignReassigns() end
--Returns: *integer reassignCount

function GetPreferredCampaign() end
--Returns: *integer preferredCampaign

function GetCampaignPreference() end
--Returns: *[CampaignPreferenceType|#CampaignPreferenceType] campaignPreference

function SetCampaignPreference(campaignPreference) end

function AssignCampaignToPlayer(campaignId, reassignOnEnd) end

function GetCampaignUnassignCooldown() end
--Returns: *integer cooldownSeconds

function GetCampaignUnassignCost(campaignUnassignType) end
--Returns: *integer cost

function GetNumFreeAnytimeCampaignUnassigns() end
--Returns: *integer unassignCount

function UnassignCampaignForPlayer(campaignUnassignType) end

function QueryCampaignSelectionData() end

function GetCampaignSequenceId(campaignId) end
--Returns: *integer sequenceId

function QueryCampaignLeaderboardData() end

function GetLeaderboardCampaignSequenceId(campaignId) end
--Returns: *integer campaignSequenceId

function GetCampaignLeaderboardMaxRank(campaignId) end
--Returns: *integer maxRank

function GetNumCampaignLeaderboardEntries(campaignId) end
--Returns: *integer entryCount

function GetNumCampaignAllianceLeaderboardEntries(campaignId, allianceId) end
--Returns: *integer entryCount

function GetCampaignLeaderboardEntryInfo(campaignId, entryIndex) end
--Returns: *bool isPlayer, ranking, charName, alliancePoints, classId, allianceId, displayName

function GetCampaignAllianceLeaderboardEntryInfo(campaignId, allianceId, entryIndex) end
--Returns: *bool isPlayer, ranking, charName, alliancePoints, classId, displayName

function GetPlayerCampaignRewardTierInfo(campaignId) end
--Returns: *integer earnedTier, nextTierProgress, nextTierTotal

function GetNumSelectionCampaigns() end
--Returns: *integer campaignCount

function GetSelectionCampaignAllianceScore(campaignIndex, alliance) end
--Returns: *integer score

function GetSelectionCampaignId(campaignIndex) end
--Returns: *integer campaignId

function GetSelectionCampaignTimes(campaignIndex) end
--Returns: *integer secondsUntilCampaignStart, secondsUntilCampaignEnd

function GetSelectionCampaignUnderdogLeaderAlliance(campaignIndex) end
--Returns: *integer alliance

function GetNumSelectionCampaignFriends(campaignIndex) end
--Returns: *integer numFriends

function GetNumSelectionCampaignGuildMembers(campaignIndex) end
--Returns: *integer numGuilds

function GetNumSelectionCampaignGroupMembers(campaignIndex) end
--Returns: *integer numGroupmates

function GetSelectionCampaignPopulationData(campaignIndex, alliance) end
--Returns: *[CampaignPopulationType|#CampaignPopulationType] currentPopulationEstimate

function GetSelectionCampaignQueueWaitTime(campaignIndex) end
--Returns: *integer queueWaitTimeSeconds

function DoesPlayerMeetCampaignRequirements(campaignId) end
--Returns: *bool meetsJoiningRequirements

function GetCampaignRulesetId(campaignId) end
--Returns: *integer rulesetId

function GetCampaignRulesetName(campaignId) end
--Returns: *string name

function GetCampaignRulesetType(rulesetId) end
--Returns: *[CampaignRulesetType|#CampaignRulesetType] rulesetType

function GetCampaignRulesetDescription(rulesetId) end
--Returns: *string description

function GetNumCampaignSocialConnections() end
--Returns: *integer connectionCount

function GetCurrentCampaignLoyaltyStreak() end
--Returns: *integer currentLoyaltyStreak

function GetCampaignRulesetNumImperialKeeps(rulesetId, alliance) end
--Returns: *integer numKeeps

function GetCampaignRulesetImperialKeepId(rulesetId, alliance, index) end
--Returns: *integer keepId

function GetCampaignRulesetImperialAccessRule(rulesetId) end
--Returns: *[ImperialCityAccessRulesType|#ImperialCityAccessRulesType] accessRuleType

function GetCampaignRulsetMinEmperorAlliancePoints(rulesetId, alliance) end
--Returns: *integer minPoints

function GetCampaignRulesetDurationInSeconds(rulesetId) end
--Returns: *integer duration

function DoesCurrentCampaignRulesetAllowChampionPoints() end
--Returns: *bool isNoChampionPointsCampaign

function RegisterForAssignedCampaignData() end

function UnregisterForAssignedCampaignData() end

function ResetCampaignHistoryWindow(battlegroundContext, currentHistoryPercent) end
--Returns: *bool requiresRebuild

function GetCampaignHistoryWindow(battlegroundContext) end
--Returns: *integer windowStartSecsAgo, windowEndSecsAgo

function DoesHistoryRequireMapRebuild(battlegroundContext, oldHistoryPercent, newHistoryPercent) end
--Returns: *bool needsRebuild

function DoesAllianceHaveImperialCityAccess(campaignId, alliance) end
--Returns: *bool hasAccess

function IsUnderpopBonusEnabled(campaignId, alliance) end
--Returns: *bool isBonusEnabled

function IsLocalBattlegroundContext(battlegroundContext) end
--Returns: *bool isLocal

function IsAssignedBattlegroundContext(battlegroundContext) end
--Returns: *bool isAssigned

function DoBattlegroundContextsIntersect(context1, context2) end
--Returns: *bool intersects

function QueueForCampaign(campaignId, queueAsGroup) end

function LeaveCampaignQueue(campaignId, queueAsGroup) end

function GetNumCampaignQueueEntries() end
--Returns: *integer entryCount

function IsQueuedForCampaign(campaignId, queueAsGroup) end
--Returns: *bool isQueued

function GetCampaignQueueEntry(entryIndex) end
--Returns: *integer campaignId, queueAsGroup

function GetSecondsInCampaignQueue(campaignId, queueAsGroup) end
--Returns: *integer timeInQueueInSeconds

function GetCampaignQueuePosition(campaignId, queueAsGroup) end
--Returns: *integer queuePosition

function GetCampaignQueueRemainingConfirmationSeconds(campaignId, queueAsGroup) end
--Returns: *integer confirmationTimeRemainingInSeconds

function GetCampaignQueueState(campaignId, queueAsGroup) end
--Returns: *[CampaignQueueRequestStateType|#CampaignQueueRequestStateType] currentState

function ConfirmCampaignEntry(campaignId, queueAsGroup, accept) end

function GetCampaignQueueConfirmationDuration() end
--Returns: *integer numSeconds

function GetStoreEntryInfo(entryIndex) end
--Returns: *textureName icon, name, stack, price, sellPrice, meetsRequirementsToBuy, meetsRequirementsToUse, quality, questNameColor, currencyType1, currencyQuantity1, currencyType2, currencyQuantity2, entryType

function GetStoreCollectibleInfo(entryIndex) end
--Returns: *integer collectibleId, locked

function GetNumStoreItems() end
--Returns: *integer numItems

function GetNumBuybackItems() end
--Returns: *integer numBuybackItems

function GetStoreCurrencyTypes() end
--Returns: *bool usesMoney, usesAlliancePoints, usesTelvarStones

function GetStoreItemLink(entryIndex, linkStyle) end
--Returns: *string link

function GetStoreEntryTypeInfo(entryIndex) end

--Returns: *integer itemType

function GetStoreEntryStatValue(entryIndex) end
--Returns: *integer statValue

function GetStoreEntryMaxBuyable(entryIndex) end
--Returns: *integer quantity

function GetBuybackItemInfo(entryIndex) end
--Returns: *textureName icon, name, stack, price, quality, meetsRequirementsToEquip

function GetBuybackItemLink(entryIndex, linkStyle) end
--Returns: *string link

function BuyStoreItem(entryIndex, quantity) end

function BuybackItem(entryIndex) end

function SellInventoryItem(bagId, slotIndex, quantity) end

function SellAllJunk() end

function CloseStore() end

function RepairAll() end

function RepairItem(bagId, slotIndex) end

function LaunderItem(bagId, slotIndex, quantity) end

function IsStoreEmpty() end
--Returns: *bool isEmpty

function CanStoreRepair() end
--Returns: *bool canRepair

function LootAll(ignoreStolenItems) end

function GetLootItemLink(lootId, linkStyle) end
--Returns: *string link

function LootItemById(lootId) end

function LootCurrency(type) end

function LootMoney() end

function EndLooting() end

function IsLooting() end
--Returns: *bool isLooting

function GetLootTargetInfo() end
--Returns: *string name, targetType, actionName, isOwned

function GetLootItemInfo(lootIndex) end
--Returns: *integer lootId, name, icon, count, quality, value, isQuest, stolen

function GetLootCurrency(type) end
--Returns: *integer unownedCurrency, ownedCurrency

function GetLootMoney() end
--Returns: *integer unownedMoney, ownedMoney

function GetQuestLootItemTooltipInfo(lootId) end
--Returns: *string header, itemName, tooltipText

function GetKeepType(keepId) end
--Returns: *integer keepType

function GetNumKeeps() end
--Returns: *integer numKeeps

function GetAvAKeepScore(campaignId, alliance) end
--Returns: *bool isAllianceHoldingAllNativeKeeps, numEnemyKeepsThisAllianceHolds, numNativeKeepsThisAllianceHolds, totalNativeKeepsInThisAlliancesArea

function GetAvAKeepsHeld(campaignId, alliance) end
--Returns: *integer keepsHeld

function GetNumKeepScoreBonuses() end
--Returns: *integer numBonuses

function GetKeepScoreBonusInfo(index) end
--Returns: *string name, icon, description

function GetKeepPinInfo(keepId, battlegroundContext) end
--Returns: *integer pinType, normalizedX, normalizedY

function GetKeepName(keepId) end
--Returns: *string keepName

function GetKeepAlliance(keepId, battlegroundContext) end
--Returns: *integer alliance

function GetResourceKeepForKeep(parentKeepId, resourceType) end
--Returns: *integer keepId

function GetKeepResourceLevel(keepId, battlegroundContext, resourceType) end
--Returns: *integer resourceLevel

function GetKeepResourceType(keepId) end
--Returns: *[KeepResourceType|#KeepResourceType] resourceType

function GetKeepResourceInfo(keepId, battlegroundContext, resourceType, level) end
--Returns: *integer currentAmount, amountForNextLevel, upkeepPerMinute

function GetKeepUpgradeInfo(keepId, battlegroundContext, upgradePath, level) end
--Returns: *integer currentAmount, amountForNextLevel, upkeepPerMinute

function GetKeepProductionLevel(keepId, battlegroundContext) end
--Returns: *integer productionLevel

function GetKeepDefensiveLevel(keepId, battlegroundContext) end
--Returns: *integer defensiveLevel

function GetSecondsUntilKeepClaimAvailable(keepId, battlegroundContext) end
--Returns: *integer secondsUntilAvailable

function GetGuildClaimInteractionKeepId() end
--Returns: *integer keepId

function GetGuildReleaseInteractionKeepId() end
--Returns: *integer keepId

function CancelKeepGuildClaimInteraction() end

function CancelKeepGuildReleaseInteraction() end

function GetHistoricalKeepUnderAttack(keepId, battlegroundContext, historyPercent) end
--Returns: *bool underAttack

function GetHistoricalKeepPinInfo(keepId, battlegroundContext, historyPercent) end
--Returns: *integer pinType, normalizedX, normalizedY

function GetHistoricalKeepAlliance(keepId, battlegroundContext, historyPercent) end
--Returns: *integer alliance

function GetInteractionKeepId() end
--Returns: *integer keepId

function GetKeepUnderAttack(keepId, battlegroundContext) end
--Returns: *bool underAttack

function GetKeepUpgradeRate(keepId, battlegroundContext, upgradeLine) end
--Returns: *integer rate

function GetClaimedKeepGuildName(keepId, battlegroundContext) end
--Returns: *string guildName

function GetMaxKeepSieges(keepId, battlegroundContext) end
--Returns: *integer maxSiege

function GetMaxKeepNPCs(keepId, battlegroundContext) end
--Returns: *integer maxNPC

function GetNumFriendlyKeepNPCs(keepId, battlegroundContext) end
--Returns: *integer numFriendlyNPC

function GetNumSieges(keepId, battlegroundContext, alliance) end
--Returns: *integer numSieges

function GetKeepKeysByIndex(index) end
--Returns: *integer keepId, battlegroundContext

function IsKeepTypeClaimable(keepType) end
--Returns: *bool isClaimable

function GetDistrictOwnershipTelVarBonusPercent(keepId, battlegroundContext) end
--Returns: *integer districtOwnershipTelVarBonusPercent

function DoesKeepPassCompassVisibilitySubzoneCheck(keepId, battlegroundContext) end
--Returns: *bool doesPassVisibilityCheck

function GetNumTitles() end
--Returns: *integer titleCount

function GetTitle(titleIndex) end
--Returns: *string titleString

function GetCurrentTitleIndex() end
--Returns: *luaindex:nilable titleIndex

function SelectTitle(titleIndex) end

function AcceptResurrect() end

function DeclineResurrect() end

function IsResurrectPending() end
--Returns: *bool resurrectPending

function GetPendingResurrectInfo() end
--Returns: *string casterName, timeLeft, casterDisplayName

function GetDeathInfo() end
--Returns: *integer timeUntilRevive, timeUntilAutoRelease, corpseSummonTime, isPenaltyTooHighToRevive, encounterIsInProgress, isAVADeath, isBattleGroundDeath, isReleaseOnly, soulGemAvailable, freeRevive, isRaidDeath, isImperialCityLocked, cyclicRespawnQueueDuration, cyclicRespawnQueueTimeLeft

function Revive() end

function Release() end

function JoinRespawnQueue() end

function IsQueuedForCyclicRespawn() end
--Returns: *bool queuedForRespawn

function RespawnAtKeep(keepId) end

function IsDuelingDeath() end
--Returns: *bool duelingDeath

function RespawnAtForwardCamp(index) end

function GetNumForwardCamps(battlegroundContext) end
--Returns: *integer num

function GetForwardCampPinInfo(battlegroundContext, index) end
--Returns: *integer pinType, normalizedX, normalizedY, normalizedRadius, useable

function IsForwardCampGuildOwned(battlegroundContext, index) end
--Returns: *bool isGuildOwned

function GetForwardCampOwnerName(battlegroundContext, index) end
--Returns: *string guildName

function GetNextForwardCampRespawnTime() end
--Returns: *integer nextForwardCampRespawnTime

function GetNumBattleStandards(battlegroundContext) end
--Returns: *integer num

function GetBattleStandardPinInfo(battlegroundContext, index) end
--Returns: *integer pinType, normalizedX, normalizedY

function GetBattleStandardGuildName(battlegroundContext, index) end
--Returns: *string guildName

function GetDuelInfo() end
--Returns: *[DuelState|#DuelState] duelState, partnerCharacterName, partnerDisplayName

function ChallengeTargetToDuel(characterOrDisplayName) end

function AcceptDuel() end

function DeclineDuel() end

function IsNearDuelBoundary() end
--Returns: *bool isNearBoundary

function TradeInvite(target) end

function TradeInviteByName(playerName) end

function TradeInviteAccept() end

function TradeInviteDecline() end

function GetTradeInviteInfo() end
--Returns: *string characterName, millisecondsSinceRequest, displayName

function TradeSetMoney(amount) end

function TradeInviteCancel() end

function TradeCancel() end

function TradeAccept() end

function TradeEdit() end

function TradeAddItem(bagId, slotIndex, tradeIndex) end

function TradeRemoveItem(tradeIndex) end

function GetTradeItemInfo(who, tradeIndex) end
--Returns: *string name, icon, stack, quality, creatorName, sellPrice, meetsUsageRequirement, equipType, itemStyle

function IsTradeItemBoPAndTradeable(who, tradeIndex) end
--Returns: *bool isBoPAndTradeable

function GetTradeItemBoPTimeRemainingSeconds(who, tradeIndex) end
--Returns: *integer timeRemainingS

function GetTradeItemBoPTradeableDisplayNamesString(who, tradeIndex) end
--Returns: *string namesString

function GetTradeItemBagAndSlot(who, tradeIndex) end
--Returns: *[Bag|#Bag]:nilable bagId, slotIndex

function GetTradeItemLink(who, tradeIndex, linkStyle) end
--Returns: *string link

function GetTradeMoneyOffer(who) end
--Returns: *integer moneyOffer

function StartMapPinAnimation(animationTimeline, animationTarget, limitToMapType, pinType, param1, param2, param3, playOffset, ignoreBreadcrumbs) end
--Returns: *bool played

function IsPlayerInsidePinArea(pinType, param1, param2, param3) end
--Returns: *bool isPlayerInside

function RemoveMapPinsInRange(startType, endType, param1, param2, param3) end

function AssistedQuestPinForTracked(trackedPinType) end
--Returns: *[MapDisplayPinType|#MapDisplayPinType] assistedPinType

function TrackedQuestPinForAssisted(assistedPinType) end
--Returns: *[MapDisplayPinType|#MapDisplayPinType] trackedPinType

function GetAvailableSkillPoints() end
--Returns: *integer numPoints

function GetNumSkyShards() end
--Returns: *integer numShards

function GetNumSkillTypes() end
--Returns: *integer numSkillTypes

function GetNumSkillLines(skillType) end
--Returns: *integer numSkillLines

function GetSkillLineInfo(skillType, skillIndex) end
--Returns: *string name, rank

function GetSkillLineXPInfo(skillType, skillIndex) end
--Returns: *integer lastRankXP, nextRankXP, currentXP

function GetSkillLineRankXPExtents(skillType, skillIndex, rank) end
--Returns: *integer:nilable startXP, nextRankStartXP

function GetNumSkillAbilities(skillType, skillIndex) end
--Returns: *integer numAbilities

function GetSkillAbilityInfo(skillType, skillIndex, abilityIndex) end
--Returns: *string name, texture, earnedRank, passive, ultimate, purchased, progressionIndex

function GetSkillAbilityId(skillType, skillIndex, abilityIndex, showUpgrade) end
--Returns: *integer abilityId

function GetSkillAbilityUpgradeInfo(skillType, skillIndex, abilityIndex) end
--Returns: *integer:nilable currentUpgradeLevel, maxUpgradeLevel

function GetSkillAbilityNextUpgradeInfo(skillType, skillIndex, abilityIndex) end
--Returns: *string name, texture, earnedRank

function GetCraftingSkillLineIndices(craftingSkillType) end
--Returns: *[SkillType|#SkillType] skillType, skillIndex

function PutPointIntoSkillAbility(skillType, skillIndex, index, putPointInNextUpgrade) end

function GetSkillAbilityIndicesFromProgressionIndex(progressionIndex) end
--Returns: *[SkillType|#SkillType] skillType, skillIndex, abilityIndex

function IsWerewolfSkillLine(skillType, skillLineIndex) end
--Returns: *bool isWerewolfSkillLine

function IsLocalMailboxFull() end
--Returns: *bool isFull

function GetNumMailItems() end
--Returns: *integer numMail

function GetNextMailId(lastMailId) end
--Returns: *id64:nilable nextMailId

function GetMailItemInfo(mailId) end
--Returns: *string senderDisplayName, senderCharacterName, subject, icon, unread, fromSystem, fromCustomerService, returned, numAttachments, attachedMoney, codAmount, expiresInDays, secsSinceReceived

function GetMailSender(mailId) end
--Returns: *string senderDisplayName, senderCharacterName

function GetMailAttachmentInfo(mailId) end
--Returns: *integer numAttachments, attachedMoney, codAmount

function GetMailFlags(mailId) end
--Returns: *bool unread, returned, fromSystem, fromCustomerService

function SendMail(to, subject, body) end

function GetQueuedMailPostage() end
--Returns: *integer postage

function ClearQueuedMail() end

function CloseMailbox() end

function RequestReadMail(mailId) end

function DeleteMail(mailId, forceDelete) end

function IsMailReturnable(mailId) end
--Returns: *bool isReturnable

function ReturnMail(mailId) end

function ReadMail(mailId) end
--Returns: *string body

function HasUnreadMail() end
--Returns: *bool unread

function GetNumUnreadMail() end
--Returns: *integer numUnread

function CanQueueItemAttachment(bagId, slotIndex, attachmentSlot) end
--Returns: *bool canAttach

function RemoveQueuedItemAttachment(attachmentSlot) end

function QueueMoneyAttachment(amount) end

function GetQueuedMoneyAttachment() end
--Returns: *integer amount

function QueueCOD(amount) end

function GetQueuedCOD() end
--Returns: *integer amount

function GetMailQueuedAttachmentLink(attachmentSlot, linkStyle) end
--Returns: *string link

function GetQueuedItemAttachmentInfo(attachmentSlot) end
--Returns: *integer bagId, slotIndex, icon, stack

function GetAttachedItemLink(mailId, attachIndex, linkStyle) end
--Returns: *string link

function GetAttachedItemInfo(mailId, attachIndex) end
--Returns: *textureName icon, stack, creatorName, sellPrice, meetsUsageRequirement, equipType, itemStyle, quality

function TakeMailAttachedItems(mailId) end

function TakeMailAttachedMoney(mailId) end

function RequestOpenMailbox() end

function IsReadMailInfoReady(mailId) end
--Returns: *bool isReady

function GetNumCollectibleCategories() end
--Returns: *integer numCategories

function GetCollectibleCategoryInfo(topLevelIndex) end
--Returns: *string name, numSubCatgories, numCollectibles, unlockedCollectibles, totalCollectibles, hidesLocked

function GetCollectibleCategoryKeyboardIcons(categoryIndex) end
--Returns: *textureName normalIcon, pressedIcon, mouseoverIcon

function GetCollectibleCategoryGamepadIcon(categoryIndex) end
--Returns: *textureName gamepadIcon

function GetCollectibleSubCategoryInfo(topLevelIndex, subCategoryIndex) end
--Returns: *string name, numCollectibles, unlockedCollectibles, totalCollectibles

function GetUnlockedCollectiblesCount() end
--Returns: *integer count

function GetTotalCollectiblesCount() end
--Returns: *integer count

function GetCollectibleId(topLevelIndex, categoryIndex, collectibleIndex) end
--Returns: *integer collectibleId

function GetCollectibleInfo(collectibleId) end
--Returns: *string name, description, icon, lockedIcon, unlocked, purchasable, isActive, categoryType, hint, isPlaceholder

function GetCollectibleKeyboardBackgroundImage(collectibleId) end
--Returns: *textureName backgroundImage

function GetCollectibleGamepadBackgroundImage(collectibleId) end
--Returns: *textureName backgroundImage

function GetCategoryInfoFromCollectibleId(collectibleId) end
--Returns: *luaindex:nilable topLevelIndex, categoryIndex, collectibleIndex

function GetTotalCollectiblesByCategoryType(collectibleCategoryType) end
--Returns: *integer count

function GetCollectibleIdFromType(collectibleCategoryType, index) end
--Returns: *integer collectibleId

function IsCollectibleCategorySlottable(collectibleCategoryType) end
--Returns: *bool isSlottable

function IsCollectibleCategoryUsable(collectibleCategoryType) end
--Returns: *bool isUsable

function IsCollectibleCategoryPlaceableFurniture(collectibleCategoryType) end
--Returns: *bool isPlaceable

function IsCollectibleBlocked(collectibleId) end
--Returns: *bool isBlocked

function IsCollectibleValidForPlayer(collectibleId) end
--Returns: *bool isValidForPlayer

function GetCollectibleBlockReason(collectibleId) end
--Returns: *[CollectibleUsageBlockReason|#CollectibleUsageBlockReason] usageBlockReason

function IsCollectibleSlottable(collectibleId) end
--Returns: *bool isSlottable

function IsCollectibleUsable(collectibleId) end
--Returns: *bool isUsable

function IsCollectibleRenameable(collectibleId) end
--Returns: *bool isRenameable

function IsCollectiblePlaceholder(collectibleId) end
--Returns: *bool isPlaceholder

function UseCollectible(collectibleId) end

function GetCollectibleLink(collectibleId, linkStyle) end
--Returns: *string link

function GetCollectibleCategoryTypeFromLink(link) end
--Returns: *[CollectibleCategoryType|#CollectibleCategoryType] categoryType

function GetCollectibleIdFromLink(link) end
--Returns: *integer:nilable collectibleId

function StartCollectibleSearch(searchString) end

function GetNumCollectiblesSearchResults() end
--Returns: *integer numSearchResults

function GetCollectiblesSearchResult(searchResultIndex) end
--Returns: *luaindex categoryIndex, subcategoryIndex, collectibleIndex

function IsValidCollectibleName(collectibleName) end

--Returns: *integer violationCode

function RenameCollectible(collectibleId, name) end

function GetCollectibleNickname(collectibleId) end
--Returns: *string name

function GetCollectibleHelpIndices(collectibleId) end
--Returns: *luaindex:nilable helpCategoryIndex, helpIndex

function IsCollectibleNew(collectibleId) end
--Returns: *bool isNew

function ClearCollectibleNewStatus(collectibleId) end

function GetNumCollectibleNotifications() end
--Returns: *integer count

function GetCollectibleNotificationInfo(notificationIndex) end
--Returns: *integer notificationId, collectibleId

function RemoveCollectibleNotification(notificationId) end

function RemoveCollectibleNotificationByCollectibleId(collectibleId) end

function GetCollectibleUnlockStateById(collectibleId) end
--Returns: *[CollectibleUnlockState|#CollectibleUnlockState] unlockState

function GetCollectibleName(collectibleId) end
--Returns: *string name

function IsCollectibleUnlocked(collectibleId) end
--Returns: *bool isUnlocked

function GetImperialCityCollectibleId() end
--Returns: *integer collectibleId

function GetCollectibleQuestPreviewInfo(collectibleId) end
--Returns: *string questName, backgroundText

function GetActiveCollectibleByType(categoryType) end
--Returns: *integer collectibleId

function GetCollectibleCooldownAndDuration(collectibleId) end
--Returns: *integer cooldownRemaining, cooldownDuration

function GetCollectiblePersonalityOverridenEmoteDisplayNames(collectibleId) end

--Returns: *string overriddenEmoteDisplayName

function GetCollectiblePersonalityOverridenEmoteSlashCommandNames(collectibleId) end

--Returns: *string overriddenEmoteSlashCommandName

function GetCollectibleRestrictionsByType(collectibleId, restrictionType) end
--Returns: *bool hasRestrictions, passesRestrictions, allowedNamesString

function GetNumAchievementCategories() end
--Returns: *integer numCategories

function GetAchievementCategoryInfo(topLevelIndex) end
--Returns: *string name, numSubCatgories, numAchievements, earnedPoints, totalPoints, hidesPoints

function GetAchievementSubCategoryInfo(topLevelIndex, subCategoryIndex) end
--Returns: *string name, numAchievements, earnedPoints, totalPoints, hidesPoints

function GetAchievementCategoryKeyboardIcons(categoryIndex) end
--Returns: *textureName normalIcon, pressedIcon, mouseoverIcon

function GetAchievementCategoryGamepadIcon(categoryIndex) end
--Returns: *textureName gamepadIcon

function GetEarnedAchievementPoints() end
--Returns: *integer points

function GetTotalAchievementPoints() end
--Returns: *integer points

function GetAchievementId(topLevelIndex, categoryIndex, achievementIndex) end
--Returns: *integer achievementId

function GetAchievementInfo(achievementId) end
--Returns: *string name, description, points, icon, completed, date, time

function IsAchievementComplete(achievementId) end
--Returns: *bool completed

function GetAchievementNumRewards(achievementId) end
--Returns: *integer numRewards

function GetAchievementItemLink(achievementId, linkStyle) end
--Returns: *string link

function GetAchievementNumCriteria(achievementId) end
--Returns: *integer numCriteria

function GetAchievementCriterion(achievementId, criterionIndex) end
--Returns: *string description, numCompleted, numRequired

function GetRecentlyCompletedAchievements(numAchievementsToGet) end

--Returns: *integer achievementId

function GetCategoryInfoFromAchievementId(achievementId) end
--Returns: *luaindex:nilable topLevelIndex, categoryIndex, achievementIndex, offsetFromParent

function GetFirstAchievementInLine(achievementId) end
--Returns: *integer firstAchievementId

function GetNextAchievementInLine(achievementId) end
--Returns: *integer nextAchievementId

function GetPreviousAchievementInLine(achievementId) end
--Returns: *integer previousAchievementId

function GetAchievementLink(achievementId, linkStyle) end
--Returns: *string link

function GetAchievementIdFromLink(link) end
--Returns: *integer achievementId

function GetAchievementNameFromLink(link) end
--Returns: *string name

function GetAchievementProgressFromLinkData(achievementId, progress) end

--Returns: *integer numCompleted

function GetAchievementRewardPoints(achievementId) end
--Returns: *integer points

function GetAchievementRewardItem(achievementId) end
--Returns: *bool hasRewardOfType, itemName, iconTextureName, quality

function GetAchievementRewardTitle(achievementId) end
--Returns: *bool hasRewardOfType, titleName

function GetAchievementRewardDye(achievementId) end
--Returns: *bool hasRewardOfType, dyeId

function GetAchievementRewardCollectible(achievementId) end
--Returns: *bool hasRewardOfType, collectibleId

function GetNumExperiencePointsInLevel(level) end
--Returns: *integer:nilable numXP

function GetEnlightenedMultiplier() end
--Returns: *number multiplier

function GetEnlightenedPool() end
--Returns: *integer poolAmount

function IsEnlightenedAvailableForAccount() end
--Returns: *bool availableForAccount

function IsEnlightenedAvailableForCharacter() end
--Returns: *bool availableForCharacter

function GetNumChampionXPInChampionPoint(championPointsEarned) end
--Returns: *integer:nilable maxExp

function GetMaxSpendableChampionPointsInAttribute() end
--Returns: *integer maxSpendableChampionPointsInAttribute

function GetMaxLevel() end
--Returns: *integer maxLevel

function GetChampionPointsPlayerProgressionCap() end
--Returns: *integer maxRank

function GetAbilityProgressionAbilityId(progressionIndex, morph, rank) end
--Returns: *integer abilityId

function GetLatestAbilityRespecNote() end
--Returns: *string note

function GetLatestAttributeRespecNote() end
--Returns: *string note

function PurchaseAttributes(health, magicka, stamina) end

function GetAttributeSpentPoints(attributeType) end
--Returns: *integer points

function GetAttributeUnspentPoints() end
--Returns: *integer points

function GetNumScriptedEventInvites() end
--Returns: *integer eventCount

function GetScriptedEventInviteIdFromIndex(eventIndex) end
--Returns: *integer eventId

function GetScriptedEventInviteInfo(eventId) end
--Returns: *bool isValid, eventName, inviterName, questName, timeRemainingMS

function GetScriptedEventInviteTimeRemainingMS(eventId) end
--Returns: *integer timeRemainingMS

function AcceptWorldEventInvite(eventId) end

function DeclineWorldEventInvite(eventId) end

function RemoveScriptedEventInviteForQuest(questName) end

function GetNumLoreCategories() end
--Returns: *integer numTopCategories

function GetLoreCategoryInfo(categoryIndex) end
--Returns: *string name, numCollections

function GetLoreCollectionInfo(categoryIndex, collectionIndex) end
--Returns: *string name, description, numKnownBooks, totalBooks, hidden, gamepadIcon

function GetLoreBookInfo(categoryIndex, collectionIndex, bookIndex) end
--Returns: *string title, icon, known

function ReadLoreBook(categoryIndex, collectionIndex, bookIndex) end
--Returns: *string body, medium, showTitle

function GetLoreBookLink(categoryIndex, collectionIndex, bookIndex, linkStyle) end
--Returns: *string link

function GetLoreBookTitleFromLink(link) end
--Returns: *string title

function GetGameCameraNonInteractableName() end
--Returns: *string:nilable name

function IsInteracting() end
--Returns: *bool name

function GetPledgeOfMaraOfferInfo() end
--Returns: *string targetCharacterName, millisecondsSinceRequest, isSender, targetDisplayName

function SendPledgeOfMaraResponse(response) end

function GetRingOfMaraExperienceBonus() end
--Returns: *number bonusPercentage

function GetNumTutorials() end
--Returns: *integer numTutorials

function GetTutorialType(tutorialIndex) end
--Returns: *[TutorialType|#TutorialType]:nilable tutorialType

function GetTutorialInfo(tutorialIndex) end
--Returns: *string title, description, displayPriority

function GetTutorialLinkedHelpInfo(tutorialIndex) end
--Returns: *luaindex:nilable helpCategoryIndex, helpIndex

function TriggerTutorial(triggerType) end

function FireTutorialHiddenEvent(tutorialIndex) end

function ResetAllTutorials() end

function HasSeenTutorial(tutorialIndex) end
--Returns: *bool seen

function CanTutorialBeSeen(tutorialIndex) end
--Returns: *bool canBeSeen

function IsTutorialActionRequired(tutorialIndex) end
--Returns: *bool isActionRequired

function GetTutorialId(triggerType) end
--Returns: *luaindex tutorialId

function SetTutorialSeen(tutorialIndex) end

function ClearActiveActionRequiredTutorial() end

function ReportFeedback(impact, category, subcategory, details, description, takeScreenshot) end

function GetHelpCategoryInfo(helpCategoryIndex) end
--Returns: *string name, description, upIcon, downIcon, overIcon, gamepadIcon

function GetNumHelpCategories() end
--Returns: *integer numHelpCategories

function GetNumHelpEntriesWithinCategory(helpCategoryIndex) end
--Returns: *integer numHelpEntries

function GetHelpInfo(helpCategoryIndex, helpIndex) end
--Returns: *string name, description, description2, image, descriptionGamepad, descriptionGamepad2, showOptions

function GetHelpSearchResults() end

--Returns: *luaindex helpCategoryIndex, helpIndex

function SubmitCustomerServiceTicket() end
--Returns: *bool success

function ResetCustomerServiceTicket() end

function SetCustomerServiceTicketContactEmail(contactEmail) end

function SetCustomerServiceTicketBody(body) end

function SetCustomerServiceTicketCategory(category) end

function SetCustomerServiceTicketPlayerTarget(displayName) end

function SetCustomerServiceTicketItemTargetByLink(itemLink) end

function SetCustomerServiceTicketItemTarget(itemName, itemId) end

function SetCustomerServiceTicketQuestTarget(questName) end

function StartHelpSearch(searchString) end

function GetHelpOverviewIntroParagraph() end
--Returns: *string paragraph

function GetNumHelpOverviewQuestionAnswers() end
--Returns: *integer length

function GetHelpOverviewQuestionAnswerPair(index) end
--Returns: *string question, answer

function IsKeyboardHelpOption(showOption) end
--Returns: *bool isKeyboardOption

function IsGamepadHelpOption(showOption) end
--Returns: *bool isGamepadOption

function IsSubmitFeedbackSupported() end
--Returns: *bool isSupported

function GetCraftingInteractionType() end
--Returns: *[TradeskillType|#TradeskillType] currentCraftingInteraction

function IsPerformingCraftProcess() end
--Returns: *bool isCrafting

function GetLastCraftingResultTotalInspiration() end
--Returns: *integer totalInspiration

function GetNumLastCraftingResultLearnedTranslations() end
--Returns: *integer numLearnedTranslations

function GetLastCraftingResultLearnedTranslationInfo(resultIndex) end
--Returns: *string translationName, itemName, icon, sellPrice, meetsUsageRequirement, equipType, itemStyle, quality

function GetNumLastCraftingResultLearnedTraits() end
--Returns: *integer numLearnedTraits

function GetLastCraftingResultLearnedTraitInfo(resultIndex) end
--Returns: *string traitName, itemName, icon, sellPrice, meetsUsageRequirement, equipType, itemStyle, quality

function GetNumLastCraftingResultItemsAndPenalty() end
--Returns: *integer numItems, penaltyApplied

function GetLastCraftingResultItemInfo(resultIndex) end
--Returns: *string name, icon, stack, sellPrice, meetsUsageRequirement, equipType, itemType, itemStyle, quality, soundCategory, itemInstanceId

function GetCostToCraftAlchemyItem(solventBagId, solventSlotIndex) end
--Returns: *integer cost

function CraftAlchemyItem(solventBagId, solventSlotIndex, reagent1BagId, reagent1SlotIndex, reagent2BagId, reagent2SlotIndex, reagent3BagId, reagent3SlotIndex) end

function GetAlchemyResultingItemInfo(solventBagId, solventSlotIndex, reagent1BagId, reagent1SlotIndex, reagent2BagId, reagent2SlotIndex, reagent3BagId, reagent3SlotIndex) end
--Returns: *string name, icon, stack, sellPrice, meetsUsageRequirement, equipType, itemStyle, quality

function GetAlchemyResultingItemLink(solventBagId, solventSlotIndex, reagent1BagId, reagent1SlotIndex, reagent2BagId, reagent2SlotIndex, reagent3BagId, reagent3SlotIndex, linkStyle) end
--Returns: *string link

function GetAlchemyResultInspiration(solventBagId, solventSlotIndex, reagent1BagId, reagent1SlotIndex, reagent2BagId, reagent2SlotIndex, reagent3BagId, reagent3SlotIndex) end
--Returns: *integer inspiration

function GetAlchemyItemTraits(reagentBagId, reagentSlotIndex) end

--Returns: *string:nilable trait, icon, matchIcon, cancellingTrait, conflictIcon

function IsAlchemySolvent(itemType) end
--Returns: *bool isAlchemySolvent

function GetNumRecipeLists() end
--Returns: *integer numRecipeLists

function GetRecipeListInfo(recipeListIndex) end
--Returns: *string name, numRecipes, upIcon, downIcon, overIcon, disabledIcon, createSound

function GetRecipeInfo(recipeListIndex, recipeIndex) end
--Returns: *bool known, name, numIngredients, provisionerLevelReq, qualityReq, specialIngredientType

function GetRecipeIngredientItemInfo(recipeListIndex, recipeIndex, ingredientIndex) end
--Returns: *string name, icon, requiredQuantity, sellPrice, quality

function GetRecipeIngredientItemLink(recipeListIndex, recipeIndex, ingredientIndex, linkStyle) end
--Returns: *string link

function GetRecipeResultItemInfo(recipeListIndex, recipeIndex) end
--Returns: *string name, icon, stack, sellPrice, quality

function GetRecipeResultItemLink(recipeListIndex, recipeIndex, linkStyle) end
--Returns: *string link

function GetCostToCraftProvisionerItem(recipeListIndex, recipeIndex) end
--Returns: *integer cost

function CraftProvisionerItem(recipeListIndex, recipeIndex) end

function GetCurrentRecipeIngredientCount(recipeListIndex, recipeIndex, ingredientIndex) end
--Returns: *integer count

function GetCostToCraftEnchantingItem(potencyRuneBagId, potencyRuneSlotIndex, essenceRuneBagId, essenceRuneSlotIndex, aspectRuneBagId, aspectRuneSlotIndex) end
--Returns: *integer cost

function CraftEnchantingItem(potencyRuneBagId, potencyRuneSlotIndex, essenceRuneBagId, essenceRuneSlotIndex, aspectRuneBagId, aspectRuneSlotIndex) end

function ExtractEnchantingItem(bagId, slotIndex) end

function GetEnchantingResultingItemInfo(potencyRuneBagId, potencyRuneSlotIndex, essenceRuneBagId, essenceRuneSlotIndex, aspectRuneBagId, aspectRuneSlotIndex) end
--Returns: *string name, icon, stack, sellPrice, meetsUsageRequirement, quality

function GetEnchantingResultingItemLink(potencyRuneBagId, potencyRuneSlotIndex, essenceRuneBagId, essenceRuneSlotIndex, aspectRuneBagId, aspectRuneSlotIndex, linkStyle) end
--Returns: *string link

function GetRunestoneTranslatedName(bagId, slotIndex) end
--Returns: *string:nilable name

function GetRunestoneSoundInfo(bagId, slotIndex) end
--Returns: *string soundName, soundLength

function GetEnchantedItemResultingItemLink(itemBagId, itemSlotIndex, enchantmentBagId, enchantmentSlotIndex, linkStyle) end
--Returns: *string link

function GetCostToCraftSmithingItem(patternIndex, materialIndex, materialQuantity, styleIndex, traitIndex) end
--Returns: *integer cost

function CraftSmithingItem(patternIndex, materialIndex, materialQuantity, styleIndex, traitIndex, useUniversalStyleItem) end

function GetSmithingPatternResultLink(patternIndex, materialIndex, materialQuantity, styleIndex, traitIndex, linkStyle) end
--Returns: *string link

function CanSmithingWeaponPatternsBeCraftedHere() end
--Returns: *bool canBeCrafted

function CanSmithingApparelPatternsBeCraftedHere() end
--Returns: *bool canBeCrafted

function CanSmithingSetPatternsBeCraftedHere() end
--Returns: *bool canBeCrafted

function GetNumSmithingPatterns() end
--Returns: *integer smithingPatterns

function GetSmithingPatternInfo(patternIndex, materialIndexOverride, materialQuanityOverride, styleOverride, traitTypeOverride) end
--Returns: *string patternName, baseName, icon, numMaterials, numTraitsRequired, numTraitsKnown, resultItemFilterType

function GetSmithingPatternMaterialItemInfo(patternIndex, materialIndex) end
--Returns: *string itemName, icon, stack, sellPrice, meetsUsageRequirement, equipType, itemStyle, quality, itemInstanceId, skillRequirement

function GetSmithingPatternNextMaterialQuantity(patternIndex, materialIndex, startingPoint, step) end
--Returns: *integer value

function GetSmithingPatternMaterialItemLink(patternIndex, materialIndex, linkStyle) end
--Returns: *string link

function GetSmithingPatternArmorType(patternIndex) end
--Returns: *[ArmorType|#ArmorType] armorType

function GetCurrentSmithingMaterialItemCount(patternIndex, materialIndex) end
--Returns: *integer count

function GetNumSmithingStyleItems() end
--Returns: *integer numStyleItems

function GetSmithingStyleItemInfo(styleItemIndex) end
--Returns: *string itemName, icon, sellPrice, meetsUsageRequirement, itemStyle, quality, alwaysHideIfLocked

function GetSmithingStyleItemLink(styleItemIndex, linkStyle) end
--Returns: *string link

function GetCurrentSmithingStyleItemCount(styleItemIndex) end
--Returns: *integer count

function IsSmithingStyleKnown(styleItemIndex, patternIndex) end
--Returns: *bool known

function GetFirstKnownStyleIndex(patternIndex) end
--Returns: *luaindex styleItemIndex

function CanSmithingStyleBeUsedOnPattern(styleIndex, patternIndex, materialIndex, materialQuantity) end
--Returns: *bool canBeUsed, levelRequirement, championPointsRequirement

function GetNumSmithingTraitItems() end
--Returns: *integer numTraitItems

function GetSmithingTraitItemInfo(traitItemIndex) end
--Returns: *[ItemTraitType|#ItemTraitType]:nilable traitType, itemName, icon, sellPrice, meetsUsageRequirement, itemStyle, quality

function GetSmithingTraitItemLink(traitItemIndex, linkStyle) end
--Returns: *string link

function GetCurrentSmithingTraitItemCount(traitItemIndex) end
--Returns: *integer count

function IsSmithingTraitItemValidForPattern(patternIndex, traitItemIndex) end
--Returns: *bool valid

function IsSmithingTraitKnownForResult(patternIndex, materialIndex, materialQuantity, styleIndex, traitIndex) end
--Returns: *bool known

function GetNumSmithingResearchLines(craftingSkillType) end
--Returns: *integer numLines

function GetMaxSimultaneousSmithingResearch(craftingSkillType) end
--Returns: *integer maxSimultaneousResearch

function GetSmithingResearchLineInfo(craftingSkillType, researchLineIndex) end
--Returns: *string name, icon, numTraits, timeRequiredForNextResearchSecs

function GetSmithingResearchLineTraitInfo(craftingSkillType, researchLineIndex, traitIndex) end
--Returns: *[ItemTraitType|#ItemTraitType] traitType, traitDescription, known

function GetSmithingResearchLineTraitTimes(craftingSkillType, researchLineIndex, traitIndex) end
--Returns: *integer:nilable duration, timeRemainingSecs

function CanItemBeSmithingTraitResearched(bagId, slotIndex, craftingSkillType, researchLineIndex, traitIndex) end
--Returns: *bool canBeResearched

function ResearchSmithingTrait(bagId, slotIndex) end

function CanItemBeSmithingExtractedOrRefined(bagId, slotIndex, craftingSkillType) end
--Returns: *bool canItemBeExtractedOrRefined

function GetRequiredSmithingRefinementStackSize() end
--Returns: *integer requiredStackSize

function GetSmithingRefinementMinRawMaterial() end
--Returns: *integer minRawMaterial

function GetSmithingRefinementMaxRawMaterial() end
--Returns: *integer maxRawMaterial

function ExtractOrRefineSmithingItem(bagId, slotIndex) end

function CanItemBeSmithingImproved(bagId, slotIndex, craftingSkillType) end
--Returns: *bool canBeImproved

function GetSmithingImprovementChance(itemToImproveBagId, itemToImproveSlotIndex, numBoostersToUse, craftingSkillType) end
--Returns: *number chance

function GetNumSmithingImprovementItems() end
--Returns: *integer numImprovementItems

function GetSmithingImprovementItemInfo(craftingSkillType, improvementItemIndex) end
--Returns: *string itemName, icon, currentStack, sellPrice, meetsUsageRequirement, equipType, itemStyle, quality

function GetSmithingImprovementItemLink(craftingSkillType, improvementItemIndex, linkStyle) end
--Returns: *string link

function GetSmithingImprovedItemInfo(itemToImproveBagId, itemToImproveSlotIndex, craftingSkillType) end
--Returns: *string itemName, icon, sellPrice, meetsUsageRequirement, equipType, itemStyle, quality

function GetSmithingImprovedItemLink(itemToImproveBagId, itemToImproveSlotIndex, craftingSkillType, linkStyle) end
--Returns: *string link

function ImproveSmithingItem(itemToImproveBagId, itemToImproveSlotIndex, numBoostersToUse) end

function GetNonCombatBonus(nonCombatBonus) end
--Returns: *integer bonusValue

function GetNumEmotes() end
--Returns: *integer numEmotes

function GetEmoteInfo(emoteIndex) end
--Returns: *string slashName, category, emoteId, displayName, showInGamepadUI

function GetEmoteSlashNameByIndex(emoteIndex) end
--Returns: *string slashName

function PlayEmoteByIndex(emoteIndex) end

function GetNumLFGOptions(activity) end
--Returns: *integer count

function GetLFGOption(activity, index) end
--Returns: *string name, levelMin, levelMax, championPointsMin, championPointsMax, groupType, minGroupSize, description, sortOrder

function GetLFGOptionKeyboardDescriptionTextures(activity, index) end
--Returns: *textureName descriptionTextureSmallKeyboard, descriptionTextureLargeKeyboard

function GetLFGOptionGamepadDescriptionTexture(activity, index) end
--Returns: *textureName descriptionTextureGamepad

function GetLFGDisplayLevels(activity, index) end
--Returns: *integer displayLevelMin, displayLevelMax, displayChampionPointsMin, displayChampionPointsMax

function GetLFGOptionGroupType(activity, index) end
--Returns: *[LFGGroupType|#LFGGroupType] groupTypeAllowed

function DoesPlayerMeetLFGLevelRequirements(activity, index) end
--Returns: *bool meetsLevelRequirements

function DoesGroupMeetLFGLevelRequirements(activity, index) end
--Returns: *bool meetsLevelRequirements

function UpdatePlayerRole(activity, selected) end

function GetPlayerRoles() end
--Returns: *bool isDPS, isHeal, isTank

function DoesLFGActivityHasAllOption(activity) end
--Returns: *bool hasAllOption

function GetLFGActivityRewardData(activity) end
--Returns: *[LFGItemRewardType|#LFGItemRewardType] itemRewardType, xpReward

function IsEligibleForDailyActivityReward() end
--Returns: *bool isEligible

function GetActivityQueueCooldownTimeRemainingSeconds() end
--Returns: *integer timeRemainingSeconds

function AddGroupFinderSearchEntry(activity, index) end

function ClearGroupFinderSearch() end

function StartGroupFinderSearch() end
--Returns: *[ActivityQueueResult|#ActivityQueueResult] result

function CanSendLFMRequest() end
--Returns: *bool canSendLFMRequest

function SendLFMRequest() end

function GetNumLFGRequests() end
--Returns: *integer numRequests

function GetLFGRequestInfo(requestIndex) end
--Returns: *[LFGActivity|#LFGActivity] activity, index

function CancelGroupSearches() end

function GetActivityFinderStatus() end
--Returns: *[ActivityFinderStatus|#ActivityFinderStatus] status

function IsCurrentlySearchingForGroup() end
--Returns: *bool isSearching

function GetRequiredLFGCollectibleId(activityType, index) end
--Returns: *integer collectibleId

function GetLFGSearchTimes() end
--Returns: *integer startTimeMs, estimatedCompletionTimeMs

function HasLFGJumpNotification() end
--Returns: *bool hasJumpNotification

function GetLFGJumpNotificationInfo() end
--Returns: *[LFGActivity|#LFGActivity]:nilable activityType, activityIndex, timeRemainingSeconds

function AcceptLFGJumpNotification() end

function ClearLFGJumpNotification() end

function HasLFGFindReplacementNotification() end
--Returns: *bool hasfindReplacementNotification

function GetLFGFindReplacementNotificationInfo() end
--Returns: *[LFGActivity|#LFGActivity]:nilable activityType, activityIndex

function AcceptLFGFindReplacementNotification() end

function DeclineLFGFindReplacementNotification() end

function GetGroupSizeFromLFGGroupType(groupType) end
--Returns: *integer size

function GetLFGAverageRoleTimeByActivity(activityType, activityIndex, role) end
--Returns: *bool hasData, timeSeconds

function GetNumFishingLures() end
--Returns: *integer numLures

function GetFishingLureInfo(lureIndex) end
--Returns: *string name, icon, stack, sellPrice, quality

function SetFishingLure(lureIndex) end

function GetFishingLure() end
--Returns: *luaindex:nilable lureIndex

function GetNumViewableTreasureMaps() end
--Returns: *integer numViewableMaps

function GetTreasureMapInfo(treasureMapIndex) end
--Returns: *string name, imagePath

function SetFloatingMarkerInfo(markerType, size, primaryTexturePath, secondaryTexturePath, primaryPulses, secondaryPulses) end

function SetFloatingMarkerGlobalAlpha(alpha) end

function GetAgentChatRequestInfo() end
--Returns: *bool isChatRequested, millisecondsSinceRequest

function IsAgentChatActive() end
--Returns: *bool isActive

function AcceptAgentChat() end

function DeclineAgentChat() end

function GetNumKillingAttacks() end
--Returns: *integer numKillingAttacks

function GetKillingAttackInfo(index) end
--Returns: *string attackName, attackDamage, attackIcon, wasKillingBlow, castTimeAgoMS, durationMS

function DoesKillingAttackHaveAttacker(index) end
--Returns: *bool hasAttacker

function GetKillingAttackerInfo(index) end
--Returns: *string attackerRawName, attackerChampionPoints, attackerLevel, attackerAvARank, isPlayer, isBoss, alliance, minionName, attackerDisplayName

function GetNumDeathRecapHints() end
--Returns: *integer numHints

function GetDeathRecapHintInfo(index) end
--Returns: *string text, importance

function GetNumTelvarStonesLost() end
--Returns: *integer telvarStonesLost

function InitializePendingDyes(dyeMode) end

function SetPendingSlotDyes(dyeableSlot, primaryDyeId, secondaryDyeId, accentDyeId) end

function GetPendingSlotDyes(dyeableSlot) end
--Returns: *integer primaryDyeId, secondaryDyeId, accentDyeId

function GetNumDyes() end
--Returns: *integer numDyes

function GetDyeInfo(dyeIndex) end
--Returns: *string dyeName, known, rarity, hueCategory, achievementId, r, g, b, sortKey, dyeId

function GetDyeInfoById(dyeId) end
--Returns: *string dyeName, known, rarity, hueCategory, achievementId, r, g, b, sortKey

function GetDyeColorsById(dyeId) end
--Returns: *number r, g, b

function GetCurrentItemDyes(bagId, slotIndex) end
--Returns: *integer primaryDyeIndex, secondaryDyeIndex, accentDyeIndex

function GetCurrentCollectibleDyes(collectibleId) end
--Returns: *integer primaryDyeIndex, secondaryDyeIndex, accentDyeIndex

function ApplyPendingDyes() end

function GetNumSavedDyeSets() end
--Returns: *integer numSavedDyeSets

function GetSavedDyeSetDyes(dyeSetIndex) end
--Returns: *integer primaryDyeId, secondaryDyeId, accentDyeId

function SetSavedDyeSetDyes(dyeSetIndex, primaryDyeId, secondaryDyeId, accentDyeId) end

function CanUseCollectibleDyeing() end
--Returns: *bool collectibleDyeingAllowed

function IsDyeableSlotDyeable(dyeableSlot) end
--Returns: *bool isDyeable

function IsDyeableSlotBound(dyeableSlot) end
--Returns: *bool isBound

function AreDyeableSlotDyeChannelsDyeable(dyeableSlot) end
--Returns: *bool primary, secondary, accent

function GetDyeableSlotDyeData(dyeableSlot) end
--Returns: *integer dyeData

function GetDyeableSlotId(dyeableSlot) end
--Returns: *integer id

function GetDyeableSlotIcon(dyeableSlot) end
--Returns: *textureName icon

function GetDyeableSlotCurrentDyes(dyeableSlot) end
--Returns: *integer primaryDyeId, secondaryDyeId, accentDyeId

function IsDyeIndexKnown(dyeIndex) end
--Returns: *bool isKnown

function CanPlayerUseCostumeDyeStamp(dyeStampId) end
--Returns: *[DyeStampUseResult|#DyeStampUseResult] dyeStampUseResult

function CanPlayerUseItemDyeStamp(dyeStampId) end
--Returns: *[DyeStampUseResult|#DyeStampUseResult] dyeStampUseResult

function SetupDyeStampPreview(bagId, slotIndex) end

function GetNumDyeableEquipSlots() end
--Returns: *integer numDyeableEquipSlots

function GetNumDyeableCollectibleCategories() end
--Returns: *integer numDyeableCollectibleCategories

function GetDyeableEquipSlot(dyeableEquipSlotIndex) end
--Returns: *[DyeableSlot|#DyeableSlot] dyeableSlot

function GetDyeableCollectibleCategory(dyeableCollectibleCategoryIndex) end
--Returns: *[DyeableSlot|#DyeableSlot] dyeableSlot

function GetDyeableEquipSlotGamepadOrder(dyeableEquipSlotIndex) end
--Returns: *luaindex gamepadOrder

function GetDyeableCollectibleCategoryGamepadOrder(dyeableCollectibleCategoryIndex) end
--Returns: *luaindex gamepadOrder

function GetEquipSlotFromDyeableSlot(dyeableSlot) end
--Returns: *[EquipSlot|#EquipSlot] equipSlot

function GetCollectibleCategoryFromDyeableSlot(dyeableSlot) end
--Returns: *[CollectibleCategoryType|#CollectibleCategoryType] collectibleCategory

function IsJusticeEnabled() end
--Returns: *bool isJusticeEnabled

function IsJusticeEnabledForZone(aZoneIndex) end
--Returns: *bool isBountyEnabled

function IsKillOnSight() end
--Returns: *bool isKillOnSight

function GetInfamy() end
--Returns: *integer infamy

function GetBounty() end
--Returns: *integer bounty

function GetPlayerInfamyData() end
--Returns: *integer heat, bounty

function GetReducedBountyPayoffAmount() end
--Returns: *integer payoffAmount

function GetFullBountyPayoffAmount() end
--Returns: *integer payoffAmount

function GetInfamyLevel(infamyAmount) end
--Returns: *[InfamyThresholdsType|#InfamyThresholdsType] infamyLevel

function GetInfamyMeterSize() end
--Returns: *integer meterSize

function GetFenceSellTransactionInfo() end
--Returns: *integer totalSells, sellsUsed, resetTimeSeconds

function GetFenceLaunderTransactionInfo() end
--Returns: *integer totalLaunders, laundersUsed, resetTimeSeconds

function GetSecondsUntilArrestTimeout() end
--Returns: *integer secondsUntilArrestTimeout

function IsTrespassing() end
--Returns: *bool isTrespassing

function GetTimeToClemencyResetInSeconds() end
--Returns: *integer timeRemaining

function GetTimeToShadowyConnectionsResetInSeconds() end
--Returns: *integer timeRemaining

function IsStuckFixPending() end
--Returns: *bool isStuckFixPending

function CanUseStuck(warn) end
--Returns: *bool canUseStuck

function GetTimeUntilStuckAvailable() end
--Returns: *integer millisecondsUntilAvailable

function GetStuckCooldown() end
--Returns: *integer cooldownRemainingSecs

function ApplyPendingHeraldryChanges() end

function IsPlayerAllowedToEditHeraldry(guildIndex) end
--Returns: *bool allowed

function IsCurrentlyCustomizingHeraldry() end
--Returns: *bool currentlyCustomizing

function GetHeraldryCustomizationCosts() end
--Returns: *integer backgroundStyleCost, backgroundPrimaryColorCost, backgroundSecondaryColorCost, crestStyleCost, crestColorCost

function IsCreatingHeraldryForFirstTime() end
--Returns: *bool creatingForFirstTime

function HasPendingHeraldryChanges() end
--Returns: *bool hasPendingChanges

function GetPendingHeraldryCost() end
--Returns: *integer pendingCost

function RevertToSavedHeraldry(hasActiveAppearance) end

function SetPendingHeraldryIndices(backgroundCategoryIndex, backgroundStyleIndex, backgroundPrimaryColorIndex, backgroundSecondaryColorIndex, crestCategoryIndex, crestStyleIndex, crestColorIndex) end

function GetPendingHeraldryIndices() end
--Returns: *luaindex backgroundCategoryIndex, backgroundStyleIndex, backgroundPrimaryColorIndex, backgroundSecondaryColorIndex, crestCategoryIndex, crestStyleIndex, crestColorIndex

function GetNumHeraldryColors() end
--Returns: *integer numColors

function GetHeraldryColorInfo(colorIndex) end
--Returns: *string colorName, hueCategory, r, g, b, sortKey

function GetNumHeraldryBackgroundCategories() end
--Returns: *integer numCategories

function GetHeraldryBackgroundCategoryInfo(categoryIndex) end
--Returns: *string categoryName, icon

function GetNumHeraldryBackgroundStyles(categoryIndex) end
--Returns: *integer numStyles

function GetHeraldryBackgroundStyleInfo(categoryIndex, styleIndex) end
--Returns: *string styleName, icon

function GetNumHeraldryCrestCategories() end
--Returns: *integer numCategories

function GetHeraldryCrestCategoryInfo(categoryIndex) end
--Returns: *string categoryName, icon

function GetNumHeraldryCrestStyles(categoryIndex) end
--Returns: *integer numStyles

function GetHeraldryCrestStyleInfo(categoryIndex, styleIndex) end
--Returns: *string styleName, icon

function StartHeraldryCustomization(guildIndex) end

function EndHeraldryCustomization() end

function GetHeraldryGuildBankedMoney() end
--Returns: *integer:nilable money

function GetGamepadTemplate() end
--Returns: *[GamepadTemplate|#GamepadTemplate] gamepadTemplate

function SendAllCachedSettingMessages() end

function GetVibrationInfoFromTrigger(triggerType) end
--Returns: *integer durationMS, coarseMotor, fineMotor, leftTriggerMotor, rightTriggerMotor, foundInfo, debugSourceInfo

function SetShouldRenderWorld(shouldRenderWorld) end

function GetNumChampionDisciplines() end
--Returns: *integer numDisciplines

function GetChampionDisciplineName(disciplineIndex) end
--Returns: *string name

function GetChampionDisciplineDescription(disciplineIndex) end
--Returns: *string description

function GetChampionDisciplineAttribute(disciplineIndex) end
--Returns: *[Attributes|#Attributes] attribute

function GetNumChampionDisciplineSkills(disciplineIndex) end
--Returns: *integer numSkills

function GetChampionSkillPosition(disciplineIndex, skillIndex) end
--Returns: *number normalizedX, normalizedY

function GetChampionSkillName(disciplineIndex, skillIndex) end
--Returns: *string skillName

function GetMaxPossiblePointsInChampionSkill() end
--Returns: *integer maxPossiblePoints

function GetNumPointsSpentOnChampionSkill(disciplineIndex, skillIndex) end
--Returns: *integer numSpentPoints

function GetNumPointsSpentInChampionDiscipline(disciplineIndex) end
--Returns: *integer numSpentPoints

function GetChampionSkillUnlockLevel(disciplineIndex, skillIndex) end
--Returns: *integer:nilable autoGrantLevel

function GetNumSpentChampionPoints(attribute) end
--Returns: *integer numSpentPoints

function GetNumUnspentChampionPoints(attribute) end
--Returns: *integer numUnspentPoints

function ClearPendingChampionPoints() end

function GetNumPendingChampionPoints(disciplineIndex, skillIndex) end
--Returns: *integer numPendingPoints

function SetNumPendingChampionPoints(disciplineIndex, skillIndex, numPendingPoints) end

function HasAvailableChampionPointsInAttribute(attribute) end
--Returns: *bool hasPoints

function WillChampionSkillBeUnlocked(disciplineIndex, skillIndex) end
--Returns: *bool willBeUnlocked

function SetChampionIsInRespecMode(isInRespecMode) end

function IsChampionInRespecMode() end
--Returns: *bool isInRespecMode

function IsChampionRespecNeeded() end
--Returns: *bool needsRespec

function SpendPendingChampionPoints() end
--Returns: *bool requested

function SetChampionMusicActive(active) end

function GetChampionAbilityDescription(abilityId, numPendingPoints) end
--Returns: *string description

function GetChampionAbilityId(disciplineIndex, skillIndex) end
--Returns: *integer abilityId

function GetChampionRespecCost() end
--Returns: *integer cost

function GetChampionPointAttributeForRank(rank) end
--Returns: *[Attributes|#Attributes] pointAttribute

function IsChampionSystemUnlocked() end
--Returns: *bool unlocked

function AreChampionPointsActive() end
--Returns: *bool active, activeReason

function BeginPreviewMode() end

function EndPreviewMode(resetTargetFrame) end

function IsCurrentlyPreviewing() end
--Returns: *bool isPreviewing

function IsInPreviewMode() end
--Returns: *bool isInPreviewMode

function IsCharacterPreviewingAvailable() end
--Returns: *bool canPreview

function EndCurrentItemPreview() end

function BeginItemPreviewSpin() end

function EndItemPreviewSpin() end

function CanSpinPreviewCharacter() end
--Returns: *bool canSpin

function PreviewCollectible(collectibleDefId, variation, dyeBrushId) end

function PreviewDyeStamp(dyeStampId, itemType) end

function PreviewCraftItem(patternIndex, materialIndex, materialQuantity, styleIndex, traitIndex, useUniversalStyleItem, aDyeStampId) end

function SetPreviewDyeMode(dyeMode) end

function GetNumDefaultQuickChats() end
--Returns: *integer numQuickChats

function GetDefaultQuickChatName(index) end
--Returns: *string name

function GetDefaultQuickChatMessage(index) end
--Returns: *string message

function PlayDefaultQuickChat(index) end

function SetSCTAnimationOffsetX(timeline, offsetX) end

function SetSCTAnimationOffsetY(timeline, offsetY) end

function ZoUTF8StringLength(string) end
--Returns: *integer length

function ResetSCTDataToDefaults() end

function GetSCTKeyboardFont() end
--Returns: *string fontName, fontStyle

function SetSCTKeyboardFont(fontName, fontStyle) end

function GetSCTGamepadFont() end
--Returns: *string fontName, fontStyle

function SetSCTGamepadFont(fontName, fontStyle) end

function GetSCTEventVisualInfoId(eventType) end
--Returns: *integer SCTEventVisualInfoId

function SetSCTEventVisualInfo(eventType, SCTEventVisualInfoId) end

function GetNumSCTSlots() end
--Returns: *integer numSlots

function CreateNewSCTSlot() end
--Returns: *luaindex slotIndex

function GetSCTSlotPosition(slotIndex) end
--Returns: *[SCTUnitAnchorType|#SCTUnitAnchorType] SCTAnchorType, anchorPoint, UIOffsetX, UIOffsetY, cameraOffsetRight, cameraOffsetUp

function SetSCTSlotPosition(slotIndex, SCTAnchorType, anchorPoint, UIOffsetX, UIOffsetY, cameraOffsetRight, cameraOffsetUp) end

function GetSCTSlotZoomedInPosition(slotIndex) end
--Returns: *number zoomedInCameraDistanceThreshold, zoomedInUIOffsetX, zoomedInUIOffsetY

function SetSCTSlotZoomedInPosition(slotIndex, zoomedInCameraDistanceThreshold, zoomedInUIOffsetX, zoomedInUIOffsetY) end

function GetSCTSlotClamping(slotIndex) end
--Returns: *number topEdgeUIOffsetBuffer, bottomEdgeUIOffsetBuffer

function SetSCTSlotClamping(slotIndex, topEdgeUIOffsetBuffer, bottomEdgeUIOffsetBuffer) end

function GetSCTSlotAnimationTimeline(slotIndex) end
--Returns: *string animationTimelineName

function SetSCTSlotAnimationTimeline(slotIndex, animationTimelineName) end

function GetSCTSlotAnimationMinimumSpacing(slotIndex) end
--Returns: *integer minSpacingMS

function SetSCTSlotAnimationMinimumSpacing(slotIndex, minSpacingMS) end

function IsSCTSlotEventTypeShown(slotIndex, eventType) end
--Returns: *bool isShown

function SetSCTSlotEventTypeShown(slotIndex, eventType, isShown) end

function DoesSCTSlotAllowTargetType(slotIndex, targetType) end
--Returns: *bool allowed

function AddSCTSlotAllowedTargetType(slotIndex, targetType) end

function ClearSCTSlotAllowedTargetTypes(slotIndex) end

function DoesSCTSlotExcludeTargetType(slotIndex, targetType) end
--Returns: *bool allowed

function AddSCTSlotExcludedTargetType(slotIndex, targetType) end

function ClearSCTSlotExcludedTargetTypes(slotIndex) end

function DoesSCTSlotAllowSourceType(slotIndex, targetType) end
--Returns: *bool allowed

function AddSCTSlotAllowedSourceType(slotIndex, sourceType) end

function ClearSCTSlotAllowedSourceTypes(slotIndex) end

function DoesSCTSlotExcludeSourceType(slotIndex, targetType) end
--Returns: *bool allowed

function AddSCTSlotExcludedSourceType(slotIndex, sourceType) end

function ClearSCTSlotExcludedSourceTypes(slotIndex) end

function GetSCTSlotTargetReputationTypes(slotIndex) end
--Returns: *bool showForFriendly, showForNeutral, showForEnemy

function SetSCTSlotTargetReputationTypes(slotIndex, showForFriendly, showForNeutral, showForEnemy) end

function GetSCTSlotSourceReputationTypes(slotIndex) end
--Returns: *bool showForFriendly, showForNeutral, showForEnemy

function SetSCTSlotSourceReputationTypes(slotIndex, showForFriendly, showForNeutral, showForEnemy) end

function GetSCTSlotEventControlScales(slotIndex) end
--Returns: *number defaultScale, critScale

function SetSCTSlotEventControlScales(slotIndex, defaultScale, critScale) end

function GetSCTSlotKeyboardCloudId(slotIndex) end
--Returns: *integer SCTCloudId

function SetSCTSlotKeyboardCloud(slotIndex, SCTCloudId) end

function GetSCTSlotGamepadCloudId(slotIndex) end
--Returns: *integer SCTCloudId

function SetSCTSlotGamepadCloud(slotIndex, SCTCloudId) end

function CreateNewSCTEventVisualInfo() end
--Returns: *integer SCTEventVisualInfoId

function GetSCTSlotEventVisualInfo(slotIndex, eventType) end
--Returns: *integer SCTEventVisualInfoId

function SetSCTSlotEventVisualInfo(slotIndex, eventType, SCTEventVisualInfoId) end

function GetSCTEventVisualInfoTextFormat(SCTEventVisualInfoId, textType) end
--Returns: *string format, enabled

function SetSCTEventVisualInfoTextFormat(SCTEventVisualInfoId, textType, format) end

function GetSCTEventVisualInfoTextFontSizes(SCTEventVisualInfoId, textType) end
--Returns: *integer keyboardFontSize, gamepadFontSize, enabled

function SetSCTEventVisualInfoTextFontSizes(SCTEventVisualInfoId, textType, keyboardFontSize, gamepadFontSize) end

function GetSCTEventVisualInfoTextColor(SCTEventVisualInfoId, textType) end
--Returns: *number r, g, b, enabled

function SetSCTEventVisualInfoTextColor(SCTEventVisualInfoId, textType, r, g, b) end

function GetSCTEventVisualInfoHideWhenValueIsZero(SCTEventVisualInfoId) end
--Returns: *bool hideWhenValueIsZero, enabled

function SetSCTEventVisualInfoHideWhenValueIsZero(SCTEventVisualInfoId, hideWhenValueIsZero) end

function CreateNewSCTCloud() end
--Returns: *integer SCTCloudId

function GetNumSCTCloudOffsets(SCTCloudId) end

function GetSCTCloudOffset(SCTCloudId, offsetIndex, ordering, UIOffsetX, UIOffsetY) end

function AddSCTCloudOffset(SCTCloudId, ordering, UIOffsetX, UIOffsetY) end

function ClearSCTCloudOffsets(SCTCloudId) end

function GetSCTCloudAnimationOverlapPercent(SCTCloudId) end
--Returns: *number animationOverlapPercent

function SetSCTCloudAnimationOverlapPercent(SCTCloudId, animationOverlapPercent) end

function ShowMarketProduct(marketProductId, source) end

function ShowMarketAndSearch(marketProductSearchString, source) end

function SendCrownCrateOpenRequest(crateId) end

function GetNumOwnedCrownCrateTypes() end
--Returns: *integer numCrownCrateTypes

function GetNextOwnedCrownCrateId(lastCrateId) end
--Returns: *integer:nilable nextCrateId

function GetOnSaleCrownCrateId() end
--Returns: *integer:nilable crateId

function GetCrownCrateName(crateId) end
--Returns: *string crateName

function GetCrownCrateCount(crateId) end
--Returns: *integer count

function GetInventorySpaceRequiredToOpenCrownCrate(crateId) end
--Returns: *integer inventorySpaceRequired

function GetCrownCratePackNormalTexture(crateId) end
--Returns: *textureName normalImage

function GetCrownCrateCardTextures(crateId) end
--Returns: *textureName cardBackImage, cardBackGlowImage, cardFaceImage, cardFaceGlowImage

function GetCurrentCrownCrateId() end
--Returns: *integer crateId

function GetNumCurrentCrownCrateTotalRewards() end
--Returns: *integer numRewards

function GetNumCurrentCrownCratePrimaryRewards() end
--Returns: *integer numPrimaryRewards

function GetNumCurrentCrownCrateBonusRewards() end
--Returns: *integer numBonusRewards

function GetCrownCrateRewardInfo(rewardIndex) end
--Returns: *string rewardName, rewardTypeText, cardFaceImage, cardFaceFrameAccentImage, gemsExchanged, isBonus, crownCrateTierId, stackCount

function GetCrownCrateRewardProductReferenceData(rewardIndex) end
--Returns: *[MarketProductType|#MarketProductType] rewardProductType, referenceDataId

function GetCrownCrateNPCBoneWorldPosition(boneName) end
--Returns: *bool success, positionX, positionY, positionZ

function CreateCrownCrateSpecificParticleEffect(crownCrateId, crownCrateParticleEffects, worldX, worldY, worldZ) end
--Returns: *integer:nilable particleEffectId

function CreateCrownCrateTierSpecificParticleEffect(crownCrateTierId, crownCrateTierParticleEffects, worldX, worldY, worldZ) end
--Returns: *integer:nilable particleEffectId

function GetCrownCrateNPCCardThrowingBoneName() end
--Returns: *string boneName

function SetCrownCrateNPCVisible(show) end

function TriggerCrownCrateNPCAnimation(event) end

function GetCrownCrateTierQualityColor(crownCrateTierId) end
--Returns: *number r, g, b

function GetCrownCrateTierReactionNPCAnimation(crownCrateTierId) end
--Returns: *[CrownCrateEvent|#CrownCrateEvent] reactionEvent

function GetCrownCratesSystemState() end
--Returns: *[LootCratesSystemState|#LootCratesSystemState] crownCratesSystemState

function CanInteractWithCrownCratesSystem() end
--Returns: *bool canInteractWithCrownCratesSystem

function IsPlayerAllowedToOpenCrownCrates() end
--Returns: *bool isAllowed, errorStringId

function PlayCrownCrateTierSpecificParticleSoundAndVibration(crownCrateTierId, crownCrateTierParticleEffects) end

function PlayCrownCrateSpecificParticleSoundAndVibration(crownCrateId, crownCrateTierParticleEffects) end

function RefreshCardsInCrownCrateNPCsHand() end

function SetCrownCrateUIMenuActive(active) end

function GetCrownCrateTierOrdering(tierId) end
--Returns: *integer tierOrdering

function StartWorldParticleEffect(particleEffectId) end

function StopWorldParticleEffect(particleEffectId) end

function SetWorldParticleEffectPosition(particleEffectId, worldX, worldY, worldZ) end

function SetWorldParticleEffectOrientation(particleEffectId, pitchRadians, yawRadians, rollRadians) end

function SetWorldParticleEffectScale(particleEffectId, scale) end

function DeleteWorldParticleEffect(particleEffectId) end

function GetActiveUserEmailAddress() end
--Returns: *string emailAddress

function GetCurrentZoneDungeonDifficulty() end
--Returns: *[DungeonDifficulty|#DungeonDifficulty] isVeteranDifficulty

function HousingEditorToggleSurfaceDragMode() end

function HousingEditorRequestPlacement() end

function HousingEditorRequestRemoveFurniture(furnitureId) end

function HousingEditorRotateFurniture(axis, magnitude) end

function HousingEditorPushFurniture(magnitude) end

function HousingEditorAlignFurnitureToSurface() end

function HousingEditorPreviewItemFurniture(bagId, slotIndex) end
--Returns: *bool success

function HousingEditorPreviewCollectibleFurniture(collectibleId) end
--Returns: *bool success

function HousingEditorEndCurrentPreview() end

function HousingEditorIsPreviewing() end
--Returns: *bool isPreview

function HousingEditorSelectFurniture() end

function HousingEditorCanSelectFurniture() end

function HousingEditorRequestModeChange(mode) end

function GetHousingEditorMode() end
--Returns: *[HousingEditorMode|#HousingEditorMode] mode

function GetNextPlacedHousingFurnitureId(lastItemId) end
--Returns: *id64:nilable nextItemId

function GetPlacedHousingFurnitureInfo(itemId) end
--Returns: *string itemName, icon

function HousingEditorCanPlaceCollectible(collectibleId) end
--Returns: *bool success

function HousingEditorJumpToSafeLocation() end

function SetNameplateKeyboardFont(fontName, fontStyle) end

function GetNameplateKeyboardFont() end
--Returns: *string fontName, fontStyle

function SetNameplateGamepadFont(fontName, fontStyle) end

function GetNameplateGamepadFont() end
--Returns: *string fontName, fontStyle

function GetNextActiveArtificialEffectId(lastActiveEffectId) end
--Returns: *integer:nilable nextActiveEffectId

function GetArtificialEffectInfo(artificialEffectId) end
--Returns: *string displayName, icon, effectType, sortOrder

function GetArtificialEffectTooltipText(artificialEffectId) end
--Returns: *string tooltipText
