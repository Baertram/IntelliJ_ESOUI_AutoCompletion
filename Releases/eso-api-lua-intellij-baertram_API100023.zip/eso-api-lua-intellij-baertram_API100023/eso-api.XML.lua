--UI XML Layout

-- Attributes:
addressMode = nil = nil ---[TextureAddressMode|#TextureAddressMode]
allowBringToTop = nil ---bool
alpha = nil ---number
anchorIndex = nil ---integer
autoAdjustTextureCoords = nil ---bool
barAlignment = nil ---[BarAlignment|#BarAlignment]
blendMode = nil ---[TextureBlendMode|#TextureBlendMode]
cellsHigh = nil ---integer
cellsWide = nil ---integer
centerColor = nil ---string
clampedToScreen = nil ---bool
clickSound = nil ---string
color = nil ---string
delay = nil ---integer
deltaX = nil ---number
deltaXFromEnd = nil ---number
deltaY = nil ---number
deltaYFromEnd = nil ---number
deltaZ = nil ---number
deltaZFromEnd = nil ---number
disabled = nil ---string
disabledColor = nil ---string
disabledPressed = nil ---string
disabledPressedColor = nil ---string
dragFromThumb = nil ---bool
drawLastEntryIfOutOfRoom = nil ---bool
duration = nil ---integer
edgeColor = nil ---string
editEnabled = nil ---bool
enableFadeOut = nil ---bool
endAlpha = nil ---number
endCapWidth = nil ---integer
endColor = nil ---string
endHeight = nil ---number
endPitch = nil ---number
endRoll = nil ---number
endRotation = nil ---number
endScale = nil ---number
endWidth = nil ---number
endX = nil ---number
endY = nil ---number
endYaw = nil ---number
endZ = nil ---number
excludeFromResizeToFitExtents = nil ---bool
fadeOutGainColor = nil ---string
fadeOutLossColor = nil ---string
fadeOutTextureFile = nil ---string
fillColor = nil ---string
font = nil ---string
framerate = nil ---number
headerRowSpacing = nil ---number
headerVerticalOffset = nil ---number
hidden = nil ---bool
horizontalAlignment = nil ---[TextAlignment|#TextAlignment]
id = nil ---integer
inheritAlpha = nil ---bool
inheritScale = nil ---bool
inherits = nil ---string
integralWrapping = nil ---bool
keyboardEnabled = nil ---bool
layer = nil ---string
leadingEdgeTexture = nil ---string
level = nil ---integer
lineSpacing = nil ---integer
linkEnabled = nil ---bool
loopCount = nil ---string
maxHistoryLines = nil ---integer
maxInputCharacters = nil ---integer
maxLineCount = nil ---integer
mirrorAlongX = nil ---bool
mirrorAlongY = nil ---bool
modifyTextType = nil ---[ModifyTextType|#ModifyTextType]
mouseEnabled = nil ---bool
mouseOver = nil ---string
mouseOverBlendMode = nil ---[TextureBlendMode|#TextureBlendMode]
mouseOverColor = nil ---string
movable = nil ---bool
multiLine = nil ---bool
newLineEnabled = nil ---bool
newLineIndent = nil ---number
normal = nil ---string
normalColor = nil ---string
orientation = nil ---[ControlOrientation|#ControlOrientation]
pinFont = nil ---string
pixelRoundingEnabled = nil ---bool
playbackType = nil ---[AnimationPlayback|#AnimationPlayback]
pressed = nil ---string
pressedColor = nil ---string
pressedMouseOver = nil ---string
radialCooldownClockwise = nil ---bool
radialCooldownOriginAngle = nil ---number
resizeHandleSize = nil ---number
resizeToFitDescendents = nil ---bool
resizeToFitFile = nil ---bool
scale = nil ---number
selectionColor = nil ---string
shape = nil ---[ShapeType|#ShapeType]
splitLongMessages = nil ---bool
startAlpha = nil ---number
startColor = nil ---string
startHeight = nil ---number
startPitch = nil ---number
startRoll = nil ---number
startRotation = nil ---number
startScale = nil ---number
startWidth = nil ---number
startX = nil ---number
startY = nil ---number
startYaw = nil ---number
startZ = nil ---number
step = nil ---number
styleColor = nil ---string
text = nil ---string
textType = nil ---string
textureCoordsRotation = nil ---number
textureFile = nil ---string
textureFileReleaseOption = nil ---[ReleaseReferenceOptions|#ReleaseReferenceOptions]
thickness = nil ---number
tier = nil ---string
topmost = nil ---bool
verticalAlignment = nil ---[TextAlignment|#TextAlignment]
wrapMode = nil ---[TextWrapMode|#TextWrapMode]

-- AlphaAnimation = nil ---[Inherits: AnimationBase|#AnimationBase]
---[Child: endAlpha|#Attributes] = nil ---[Child: startAlpha|#Attributes]

-- Anchor = nil ---attribute: [AnchorPosition|#AnchorPosition] point
---attribute: [AnchorPosition|#AnchorPosition] relativePoint = nil ---attribute: string relativeTo
---attribute: number offsetX = nil ---attribute: number offsetY
---attribute: [AnchorConstrains|#AnchorConstrains] constrains

-- AnchorFill

-- AnchorToBaseline = nil ---attribute: string relativeToLabel
---attribute: number offsetX = nil ---attribute: [AnchorPosition|#AnchorPosition] side

-- AnimationBase = nil ---attribute: string name
---[Child: EasingFunction|#EasingFunction] = nil ---[Child: OnPlayAnimation|#OnPlayAnimation]
---[Child: OnStopAnimation|#OnStopAnimation] = nil ---[Child: delay|#Attributes]
---[Child: duration|#Attributes] = nil ---[Child: inherits|#Attributes]

-- AnimationTimeline = nil ---attribute: string name
---[Child: Animations|#Animations] = nil ---[Child: Callbacks|#Callbacks]
---[Child: OnDurationChanged|#OnDurationChanged] = nil ---[Child: OnPlay|#OnPlay]
---[Child: OnStop|#OnStop] = nil ---[Child: delay|#Attributes]
---[Child: inherits|#Attributes] = nil ---[Child: loopCount|#Attributes]
---[Child: playbackType|#Attributes]

-- Animations = nil ---[Child: AlphaAnimation|#AlphaAnimation]
---[Child: AnimationTimeline|#AnimationTimeline] = nil ---[Child: ColorAnimation|#ColorAnimation]
---[Child: CustomAnimation|#CustomAnimation] = nil ---[Child: Rotate3DAnimation|#Rotate3DAnimation]
---[Child: ScaleAnimation|#ScaleAnimation] = nil ---[Child: SizeAnimation|#SizeAnimation]
---[Child: TextureAnimation|#TextureAnimation] = nil ---[Child: TextureRotateAnimation|#TextureRotateAnimation]
---[Child: Translate3DAnimation|#Translate3DAnimation] = nil ---[Child: TranslateAnimation|#TranslateAnimation]

-- Backdrop = nil ---[Inherits: Control|#Control]
---[Child: Center|#Center] = nil ---[Child: Edge|#Edge]
---[Child: Insets|#Insets] = nil ---[Child: blendMode|#Attributes]
---[Child: centerColor|#Attributes] = nil ---[Child: edgeColor|#Attributes]
---[Child: integralWrapping|#Attributes] = nil ---[Child: pixelRoundingEnabled|#Attributes]
---[Child: textureFileReleaseOption|#Attributes]

-- BackgroundBottom = nil ---attribute: string textureFile
---attribute: number left = nil ---attribute: number top
---attribute: number bottom = nil ---attribute: number right

-- BackgroundMiddle = nil ---attribute: string textureFile
---attribute: number left = nil ---attribute: number top
---attribute: number bottom = nil ---attribute: number right

-- BackgroundTop = nil ---attribute: string textureFile
---attribute: number left = nil ---attribute: number top
---attribute: number bottom = nil ---attribute: number right

-- Browser = nil ---[Inherits: Control|#Control]
---[Child: OnLoadFinished|#OnLoadFinished] = nil ---[Child: OnLoadStart|#OnLoadStart]
---[Child: OnRequestClose|#OnRequestClose]

-- Button = nil ---[Inherits: Control|#Control]
---[Child: ButtonState|#ButtonState] = nil ---[Child: FontColors|#FontColors]
---[Child: MouseButton|#MouseButton] = nil ---[Child: NormalOffset|#NormalOffset]
---[Child: OnClicked|#OnClicked] = nil ---[Child: PressedOffset|#PressedOffset]
---[Child: TextureCoords|#TextureCoords] = nil ---[Child: Textures|#Textures]
---[Child: clickSound|#Attributes] = nil ---[Child: endCapWidth|#Attributes]
---[Child: font|#Attributes] = nil ---[Child: horizontalAlignment|#Attributes]
---[Child: modifyTextType|#Attributes] = nil ---[Child: mouseOverBlendMode|#Attributes]
---[Child: pixelRoundingEnabled|#Attributes] = nil ---[Child: text|#Attributes]
---[Child: textureFileReleaseOption|#Attributes] = nil ---[Child: verticalAlignment|#Attributes]

-- ButtonState = nil ---attribute: [ButtonState|#ButtonState] state
---attribute: bool locked

-- Callback = nil ---[Inherits: OnInsertAnimationTimelineCallback|#OnInsertAnimationTimelineCallback]
---ScriptArguments: local self, time = ...

-- Callbacks = nil ---[Child: Callback|#Callback]

-- Center = nil ---attribute: string file
---attribute: bool tiled = nil ---attribute: integer tileSize

-- ClampedToScreenInsets = nil ---attribute: number left
---attribute: number top = nil ---attribute: number right
---attribute: number bottom

-- ColorAnimation = nil ---[Inherits: AnimationBase|#AnimationBase]
---[Child: endColor|#Attributes] = nil ---[Child: startColor|#Attributes]

-- ColorSelect = nil ---[Inherits: Control|#Control]
---[Child: OnColorSelected|#OnColorSelected]

-- Compass = nil ---[Inherits: Control|#Control]
---[Child: CompassPinType|#CompassPinType]

-- CompassPinType = nil ---attribute: [MapDisplayPinType|#MapDisplayPinType] name
---attribute: number pinSize = nil ---attribute: string pinTexture
---attribute: string areaTexture = nil ---attribute: string aboveTexture
---attribute: string belowTexture = nil ---attribute: string linkTexture
---attribute: bool clamped = nil ---attribute: bool allowUpdatesWhenAnimating
---attribute: number minScale = nil ---attribute: number maxScale
---attribute: number minVisibleScale = nil ---attribute: number minAlpha
---attribute: number maxAlpha = nil ---attribute: number minVisibleAlpha
---attribute: number maxVisibleNormalizedDistance = nil ---attribute: number leadingScaleCoefficient
---attribute: number scaleCoefficient = nil ---attribute: number scaleConstant
---attribute: number leadingAlphaCoefficient = nil ---attribute: number alphaCoefficient
---attribute: number alphaConstant = nil ---attribute: string animation
---attribute: string addedAnimation = nil ---attribute: string removedAnimation
---attribute: [DrawLayer|#DrawLayer] layer

-- Control = nil ---attribute: string name
---attribute: bool virtual = nil ---attribute: bool override
---attribute: [ControlAccessControl|#ControlAccessControl] accessControl = nil ---[Child: Anchor|#Anchor]
---[Child: AnchorFill|#AnchorFill] = nil ---[Child: ClampedToScreenInsets|#ClampedToScreenInsets]
---[Child: Controls|#Controls] = nil ---[Child: DimensionConstraints|#DimensionConstraints]
---[Child: Dimensions|#Dimensions] = nil ---[Child: HitInsets|#HitInsets]
---[Child: OnChar|#OnChar] = nil ---[Child: OnDragStart|#OnDragStart]
---[Child: OnEffectivelyHidden|#OnEffectivelyHidden] = nil ---[Child: OnEffectivelyShown|#OnEffectivelyShown]
---[Child: OnHide|#OnHide] = nil ---[Child: OnInitialized|#OnInitialized]
---[Child: OnKeyDown|#OnKeyDown] = nil ---[Child: OnKeyUp|#OnKeyUp]
---[Child: OnMouseDoubleClick|#OnMouseDoubleClick] = nil ---[Child: OnMouseDown|#OnMouseDown]
---[Child: OnMouseEnter|#OnMouseEnter] = nil ---[Child: OnMouseExit|#OnMouseExit]
---[Child: OnMouseUp|#OnMouseUp] = nil ---[Child: OnMouseWheel|#OnMouseWheel]
---[Child: OnMoveStart|#OnMoveStart] = nil ---[Child: OnMoveStop|#OnMoveStop]
---[Child: OnReceiveDrag|#OnReceiveDrag] = nil ---[Child: OnResizeStart|#OnResizeStart]
---[Child: OnResizeStop|#OnResizeStop] = nil ---[Child: OnResizedToFit|#OnResizedToFit]
---[Child: OnShow|#OnShow] = nil ---[Child: OnUpdate|#OnUpdate]
---[Child: ResizeToFitPadding|#ResizeToFitPadding] = nil ---[Child: alpha|#Attributes]
---[Child: clampedToScreen|#Attributes] = nil ---[Child: excludeFromResizeToFitExtents|#Attributes]
---[Child: hidden|#Attributes] = nil ---[Child: id|#Attributes]
---[Child: inheritAlpha|#Attributes] = nil ---[Child: inheritScale|#Attributes]
---[Child: inherits|#Attributes] = nil ---[Child: keyboardEnabled|#Attributes]
---[Child: layer|#Attributes] = nil ---[Child: level|#Attributes]
---[Child: mouseEnabled|#Attributes] = nil ---[Child: movable|#Attributes]
---[Child: resizeHandleSize|#Attributes] = nil ---[Child: resizeToFitDescendents|#Attributes]
---[Child: scale|#Attributes] = nil ---[Child: tier|#Attributes]

-- Controls = nil ---[Child: Backdrop|#Backdrop]
---[Child: Browser|#Browser] = nil ---[Child: Button|#Button]
---[Child: ColorSelect|#ColorSelect] = nil ---[Child: Compass|#Compass]
---[Child: Control|#Control] = nil ---[Child: Cooldown|#Cooldown]
---[Child: DebugText|#DebugText] = nil ---[Child: EditBox|#EditBox]
---[Child: Label|#Label] = nil ---[Child: Line|#Line]
---[Child: MapDisplay|#MapDisplay] = nil ---[Child: Scroll|#Scroll]
---[Child: Slider|#Slider] = nil ---[Child: StatusBar|#StatusBar]
---[Child: TextBuffer|#TextBuffer] = nil ---[Child: Texture|#Texture]
---[Child: TextureComposite|#TextureComposite] = nil ---[Child: Tooltip|#Tooltip]
---[Child: TopLevelControl|#TopLevelControl]

-- Cooldown = nil ---[Inherits: Control|#Control]
---[Child: RadialCooldownGradient|#RadialCooldownGradient] = nil ---[Child: blendMode|#Attributes]
---[Child: fillColor|#Attributes] = nil ---[Child: leadingEdgeTexture|#Attributes]
---[Child: radialCooldownClockwise|#Attributes] = nil ---[Child: radialCooldownOriginAngle|#Attributes]
---[Child: textureFile|#Attributes] = nil ---[Child: textureFileReleaseOption|#Attributes]

-- CustomAnimation = nil ---[Inherits: AnimationBase|#AnimationBase]
---[Child: UpdateFunction|#UpdateFunction]

-- DebugText = nil ---[Inherits: Control|#Control]
---[Child: font|#Attributes]

-- DimensionConstraints = nil ---attribute: number minX
---attribute: number minY = nil ---attribute: number maxX
---attribute: number maxY

-- Dimensions = nil ---attribute: number x
---attribute: number y

-- EasingFunction = nil ---[Inherits: OnSetAnimationEaseFunction|#OnSetAnimationEaseFunction]
---ScriptArguments: local progress = ...

-- Edge = nil ---attribute: string file
---attribute: integer edgeFileWidth = nil ---attribute: integer edgeFileHeight
---attribute: integer edgeSize = nil ---attribute: integer edgeFilePadding

-- EditBox = nil ---[Inherits: Control|#Control]
---[Child: OnBackspace|#OnBackspace] = nil ---[Child: OnDownArrow|#OnDownArrow]
---[Child: OnEnter|#OnEnter] = nil ---[Child: OnEscape|#OnEscape]
---[Child: OnFocusGained|#OnFocusGained] = nil ---[Child: OnFocusLost|#OnFocusLost]
---[Child: OnIMEBeginComposition|#OnIMEBeginComposition] = nil ---[Child: OnIMEEndComposition|#OnIMEEndComposition]
---[Child: OnPageDown|#OnPageDown] = nil ---[Child: OnPageUp|#OnPageUp]
---[Child: OnSpace|#OnSpace] = nil ---[Child: OnTab|#OnTab]
---[Child: OnTextChanged|#OnTextChanged] = nil ---[Child: OnUpArrow|#OnUpArrow]
---[Child: color|#Attributes] = nil ---[Child: editEnabled|#Attributes]
---[Child: font|#Attributes] = nil ---[Child: maxInputCharacters|#Attributes]
---[Child: multiLine|#Attributes] = nil ---[Child: newLineEnabled|#Attributes]
---[Child: selectionColor|#Attributes] = nil ---[Child: textType|#Attributes]

-- FadeGradient = nil ---attribute: number x1
---attribute: number y1 = nil ---attribute: number size1
---attribute: number x2 = nil ---attribute: number y2
---attribute: number size2

-- Font = nil ---attribute: string name
---attribute: bool virtual = nil ---[Child: sentinelelement|#sentinelelement]
---[Child: font|#Attributes] = nil ---[Child: inherits|#Attributes]

-- FontColors = nil ---[Child: disabledColor|#Attributes]
---[Child: disabledPressedColor|#Attributes] = nil ---[Child: mouseOverColor|#Attributes]
---[Child: normalColor|#Attributes] = nil ---[Child: pressedColor|#Attributes]

-- GuiXml = nil ---[Child: Animations|#Animations]
---[Child: Controls|#Controls] = nil ---[Child: Font|#Font]
---[Child: String|#String]

-- HitInsets = nil ---attribute: number left
---attribute: number top = nil ---attribute: number right
---attribute: number bottom

-- Insets = nil ---attribute: number left
---attribute: number top = nil ---attribute: number right
---attribute: number bottom

-- Label = nil ---[Inherits: Control|#Control]
---[Child: AnchorToBaseline|#AnchorToBaseline] = nil ---[Child: OnLinkClicked|#OnLinkClicked]
---[Child: OnLinkMouseUp|#OnLinkMouseUp] = nil ---[Child: OnTextChanged|#OnTextChanged]
---[Child: OnUserAreaCreated|#OnUserAreaCreated] = nil ---[Child: color|#Attributes]
---[Child: font|#Attributes] = nil ---[Child: horizontalAlignment|#Attributes]
---[Child: lineSpacing|#Attributes] = nil ---[Child: linkEnabled|#Attributes]
---[Child: maxLineCount|#Attributes] = nil ---[Child: modifyTextType|#Attributes]
---[Child: newLineIndent|#Attributes] = nil ---[Child: pixelRoundingEnabled|#Attributes]
---[Child: styleColor|#Attributes] = nil ---[Child: text|#Attributes]
---[Child: verticalAlignment|#Attributes] = nil ---[Child: wrapMode|#Attributes]

-- LeadingEdge = nil ---attribute: string textureFile
---attribute: number width = nil ---attribute: number height

-- LeadingEdgeTextureCoords = nil ---attribute: number left
---attribute: number right = nil ---attribute: number top
---attribute: number bottom

-- Limits = nil ---attribute: number min
---attribute: number max

-- Line = nil ---[Inherits: Control|#Control]
---[Child: TextureCoords|#TextureCoords] = nil ---[Child: blendMode|#Attributes]
---[Child: color|#Attributes] = nil ---[Child: pixelRoundingEnabled|#Attributes]
---[Child: textureFile|#Attributes] = nil ---[Child: thickness|#Attributes]

-- LineFade = nil ---attribute: number fadeBegin
---attribute: number fadeDuration

-- LocalDimensions3D = nil ---attribute: number x
---attribute: number y

-- MapDisplay = nil ---[Inherits: Control|#Control]
---[Child: MapGutter|#MapGutter] = nil ---[Child: MapPinType|#MapPinType]
---[Child: OnVisibleRadiusChanged|#OnVisibleRadiusChanged] = nil ---[Child: pinFont|#Attributes]
---[Child: shape|#Attributes]

-- MapGutter = nil ---attribute: number offset
---attribute: number size

-- MapPinType = nil ---attribute: [MapDisplayPinType|#MapDisplayPinType] name
---attribute: [MapArrowType|#MapArrowType] arrowType = nil ---attribute: number pinSize
---attribute: number pinXInset = nil ---attribute: number pinYInset
---attribute: number arrowSize = nil ---attribute: string pinTexture
---attribute: string arrowTexture = nil ---attribute: string areaTexture
---attribute: string aboveTexture = nil ---attribute: string belowTexture
---attribute: string linkTexture = nil ---attribute: string animation
---attribute: string addedAnimation = nil ---attribute: string removedAnimation
---attribute: [MapPinAnimationTarget|#MapPinAnimationTarget] animationTarget

-- MouseButton = nil ---attribute: integer button
---attribute: bool enabled

-- NormalOffset = nil ---attribute: number x
---attribute: number y

-- OnAddGameData = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnBackspace = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnChar = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, key = ...

-- OnCleared = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnClicked = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, button = ...

-- OnColorSelected = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, r, g, b = ...

-- OnDownArrow = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnDragStart = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, button = ...

-- OnDurationChanged = nil ---[Inherits: OnSetAnimationTimelineEventHandler|#OnSetAnimationTimelineEventHandler]
---ScriptArguments: local self, duration = ...

-- OnEffectivelyHidden = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, hidden = ...

-- OnEffectivelyShown = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, hidden = ...

-- OnEnabledStateChanged = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, enabled = ...

-- OnEnter = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnEscape = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnFocusGained = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnFocusLost = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnHide = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, hidden = ...

-- OnIMEBeginComposition = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnIMEEndComposition = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnInitialized = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnInsertAnimationTimelineCallback = nil ---attribute: integer delay

-- OnKeyDown = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, key, ctrl, alt, shift, command = ...

-- OnKeyUp = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, key, ctrl, alt, shift, command = ...

-- OnLinkClicked = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, linkData, linkText, button, ctrl, alt, shift, command = ...

-- OnLinkMouseUp = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, linkData, linkText, button, ctrl, alt, shift, command = ...

-- OnLoadFinished = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnLoadStart = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnMinMaxValueChanged = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, min, max = ...

-- OnMouseDoubleClick = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, button, ctrl, alt, shift, command = ...

-- OnMouseDown = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, button, ctrl, alt, shift, command = ...

-- OnMouseEnter = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnMouseExit = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnMouseUp = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, button, upInside, ctrl, alt, shift, command = ...

-- OnMouseWheel = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, delta, ctrl, alt, shift, command = ...

-- OnMoveStart = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnMoveStop = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnPageDown = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnPageUp = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnPlay = nil ---[Inherits: OnSetAnimationTimelineEventHandler|#OnSetAnimationTimelineEventHandler]
---ScriptArguments: local self, completedPlaying = ...

-- OnPlayAnimation = nil ---[Inherits: OnSetAnimationEventHandler|#OnSetAnimationEventHandler]
---ScriptArguments: local self, animatingControl, completedPlaying = ...

-- OnReceiveDrag = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, button = ...

-- OnRequestClose = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnResizeStart = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnResizeStop = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnResizedToFit = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, desiredWidth, desiredHeight = ...

-- OnScrollExtentsChanged = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, horizontal, vertical = ...

-- OnScrollOffsetChanged = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, horizontal, vertical = ...

-- OnSetAnimationEaseFunction

-- OnSetAnimationEventHandler

-- OnSetAnimationTimelineEventHandler

-- OnSetControlEventHandler

-- OnSetUpdateFunction

-- OnShow = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, hidden = ...

-- OnSliderReleased = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, value = ...

-- OnSpace = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnStop = nil ---[Inherits: OnSetAnimationTimelineEventHandler|#OnSetAnimationTimelineEventHandler]
---ScriptArguments: local self, completedPlaying = ...

-- OnStopAnimation = nil ---[Inherits: OnSetAnimationEventHandler|#OnSetAnimationEventHandler]
---ScriptArguments: local self, animatingControl, completedPlaying = ...

-- OnTab = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnTextChanged = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnTextureLoaded = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnUpArrow = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self = ...

-- OnUpdate = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, time = ...

-- OnUserAreaCreated = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, areaData, areaText, left, right, top, bottom, continuation = ...

-- OnValueChanged = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, value, eventReason = ...

-- OnVisibleRadiusChanged = nil ---[Inherits: OnSetControlEventHandler|#OnSetControlEventHandler]
---ScriptArguments: local self, radius = ...

-- PressedOffset = nil ---attribute: number x
---attribute: number y

-- RadialCooldownGradient = nil ---attribute: number startAlpha
---attribute: number angularDistance

-- ResizeToFitPadding = nil ---attribute: number width
---attribute: number height

-- Rotate3DAnimation = nil ---[Inherits: AnimationBase|#AnimationBase]
---[Child: endPitch|#Attributes] = nil ---[Child: endRoll|#Attributes]
---[Child: endYaw|#Attributes] = nil ---[Child: startPitch|#Attributes]
---[Child: startRoll|#Attributes] = nil ---[Child: startYaw|#Attributes]

-- ScaleAnimation = nil ---[Inherits: AnimationBase|#AnimationBase]
---[Child: endScale|#Attributes] = nil ---[Child: startScale|#Attributes]

-- Scroll = nil ---[Inherits: Control|#Control]
---[Child: FadeGradient|#FadeGradient] = nil ---[Child: OnScrollExtentsChanged|#OnScrollExtentsChanged]
---[Child: OnScrollOffsetChanged|#OnScrollOffsetChanged]

-- ScrollingOverlay = nil ---attribute: string textureFile
---attribute: number width = nil ---attribute: number height
---attribute: integer duration

-- SizeAnimation = nil ---[Inherits: AnimationBase|#AnimationBase]
---[Child: endHeight|#Attributes] = nil ---[Child: endWidth|#Attributes]
---[Child: startHeight|#Attributes] = nil ---[Child: startWidth|#Attributes]

-- Slider = nil ---[Inherits: Control|#Control]
---[Child: BackgroundBottom|#BackgroundBottom] = nil ---[Child: BackgroundMiddle|#BackgroundMiddle]
---[Child: BackgroundTop|#BackgroundTop] = nil ---[Child: Limits|#Limits]
---[Child: OnEnabledStateChanged|#OnEnabledStateChanged] = nil ---[Child: OnSliderReleased|#OnSliderReleased]
---[Child: OnValueChanged|#OnValueChanged] = nil ---[Child: ThumbTexture|#ThumbTexture]
---[Child: dragFromThumb|#Attributes] = nil ---[Child: orientation|#Attributes]
---[Child: step|#Attributes]

-- StatusBar = nil ---[Inherits: Control|#Control]
---[Child: LeadingEdge|#LeadingEdge] = nil ---[Child: LeadingEdgeTextureCoords|#LeadingEdgeTextureCoords]
---[Child: Limits|#Limits] = nil ---[Child: OnMinMaxValueChanged|#OnMinMaxValueChanged]
---[Child: OnValueChanged|#OnValueChanged] = nil ---[Child: ScrollingOverlay|#ScrollingOverlay]
---[Child: TextureCoords|#TextureCoords] = nil ---[Child: barAlignment|#Attributes]
---[Child: color|#Attributes] = nil ---[Child: enableFadeOut|#Attributes]
---[Child: fadeOutGainColor|#Attributes] = nil ---[Child: fadeOutLossColor|#Attributes]
---[Child: fadeOutTextureFile|#Attributes] = nil ---[Child: orientation|#Attributes]
---[Child: textureFile|#Attributes]

-- String = nil ---attribute: string name
---attribute: string value

-- Surface = nil ---attribute: number texCoordLeft
---attribute: number texCoordRight = nil ---attribute: number texCoordTop
---attribute: number texCoordBottom = nil ---attribute: number insetLeft
---attribute: number insetRight = nil ---attribute: number insetTop
---attribute: number insetBottom = nil ---attribute: string color

-- TextBuffer = nil ---[Inherits: Control|#Control]
---[Child: LineFade|#LineFade] = nil ---[Child: OnLinkClicked|#OnLinkClicked]
---[Child: OnLinkMouseUp|#OnLinkMouseUp] = nil ---[Child: color|#Attributes]
---[Child: drawLastEntryIfOutOfRoom|#Attributes] = nil ---[Child: font|#Attributes]
---[Child: horizontalAlignment|#Attributes] = nil ---[Child: linkEnabled|#Attributes]
---[Child: maxHistoryLines|#Attributes] = nil ---[Child: splitLongMessages|#Attributes]

-- Texture = nil ---[Inherits: Control|#Control]
---[Child: LocalDimensions3D|#LocalDimensions3D] = nil ---[Child: OnTextureLoaded|#OnTextureLoaded]
---[Child: TextureCoords|#TextureCoords] = nil ---[Child: addressMode|#Attributes]
---[Child: autoAdjustTextureCoords|#Attributes] = nil ---[Child: blendMode|#Attributes]
---[Child: color|#Attributes] = nil ---[Child: pixelRoundingEnabled|#Attributes]
---[Child: resizeToFitFile|#Attributes] = nil ---[Child: textureCoordsRotation|#Attributes]
---[Child: textureFile|#Attributes] = nil ---[Child: textureFileReleaseOption|#Attributes]

-- TextureAnimation = nil ---[Inherits: AnimationBase|#AnimationBase]
---[Child: cellsHigh|#Attributes] = nil ---[Child: cellsWide|#Attributes]
---[Child: framerate|#Attributes] = nil ---[Child: mirrorAlongX|#Attributes]
---[Child: mirrorAlongY|#Attributes]

-- TextureComposite = nil ---[Inherits: Control|#Control]
---[Child: Surface|#Surface] = nil ---[Child: blendMode|#Attributes]
---[Child: pixelRoundingEnabled|#Attributes] = nil ---[Child: textureFile|#Attributes]
---[Child: textureFileReleaseOption|#Attributes]

-- TextureCoords = nil ---attribute: number left
---attribute: number right = nil ---attribute: number top
---attribute: number bottom

-- TextureRotateAnimation = nil ---[Inherits: AnimationBase|#AnimationBase]
---[Child: endRotation|#Attributes] = nil ---[Child: startRotation|#Attributes]

-- Textures = nil ---[Child: disabled|#Attributes]
---[Child: disabledPressed|#Attributes] = nil ---[Child: mouseOver|#Attributes]
---[Child: normal|#Attributes] = nil ---[Child: pressed|#Attributes]
---[Child: pressedMouseOver|#Attributes]

-- ThumbTexture = nil ---attribute: string textureFile
---attribute: string disabledTextureFile = nil ---attribute: string highlightedTextureFile
---attribute: number thumbWidth = nil ---attribute: number thumbHeight
---attribute: number left = nil ---attribute: number top
---attribute: number bottom = nil ---attribute: number right
---attribute: bool flushWithSliderExtents

-- Tooltip = nil ---[Inherits: Control|#Control]
---[Child: OnAddGameData|#OnAddGameData] = nil ---[Child: OnCleared|#OnCleared]
---[Child: font|#Attributes] = nil ---[Child: headerRowSpacing|#Attributes]
---[Child: headerVerticalOffset|#Attributes]

-- TopLevelControl = nil ---[Inherits: Control|#Control]
---[Child: allowBringToTop|#Attributes] = nil ---[Child: topmost|#Attributes]

-- Translate3DAnimation = nil ---[Inherits: AnimationBase|#AnimationBase]
---[Child: deltaX|#Attributes] = nil ---[Child: deltaXFromEnd|#Attributes]
---[Child: deltaY|#Attributes] = nil ---[Child: deltaYFromEnd|#Attributes]
---[Child: deltaZ|#Attributes] = nil ---[Child: deltaZFromEnd|#Attributes]
---[Child: endX|#Attributes] = nil ---[Child: endY|#Attributes]
---[Child: endZ|#Attributes] = nil ---[Child: startX|#Attributes]
---[Child: startY|#Attributes] = nil ---[Child: startZ|#Attributes]

-- TranslateAnimation = nil ---[Inherits: AnimationBase|#AnimationBase]
---[Child: anchorIndex|#Attributes] = nil ---[Child: deltaX|#Attributes]
---[Child: deltaXFromEnd|#Attributes] = nil ---[Child: deltaY|#Attributes]
---[Child: deltaYFromEnd|#Attributes] = nil ---[Child: endX|#Attributes]
---[Child: endY|#Attributes] = nil ---[Child: startX|#Attributes]
---[Child: startY|#Attributes]

-- UpdateFunction = nil ---[Inherits: OnSetUpdateFunction|#OnSetUpdateFunction]
---ScriptArguments: local self, progress = ...