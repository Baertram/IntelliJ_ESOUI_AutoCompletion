﻿--All UI elements are inheriting the s defined in Control.
AddOnManager = {}
function AddRelevantFilter(relevantFilter) end
function GetAddOnDependencyInfo(addOnIndex, addOnDependencyIndex) end
--Returns:  name, active
function GetAddOnFilter() end
--Returns:  settingFilter
function GetAddOnInfo(addOnIndex) end
--Returns:  name, title, author, description, enabled, AddOnLoadState state, isOutOfDate
function GetAddOnNumDependencies(addOnIndex) end
--Returns:  numDependencies
function GetLoadOutOfDateAddOns() end
--Returns:  loadOutOfDateAddons
function GetNumAddOns() end
--Returns:  numAddOns
function RemoveAddOnFilter() end
function ResetRelevantFilters() end
function SetAddOnEnabled(addOnIndex, enabled) end
function SetAddOnFilter(settingFilter) end
function SetLoadOutOfDateAddOns(loadOutOfDateAddons) end
AnimationManager = {}
function CreateTimeline() end
--Returns:  timeline
function CreateTimelineFromVirtual(timelineName, animatedControl) end
--Returns:  timeline
AnimationObject = {}
--Objects that inherit behavior from AnimationObject
--[[
AnimationObject3DRotate,
AnimationObject3DTranslate,
AnimationObjectAlpha,
AnimationObjectColor,
AnimationObjectCustom,
AnimationObjectScale,
AnimationObjectScroll,
AnimationObjectSize,
AnimationObjectTexture,
AnimationObjectTextureRotate,
AnimationObjectTextureSlide,
AnimationObjectTranslate
]]
function GetAnimatedControl() end
--Returns:  animatedControl
function GetDuration() end
--Returns:  durationMs
function GetEasingFunction() end
--Returns:  Ref
function GetHandler(EventName) end
--Returns:  FunctionRef
function GetTimeline() end
--Returns:  owningTimeline
function IsPlaying() end
--Returns:  isPlaying
function SetAnimatedControl(animatedControl) end
function SetDuration(durationMs) end
function SetEasingFunction(Ref) end
function SetHandler(EventName, FunctionRef) end
AnimationObject3DRotate = {}
function GetEndPitch() end
--Returns:  endPitchRadians
function GetEndRoll() end
--Returns:  endRollRadians
function GetEndYaw() end
--Returns:  endYawRadians
function GetStartPitch() end
--Returns:  startPitchRadians
function GetStartRoll() end
--Returns:  startRollRadians
function GetStartYaw() end
--Returns:  startYawRadians
function SetEndPitch(endPitchRadians) end
function SetEndRoll(endRollRadians) end
function SetEndYaw(endYawRadians) end
function SetRotationValues(startPitchRadians, startYawRadians, startRollRadians, endPitchRadians, endYawRadians, endRollRadians) end
function SetStartPitch(startPitchRadians) end
function SetStartRoll(startRollRadians) end
function SetStartYaw(startYawRadians) end
AnimationObject3DTranslate = {}
function ClearBezierControlPoints() end
function GetDeltaOffsetX() end
--Returns:  deltaX
function GetDeltaOffsetY() end
--Returns:  deltaY
function GetDeltaOffsetZ() end
--Returns:  deltaZ
function GetEndOffsetX() end
--Returns:  endX
function GetEndOffsetY() end
--Returns:  endY
function GetEndOffsetZ() end
--Returns:  endZ
function GetStartOffsetX() end
--Returns:  startX
function GetStartOffsetY() end
--Returns:  startY
function GetStartOffsetZ() end
--Returns:  startZ
function GetTranslateDeltas() end
--Returns:  deltaX, deltaY, deltaZ
function SetBezierControlPoint(index, x, y, z) end
function SetDeltaOffsetX(deltaX,  translateAnimationDeltaType) end
function SetDeltaOffsetY(deltaY,  translateAnimationDeltaType) end
function SetDeltaOffsetZ(deltaZ,  translateAnimationDeltaType) end
function SetEndOffsetX(endX) end
function SetEndOffsetY(endY) end
function SetEndOffsetZ(endZ) end
function SetStartOffsetX(startX) end
function SetStartOffsetY(startY) end
function SetStartOffsetZ(startZ) end
function SetTranslateDeltas(deltaX, deltaY, deltaZ,  translateAnimationDeltaType) end
function SetTranslateOffsets(startX, startY, startZ, endX, endY, endZ) end
AnimationObjectAlpha = {}
function GetEndAlpha() end
--Returns:  endAlpha
function GetStartAlpha() end
--Returns:  startAlpha
function SetAlphaValues(startAlpha, endAlpha) end
function SetEndAlpha(endAlpha) end
function SetStartAlpha(startAlpha) end
AnimationObjectColor = {}
function GetEndColor() end
--Returns:  endR, endG, endB, endA
function GetStartColor() end
--Returns:  startR, startG, startB, startA
function SetColorValues(startR, startG, startB, startA, endR, endG, endB, endA) end
function SetEndColor(endR, endG, endB, endA) end
function SetStartColor(startR, startG, startB, startA) end
AnimationObjectCustom = {}
function SetUpdateFunction(Ref) end
AnimationObjectScale = {}
function GetEndScale() end
--Returns:  endScale
function GetStartScale() end
--Returns:  startScale
function SetEndScale(endScale) end
function SetScaleValues(startScale, endScale) end
function SetStartScale(startScale) end
AnimationObjectScroll = {}
function SetHorizontalEnd(endX) end
function SetHorizontalRelative(offsetX) end
function SetHorizontalStartAndEnd(startX, endX) end
function SetVerticalEnd(endY) end
function SetVerticalRelative(offsetY) end
function SetVerticalStartAndEnd(startY, endY) end
AnimationObjectSize = {}
function SetEndHeight(endHeight) end
function SetEndWidth(endWidth) end
function SetStartAndEndHeight(startHeight, endHeight) end
function SetStartAndEndWidth(startWidth, endWidth) end
function SetStartHeight(startHeight) end
function SetStartWidth(startWidth) end
AnimationObjectTexture = {}
function GetCellsHigh() end
--Returns:  aNumCellsHigh
function GetCellsWide() end
--Returns:  aNumCellsWide
function IsMirroringAlongX() end
--Returns:  mirroring
function IsMirroringAlongY() end
--Returns:  mirroring
function SetCellsHigh(aNumCellsHigh) end
function SetCellsWide(aNumCellsWide) end
function SetFramerate(framesPerSecond) end
function SetImageData(aNumCellsWide, aNumCellsHigh) end
function SetMirrorAlongX(mirroring) end
function SetMirrorAlongY(mirroring) end
AnimationObjectTextureRotate = {}
function GetEndRotation() end
--Returns:  endRadians
function GetStartRotation() end
--Returns:  startRadians
function SetEndRotation(endRadians) end
function SetRotationValues(startRadians, endRadians) end
function SetStartRotation(startRadians) end
AnimationObjectTextureSlide = {}
function SetSlideDistances(slideDistanceU, slideDistanceV) end
AnimationObjectTranslate = {}
function GetAnchorIndex() end
--Returns:  anchorIndex
function GetDeltaOffsetX() end
--Returns:  deltaX
function GetDeltaOffsetY() end
--Returns:  deltaY
function GetEndOffsetX() end
--Returns:  endX
function GetEndOffsetY() end
--Returns:  endY
function GetStartOffsetX() end
--Returns:  startX
function GetStartOffsetY() end
--Returns:  startY
function GetTranslateDeltas() end
--Returns:  deltaX, deltaY
function SetAnchorIndex(anchorIndex) end
function SetDeltaOffsetX(deltaX,  translateAnimationDeltaType) end
function SetDeltaOffsetY(deltaY,  translateAnimationDeltaType) end
function SetEndOffsetX(endX) end
function SetEndOffsetY(endY) end
function SetStartOffsetX(startX) end
function SetStartOffsetY(startY) end
function SetTranslateDeltas(deltaX, deltaY,  translateAnimationDeltaType) end
function SetTranslateOffsets(startX, startY, endX, endY) end
AnimationTimeline = {}
function ApplyAllAnimationsToControl(animatedControl) end
function ClearAllCallbacks() end
function GetAnimation(animationIndex) end
--Returns:  animation
function GetAnimationOffset(animation) end
--Returns:  offset
function GetAnimationTimeline(timelineIndex) end
--Returns:  timeline
function GetAnimationTimelineOffset(animation) end
--Returns:  offset
function GetDuration() end
--Returns:  duration
function GetFirstAnimation() end
--Returns:  animation
function GetFirstAnimationTimeline() end
--Returns:  timeline
function GetFullProgress() end
--Returns:  progress
function GetHandler(EventName) end
--Returns:  FunctionRef
function GetLastAnimation() end
--Returns:  animation
function GetLastAnimationTimeline() end
--Returns:  timeline
function GetNumAnimationTimelines() end
--Returns:  numTimelines
function GetNumAnimations() end
--Returns:  numAnimations
function GetParent() end
--Returns:  timeline
function GetPlaybackLoopsRemaining() end
--Returns:  loopsRemaining
function GetProgress() end
--Returns:  progress
function GetSkipAnimationsBehindPlayheadOnInitialPlay() end
--Returns:  skipAnimations
function InsertAnimation(animationType, animatedControl, offset) end
--Returns:  animation
function InsertAnimationFromVirtual(animationVirtualName, animatedControl) end
--Returns:  animation
function InsertAnimationTimeline(offset, animatedControl) end
--Returns:  animation
function InsertAnimationTimelineFromVirtual(animationVirtualName, animatedControl) end
--Returns:  animation
function InsertCallback(Ref, offset) end
--Returns:  RefRet
function IsPlaying() end
--Returns:  isPlaying
function IsPlayingBackward() end
--Returns:  reversed
function PlayBackward() end
function PlayForward() end
function PlayFromEnd(offsetMs) end
function PlayFromStart(offsetMs) end
function PlayInstantlyToEnd() end
function PlayInstantlyToStart() end
function SetAnimationOffset(animation, offset) end
function SetAnimationTimelineOffset(animation, offset) end
function SetCallbackOffset(callback, offset) end
function SetHandler(EventName, FunctionRef) end
function SetPlaybackLoopCount(maxLoopCount) end
function SetPlaybackLoopsRemaining(loopsRemaining) end
function SetPlaybackType(playbackType, maxLoopCount) end
function SetProgress(progress) end
function SetSkipAnimationsBehindPlayheadOnInitialPlay(skipAnimations) end
function Stop() end
BackdropControl = {}
function GetCenterColor() end
--Returns:  r, g, b, a
function IsPixelRoundingEnabled() end
--Returns:  pixelRoundingEnabled
function SetCenterColor(r, g, b, a) end
function SetCenterTexture(filename, tileSize, addressMode) end
function SetEdgeColor(r, g, b, a) end
function SetEdgeTexture(filename, edgeFileWidth, edgeFileHeight, edgeSize, edgeFilePadding) end
function SetInsets(left, top, right, bottom) end
function SetIntegralWrapping(integralWrappingEnabled) end
function SetPixelRoundingEnabled(enabled) end
function SetTextureReleaseOption( releaseOption) end
ButtonControl = {}
function EnableMouseButton(buttonNum, enabled) end
function GetLabelControl() end
--Returns:  labelControl
function GetState() end
--Returns:  state
function IsPixelRoundingEnabled() end
--Returns:  pixelRoundingEnabled
function SetClickSound(clickSound) end
function SetDesaturation(desaturation) end
function SetDisabledFontColor(r, g, b, a) end
function SetDisabledPressedFontColor(r, g, b, a) end
function SetDisabledPressedTexture(textureFilename) end
function SetDisabledTexture(textureFilename) end
function SetEnabled(enabled) end
function SetEndCapWidth(endCapWidth) end
function SetFont(text) end
function SetHorizontalAlignment(horizontalAlign) end
function SetMouseOverBlendMode(blendMode) end
function SetMouseOverFontColor(r, g, b, a) end
function SetMouseOverTexture(textureFilename) end
function SetNormalFontColor(r, g, b, a) end
function SetNormalOffset(x, y) end
function SetNormalTexture(textureFilename) end
function SetPixelRoundingEnabled(pixelRoundingEnabled) end
function SetPressedFontColor(r, g, b, a) end
function SetPressedMouseOverTexture(textureFilename) end
function SetPressedOffset(x, y) end
function SetPressedTexture(textureFilename) end
function SetShowingHighlight(showingHighlight) end
function SetState(newState, locked) end
function SetText(text) end
function SetTextureCoords(left, right, top, bottom) end
function SetTextureReleaseOption( releaseOption) end
function SetVerticalAlignment(verticalAlign) end
ColorSelectControl = {}
function GetColorAsHSV() end
--Returns:  hue, saturation, value
function GetColorAsRGB() end
--Returns:  red, green, blue
function GetColorWheelTextureControl() end
--Returns:  textureControl
function GetColorWheelThumbTextureControl() end
--Returns:  textureControl
function GetFullValuedColorAsRGB() end
--Returns:  red, green, blue
function GetThumbNormalizedPosition() end
--Returns:  normalizedX, normalizedY
function GetValue() end
--Returns:  value
function SetColorAsHSV(hue, saturation, value) end
function SetColorAsRGB(red, green, blue) end
function SetColorWheelThumbTextureControl(textureControl) end
function SetThumbNormalizedPosition(normalizedX, normalizedY) end
function SetValue(value) end
CompassDisplayControl = {}
function GetAlphaCoefficients( pinType) end
--Returns:  leadingCoefficient, coefficient, constant
function GetCenterOveredPinDescription(centerOveredPinIndex) end
--Returns:  description
function GetCenterOveredPinDistance(centerOveredPinIndex) end
--Returns:  distance
function GetCenterOveredPinInfo(centerOveredPinIndex) end
--Returns:  description,  type, distance,  drawLayer, drawLevel, suppressed
function GetCenterOveredPinLayerAndLevel(centerOveredPinIndex) end
--Returns:   drawLayer, drawLevel
function GetCenterOveredPinType(centerOveredPinIndex) end
--Returns:   type
function GetMinVisibleAlpha( pinType) end
--Returns:  minVisibleAlpha
function GetMinVisibleScale( pinType) end
--Returns:  minVisibleScale
function GetNumCenterOveredPins() end
--Returns:  numCenterOveredPins
function GetScaleCoefficients( pinType) end
--Returns:  leadingCoefficient, coefficient, constant
function IsCenterOveredPinSuppressed(centerOveredPinIndex) end
--Returns:  suppressed
function SetAlphaCoefficients( pinType, leadingCoefficient, coefficient, constant) end
function SetCardinalDirection(directionName, font, cardinalDirection) end
function SetMinVisibleAlpha( pinType, minVisibleAlpha) end
function SetMinVisibleScale( pinType, minVisibleScale) end
function SetScaleCoefficients( pinType, leadingCoefficient, coefficient, constant) end
Control = {}
--Objects that inherit behavior from Control
--[[BackdropControl,
ButtonControl,
ColorSelectControl,
CompassDisplayControl,
CooldownControl,
DebugTextControl,
EditControl,
LabelControl,
LineControl,
MapDisplayControl,
RootWindow,
ScrollControl,
SliderControl,
StatusBarControl,
TextBufferControl,
TextureCompositeControl,
TextureControl,
TooltipControl,
TopLevelWindow
]]
function AddFilterForEvent(event) end
--Returns:  success
function ClearAnchors() end
function Convert3DLocalOrientationToWorldOrientation(localPitch, localYaw, localRoll) end
--Returns:  worldPitch, worldYaw, worldRoll
function Convert3DLocalPositionToWorldPosition(localX, localY, localZ) end
--Returns:  worldX, worldY, worldZ
function Convert3DWorldOrientationToLocalOrientation(worldPitch, worldYaw, worldRoll) end
--Returns:  localPitch, localYaw, localRoll
function Convert3DWorldPositionToLocalPosition(worldX, worldY, worldZ) end
--Returns:  localX, localY, localZ
function Create3DRenderSpace() end
function CreateControl(arg1, type) end
--Returns:  apRet
function Destroy3DRenderSpace() end
function Does3DRenderSpaceUseDepthBuffer() end
--Returns:  usesDepthBuffer
function Get3DRenderSpaceForward() end
--Returns:  x, y, z
function Get3DRenderSpaceOrientation() end
--Returns:  pitchRadians, yawRadians, rollRadians
function Get3DRenderSpaceOrigin() end
--Returns:  x, y, z
function Get3DRenderSpaceRight() end
--Returns:  x, y, z
function Get3DRenderSpaceSystem() end
--Returns:  system
function Get3DRenderSpaceUp() end
--Returns:  x, y, z
function GetAlpha() end
--Returns:  alpha
function GetAnchor(anchorIndex) end
--Returns:  isValidAnchor, point, relativeTo, relativePoint, offsetX, offsetY,  anchorConstrains
function GetBottom() end
--Returns:  bottom
function GetCenter() end
--Returns:  centerX, centerY
function GetChild(childIndex) end
--Returns:  childControl
function GetClampedToScreen() end
--Returns:  clamped
function GetClampedToScreenInsets() end
--Returns:  left, top, right, bottom
function GetControlAlpha() end
--Returns:  alpha
function GetControlScale() end
--Returns:  scale
function GetDesiredHeight() end
--Returns:  height
function GetDesiredWidth() end
--Returns:  width
function GetDimensionConstraints() end
--Returns:  minWidth, minHeight, maxWidth, maxHeight
function GetDimensions() end
--Returns:  width, height
function Get() end
--Returns:  layer
function GetDrawLevel() end
--Returns:  level
function GetDrawTier() end
--Returns:  tier
function GetExcludeFromResizeToFitExtents() end
--Returns:  excludes
function GetHandler(handlerName) end
--Returns:  Ref
function GetHeight() end
--Returns:  height
function GetHitInsets() end
--Returns:  left, top, right, bottom
function GetId() end
--Returns:  id
function GetInheritsAlpha() end
--Returns:  inheritAlpha
function GetInheritsScale() end
--Returns:  inheritScale
function GetLeft() end
--Returns:  left
function GetName() end
--Returns:  name
function GetNamedChild(childName) end
--Returns:  returnedControl
function GetNumChildren() end
--Returns:  numChildren
function GetOwningWindow() end
--Returns:  OwningTopLevelWindow
function GetParent() end
--Returns:  ret1
function GetResizeToFitDescendents() end
--Returns:  resizes
function GetResizeToFitPadding() end
--Returns:  width, height
function GetRight() end
--Returns:  right
function GetScale() end
--Returns:  scale
function GetScreenRect() end
--Returns:  left, top, right, bottom
function GetTop() end
--Returns:  top
function GetType() end
--Returns:  type
function GetWidth() end
--Returns:  width
function Has3DRenderSpace() end
--Returns:  has3DRenderSpace
function IsChildOf(desiredParent) end
--Returns:  isChild
function IsControlHidden() end
--Returns:  hidden
function IsHandlerSet(handlerName) end
--Returns:  isSet
function IsHidden() end
--Returns:  hidden
function IsKeyboardEnabled() end
--Returns:  enabled
function IsMouseEnabled() end
--Returns:  enabled
function IsPointInside(x, y, leftOffset, topOffset, rightOffset, bottomOffset) end
--Returns:  isInside
function RegisterForEvent(event, callback) end
--Returns:  success
function Set3DRenderSpaceForward(x, y, z) end
function Set3DRenderSpaceOrientation(pitchRadians, yawRadians, rollRadians) end
function Set3DRenderSpaceOrigin(xM, yM, zM) end
function Set3DRenderSpaceRight(x, y, z) end
function Set3DRenderSpaceSystem(system) end
function Set3DRenderSpaceUp(x, y, z) end
function Set3DRenderSpaceUsesDepthBuffer(usesDepthBuffer) end
function SetAlpha(alpha) end
function SetAnchor(whereOnMe, anchorTargetControl, whereOnTarget, offsetX, offsetY,  anchorConstrains) end -- http://wiki.esoui.com/Control:SetAnchor
function SetAnchorFill(anchorTargetControl) end
function SetClampedToScreen(clamped) end
function SetClampedToScreenInsets(left, top, right, bottom) end
function SetDimensionConstraints(minWidth, minHeight, maxWidth, maxHeight) end
function SetDimensions(width, height) end
function Set(layer) end
function SetDrawLevel(level) end
function SetDrawTier(tier) end
function SetExcludeFromResizeToFitExtents(exclude) end
function SetHandler(handlerName, Ref) end
function SetHeight(height) end
function SetHidden(aHidden) end
function SetHitInsets(left, top, right, bottom) end
function SetId(id) end
function SetInheritAlpha(inheritAlpha) end
function SetInheritScale(inheritScale) end
function SetKeyboardEnabled(enabled) end
function SetMouseEnabled(enabled) end
function SetMovable(isMovable) end
function SetParent(newParent) end
function SetResizeHandleSize(handleSize) end
function SetResizeToFitDescendents(resize) end
function SetResizeToFitPadding(width, height) end
function SetScale(scale) end
function SetShapeType (shapeType) end
function SetSimpleAnchor(anchorTargetControl, offsetX, offsetY) end
function SetSimpleAnchorParent(offsetX, offsetY) end
function SetWidth(width) end
function StartMoving() end
--Returns:  isMoving
function StopMovingOrResizing() end
function ToggleHidden() end
function UnregisterForEvent(event) end
--Returns:  success
CooldownControl = {}
function GetDuration() end
--Returns:  duration
function GetPercentCompleteFixed() end
--Returns:  percentComplete
function GetTimeLeft() end
--Returns:  time
function ResetCooldown() end
function SetBlendMode(blendMode) end
function SetCooldownRemainTime(remain) end
function SetDesaturation(desaturation) end
function SetFillColor(r, g, b, a) end
function SetLeadingEdgeTexture(filename) end
function SetPercentCompleteFixed(percentComplete) end
function SetRadialCooldownClockwise(clockwise) end
function SetRadialCooldownGradient(startAlpha, angularDistance) end
function SetRadialCooldownOriginAngle(originAngle) end
function SetTexture(filename) end
function SetTextureReleaseOption( releaseOption) end
function SetVerticalCooldownLeadingEdgeHeight(leadingEdgeHeight) end
function StartCooldown(remain, duration, cooldownType, cooldownTimeType, drawLeadingEdge) end
function StartFixedCooldown(percentComplete, cooldownType, cooldownTimeType, drawLeadingEdge) end
DebugTextControl = {}
function Clear() end
function SetFont(fontStr) end
EditControl = {}
function AddValidCharacter(validCharacter) end
function Clear() end
function ClearSelection() end
function CopyAllTextToClipboard() end
function GetCopyEnabled() end
--Returns:  enabled
function GetCursorPosition() end
--Returns:  cursorPosition
function GetEditEnabled() end
--Returns:  enabled
function GetFontHeight() end
--Returns:  fontHeightUIUnits
function GetNewLineEnabled() end
--Returns:  enabled
function GetPasteEnabled() end
--Returns:  enabled
function GetScrollExtents() end
--Returns:  numLines
function GetText() end
--Returns:  apRet
function GetTopLineIndex() end
--Returns:  index
function HasFocus() end
--Returns:  aRet
function HasSelection() end
--Returns:  hasSelection
function InsertText(aText) end
function IsComposingIMEText() end
--Returns:  isComposing
function IsMultiLine() end
--Returns:  isMultiLine
function LoseFocus() end
function RemoveAllValidCharacters() end
function SelectAll() end
function SetColor(r, g, b, a) end
function SetCopyEnabled(enabled) end
function SetCursorPosition(cursorPosition) end
function SetEditEnabled(enabled) end
function SetFont(font) end
function SetMaxInputChars(maxChars) end
function SetMultiLine(isMultiLine) end
function SetNewLineEnabled(enabled) end
function SetPasteEnabled(enabled) end
function SetSelection(selectionStartIndex, selectionEndIndex) end
function SetSelectionColor(r, g, b, a) end
function SetText(aText) end
function SetTextType(textType) end
function SetTopLineIndex(index) end
function Set( aKeyboardType) end
function TakeFocus() end
function WasLastChangeVirtualKeyboard() end
--Returns:  aRet
FontObject = {}
function GetFontInfo() end
--Returns:  face, size, option
function SetFont(fontDescriptor) end
LabelControl = {}
function AnchorToBaseline(toLabel, offsetX,  anchorSide) end
function Clean() end
function ClearAnchorToBaseline(toLabel) end
function DidLineWrap() end
--Returns:  didLineWrap
function GetColor() end
--Returns:  r, g, b, a
function GetFontHeight() end
--Returns:  fontHeightUIUnits
function GetHorizontalAlignment() end
--Returns:  align
function Get() end
--Returns:   modifyTextType
function GetNumLines() end
--Returns:  numLines
function GetStringWidth(text) end
--Returns:  pixelWidth
function GetStyleColor() end
--Returns:  r, g, b, a
function GetText() end
--Returns:  apRet
function GetTextDimensions() end
--Returns:  Width, Height
function GetTextHeight() end
--Returns:  Height
function GetTextWidth() end
--Returns:  Width
function GetVerticalAlignment() end
--Returns:  align
function SetColor(r, g, b, a) end
function SetDesaturation(desaturation) end
function SetFont(fontString) end
function SetHorizontalAlignment(align) end
function SetLineSpacing(lineSpacing) end
function SetMaxLineCount(maxLineCount) end
function Set( modifyTextType) end
function SetNewLineX(newLineX) end
function SetPixelRoundingEnabled(pixelRoundingEnabled) end
function SetStyleColor(r, g, b, a) end
function SetText(aText) end
function SetVerticalAlignment(verticalAlign) end
function SetWrapMode(wrapMode) end
function WasTruncated() end
--Returns:  wasTruncated
LineControl = {}
function GetBlendMode() end
--Returns:   blendMode
function GetColor() end
--Returns:  r, g, b, a
function GetDesaturation() end
--Returns:  desaturation
function GetTextureCoords() end
--Returns:  left, right, top, bottom
function GetTextureFileDimensions() end
--Returns:  pixelWidth, pixelHeight
function GetTextureFileName() end
--Returns:  filename
function IsPixelRoundingEnabled() end
--Returns:  pixelRoundingEnabled
function IsTextureLoaded() end
--Returns:  loaded
function SetBlendMode( blendMode) end
function SetColor(r, g, b, a) end
function SetDesaturation(desaturation) end
function SetGradientColors( orientation, startR, startG, startB, startA, endR, endG, endB, endA) end
function SetPixelRoundingEnabled(pixelRoundingEnabled) end
function SetTexture(filename) end
function SetTextureCoords(left, right, top, bottom) end
function SetThickness(thickness) end
function SetVertexColors(vertexPoints, red, green, blue, alpha) end
MapDisplayControl = {}
function GetZoom() end
--Returns:  normalizedRadius
function SetPinFont(pinFont) end
function SetZoom(normalizedRadius) end
RootWindow = {}
ScrollControl = {}
function GetScrollExtents() end
--Returns:  horizontal, vertical
function GetScrollOffsets() end
--Returns:  horizontal, vertical
function RestoreToExtents(duration) end
function SetFadeGradient(gradientIndex, normalX, normalY, gradientLength) end
function SetHorizontalScroll(offset) end
function SetScrollBounding(bounding) end
function SetVerticalScroll(offset) end
SliderControl = {}
function DoesAllowDraggingFromThumb() end
--Returns:  allow
function GetEnabled() end
--Returns:  isEnabled
function GetMinMax() end
--Returns:  min, max
function GetOrientation() end
--Returns:  orientation
function GetThumbTextureControl() end
--Returns:  textureControl
function GetValue() end
--Returns:  value
function GetValueStep() end
--Returns:  step
function IsThumbFlushWithExtents() end
--Returns:  flush
function SetAllowDraggingFromThumb(allow) end
function SetBackgroundBottomTexture(fileName, texTop, texLeft, texBottom, texRight) end
function SetBackgroundMiddleTexture(fileName, texTop, texLeft, texBottom, texRight) end
function SetBackgroundTopTexture(fileName, texTop, texLeft, texBottom, texRight) end
function SetColor(r, g, b, a) end
function SetEnabled(enable) end
function SetMinMax(min, max) end
function SetOrientation(orientation) end
function SetThumbFlushWithExtents(flush) end
function SetThumbTexture(filename, disabledFilename, highlightedFilename, thumbWidth, thumbHeight, texTop, texLeft, texBottom, texRight) end
function SetThumbTextureHeight(height) end
function SetValue(value) end
function SetValueStep(step) end
StatusBarControl = {}
function ClearFadeOutLossAdjustedTopValue() end
function EnableFadeOut(enabled) end
function EnableLeadingEdge(enabled) end
function EnableScrollingOverlay(enabled) end
function GetMinMax() end
--Returns:  min, max
function GetValue() end
--Returns:  value
function SetBarAlignment(barAlignment) end
function SetColor(r, g, b, a) end
function SetFadeOutGainColor(r, g, b, a) end
function SetFadeOutLossAdjustedTopValue(topValue) end
function SetFadeOutLossColor(r, g, b, a) end
function SetFadeOutLossSetValueToAdjust(adjustValue) end
function SetFadeOutTexture(filename) end
function SetFadeOutTime(fadeOutSeconds, fadeOutDelaySeconds) end
function SetGradientColors(startR, startG, startB, startA, endR, endG, endB, endA) end
function SetLeadingEdge(textureFile, width, height) end
function SetLeadingEdgeTextureCoords(left, right, top, bottom) end
function SetMinMax(aMin, aMax) end
function SetOrientation(orientation) end
function SetTexture(filename) end
function SetTextureCoords(left, right, top, bottom) end
function SetValue(aValue) end
function SetupScrollingOverlay(textureFile, width, height, duration) end
TextBufferControl = {}
function AddMessage(aText, r, g, b, colorId) end
function Clear() end
function GetDrawLastEntryIfOutOfRoom() end
--Returns:  drawLastIfOutOfRoom
function GetLineFade() end
--Returns:  timeBeforeLineBeginsToFade, timeItTakesLineToFade
function GetLinkEnabled() end
--Returns:  linkEnabed
function GetMaxHistoryLines() end
--Returns:  numLines
function GetNumHistoryLines() end
--Returns:  numLines
function GetNumVisibleLines() end
--Returns:  numLines
function GetScrollPosition() end
--Returns:  scrollPosition
function IsSplittingLongMessages() end
--Returns:  isSplitting
function MoveScrollPosition(numLines) end
function SetClearBufferAfterFadeout(clearAfterFade) end
function SetColorById(colorId, r, g, b) end
function SetDrawLastEntryIfOutOfRoom(drawLastIfOutOfRoom) end
function SetFont(fontString) end
function SetHorizontalAlignment(align) end
function SetLineFade(timeBeforeLineFadeBegins, timeForLineToFade) end
function SetLinesInheritAlpha(linesInheritAlpha) end
function SetLinkEnabled(linkEnabed) end
function SetMaxHistoryLines(numLines) end
function SetScrollPosition(line) end
function SetSplitLongMessages(splitLongMessages) end
function ShowFadedLines() end
TextureCompositeControl = {}
function AddSurface(left, right, top, bottom) end
function ClearAllSurfaces() end
function GetBlendMode() end
--Returns:   blendMode
function GetColor(surfaceIndex) end
--Returns:  r, g, b, a
function GetDesaturation() end
--Returns:  desaturation
function GetInsets(surfaceIndex) end
--Returns:  left, right, top, bottom
function GetNumSurfaces() end
--Returns:  surfaces
function GetSurfaceAlpha(surfaceIndex) end
--Returns:  a
function GetTextureCoords(surfaceIndex) end
--Returns:  left, right, top, bottom
function GetTextureFileDimensions() end
--Returns:  pixelWidth, pixelHeight
function GetTextureFileName() end
--Returns:  filename
function IsPixelRoundingEnabled() end
--Returns:  pixelRoundingEnabled
function IsSurfaceHidden(surfaceIndex) end
--Returns:  hidden
function IsTextureLoaded() end
--Returns:  loaded
function RemoveSurface(surfaceIndex) end
function SetBlendMode( blendMode) end
function SetColor(surfaceIndex, r, g, b, a) end
function SetDesaturation(desaturation) end
function SetInsets(surfaceIndex, left, right, top, bottom) end
function SetPixelRoundingEnabled(pixelRoundingEnabled) end
function SetSurfaceAlpha(surfaceIndex, a) end
function SetSurfaceHidden(surfaceIndex, hidden) end
function SetTexture(filename) end
function SetTextureCoords(surfaceIndex, left, right, top, bottom) end
function SetTextureReleaseOption( releaseOption) end
TextureControl = {}
function Get3DLocalDimensions() end
--Returns:  width, height
function GetAddressMode() end
--Returns:   addressMode
function GetBlendMode() end
--Returns:   blendMode
function GetColor() end
--Returns:  r, g, b, a
function GetDesaturation() end
--Returns:  desaturation
function GetResizeToFitFile() end
--Returns:  resizesToFitFile
function GetTextureCoords() end
--Returns:  left, right, top, bottom
function GetTextureFileDimensions() end
--Returns:  pixelWidth, pixelHeight
function GetTextureFileName() end
--Returns:  filename
function GetVertexUV( vertex) end
--Returns:  u, v
function Is3DQuadFacingCamera() end
--Returns:  isFacing
function IsPixelRoundingEnabled() end
--Returns:  pixelRoundingEnabled
function IsTextureLoaded() end
--Returns:  loaded
function Set3DLocalDimensions(width, height) end
function SetAddressMode( addressMode) end
function SetAutoAdjustWrappedCoords(enabled) end
function SetBlendMode( blendMode) end
function SetColor(r, g, b, a) end
function SetDesaturation(desaturation) end
function SetGradientColors( orientation, startR, startG, startB, startA, endR, endG, endB, endA) end
function SetPixelRoundingEnabled(pixelRoundingEnabled) end
function SetResizeToFitFile(resizesToFitFile) end
function SetTexture(filename) end
function SetTextureCoords(left, right, top, bottom) end
function SetTextureCoordsRotation(angleInRadians) end
function SetTextureReleaseOption( releaseOption) end
function SetTextureRotation(angleInRadians, normalizedRotationPointX, normalizedRotationPointY) end
function SetTextureSampleProcessingWeight(sampleProcessingType, weight) end
function SetVertexColors(vertexPoints, red, green, blue, alpha) end
function SetVertexUV( vertex, u, v) end
TooltipControl = {}
function AddControl(control, cell, useLastRow) end
function AddHeaderControl(control, headerRow,  headerSide) end
function AddHeaderLine(text, font, headerRow,  headerSide, r, g, b) end
function AddLine(text, font, r, g, b,  lineAnchor,  modifyTextType,  textAlignment, setToFullSize) end
function AddVerticalPadding(paddingY) end
function AppendAvAObjective(queryType, keepId, iveId,  ivePinTier) end
function AppendMapPing(pingType, unitTag) end
function AppendQuestCondition(questIndex, stepIndex, conditionIndex) end
function AppendQuestEnding(questIndex) end
function AppendUnitName(unitTag) end
function ClearLines() end
function GetOwner() end
--Returns:  owner
function HideComparativeTooltips() end
function SetAbility(aAbilityIndex, aShowBase) end
function SetAbilityId(abilityId) end
function SetAchievement(aAchievementId) end
function SetAchievementRewardItem(aAchievementId) end
function SetAction(aSlotId) end
function SetAsComparativeTooltip1() end
function SetAsComparativeTooltip2() end
function SetAttachedMailItem(aMailId, aAttachSlot) end
function SetBagItem(bagIndex, slotIndex) end
function SetBook(categoryIndex, collectionIndex, bookIndex) end
function SetBuff(aBuffSlotId, unitTag) end
function SetBuybackItem(entryIndex) end
function SetChampionSkillAbility(disiplineIndex, skillIndex, numPendingPoints) end
function SetCollectible(collectibleId, addNickname, showHint, showBlockReason) end
function SetEmperorBonusAbility(campaignId, alliance) end
function SetFont(fontStr) end
function SetGuildSpecificItem(guildSpecificItemIndex) end
function SetHeaderRowSpacing(spacing) end
function SetHeaderVerticalOffset(verticalOffset) end
function SetItemUsingEnchantment(itemBagIndex, itemSlotIndex, enchantmentBagIndex, enchantmentSlotIndex) end
function SetKeepBonusAbility(bonusIndex) end
function SetKeepUpgrade(keepId,  battlegroundContext, upgradeLine, level, index) end
function SetLastCraftingResultItem(resultIndex) end
function SetLink(aLink) end
function SetLootItem(lootId) end
function SetMarketProduct(marketProductId) end
function SetMinHeaderRowHeight(minRowHeight) end
function SetMinHeaderRows(minRows) end
function SetOwner(owner, position, offsetX, offsetY, relativePoint) end
function SetPendingAlchemyItem(solventBagId, solventSlotIndex, reagent1BagId, reagent1SlotIndex, reagent2BagId, reagent2SlotIndex, reagent3BagId, reagent3SlotIndex) end
function SetPendingEnchantingItem(potencyRuneBagId, potencyRuneSlotIndex, essenceRuneBagId, essenceRuneSlotIndex, aspectRuneBagId, aspectRuneSlotIndex) end
function SetPendingRetraitItem(bagIndex, slotIndex, pendingTrait) end
function SetPendingSmithingItem(patternIndex, materialIndex, materialQuantity, styleIndex, traitIndex) end
function SetPlacedFurniture(placedFurnitureId) end
function SetProgressionAbility(aProgressionIndex, aMorph, aRank) end
function SetProvisionerIngredientItem(recipeListIndex, recipeIndex, ingredientIndex) end
function SetProvisionerResultItem(recipeListIndex, recipeIndex) end
function SetQuestItem(questIndex, stepIndex, conditionIndex) end
function SetQuestReward(aPerkIndex) end
function SetQuestTool(questIndex, toolIndex) end
function SetScrollBonusAbility(alliance,  artifactType, bonusIndex) end
function SetSkillAbility(skillType, skillIndex, abilityIndex) end
function SetSkillLine(skillType, skillIndex) end
function SetSkillUpgradeAbility(skillType, skillIndex, abilityIndex) end
function SetSmithingImprovementItem(craftingSkillType, improvementItemIndex) end
function SetSmithingImprovementResult(itemToImproveBagId, itemToImproveSlotIndex, craftingSkillType) end
function SetSmithingMaterialItem(patternIndex, materialIndex) end
function SetSmithingStyleItem(itemStyleId) end
function SetSmithingTraitItem(traitItemIndex) end
function SetStoreItem(entryIndex) end
function SetTradeItem(aWho, aTradeIndex) end
function SetTradingHouseItem(tradingHouseIndex) end
function SetTradingHouseListing(tradingHouseIndex) end
function SetVerticalPadding(paddingY) end
function SetWornItem(equipSlot) end
function ShowComparativeTooltips() end
TopLevelWindow = {}
function AllowBringToTop() end
--Returns:  allow
function BringWindowToTop() end
function SetAllowBringToTop(allow) end
function SetDrawWhenGuiHidden(drawWhenHidden) end
function SetTopmost(isTopmost) end
WindowManager = {}
function ApplyTemplateToControl(control, virtualName) end
function CompareControlVisualOrder(controlA, controlB) end
--Returns:  order
function CreateControl(arg1, parent, type) end
--Returns:  apRet
function CreateControlFromVirtual(controlName, parent, virtualName) end
--Returns:  apRet
function CreateTopLevelWindow(arg1) end
--Returns:  apRet
function GetControlByName(name, suffix) end
--Returns:  ret
function GetFocusControl() end
--Returns:  focusControl
function GetMouseOverControl() end
--Returns:  mouseOverControl
function IsHandlingHardwareEvent() end
--Returns:  isHandlingHardwareEvent
function IsMouseOverWorld() end
--Returns:  isMouseOverWorld
function IsSecureRenderModeEnabled() end
--Returns:  secureRenderModeEnabled
function SetFocusByName(name) end
function SetMouseCursor(cursorType) end
function SetMouseFocusByName(name) end