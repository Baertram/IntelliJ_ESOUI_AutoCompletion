--app\globals
function zo_mixin(object, ...) end
--app\loadingscreen
function ZO_VoiceChatHUDLoadingScreenConsole_OnInitialize(control) end
function ZO_VoiceChatHUDLoadingScreenConsole_OnUpdate(control) end
function LoadingScreen_Gamepad:InitializeAnimations() end
function LoadingScreen_Gamepad:GetSystemName() end
function LoadingScreen_Gamepad:OnLongLoadTime(event) end
function LoadingScreen_Gamepad:OnShown() end
function LoadingScreen_Gamepad:OnHidden() end
function LoadingScreen_Gamepad:IsPreferredScreen() end
function ZO_InitGamepadLoadScreen(control) end
function LoadingScreen_Keyboard:InitializeAnimations() end
function LoadingScreen_Keyboard:IsPreferredScreen() end
function LoadingScreen_Keyboard:GetSystemName() end
function ZO_InitKeyboardLoadScreen(control) end
function GetInstanceDisplayTypeIcon(instanceType) end
function LoadingScreen_Base:Initialize() end
function LoadingScreen_Base_CanHide() end
function LoadingScreen_Base:SizeLoadingTexture() end
function LoadingScreen_Base:OnAreaLoadStarted(evt, area, instance, zoneName, zoneDescription, loadingTexture, instanceType) end
function LoadingScreen_Base:OnPrepareForJump(evt, zoneName, zoneDescription, loadingTexture, instanceType) end
function LoadingScreen_Base:HideLoadingScreen() end
function LoadingScreen_Base:OnResumeFromSuspend(evt) end
function LoadingScreen_Base:QueueShow(...) end
function LoadingScreen_Base:Show(zoneName, zoneDescription, loadingTexture, instanceType) end
function LoadingScreen_Base:Hide() end
function LoadingScreen_Base:UpdateLoadingTip(delta) end
function LoadingScreen_Base:Update() end
function LoadingScreen_Base:OnZoneDescriptionNewUserAreaCreated(control, areaData, areaText, left, right, top, bottom) end
function LoadingScreen_Base:SetZoneDescription(tip) end
--common\console
function ZO_AutoSaving_Console:New(...) end
function ZO_AutoSaving_Console:Initialize(control) end
function ZO_AutoSaving_Console:ShowAutoSaving() end
function ZO_AutoSaving_Console:OnUpdate(currentFrameTimeSeconds) end
function ZO_AutoSaving_Console:LogSaveCompleted() end
function ZO_AutoSaving_Console:HideAutoSaving() end
function ZO_AutoSaving_Console:HideAutoSavingAnimComplete(timeline, completed) end
function ZO_AutoSaving_Console:MarkDirty() end
function ZO_InitializeAutoSaving_Console(control) end
function PlayerConsoleInfoRequestManager:New(...) end
function PlayerConsoleInfoRequestManager:Initialize() end
function PlayerConsoleInfoRequestManager:RequestId(idRequestType, block, callback, ...) end
function PlayerConsoleInfoRequestManager:RequestIdFromAccountId(accountId, block, callback) end
function PlayerConsoleInfoRequestManager:RequestIdFromCharacterName(characterName, block, callback) end
function PlayerConsoleInfoRequestManager:RequestIdFromDisplayName(displayName, block, callback) end
function PlayerConsoleInfoRequestManager:RequestIdFromDisplayNameOrFallbackType(displayName, block, fallbackRequestType, callback, ...) end
function PlayerConsoleInfoRequestManager:RequestIdFromUserListDialog(callback, titleText, includeOnlineFriends, includeOfflineFriends) end
function PlayerConsoleInfoRequestManager:RequestTextValidation(text, callback) end
function PlayerConsoleInfoRequestManager:RequestNameValidation(name, callback) end
function PlayerConsoleInfoRequestManager:AddPendingRequest(requestType, data, block, callback) end
function PlayerConsoleInfoRequestManager:FindPendingRequestByField(fieldName, fieldValue, requestType) end
function PlayerConsoleInfoRequestManager:OnUpdate() end
function PlayerConsoleInfoRequestManager:CheckCloseBlockingDialog(pendingRequest) end
function PlayerConsoleInfoRequestManager:OnConsoleInfoReceived(requestKey, displayName, consoleId, success) end
function PlayerConsoleInfoRequestManager:OnSelectFromUserListDialogResult(hasResult, displayName, consoleId) end
function PlayerConsoleInfoRequestManager:OnConsoleTextValidationResult(key, valid) end
--common\gamepad
function ZO_ControllerDisconnect_Initialize(self) end
function ZO_ControllerDisconnect_ShowPopup() end
function ZO_ControllerDisconnect_DismissPopup() end
function ZO_GamepadQuadrants_SetBackgroundArrowCenterOffsetY(background, arrowSide, offset) end
function ZO_GamepadQuadrants_BackgroundTemplate_Initialize(self) end
function ZO_GamepadGrid_BackgroundTextureBase_OnUpdate(self, timeS) end
function GenericFooter:New(...) end
function GenericFooter:Initialize(control) end
function GenericFooter:Refresh(data) end
function ZO_GenericFooter_Gamepad_OnInitialized(self) end
function ZO_GenericFooter_Gamepad_OnHidden(self) end
function Anchor:New(pointOnMe, targetId, pointOnTarget, offsetX, offsetY) end
function ZO_GamepadGenericHeader_Initialize(control, createTabBar, layout) end
function ZO_GamepadGenericHeader_GetChildControl(control, controlId) end
function ZO_GamepadGenericHeader_SetDataLayout(control, layout) end
function ZO_GamepadGenericHeader_RefreshData(control, data) end
function ZO_GamepadGenericHeader_Refresh(control, data, blockTabBarCallbacks) end
function ZO_GamepadGenericHeader_Activate(control) end
function ZO_GamepadGenericHeader_Deactivate(control) end
function ZO_GamepadGenericHeader_SetActiveTabIndex(control, tabIndex, allowEvenIfDisabled) end
function ZO_GamepadGenericHeader_SetTabBarPlaySoundFunction(control, fn) end
function ZO_GamepadGenericHeader_SetPipsEnabled(control, enabled) end
function ScreenAdjust:New(...) end
function ScreenAdjust:Initialize(control, sceneName) end
function ScreenAdjust:InitializeKeybindButtons() end
function ScreenAdjust:RefreshGuiDimensions() end
function ScreenAdjust:InitializeSize(storeInitialValues) end
function ScreenAdjust:SetSize(width, height) end
function ScreenAdjust:Commit() end
function ScreenAdjust:RevertChanges() end
function ScreenAdjust:OnSave() end
function ScreenAdjust:OnCancel() end
function ScreenAdjust:UpdateDirectionalInput() end
function ZO_ScreenAdjust_Handle_OnSave() end
function ZO_ScreenAdjust_Handle_OnCancel() end
function ZO_ScreenAdjust_OnInitialized(self) end
function ZO_ScreenAdjustIntro_OnInitialized(self) end
function ZO_GamepadEntryData:New(...) end
function ZO_GamepadEntryData:Initialize(text, icon, selectedIcon, highlight, isNew) end
function ZO_GamepadEntryData:InitializeInventoryVisualData(itemData) end
function ZO_GamepadEntryData:InitializeStoreVisualData(itemData) end
function ZO_GamepadEntryData:InitializeTradingHouseVisualData(itemData) end
function ZO_GamepadEntryData:InitializeItemImprovementVisualData(bag, index, stackCount, quality) end
function ZO_GamepadEntryData:InitializeCollectibleVisualData(itemData) end
function ZO_GamepadEntryData:AddSubLabels(subLabels) end
function ZO_GamepadEntryData:InitializeImprovementKitVisualData(bag, index, stackCount, quality, subLabels) end
function ZO_GamepadEntryData:InitializeCraftingInventoryVisualData(itemInfo, customSortData) end
function ZO_GamepadEntryData:InitializeLootVisualData(lootId, count, quality, value, isQuest, isStolen) end
function ZO_GamepadEntryData:SetHeader(header) end
function ZO_GamepadEntryData:SetNew(isNew) end
function ZO_GamepadEntryData:SetText(text) end
function ZO_GamepadEntryData:SetFontScaleOnSelection(active) end
function ZO_GamepadEntryData:SetAlphaChangeOnSelection(active) end
function ZO_GamepadEntryData:SetMaxIconAlpha(alpha) end
function ZO_GamepadEntryData:SetDataSource(source) end
function ZO_GamepadEntryData:GetColorsBasedOnQuality(quality) end
function ZO_GamepadEntryData:SetCooldown(remainingMs, durationMs) end
function ZO_GamepadEntryData:GetCooldownDurationMs() end
function ZO_GamepadEntryData:GetCooldownTimeRemainingMs() end
function ZO_GamepadEntryData:IsOnCooldown() end
function ZO_GamepadEntryData:AddIconSubtype(subtypeName, texture) end
function ZO_GamepadEntryData:GetNumIcons() end
function ZO_GamepadEntryData:GetSubtypeIcon(subtypeName, index) end
function ZO_GamepadEntryData:GetIcon(index, selected) end
function ZO_GamepadEntryData:AddIcon(normalTexture, selectedTexture) end
function ZO_GamepadEntryData:ClearIcons() end
function ZO_GamepadEntryData:GetNameColor(selected) end
function ZO_GamepadEntryData:SetIconTintOnSelection(selected) end
function ZO_GamepadEntryData:GetSubLabelColor(selected) end
function ZO_GamepadEntryData:SetNameColors(selectedColor, unselectedColor) end
function ZO_GamepadEntryData:SetSubLabelColors(selectedColor, unselectedColor) end
function ZO_GamepadEntryData:SetIconTint(selectedColor, unselectedColor) end
function ZO_GamepadEntryData:SetIconDesaturation(desaturation) end
function ZO_GamepadEntryData:AddSubLabel(text) end
function ZO_GamepadEntryData:SetShowUnselectedSublabels(showUnselectedSublabels) end
function ZO_GamepadEntryData:SetChannelActive(isChannelActive) end
function ZO_GamepadEntryData:SetLocked(isLocked) end
function ZO_GamepadEntryData:SetSelected(isSelected) end
function ZO_GamepadEntryData:SetChannelActive(isChannelActive) end
function ZO_GamepadEntryData:SetEnabled(isEnabled) end
function ZO_GamepadEntryData:IsEnabled() end
function ZO_GamepadEntryData:SetDisabledNameColors(selectedColor, unselectedColor) end
function ZO_GamepadEntryData:SetDisabledIconTint(selectedColor, unselectedColor) end
function ZO_GamepadEntryData:GetNameDisabledColor(selected) end
function ZO_GamepadEntryData:SetIconDisabledTintOnSelection(selected) end
function ZO_GamepadEntryData:SetModifyTextType(modifyTextType) end
function ZO_GamepadEntryData:SetIsHiddenByWardrobe(isHidden) end
function ZO_GamepadGrid:New(...) end
function ZO_GamepadGrid:Initialize(control, rowMajor) end
function ZO_GamepadGrid:GetIsRowMajor() end
function ZO_GamepadGrid:GetGridItems() end
function ZO_GamepadGrid:RefreshGridHighlight() end
function ZO_GamepadGrid:ClampToGrid(x,y) end
function ZO_GamepadGrid:GetGridPosition() end
function ZO_GamepadGrid:ResetGridPosition() end
function ZO_GamepadGrid:UpdateDirectionalInput() end
function ZO_GamepadGrid:SetDirectionalMovementSound(sound) end
function ZO_GamepadPagedGrid:New(...) end
function ZO_GamepadPagedGrid:Initialize(control, rowMajor, footerControl) end
function ZO_GamepadPagedGrid:SetPageNumberFont(font) end
function ZO_GamepadPagedGrid:SetPageInfo(currentPage, numPages) end
function ZO_GamepadPagedGrid:UpdateForPageChange() end
function ZO_GamepadPagedGrid:SetPageChangedCallback(callback) end
function ZO_GamepadPagedGrid:GetCurrentPage() end
function ZO_GamepadPagedGrid:GetNumPages() end
function ZO_GamepadPagedGrid:NextPage() end
function ZO_GamepadPagedGrid:PreviousPage() end
function ZO_GamepadPagedGrid:InitializeKeybindStripDescriptors() end
function ZO_GamepadPagedGrid:Activate() end
function ZO_GamepadPagedGrid:Deactivate() end
function ZO_GamepadPagedGrid:RefreshGrid() end
function ZO_IconSelectorPlaySound(type) end
function ZO_GamepadIconSelector:New(...) end
function ZO_GamepadIconSelector:Initialize(control, settings) end
function ZO_GamepadIconSelector:ForAllIconControls(func, ...) end
function ZO_GamepadIconSelector:ModifyHighlightIndex(rowDiff, colDiff) end
function ZO_GamepadIconSelector:HighlightIconControl(index) end
function ZO_GamepadIconSelector:GetHighlightIndex() end
function ZO_GamepadIconSelector_RefreshIconSelectionIndicator(control, index, selectedIconIndex) end
function ZO_GamepadIconSelector:Activate() end
function ZO_GamepadIconSelector:Deactivate() end
function ZO_GamepadIconSelector:SetDirectionalInputEnabled(enabled) end
function ZO_GamepadIconSelector:UpdateDirectionalInput() end
function ZO_GamepadIconSelector:MoveUp() end
function ZO_GamepadIconSelector:MoveDown() end
function ZO_GamepadIconSelector:MoveLeft() end
function ZO_GamepadIconSelector:MoveRight() end
function ZO_GamepadIconSelector:SetPlaySoundFunction(fn) end
function ZO_LoadingIcon_Gamepad_Initialize(self) end
function ZO_LoadingIcon_Gamepad_OnUpdate(self) end
function ZO_Gamepad_ParametricList_Screen:New(...) end
function ZO_Gamepad_ParametricList_Screen:Initialize(control, createTabBar, activateOnShow, scene) end
function ZO_Gamepad_ParametricList_Screen:SetListsUseTriggerKeybinds(addListTriggerKeybinds, optionalHeaderComparator) end
function ZO_Gamepad_ParametricList_Screen:GetListFragment(list) end
function ZO_Gamepad_ParametricList_Screen:GetHeaderFragment() end
function ZO_Gamepad_ParametricList_Screen:ActivateCurrentList() end
function ZO_Gamepad_ParametricList_Screen:DeactivateCurrentList() end
function ZO_Gamepad_ParametricList_Screen:EnableCurrentList() end
function ZO_Gamepad_ParametricList_Screen:DisableCurrentList() end
function ZO_Gamepad_ParametricList_Screen:SetCurrentList(list) end
function ZO_Gamepad_ParametricList_Screen:GetCurrentList() end
function ZO_Gamepad_ParametricList_Screen:IsCurrentList(list) end
function ZO_Gamepad_ParametricList_Screen:TryAddListTriggers() end
function ZO_Gamepad_ParametricList_Screen:TryRemoveListTriggers() end
function ZO_Gamepad_ParametricList_Screen:AddList(name, callbackParam, listClass, ...) end
function ZO_Gamepad_ParametricList_Screen:GetMainList() end
function ZO_Gamepad_ParametricList_Screen:GetList(name) end
function ZO_Gamepad_ParametricList_Screen:CreateListFragment(name, hideControl) end
function ZO_Gamepad_ParametricList_Screen:SetScene(scene) end
function ZO_Gamepad_ParametricList_Screen:OnStateChanged(oldState, newState) end
function ZO_Gamepad_ParametricList_Screen:Activate() end
function ZO_Gamepad_ParametricList_Screen:Deactivate() end
function ZO_Gamepad_ParametricList_Screen:RefreshKeybinds() end
function ZO_Gamepad_ParametricList_Screen:OnTabBarCategoryChanged(selectedData) end
function ZO_Gamepad_ParametricList_Screen:SetupList(list) end
function ZO_Gamepad_ParametricList_Screen:PerformUpdate() end
function ZO_Gamepad_ParametricList_Screen:InitializeKeybindStripDescriptors() end
function ZO_Gamepad_ParametricList_Screen:OnSelectionChanged(list, selectedData, oldSelectedData) end
function ZO_Gamepad_ParametricList_Screen:OnTargetChanged(list, targetData, oldTargetData, reachedTarget, targetSelectedIndex) end
function ZO_Gamepad_ParametricList_Screen:SetUpdateCooldown(updateCooldownMS) end
function ZO_Gamepad_ParametricList_Screen:CheckUpdateIfOffCooldown(timeMS) end
function ZO_Gamepad_ParametricList_Screen:Update() end
function ZO_Gamepad_ParametricList_Screen:PerformDeferredInitialize() end
function ZO_Gamepad_ParametricList_Screen:OnDeferredInitialize() end
function ZO_Gamepad_ParametricList_Screen:OnShowing() end
function ZO_Gamepad_ParametricList_Screen:OnShow() end
function ZO_Gamepad_ParametricList_Screen:OnHiding() end
function ZO_Gamepad_ParametricList_Screen:OnHide() end
function ZO_Gamepad_ParametricList_Screen:CreateAndSetupList(control, callbackParam, listClass, ...) end
function UpdateCooldownManager:New(...) end
function UpdateCooldownManager:Initialize() end
function UpdateCooldownManager:Add(screen) end
function UpdateCooldownManager:Remove(screen) end
function UpdateCooldownManager:Update(timeMS) end
function ZO_GamepadVerticalParametricScrollList:New(...) end
function ZO_GamepadVerticalParametricScrollList:Initialize(control) end
function ZO_GamepadVerticalItemParametricScrollList:New(control) end
function ZO_GamepadHorizontalParametricScrollList:New(control, onActivatedChangedFunction, onCommitWithItemsFunction, onClearedFunction) end
function ZO_GamepadTabBarScrollList:New(control, leftIcon, rightIcon, onActivatedChangedFunction, onCommitWithItemsFunction, onClearedFunction) end
function ZO_GamepadTabBarScrollList:Activate() end
function ZO_GamepadTabBarScrollList:Deactivate() end
function ZO_GamepadTabBarScrollList:InitializeKeybindStripDescriptors() end
function ZO_GamepadTabBarScrollList:Commit(dontReselect) end
function ZO_GamepadTabBarScrollList:SetPipsEnabled(enabled, divider) end
function ZO_GamepadTabBarScrollList:RefreshPips() end
function ZO_GamepadTabBarScrollList:SetSelectedIndex(selectedIndex, allowEvenIfDisabled, forceAnimation) end
function ZO_GamepadTabBarScrollList:MovePrevious(allowWrapping, suppressFailSound) end
function ZO_GamepadTabBarScrollList:MoveNext(allowWrapping, suppressFailSound) end
function ZO_GamepadVerticalParametricScrollListSubList:New(control, parentList, parentKeybinds, onDataChosen) end
function ZO_GamepadVerticalParametricScrollListSubList:Initialize(control, parentList, parentKeybinds, onDataChosen) end
function ZO_GamepadVerticalParametricScrollListSubList:Commit(dontReselect) end
function ZO_GamepadVerticalParametricScrollListSubList:CancelSelection() end
function ZO_GamepadVerticalParametricScrollListSubList:InitializeKeybindStrip() end
function ZO_GamepadVerticalParametricScrollListSubList:Activate() end
function ZO_GamepadVerticalParametricScrollListSubList:Deactivate() end
function ZO_SharedGamepadEntry_OnInitialized(control) end
function ZO_PregameGamepadEntry_OnInitialized(control) end
function ZO_CraftingGamepadEntryTraits_OnInitialized(control) end
function ZO_CraftingGamepadEntry_OnInitialized(control) end
function ZO_SkillsGamepadEntry_OnInitialized(control) end
function ZO_CharacterGamepadEntry_OnInitialized(control) end
function ZO_SharedGamepadEntry_Cooldown(control, remaining, duration, cooldownType, timeType, useLeadingEdge, alpha, desaturation, preservePreviousCooldown) end
function ZO_SharedGamepadEntryIconColorize(icon, data, selected) end
function ZO_GamepadGuildHubRow_OnInitialized(control) end
function ZO_SharedGamepadEntry_OnSetup(control, data, selected, reselectingDuringRebuild, enabled, active) end
function SetDefaultColorOnLabel(label, selected) end
function ZO_GamepadMenuEntryTemplate_GetAlpha(selected, disabled) end
function SharedGamepadEntryTemplateSetup(control, text, pressedTexture, normalTexture, highlightTexture, selected, activated, stackCount) end
function ZO_GamepadMenuEntryTemplate_Setup(control, text, pressedTexture, normalTexture, highlightTexture, selected, activated, stackCount) end
function ZO_GamepadOnDefaultActivatedChanged(control, activated) end
function ZO_GamepadOnDefaultScrollListActivatedChanged(list, activated) end
function ZO_GamepadCheckBoxTemplate_OnInitialized(control, offsetX) end
function ZO_GamepadCheckBoxTemplate_Setup(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadCheckBoxListEntryTemplate_Setup(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadCheckBoxTemplate_OnClicked(control) end
function ZO_GamepadCheckBoxTemplate_IsChecked(control) end
function ZO_GamepadMenuHeaderTemplate_OnInitialized(control) end
function ZO_GamepadMenuHeaderTemplate_Setup(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadTabBarTemplate_OnInitialized(self) end
function ZO_GamepadTabBarTemplate_Setup(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadPipCreator:New(control, drawLayer) end
function ZO_GamepadPipCreator:RefreshPips(numPips, activePipIndex) end
function ZO_GetPlatformTemplate(baseTemplate) end
function ZO_GamepadDefaultHorizontalListEntrySetup(control, data, selected, reselectingDuringRebuild, enabled, selectedFromParent) end
function ZO_GamepadHorizontalListRow_Initialize(self, setupFunction, equalityFunction) end
--common\gamepadgrid
function ZO_GamepadGrid_AnchorToNav(control, navLocation) end
function ZO_GamepadGrid_GetNavAnchor(navLocation, anchorIndex) end
function ZO_GamepadGrid_GetNavContainerAnchor(navLocation, anchorIndex) end
--common\gammaadjust
function ZO_GammaAdjust_Initialize(self) end
function ZO_GammaAdjust_ChangeGamma(delta) end
function ZO_GammaAdjust_NeedsFirstSetup() end
function ZO_GammaAdjustSlider_Gamepad_OnInitialized(slider) end
function ZO_GammaAdjustSlider_Keyboard_OnInitialized(slider) end
--common\globals
function ZO_GetAllianceIcon(alliance) end
--common\optionspanels
function ZO_OptionsPanel_Video_InitializeResolution(control) end
function ZO_OptionsPanel_Video_SetCustomScale(self, formattedValueString) end
function ZO_OptionsPanel_Video_CustomScale_OnShow(control) end
function ZO_OptionsPanel_Video_InitializeScaleControl(self) end
--common\scenes
function ZO_GamepadMenuSoundFragment:New() end
function ZO_GamepadMenuSoundFragment:Show() end
function ZO_GamepadMenuSoundFragment:Hide() end
function ZO_CreateQuadrantConveyorFragment(control, alwaysAnimate) end
--common\zo_addonmanager
function ZO_AddOnEulaInit(self) end
function ZO_AddOnManager:New(...) end
function ZO_AddOnManager:Initialize(control, allowReload) end
function ZO_AddOnManager:GetRowSetupFunction() end
function ZO_AddOnManager:GetCombinedAddOnStates(index) end
function ZO_AddOnManager:SetCharacterData(characterData) end
function ZO_AddOnManager:GetNumCharacters() end
function ZO_AddOnManager:GetCharacterInfo(characterIndex) end
function ZO_AddOnManager:OnCharacterChanged(name) end
function ZO_AddOnManager:BuildCharacterDropdown() end
function ZO_AddOnManager:ChangeEnabledState(index, checkState) end
function ZO_AddOnManager:SetupTypeId(description, dependencyText) end
function ZO_AddOnManager:ResetDataTypes() end
function ZO_AddOnManager:BuildMasterList() end
function ZO_AddOnManager:OnShow() end
function ZO_AddOnManager:RefreshMultiButton() end
function ZO_AddOnManager:OnMouseEnter(control) end
function ZO_AddOnManager:OnEnabledButtonClicked(control, checkState) end
function ZO_AddOnManager:OnExpandButtonClicked(row) end
function ZO_AddOnManager:AllowReload() end
function ZO_AddOnManager_OnExpandButtonClicked(control) end
function ZO_AddOnManager_OnEnabledButtonMouseEnter(control) end
function ZO_AddOnManagerMultiButton_Callback() end
--common\zo_gamemenu
function ZO_GameMenuManager:New(...) end
function ZO_GameMenuManager:Initialize(control) end
function ZO_GameMenuManager:InitializeTree() end
function ZO_GameMenuManager:SubmitLists(...) end
function ZO_GameMenuManager:AddEntry(data) end
function ZO_GameMenu_ChildlessHeader_OnMouseUp(self, upInside) end
function ZO_GameMenu_OnShow(control) end
function ZO_GameMenu_OnHide(control) end
function ZO_GameMenu_AddSettingPanel(data) end
function ZO_GameMenu_AddControlsPanel(data) end
function ZO_GameMenu_Initialize(control, onShowFunction, onHideFunction) end
--common\zo_keybindings
function ZO_Keybindings_DoesKeyMatchAnyModifiers(modifierKeyToMatch, mod1, mod2, mod3, mod4) end
function ZO_Keybindings_DoesActionMatchInput(actionName, key, ctrl, alt, shift, command) end
function ZO_Keybindings_GetTexturePathForKey(keyCode) end
function ZO_Keybindings_HasTexturePathForKey(keyCode) end
function ZO_Keybindings_GenerateKeyMarkup(name) end
function ZO_Keybindings_GetKeyText(key, widthPercent, heightPercent) end
function ZO_Keybindings_RegisterLabelForBindingUpdate(label, actionName, showUnbound, gamepadActionName, onChangedCallback, alwaysPreferGamepadMode) end
function ZO_Keybindings_UnregisterLabelForBindingUpdate(label) end
function ZO_Keybinding_GetGamepadActionName(actionName) end
--common\zo_keybindstrip
function ZO_KeybindStrip_HandleKeybindDown(keybind) end
function ZO_KeybindStrip_HandleKeybindUp(keybind) end
function ZO_KeybindStrip_OnInitialized(control) end
--common\zo_options
function ZO_GamepadOptions:New(control) end
function ZO_GamepadOptions:Initialize(control) end
function ZO_GamepadOptions:InitializeScenes() end
function ZO_GamepadOptions:PerformUpdate() end
function ZO_GamepadOptions:DeactivateSelectedControl() end
function ZO_GamepadOptions:OnDeferredInitialize() end
function ZO_GamepadOptions:InitializeHeader() end
function ZO_GamepadOptions:RefreshHeader() end
function ZO_GamepadOptions:OnOptionWithDependenciesChanged() end
function ZO_GamepadOptions:Select() end
function ZO_GamepadOptions:InitializeKeybindStrip() end
function ZO_GamepadOptions:HasInfoPanel() end
function ZO_GamepadOptions:IsAtRoot() end
function ZO_GamepadOptions:InitializeGamepadInfoPanelTable() end
function ZO_GamepadOptions_OptionsHorizontalListSetup(control, data, selected, reselectingDuringRebuild, enabled, selectedFromParent) end
function ZO_GamepadOptions_HorizontalListEqualityFunction(left, right) end
function ZO_GamepadOptions:SetupList(list) end
function ZO_GamepadOptions:SetupOptionsList(list) end
function ZO_GamepadOptions:InitializeOptionsLists() end
function ZO_GamepadOptions:OnSelectionChanged(list) end
function ZO_GamepadOptions:InitializeControl(control, selected) end
function ZO_GamepadOptions:RefreshGamepadInfoPanel() end
function ZO_GamepadOptions:GetButtonTextureInfoFromActionName(actionName) end
function ZO_GamepadOptions_RefreshGamepadInfoPanel() end
function ZO_GamepadOptions_OnInitialize(control) end
function ZO_GamepadOptions:RefreshCategoryList() end
function ZO_GamepadOptions:RefreshOptionsList() end
function ZO_GamepadOptions:AddSettingGroup(panelId) end
function ZO_GamepadOptions:LoadPanelDefaults(panelSettings) end
function ZO_GamepadOptions:LoadDefaults() end
function ZO_GamepadOptions:SetGamepadOptionsInputBlocked(blocked) end
function ZO_KeyboardOptions:New(control) end
function ZO_KeyboardOptions:Initialize(control) end
function ZO_KeyboardOptions:AddUserPanel(panelIdOrString, panelName, panelType) end
function ZO_KeyboardOptions:InitializeControl(control) end
function ZO_KeyboardOptions:ChangePanels(panel) end
function ZO_KeyboardOptions:ApplySettings(control) end
function ZO_KeyboardOptions:LoadDefaults() end
function ZO_KeyboardOptions:UpdatePanelOptions(panelIndex, saveOptions) end
function ZO_KeyboardOptions:UpdateCurrentPanelOptions(saveOptions) end
function ZO_KeyboardOptions:UpdateAllPanelOptions(saveOptions) end
function ZO_KeyboardOptions:SetSectionTitleData(control, panel, text) end
function ZO_Options_Keyboard_OnInitialize(control) end
function ZO_OptionsWindow_InitializeControl(control) end
function ZO_OptionsWindow_ApplySettings(control) end
function ZO_OptionsWindow_ToggleFirstPerson(control) end
function ZO_OptionsWindow_AddUserPanel(panelIdString, panelName, panelType) end
function ZO_SharedOptions:New(control) end
function ZO_SharedOptions:Initialize(control) end
function ZO_SharedOptions:IsGamepadOptions() end
function ZO_SharedOptions:SaveCachedSettings() end
function ZO_SharedOptions:GetControlTypeFromControl(control) end
function ZO_SharedOptions:GetControlType(controlType) end
function ZO_SharedOptions:InitializeControl(control, selected) end
function ZO_SharedOptions:IsControlTypeAnOption(data) end
function ZO_SharedOptions:LoadDefaults(control, data) end
function ZO_SharedOptions:GetSettingsData(panel, system, settingId) end
function ZO_SharedOptions:AddTableToPanel(panel, table) end
function ZO_SharedOptions:AddTableToSystem(panel, system, table) end
--common\zo_playerinventoryfooter
function ZO_Gamepad_PlayerInventoryFooterFragment:New(...) end
function ZO_Gamepad_PlayerInventoryFooterFragment:Initialize(...) end
function ZO_Gamepad_PlayerInventoryFooterFragment:CapacityUpdate(forceUpdate) end
--common\zo_uierrors
function ZO_ErrorFrame:New(...) end
function ZO_ErrorFrame:Initialize(control) end
function ZO_ErrorFrame:UpdatePlatformStyles(styleTable) end
function ZO_ErrorFrame:InitializePlatformStyles() end
function ZO_ErrorFrame:GetNextQueuedError() end
function ZO_ErrorFrame:OnUIError(errorString) end
function ZO_ErrorFrame:HideCurrentError() end
function ZO_ErrorFrame:HideAllErrors() end
function ZO_ErrorFrame:ToggleSupressDialog() end
function ZO_UIErrors_Init(control) end
function ZO_UIErrors_HideCurrent() end
function ZO_UIErrors_HideAll() end
function ZO_UIErrors_ToggleSupressDialog() end
--ingame\achievements
function ZO_GetNextInProgressAchievementInLine(achievementId) end
function ZO_ShouldShowAchievement(filterType, id) end
function ZO_GetAchievementIds(categoryIndex, subCategoryIndex, numAchievements) end
function ZO_Achievements_Gamepad:New(...) end
function ZO_Achievements_Gamepad:Initialize(control) end
function ZO_Achievements_Gamepad:SetupList(list) end
function ZO_Achievements_Gamepad:OnDeferredInitialize() end
function ZO_Achievements_Gamepad:InitializeEvents() end
function ZO_Achievements_Gamepad:SetRecentAchievementsHidden(hidden) end
function ZO_Achievements_Gamepad:UpdateDirectionalInput() end
function ZO_Achievements_Gamepad:AchievementListSelectionChanged(list, entry) end
function ZO_Achievements_Gamepad:RefreshRecentAchievements() end
function ZO_Achievements_Gamepad:ShowAchievement(achievementId) end
function ZO_Achievements_Gamepad:OnShowing() end
function ZO_Achievements_Gamepad:OnHide() end
function ZO_Achievements_Gamepad:SwitchToFilterMode(newMode) end
function ZO_Achievements_Gamepad:InitializeOptionsDialog() end
function ZO_Achievements_Gamepad:SwitchToCategoryAndAchievement(categoryId, achievementId) end
function ZO_Achievements_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_Achievements_Gamepad:ShowAchievementSummaryTooltip() end
function ZO_Achievements_Gamepad:ShowNoAchievementTooltip() end
function ZO_Achievements_Gamepad:ShowAchievementTooltip(achievementId) end
function ZO_Achievements_Gamepad:ClearLineList() end
function ZO_Achievements_Gamepad:SetupLineList(achievementId) end
function ZO_Achievements_Gamepad:HideTooltip() end
function ZO_Achievements_Gamepad:OnSelectionChanged(list, selectedData, oldSelectedData) end
function ZO_Achievements_Gamepad:PopulateCategories() end
function ZO_Achievements_Gamepad:AddAchievements(categoryIndex, subCategoryIndex, subCategoryName, achievementIds) end
function ZO_Achievements_Gamepad:PopulateAchievements(categoryIndex) end
function ZO_Achievements_Gamepad:GetSelectionInformation() end
function ZO_Achievements_Gamepad:PerformUpdate() end
function ZO_Achievements_Gamepad_OnInitialize(control) end
function Achievement:New(...) end
function Achievement:Initialize(control, checkPool, statusBarPool, rewardLabelPool, rewardIconPool, lineThumbPool, dyeSwatchPool) end
function Achievement:GetId() end
function Achievement:GetAchievementInfo(achievementId) end
function Achievement:Show(achievementId) end
function Achievement:SetRewardThumb(achievementId) end
function Achievement:AddProgressBar(description, numCompleted, numRequired, showBarDescription) end
function Achievement:AddCheckBox(description, checked) end
function Achievement:AddIconReward(name, icon, quality, rewardIndex) end
function Achievement:GetPooledLabel(labelType, completed) end
function Achievement:AddTitleReward(name, completed) end
function Achievement:AddDyeReward(dyeId, completed) end
function Achievement:AddCollectibleReward(collectibleId, completed) end
function Achievement:WouldShowLines() end
function Achievement:WouldHaveVisibleCriteria() end
function Achievement:HasTangibleReward() end
function Achievement:IsExpandable() end
function Achievement:RefreshExpandedCriteria() end
function Achievement:RefreshExpandedRewards() end
function Achievement:RefreshRewardThumb() end
function Achievement:RefreshExpandedView() end
function Achievement:PlayExpandCollapseSound() end
function Achievement:UpdateExpandedStateIcon() end
function Achievement:CalculateDescriptionWidth() end
function Achievement:Expand() end
function Achievement:ApplyCollapsedDescriptionConstraints() end
function Achievement:Collapse() end
function Achievement:SetAnchor(previous) end
function Achievement:GetControl() end
function Achievement:ToggleCollapse() end
function Achievement:Destroy() end
function Achievement:SetHighlightHidden(hidden) end
function Achievement:OnMouseEnter() end
function Achievement:OnMouseExit() end
function Achievement:OnClicked(button) end
function PopupAchievement:New(...) end
function PopupAchievement:Initialize(parentControl, ...) end
function PopupAchievement:GetAchievementInfo(achievementId) end
function PopupAchievement:RefreshExpandCriteriaFromDataLink(...) end
function PopupAchievement:RefreshExpandedCriteria() end
function PopupAchievement:RefreshExpandedLineView() end
function PopupAchievement:PerformExpandedLayout() end
function PopupAchievement:Show(id, progress, timestamp) end
function PopupAchievement:Hide() end
function IconAchievement:New(...) end
function IconAchievement:Initialize(control) end
function IconAchievement:Show(achievementId) end
function IconAchievement:Destroy() end
function IconAchievement:SetAnchor(previous) end
function IconAchievement:OnMouseEnter() end
function IconAchievement:OnMouseExit() end
function IconAchievement:OnClicked(button) end
function IconAchievement:GetId() end
function Achievements:New(...) end
function Achievements:InitializeControls() end
function Achievements:InitializeEvents() end
function Achievements:OnAchievementAwarded(achievementId) end
function Achievements:OnAchievementUpdated(achievementId) end
function Achievements:GetNumCategories() end
function Achievements:GetCategoryInfo(categoryIndex) end
function Achievements:GetCategoryIcons(categoryIndex) end
function Achievements:GetSubCategoryInfo(categoryIndex, i) end
function Achievements:LookupTreeNodeForData(categoryIndex, subCategoryIndex) end
function Achievements:OpenCategory(categoryIndex, subCategoryIndex) end
function Achievements:ShowAchievement(achievementId) end
function Achievements:InitializeAchievementList(control) end
function Achievements:UpdateCategoryLabels(data, saveExpanded) end
function Achievements:LayoutAchievements(achievements) end
function Achievements:LayoutAchievementsIconStyle(...) end
function Achievements:InitializeSummary(control) end
function Achievements:RefreshRecentAchievements() end
function Achievements:UpdateSummary() end
function Achievements:ShowSummary() end
function Achievements:OnAchievementsUpdated() end
function Achievements:UpdatePointDisplay() end
function Achievements:ShowAchievementPopup(id, progress, timestamp) end
function Achievements:OnLinkClicked(link, button, text, color, linkType, ...) end
function ZO_Achievements_OnInitialize(self) end
function ZO_Achievement_OnMouseEnter(control) end
function ZO_Achievement_OnMouseExit(control) end
function ZO_Achievement_Reward_OnMouseEnter(control) end
function ZO_Achievement_Reward_OnMouseExit(control) end
function ZO_Achievement_Reward_OnMouseUp(control) end
function ZO_Achievement_Line_OnMouseEnter(control) end
function ZO_Achievement_Line_OnMouseExit(control) end
--ingame\actionbar
function ZO_ActionSlot_SetupSlot(iconControl, buttonControl, icon, normalFrame, downFrame, cooldownIconControl) end
function ZO_ActionSlot_ClearSlot(iconControl, buttonControl, normalFrame, downFrame, cooldownIconControl) end
function ZO_ActionSlot_SetUnusable(iconControl, unusable, useDesaturation) end
function ZO_AbilitySlot_OnSlotClicked(abilitySlot, buttonId) end
function ZO_AbilitySlot_OnSlotDoubleClicked(abilitySlot, buttonId) end
function ZO_AbilitySlot_OnSlotMouseUp(abilitySlot, upInside, buttonId) end
function ZO_AbilitySlot_OnSlotMouseDown(abilitySlot, buttonId) end
function ZO_AbilitySlot_OnDragStart(abilitySlot, button) end
function ZO_AbilitySlot_OnReceiveDrag(abilitySlot, button) end
function ZO_AbilitySlot_OnMouseEnter(abilitySlot) end
function ZO_AbilitySlot_OnMouseExit(abilitySlot) end
function ZO_ActionBar_HasAnyActionSlotted() end
function ZO_ActionBar_GetButton(slotNum) end
function ActionButtonDownAndUp(slotNum) end
function ActionButtonDown(slotNum) end
function ActionButtonUp(slotNum) end
function AreActionBarsLocked() end
function ZO_ActionBar_AreHiddenButtonsShowing() end
function ZO_ActionBar_AttemptPlacement(slotNum) end
function ZO_ActionBar_AttemptPickup(slotNum) end
function ZO_ActionBar_GetAnchor() end
function ZO_ActionBar_Initialize() end
function ZO_ActionBar1_OnInitialized(self) end
function ZO_ActionButtons_ToggleShowGlobalCooldown() end
function ActionButton:New(slotNum, buttonType, parent, controlTemplate) end
function ActionButton:IsClassBarButton() end
function ActionButton:IsSiegeBarButton() end
function ActionButton:SetShowBindingText(visible) end
function ActionButton:GetSlot() end
function ActionButton:GetButtonType() end
function ActionButton:HasAction() end
function ActionButton:HandlePressAndRelease() end
function ActionButton:HandlePress() end
function ActionButton:HandleRelease() end
function ActionButton:ResetVisualState() end
function ActionButton:SetupCount(count, consumable) end
function ActionButton:HandleSlotChanged() end
function ActionButton:Clear() end
function ActionButton:RefreshUltimateNumberVisibility() end
function ActionButton:UpdateUltimateNumber() end
function ActionButton:UpdateActivationHighlight() end
function ActionButton:UpdateState() end
function ActionButton:UpdateUseFailure() end
function ActionButton:UpdateUsable() end
function ActionButton:SetCooldownIconAnchors(inCooldown) end
function ActionButton:SetCooldownHeight(percentComplete) end
function ActionButton:RefreshCooldown() end
function ActionButton:UpdateCooldown(options) end
function ActionButton:ApplyFlipAnimationStyle() end
function ActionButton:ApplyStyle(template) end
function ActionButton:ApplyAnchor(target, offsetX) end
function ActionButton:SetupFlipAnimation(OnStopHandlerFirst, OnStopHandlerLast) end
function ActionButton:SetupBounceAnimation() end
function ActionButton:PlayAbilityUsedBounce(offset) end
function ActionButton:PlayGlow() end
function ActionButton:SetNeedsAnimationParameterUpdate(needsUpdate) end
function ActionButton:SetupKeySlideAnimation() end
function ActionButton:SlideKeysIn() end
function ActionButton:SlideKeysOut() end
function ActionButton:HideKeys(hide) end
function QuickslotActionButton:New(...) end
function QuickslotActionButton:GetSlot() end
function QuickslotActionButton:HandleRelease() end
function QuickslotActionButton:ApplyStyle(template) end
--ingame\activecombattips
function ZO_ActiveCombatTip:New(...) end
function ZO_ActiveCombatTip:Initialize(control) end
function ZO_ActiveCombatTip:ApplyStyle() end
function ZO_ActiveCombatTip:OnGamepadPreferredModeChanged() end
function ZO_ActiveCombatTip:IsInSupression() end
function ZO_ActiveCombatTip:RefreshTip() end
function ZO_ActiveCombatTip:OnDisplayActiveCombatTip(activeCombatTipId) end
function ZO_ActiveCombatTip:OnRemoveActiveCombatTip(activeCombatTipId, reason) end
function ZO_ActiveCombatTips_Initialize(control) end
--ingame\addoncompatibilityaliases
function GetItemLinkGlyphMinMaxLevels(itemLink) end
--ingame\alerttext
function ZO_AlertText_GetHandlers() end
function ShouldShowSocialErrorInAlert(error) end
function IsSocialErrorIgnoreResponse(error) end
function ShouldShowGroupErrorInAlert(error) end
function IsGroupErrorIgnoreResponse(error) end
function ZO_AlertText_Manager:New() end
function ZO_AlertEvent(eventId, ...) end
function ZO_AlertText_Manager:Initialize() end
function ZO_AlertText_Manager:ShouldDisplayMessage(soundId) end
function ZO_AlertText_Manager:AddRecent(soundId) end
function ZO_AlertText_Base:New(...) end
function ZO_AlertText_Base:Initialize(control) end
function ZO_AlertText_Base:GetAlertColor(category) end
function ZO_Alert(category, soundId, message, ...) end
function ZO_AlertNoSuppression(category, soundId, message, ...) end
function ZO_SoundAlert(category, soundId) end
function ZO_AlertText_Gamepad:New(...) end
function ZO_AlertText_Gamepad:InternalPerformAlert(category, soundId, message, template) end
function ZO_AlertText_Gamepad:AddTemplate(template, templateData) end
function ZO_AlertText_Gamepad:ClearAll() end
function ZO_AlertText_Gamepad:FadeAll() end
function ZO_AlertText_Gamepad:Initialize(control) end
function ZO_AlertText_Gamepad:HasActiveEntries() end
function ZO_AlertText_Gamepad:SetHoldDisplayingEntries(holdEntries) end
function ZO_AlertTextGamepad_OnInitialized(control) end
function ZO_AlertTemplated_Gamepad(category, soundId, message, template, ...) end
function ZO_AlertNoSuppressionTemplated_Gamepad(category, soundId, message, template, ...) end
function ZO_AlertAddTemplate_Gamepad(template, templateData) end
function ZO_AlertFadeAll_Gamepad() end
function ZO_AlertClearAll_Gamepad() end
function ZO_AlertText_Keyboard:New(...) end
function ZO_AlertText_Keyboard:InternalPerformAlert(category, soundId, message) end
function ZO_AlertText_Keyboard:Initialize(control) end
function ZO_AlertTextKeyboard_OnInitialized(control) end
--ingame\banking
function ZO_GamepadBankCommonInventoryList:New(...) end
function ZO_GamepadBankCommonInventoryList:Initialize(control, bankMode, ...) end
function ZO_GamepadBankCommonInventoryList:SetBankMode(mode) end
function ZO_BankingCommon_Gamepad:New(...) end
function ZO_BankingCommon_Gamepad:Initialize(control, bankScene) end
function ZO_BankingCommon_Gamepad:OnStateChanged(oldState, newState) end
function ZO_BankingCommon_Gamepad:OnDeferredInitialize() end
function ZO_BankingCommon_Gamepad:InitializeHeader() end
function ZO_BankingCommon_Gamepad:InitializeWithdrawDepositSelector() end
function ZO_BankingCommon_Gamepad:InitializeWithdrawDepositKeybindDescriptor() end
function ZO_BankingCommon_Gamepad:SetSelectorCurrency(currencyType) end
function ZO_BankingCommon_Gamepad:UpdateInput() end
function ZO_BankingCommon_Gamepad:ShowSelector() end
function ZO_BankingCommon_Gamepad:SetMaxInputFunction(maxInputFunction) end
function ZO_BankingCommon_Gamepad:HideSelector() end
function ZO_BankingCommon_Gamepad:RegisterForEvents() end
function ZO_BankingCommon_Gamepad:UnregisterForEvents() end
function ZO_BankingCommon_Gamepad:SetWithdrawList(list) end
function ZO_BankingCommon_Gamepad:SetDepositList(list) end
function ZO_BankingCommon_Gamepad:SetBankedBag(bag) end
function ZO_BankingCommon_Gamepad:SetCarriedBag(bag) end
function ZO_BankingCommon_Gamepad:SetCurrencyType(type) end
function ZO_BankingCommon_Gamepad:SetDepositKeybindDescriptor(descriptor) end
function ZO_BankingCommon_Gamepad:SetWithdrawKeybindDescriptor(descriptor) end
function ZO_BankingCommon_Gamepad:SetCurrentKeybindDescriptor(descriptor) end
function ZO_BankingCommon_Gamepad:SetMode(mode) end
function ZO_BankingCommon_Gamepad:CreateModeData(name, mode, itemList, keybind) end
function ZO_BankingCommon_Gamepad:RefreshHeaderData() end
function ZO_BankingCommon_Gamepad:OnCategoryChanged(selectedData) end
function ZO_BankingCommon_Gamepad:SetCurrentCarriedAmount(control) end
function ZO_BankingCommon_Gamepad:SetCurrentBankedAmount(control) end
function ZO_BankingCommon_Gamepad:GetCurrencyType() end
function ZO_BankingCommon_Gamepad:SetSimpleCurrency(control, amount, currencyType, colorMinValueForMode) end
function ZO_BankingCommon_Gamepad:RecolorCapacityHeader(control, usedSlots, bagSize, recolorMode) end
function ZO_BankingCommon_Gamepad:SetBankCapacityHeaderText(control) end
function ZO_BankingCommon_Gamepad:SetPlayerCapacityHeaderText(control) end
function ZO_BankingCommon_Gamepad:OnSelectionChanged(_, selectedData) end
function ZO_BankingCommon_Gamepad:LayoutInventoryItemTooltip(inventoryData) end
function ZO_BankingCommon_Gamepad:GetWithdrawMoneyAmount() end
function ZO_BankingCommon_Gamepad:GetMaxedBankedFunds(currencyType) end
function ZO_BankingCommon_Gamepad:GetDepositMoneyAmount() end
function ZO_BankingCommon_Gamepad:DepositFunds(currencyType, amount) end
function ZO_BankingCommon_Gamepad:WithdrawFunds(currencyType, amount) end
function ZO_BankingCommon_Gamepad:AddKeybinds() end
function ZO_BankingCommon_Gamepad:RemoveKeybinds() end
function ZO_BankingCommon_Gamepad:UpdateKeybinds() end
function ZO_BankingCommon_Gamepad:OnSceneShowing() end
function ZO_BankingCommon_Gamepad:OnSceneShown() end
function ZO_BankingCommon_Gamepad:OnSceneHiding() end
function ZO_BankingCommon_Gamepad:OnSceneHidden() end
function ZO_BankingCommon_Gamepad:OnCategoryChangedCallback(selectedData) end
function ZO_BankingCommon_Gamepad:OnSelectionChangedCallback() end
function ZO_BankingCommon_Gamepad:OnDeferredInitialization() end
function ZO_BankingCommon_Gamepad:CreateEventTable() end
function ZO_BankingCommon_Gamepad:InitializeLists() end
function ZO_BankingCommon_Gamepad:OnRefreshHeaderData() end
function ZO_GamepadBankInventoryList:New(...) end
function ZO_GamepadBankInventoryList:RefreshList() end
function ZO_GamepadBanking:New(...) end
function ZO_GamepadBanking:Initialize(control) end
function ZO_GamepadBanking:OnSceneHiding() end
function ZO_GamepadBanking:AddKeybinds() end
function ZO_GamepadBanking:RemoveKeybinds() end
function ZO_GamepadBanking:OnDeferredInitialization() end
function ZO_GamepadBanking:InitializeLists() end
function ZO_GamepadBanking:SetupItem(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadBanking:GetTelvarStoneMinimumDepositLabel() end
function ZO_GamepadBanking:GetTelvarStoneBankFeeLabel() end
function ZO_GamepadBanking:SetTelvarStoneMinimumDepositValue(control) end
function ZO_GamepadBanking:SetTelvarStoneBankFeeValue(control) end
function ZO_GamepadBanking:ShowSelector() end
function ZO_GamepadBanking:SetSpinnerValue(max, value) end
function ZO_GamepadBanking:ConfirmWithdrawDeposit(list, bagType) end
function ZO_GamepadBanking:UpdateSpinnerConfirmation(activateSpinner, list) end
function ZO_GamepadBanking:CancelWithdrawDeposit(list) end
function ZO_GamepadBanking:InitializeKeybindStripDescriptors() end
function ZO_GamepadBanking:GetWithdrawMoneyAmount() end
function ZO_GamepadBanking:GetMaxBankedFunds(currencyType) end
function ZO_GamepadBanking:GetDepositMoneyAmount() end
function ZO_GamepadBanking:DepositFunds(currencyType, amount) end
function ZO_GamepadBanking:WithdrawFunds(currencyType, amount) end
function ZO_GamepadBanking:CreateEventTable() end
function ZO_GamepadBanking:CanInteract() end
function ZO_GamepadBanking:PerformWithdrawDeposit() end
function ZO_Banking_Gamepad_Initialize(control) end
function ZO_BuyBankSpace_Gamepad:New(...) end
function ZO_BuyBankSpace_Gamepad:Initialize(control) end
function ZO_BuyBankSpace_Gamepad:Show(cost) end
function ZO_BuyBankSpace_Gamepad:Hide() end
function ZO_GamepadBankingBuyBankSpaceTopLevel_Initialize(control) end
--ingame\cadwell
function ZO_CadwellSort(entry1, entry2) end
function ZO_CadwellManager_Gamepad:New(...) end
function ZO_CadwellManager_Gamepad:Initialize(control) end
function ZO_CadwellManager_Gamepad:OnDeferredInitialize() end
function ZO_CadwellManager_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_CadwellManager_Gamepad:OnShowing() end
function ZO_CadwellManager_Gamepad:OnHide(...) end
function ZO_CadwellManager_Gamepad:PerformUpdate() end
function ZO_CadwellManager_Gamepad:OnSelectionChanged(list, selectedData, oldSelectedData) end
function ZO_CadwellManager_Gamepad:RefreshEntryHeaderDescriptionAndObjectives() end
function ZO_Cadwell_Gamepad_OnInitialize(control) end
function ZO_CadwellManager:New(control) end
function ZO_CadwellManager:InitializeCategoryList(control) end
function ZO_CadwellManager:RefreshList() end
function ZO_CadwellManager:RefreshDetails() end
function ZO_CadwellManager:OnShown() end
function ZO_Cadwell_OnShown() end
function ZO_Cadwell_Initialize(control) end
--ingame\campaign
function CampaignAvARank:New(control) end
function CampaignAvARank:Refresh() end
function ZO_CampaignAvARankStatusBar_OnMouseEnter(control) end
function ZO_CampaignAvARankStatusBar_OnMouseExit() end
function ZO_CampaignAvARank_OnInitialized(self) end
function ZO_CampaignBonusesManager:New(control) end
function ZO_CampaignBonusesManager:SetCampaignAndQueryType(campaignId, queryType) end
function ZO_CampaignBonusesManager:SetupBonusesHeaderEntry(control, data) end
function ZO_CampaignBonusesManager:SetupBonusesEntry(control, data) end
function ZO_CampaignBonusesManager:SortScrollList() end
function ZO_CampaignBonusesManager:FilterScrollList() end
function ZO_CampaignBonusesManager:BuildMasterList() end
function ZO_CampaignBonusesManager:GetRowColors(data, mouseIsOver) end
function ZO_CampaignBonusesManager:ColorRow(control, data, mouseIsOver) end
function ZO_CampaignBonuses_AbilitySlot_OnMouseEnter(control) end
function ZO_CampaignBonuses_AbilitySlot_OnMouseExit() end
function ZO_CampaignBonuses_CountInfo_OnMouseEnter(control) end
function ZO_CampaignBonuses_CountInfo_OnMouseExit() end
function ZO_CampaignBonuses_OnInitialized(self) end
function ZO_CampaignBonuses_Shared:New(...) end
function ZO_CampaignBonuses_Shared:Initialize(control) end
function ZO_CampaignBonuses_Shared:SetCampaignAndQueryType(campaignId, queryType) end
function ZO_CampaignBonuses_Shared:GetCurrentCampaignId() end
function ZO_CampaignBonuses_Shared:CreateDataTable() end
function ZO_CampaignBonuses_Shared:BuildMasterList() end
function CampaignBrowser:New(control) end
function CampaignBrowser:InitializeTree() end
function CampaignBrowser:SetRulesetTypeFilter(rulesetType) end
function CampaignBrowser:SetRulesetIdFilter(rulesetId) end
function CampaignBrowser:CanGuest() end
function CampaignBrowser:DoGuest() end
function CampaignBrowser:CanHome() end
function CampaignBrowser:DoHome() end
function CampaignBrowser:CanAbandon() end
function CampaignBrowser:DoAbandon() end
function CampaignBrowser:CanEnter() end
function CampaignBrowser:DoEnter() end
function CampaignBrowser:CanQueue() end
function CampaignBrowser:DoQueue() end
function CampaignBrowser:CanLeave() end
function CampaignBrowser:DoLeave() end
function CampaignBrowser:GetCampaignBrowser() end
function CampaignBrowser:InitializeKeybindDescriptors() end
function CampaignBrowser:SetupAllianceControl(control, data) end
function CampaignBrowser:SetupCampaign(control, data) end
function CampaignBrowser:SetupCampaignQueue(control, data) end
function CampaignBrowser:AddQueueRow(data, isGroup) end
function CampaignBrowser:RefreshQueueRows(data) end
function CampaignBrowser:BuildMasterList() end
function CampaignBrowser:BuildCategories() end
function CampaignBrowser:FilterScrollList() end
function CampaignBrowser:CompareCampaigns(listEntry1, listEntry2) end
function CampaignBrowser:SortScrollList() end
function CampaignBrowser:GetRowColors(data, mouseIsOver, control) end
function CampaignBrowser:GetDataByCampaignId(campaignId) end
function CampaignBrowser:OnCampaignSelectionDataChanged() end
function CampaignBrowser:OnCampaignQueueJoined(campaignId) end
function CampaignBrowser:OnCampaignQueueLeft(campaignId) end
function CampaignBrowser:OnCampaignQueueStateChanged(campaignId) end
function CampaignBrowser:OnCampaignQueuePositionChanged() end
function CampaignBrowser:OnUnitUpdated(unitTag) end
function CampaignBrowser:OnGroupLeaderUpdate() end
function CampaignBrowser:QueueRowIcon_OnMouseEnter(control) end
function CampaignBrowser:QueueRowIcon_OnMouseExit(control) end
function CampaignBrowser:RowIcon_OnMouseEnter(control) end
function CampaignBrowser:RowIcon_OnMouseExit(control) end
function CampaignBrowser:RowGroupMembers_OnMouseEnter(control) end
function CampaignBrowser:RowGroupMembers_OnMouseExit(control) end
function CampaignBrowser:RowFriends_OnMouseEnter(control) end
function CampaignBrowser:RowFriends_OnMouseExit(control) end
function CampaignBrowser:RowGuildMembers_OnMouseEnter(control) end
function CampaignBrowser:RowGuildMembers_OnMouseExit(control) end
function CampaignBrowser:RowAlliancePopulation_OnMouseEnter(control) end
function CampaignBrowser:RowAlliancePopulation_OnMouseExit(control) end
function CampaignBrowser:Row_OnMouseUp(control, button, upInside) end
function CampaignBrowser:Row_OnMouseDoubleClick(control) end
function CampaignBrowser:QueueRow_OnMouseUp(control, button, upInside) end
function CampaignBrowser:QueueRow_OnMouseDoubleClick(control) end
function ZO_CampaignBrowserQueueRowIcon_OnMouseEnter(control) end
function ZO_CampaignBrowserQueueRowIcon_OnMouseExit(control) end
function ZO_CampaignBrowserRowIcon_OnMouseEnter(control) end
function ZO_CampaignBrowserRowIcon_OnMouseExit(control) end
function ZO_CampaignBrowserRowGroupMembers_OnMouseEnter(control) end
function ZO_CampaignBrowserRowGroupMembers_OnMouseExit(control) end
function ZO_CampaignBrowserRowFriends_OnMouseEnter(control) end
function ZO_CampaignBrowserRowFriends_OnMouseExit(control) end
function ZO_CampaignBrowserRowGuildMembers_OnMouseEnter(control) end
function ZO_CampaignBrowserRowGuildMembers_OnMouseExit(control) end
function ZO_CampaignBrowserRowAlliancePopulation_OnMouseEnter(control) end
function ZO_CampaignBrowserRowAlliancePopulation_OnMouseExit(control) end
function ZO_CampaignBrowserRow_OnMouseEnter(control) end
function ZO_CampaignBrowserRow_OnMouseExit(control) end
function ZO_CampaignBrowserRow_OnMouseUp(control, button, upInside) end
function ZO_CampaignBrowserRow_OnMouseDoubleClick(control) end
function ZO_CampaignBrowserQueueRow_OnMouseEnter(control) end
function ZO_CampaignBrowserQueueRow_OnMouseExit(control) end
function ZO_CampaignBrowserQueueRow_OnMouseUp(control, button, upInside) end
function ZO_CampaignBrowserQueueRow_OnMouseDoubleClick(control) end
function ZO_CampaignBrowser_OnInitialized(self) end
function SelectGuestCampaign:New(control) end
function SelectGuestCampaign:SetupUnlocked(data) end
function SelectGuestCampaign:SetupLocked(data) end
function ZO_SelectGuestCampaignDialog_OnInitialized(self) end
function SelectHomeCampaign:New(control) end
function SelectHomeCampaign:SetupUnlocked(data) end
function SelectHomeCampaign:SetupLocked(data) end
function SelectHomeCampaign:SetupCost() end
function SelectHomeCampaign:DialogSetNow_OnClicked(control) end
function SelectHomeCampaign:DialogSetOnEnd_OnClicked(control) end
function ZO_SelectHomeCampaignDialogSetNow_OnClicked(control) end
function ZO_SelectHomeCampaignDialogSetOnEnd_OnClicked(control) end
function ZO_SelectHomeCampaignDialog_OnInitialized(self) end
function AbandonGuestCampaign:New(control) end
function AbandonGuestCampaign:SetupUnlocked(data) end
function AbandonGuestCampaign:SetupLocked(data) end
function ZO_AbandonGuestCampaignDialog_OnInitialized(self) end
function AbandonHomeCampaign:New(control) end
function AbandonHomeCampaign:SetupUnlocked(data) end
function AbandonHomeCampaign:SetupLocked(data) end
function AbandonHomeCampaign:DialogUseAlliancePoints_OnClicked(control) end
function AbandonHomeCampaign:DialogUseGold_OnClicked(control) end
function AbandonHomeCampaign:SetupCost() end
function ZO_AbandonHomeCampaignDialogUseAlliancePoints_OnClicked(control) end
function ZO_AbandonHomeCampaignDialogUseGold_OnClicked(control) end
function ZO_AbandonHomeCampaignDialog_OnInitialized(self) end
function ZO_SelectHomeCampaign_GetCost() end
function ZO_AbandonHomeCampaign_GetCost() end
function ZO_CampaignBrowser_Shared:New(...) end
function ZO_CampaignBrowser_Shared:CanHome(data) end
function ZO_CampaignBrowser_Shared:CanGuest(data) end
function ZO_CampaignBrowser_Shared:CanQueue(data) end
function ZO_CampaignBrowser_Shared:CanLeave(data) end
function ZO_CampaignBrowser_Shared:DoQueue(data) end
function ZO_CampaignBrowser_Shared:GetCampaignType() end
function ZO_CampaignBrowser_Shared:GetQueueType(data) end
function ZO_CampaignBrowser_Shared:GetMasterHomeData() end
function ZO_CampaignBrowser_Shared:GetMasterGuestData() end
function ZO_CampaignBrowser_Shared:SetupQueuedData(data) end
function ZO_CampaignBrowser_Shared:ShowCampaignQueueReadyDialog(campaignId, isGroup, campaignName) end
function ZO_CampaignBrowser_Shared:BuildMasterList() end
function ZO_CampaignBrowser_Shared:BuildCategoriesList() end
function ZO_CampaignBrowser_Shared:DoLeave(data) end
function ZO_CampaignBrowser_Shared:GetDataByCampaignId(campaignId) end
function ZO_CampaignBrowser_Shared:UpdateQueuedMessageControls(loading, description, icon, id, isGroup, state) end
function ZO_CampaignBrowser_GetPopulationIcon(population) end
function ZO_CampaignBrowser_GetIcons(rulesetType) end
function ZO_CampaignDataRegistration:New(...) end
function ZO_CampaignDataRegistration:Initialize(namespace, needsDataFunction) end
function ZO_CampaignDataRegistration:Refresh() end
function ZO_CampaignDataRegistration:OnPlayerActivated() end
function ZO_CampaignDataRegistration:OnPlayerDeactivated() end
function CampaignEmperor:New(control) end
function CampaignEmperor:Initialize(control) end
function CampaignEmperor:ChangeAlliance(alliance, shownAllianceString) end
function CampaignEmperor:ImperialKeep_OnMouseEnter(control) end
function CampaignEmperor:ImperialKeep_OnMouseExit(control) end
function CampaignEmperor:OnDropdownClicked(control) end
function CampaignEmperor:SetKeepAllianceNoneStatus(keep) end
function ZO_CampaignImperialKeep_OnMouseEnter(control) end
function ZO_CampaignImperialKeep_OnMouseExit(control) end
function ZO_CampaignEmperor_DropdownClicked(control) end
function ZO_CampaignEmperorName_OnMouseEnter(control) end
function ZO_CampaignEmperorName_OnMouseExit(control) end
function ZO_CampaignEmperor_OnInitialized(self) end
function CampaignEmperor_Shared:New(control) end
function CampaignEmperor_Shared:Initialize(control) end
function CampaignEmperor_Shared:InitializeMenu() end
function CampaignEmperor_Shared:ChangeAlliance(alliance, shownAllianceString) end
function CampaignEmperor_Shared:CreateImperialKeepControl(rulesetId, playerAlliance, index, prevKeep) end
function CampaignEmperor_Shared:BuildImperialKeeps() end
function CampaignEmperor_Shared:SetCampaignAndQueryType(campaignId, queryType) end
function CampaignEmperor_Shared:SetReignDurationEnabled(enabled) end
function CampaignEmperor_Shared:RefreshEmperor() end
function CampaignEmperor_Shared:RefreshImperialKeeps() end
function CampaignEmperor_Shared:SetKeepAllianceNoneStatus(keep) end
function CampaignEmperor_Shared:RefreshAll() end
function CampaignEmperor_Shared:SetupBackgroundForEntry(control, data) end
function CampaignEmperor_Shared:SetupLeaderboardEntry(control, data) end
function CampaignEmperor_Shared:SetupLeaderboardNonPlayerEntry(control, data) end
function CampaignEmperor_Shared:SetupPlayerRow(data) end
function CampaignEmperor_Shared:SortScrollList() end
function CampaignEmperor_Shared:FilterScrollList() end
function CampaignEmperor_Shared:CommitScrollList() end
function CampaignEmperor_Shared:AddAllianceToMasterList(alliance) end
function CampaignEmperor_Shared:BuildMasterList() end
function CampaignEmperor_Shared:GetRowColors(data, mouseIsOver) end
function CampaignEmperor_Shared:ColorRow(control, data, mouseIsOver) end
function CampaignEmperor_Shared:OnCampaignEmperorChanged(campaignId) end
function CampaignEmperor_Shared:OnCampaignStateInitialized(campaignId) end
function ZO_CampaignOverviewManager:New(control) end
function ZO_CampaignOverviewManager:UpdateCampaignName(campaignId) end
function ZO_CampaignOverviewManager:SetCampaignAndQueryType(campaignId, queryType) end
function ZO_CampaignOverviewManager:InitializeCategories() end
function ZO_CampaignOverviewManager:RefreshCategories() end
function ZO_CampaignOverviewManager:ChangeCategory(overviewType) end
function ZO_CampaignOverview_OnInitialized(self) end
function ZO_CampaignScoringManager:New(control) end
function ZO_CampaignScoring_IconOnMouseEnter(control) end
function ZO_CampaignScoring_IconOnMouseExit(control) end
function ZO_CampaignScoring_OnInitialized(self) end
function ZO_CampaignScoring_TimeUpdate(control, timeFunction) end
function ZO_CampaignScoringManager_Shared:New(control) end
function ZO_CampaignScoringManager_Shared:SetCampaignAndQueryType(campaignId, queryType) end
function ZO_CampaignScoringManager_Shared:UpdateScores() end
function ZO_CampaignScoringManager_Shared:UpdateRewardTier() end
function ZO_CampaignScoringManager_Shared:UpdateBonusIconVisibilities(initialControlAnchor, lowScoreIcon, isLowScoring, lowPopIcon, isLowPop) end
function ZO_CampaignScoringManager_Shared:UpdateScoreSection(index, scoreInfo) end
function ZO_CampaignScoringManager_Shared:OnTimeControlUpdate(control, timeFunction) end
function ZO_CampaignScoring_AllianceSection_OnInitialized(control) end
function CampaignSelector:New(control) end
function CampaignSelector:Initialize(control) end
function CampaignSelector:RefreshQueryTypes() end
function ZO_CampaignSelector_OnInitialized(self) end
function ZO_CampaignSelector_Shared:New(control) end
function ZO_CampaignSelector_Shared:Initialize(control) end
function ZO_CampaignSelector_Shared:RefreshQueryTypes() end
function ZO_CampaignSelector_Shared:NeedsData() end
function ZO_CampaignSelector_Shared:GetCampaignId() end
function ZO_CampaignSelector_Shared:GetQueryType() end
function ZO_CampaignSelector_Shared:UpdateCampaignWindows() end
function ZO_CampaignSelector_Shared:OnCurrentCampaignChanged() end
function ZO_CampaignSelector_Shared:OnAssignedCampaignChanged() end
function CurrentCampaigns:New(control) end
function CurrentCampaigns:RefreshCampaigns() end
function CurrentCampaigns:RefreshCampaign(campaignId, label) end
function ZO_CurrentCampaigns_GetName(campaignId) end
function ZO_CurrentCampaigns_OnInitialized(self) end
function ZO_CampaignBonusesGamepad:New(...) end
function ZO_CampaignBonusesGamepad:Initialize(control) end
function ZO_CampaignBonusesGamepad:RegisterForEvents() end
function ZO_CampaignBonusesGamepad:UnregisterForEvents() end
function ZO_CampaignBonusesGamepad:Activate() end
function ZO_CampaignBonusesGamepad:Deactivate() end
function ZO_CampaignBonusesGamepad:UpdateToolTip() end
function ZO_CampaignBonusesGamepad:SetTooltipHidden(hidden) end
function ZO_CampaignBonusesGamepad:UpdateBonuses() end
function ZO_CampaignBonuses_Gamepad_OnInitialized(control) end
function ZO_CampaignBonusEntryHeaderTemplateSetup(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_CampaignBonusEntryTemplateSetup(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_CampaignBonusEntryTemplate_OnInitialized(control) end
function ZO_CampaignDialogGamepad_Initialize(screen) end
function ZO_CampaignBrowser_Gamepad:New(...) end
function ZO_CampaignBrowser_Gamepad:Initialize(control) end
function ZO_CampaignBrowser_Gamepad:PerformUpdate() end
function ZO_CampaignBrowser_Gamepad:UpdateLists() end
function ZO_CampaignBrowser_Gamepad:UpdateContent(updateFromTimer) end
function ZO_CampaignBrowser_Gamepad:UpdateQueuedMessageControls(loadingControl, descriptionControl, icon, id, isGroup, state) end
function ZO_CampaignBrowser_Gamepad:UpdateQueueMessages(control, icon, groupControl, groupIcon, data) end
function ZO_CampaignBrowser_Gamepad:UpdateQueuedMessage(control, data, isGroup, state, icon) end
function ZO_CampaignBrowser_Gamepad:RefreshCampaignInfoContent() end
function ZO_CampaignBrowser_Gamepad:PerformDeferredInitialization() end
function ZO_CampaignBrowser_Gamepad:OnSelectionChanged(list, selectedData, oldSelectedData) end
function ZO_CampaignBrowser_Gamepad:InitLastStates() end
function ZO_CampaignBrowser_Gamepad:SetCurrentMode(mode) end
function ZO_CampaignBrowser_Gamepad:InitializeHeader() end
function ZO_CampaignBrowser_Gamepad:RefreshScreenHeader() end
function ZO_CampaignBrowser_Gamepad:RefreshContentHeader() end
function ZO_CampaignBrowser_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_CampaignBrowser_Gamepad:RegisterEvents() end
function ZO_CampaignBrowser_Gamepad:UnregisterEvents() end
function ZO_CampaignBrowser_Gamepad:OnUpdate(control, seconds) end
function ZO_CampaignBrowser_Gamepad:GetTargetData() end
function ZO_CampaignBrowser_Gamepad:IsQueued(data) end
function ZO_CampaignBrowser_Gamepad:CanEnter(data) end
function ZO_CampaignBrowser_Gamepad:CanHome(data) end
function ZO_CampaignBrowser_Gamepad:DoHome(data) end
function ZO_CampaignBrowser_Gamepad:CanGuest() end
function ZO_CampaignBrowser_Gamepad:DoLeave(data) end
function ZO_CampaignBrowser_Gamepad:DoAbandon(data) end
function ZO_CampaignBrowser_Gamepad:GetCampaignBrowser() end
function ZO_CampaignBrowser_Gamepad:CanQueue(data) end
function ZO_CampaignBrowser_Gamepad:DoQueue(data) end
function ZO_CampaignBrowser_Gamepad:AddCampaignListEntry(data, headerText) end
function ZO_CampaignBrowser_Gamepad:AddCampaignDataToList(data, name, icon, contentType, entryType) end
function ZO_CampaignBrowser_Gamepad:CollectAssignedCampaignData() end
function ZO_CampaignBrowser_Gamepad:AddAssignedCampaignsToList() end
function ZO_CampaignBrowser_Gamepad:AddNonAssignedCampaignsToList() end
function ZO_CampaignBrowser_Gamepad:BuildCampaignList() end
function ZO_CampaignBrowser_Gamepad:GetPriceMessage(cost, hasEnough, useGold) end
function ZO_CampaignBrowser_Gamepad:GetTextParamsForSetHomeDialog() end
function ZO_CampaignBrowser_Gamepad:GetTextParamsForAbandonHomeDialog() end
function ZO_CampaignBrowser_Gamepad:OnCampaignQueueJoined(campaignId) end
function ZO_CampaignBrowser_Gamepad:OnCampaignQueueLeft(campaignId) end
function ZO_CampaignBrowser_Gamepad:OnCampaignQueueStateChanged(campaignId) end
function ZO_CampaignBrowser_Gamepad:OnCampaignQueuePositionChanged() end
function ZO_CampaignAvARank_Gamepad_OnInitialized(control) end
function ZO_CampaignBrowser_Gamepad_Initialize(control) end
function ZO_AvAFactionPopulation_Gamepad_OnInitialize(control, alliance) end
function CampaignEmperor_Gamepad:New(control) end
function CampaignEmperor_Gamepad:Initialize(control) end
function CampaignEmperor_Gamepad:SetupLeaderboardAllianceEntry(control, data) end
function CampaignEmperor_Gamepad:SetupLeaderboardEmptyEntry(control, data) end
function CampaignEmperor_Gamepad:SetupLeaderboardAlliances() end
function CampaignEmperor_Gamepad:SetCampaignAndQueryType(campaignId, queryType) end
function CampaignEmperor_Gamepad:BuildMasterList() end
function CampaignEmperor_Gamepad:CreateImperialKeepControl(rulesetId, playerAlliance, index, _, prevKeep) end
function CampaignEmperor_Gamepad:SetKeepAllianceNoneStatus(keep) end
function CampaignEmperor_Gamepad:RefreshImperialKeeps() end
function ZO_CampaignEmperor_Gamepad_OnInitialized(self) end
function ZO_CampaignScoringManager_Gamepad:New(control) end
function ZO_CampaignScoringManager_Gamepad:UpdateScoreSection(index, scoreInfo) end
function ZO_CampaignScoring_Gamepad_OnInitialized(self) end
--ingame\centerscreenannounce
function CenterScreenPlayerProgressBarParams:New() end
function CenterScreenPlayerProgressBarParams:Reset() end
function CenterScreenPlayerProgressBarParams:Set(barType, startLevel, start, stop, sound) end
function CenterScreenPlayerProgressBarParams:GetParams() end
function CenterScreenPlayerProgressBarParams:SetShowNoGain(showNoGain) end
function CenterScreenPlayerProgressBarParams:SetSound(sound) end
function CenterScreenAnnounce:New(...) end
function CenterScreenAnnounce:InitializeLineAnimation(line, timelineTemplate, timelineMemberKey, stopHandler, expiringCallbackCheckOffset, expiringCallbackExecutor) end
function CenterScreenAnnounce:InitializeWipeAnimation(container, timelineTemplate, timelineMemberKey, stopHandler, expiringCallbackCheckOffset, expiringCallbackExecutor, wipeIn, wipeOut) end
function CenterScreenAnnounce:ApplyStyle() end
function CenterScreenAnnounce:OnGamepadPreferredModeChanged() end
function CenterScreenAnnounce:IsInactive() end
function CenterScreenAnnounce:CreateBarParams(...) end
function CenterScreenAnnounce:CanDisplayMessage(category) end
function CenterScreenAnnounce:GetWaitingQueueEventData(eventId) end
function CenterScreenAnnounce:GetPriority(eventId) end
function CenterScreenAnnounce:CreateMessagePayload(eventId, category, queuedOrder, ...) end
function CenterScreenAnnounce:QueueMessage(eventId, category, ...) end
function CenterScreenAnnounce:SortQueue() end
function CenterScreenAnnounce:GetNumQueuedEvents() end
function CenterScreenAnnounce:PeekNextEvent() end
function CenterScreenAnnounce:DoesNextEventHaveBar() end
function CenterScreenAnnounce:DoesNextEventHaveBarType(barType) end
function CenterScreenAnnounce:HasBarTypeInQueue(barType) end
function CenterScreenAnnounce:RemoveNextEvent() end
function CenterScreenAnnounce:DisplayNextQueuedEvent() end
function CenterScreenAnnounce:MoveSmallTextLinesUp(completedLine) end
function CenterScreenAnnounce:IsTopLine(line) end
function CenterScreenAnnounce:TryDisplayingNextQueuedMessage() end
function CenterScreenAnnounce:UpdateDisplay(completedLine, skipSmallBlockMove) end
function CenterScreenAnnounce:ReleaseLine(completedLine) end
function CenterScreenAnnounce:CheckNowInactive() end
function CenterScreenAnnounce:ShouldRejectCategory(category) end
function CenterScreenAnnounce:SetRejectCategory(category, reject) end
function CenterScreenAnnounce:SetExpiringCallback(line, callback) end
function CenterScreenAnnounce:CallExpiringCallback(control) end
function CenterScreenAnnounce:DisplayMessage(category, ...) end
function CenterScreenAnnounce:AddMessage(eventId, category, ...) end
function ZO_CenterScreenAnnounce_SetEventPriority(eventId, priority) end
function ZO_CenterScreenAnnounce_Initialize(self) end
function GetAvAObjectiveEventDescription(keepId, objectiveId, objectiveName, objectiveType, event, param1, param2) end
function GetAvAArtifactEventDescription(artifactName, keepId, playerName, playerAlliance, event, campaignId) end
function GetKeepOwnershipChangedEventDescription(campaignId, keepId, oldOwner, newOwner) end
function GetGateStateChangedDescription(keepId, open) end
function GetCoronateEmperorEventDescription(campaignId, playerCharacterName, playerAlliance, playerDisplayName) end
function GetDeposeEmperorEventDescription(campaignId, playerCharacterName, playerAlliance, abdication, playerDisplayName) end
function GetImperialCityAccessGainedEventDescription(campaignId, alliance) end
function GetImperialCityAccessLostEventDescription(campaignId, alliance) end
function GetClaimKeepCampaignEventDescription(campaignId, keepId, guildName, playerName) end
function GetReleaseKeepCampaignEventDescription(campaignId, keepId, guildName, playerName) end
function GetLostKeepCampaignEventDescription(campaignId, keepId, guildName) end
function ZO_CenterScreenAnnounce_GetHandlers() end
function ZO_CenterScreenAnnounce_GetHandler(eventId) end
function ZO_CenterScreenAnnounce_InitializePriorities() end
function ZO_CenterScreenAnnounce_GetQueueableHandlers() end
function ZO_CenterScreenAnnounce_GetQueueableHandler(eventId) end
--ingame\championperks
function ZO_ChampionConstellation:New(...) end
function ZO_ChampionConstellation:Initialize(sceneGraph, node, disciplineIndex, constellationsDepth) end
function ZO_ChampionConstellation:GetDisciplineIndex() end
function ZO_ChampionConstellation:GetAttributeType() end
function ZO_ChampionConstellation:GetName() end
function ZO_ChampionConstellation:GetDescription() end
function ZO_ChampionConstellation:GetNumSpentPoints() end
function ZO_ChampionConstellation:GetNumCommittedSpentPoints() end
function ZO_ChampionConstellation:GetNumPendingPoints() end
function ZO_ChampionConstellation:GetNumPointsThatWillBeSpent() end
function ZO_ChampionConstellation:ResetPendingPoints() end
function ZO_ChampionConstellation:RefreshSpentPoints() end
function ZO_ChampionConstellation:RefreshAllStarStates() end
function ZO_ChampionConstellation:RefreshAllStarMinMax() end
function ZO_ChampionConstellation:RefreshAllStarText() end
function ZO_ChampionConstellation:HasUnsavedChanges() end
function ZO_ChampionConstellation:SetVisualInfo(visualInfo) end
function ZO_ChampionConstellation:UpdateVisuals(timeSecs, frameDeltaSecs) end
function ZO_ChampionConstellation:MakeChosen() end
function ZO_ChampionConstellation:ClearChosen(instantly) end
function ZO_ChampionConstellation:UpdateDirectionalInput() end
function ZO_ChampionConstellation:OnStarPendingPointsChanged(star) end
function ZO_ChampionConstellation:RefreshSelectedStarTooltip() end
function ZO_ChampionConstellation:SelectStar(star) end
function ZO_ChampionConstellation:GetSelectedStar() end
function ZO_ChampionConstellation:GetStars() end
function ChampionPerks:New(...) end
function ChampionPerks:Initialize(control) end
function ChampionPerks:IsChampionSystemNew() end
function ChampionPerks:SetChampionSystemNew(isNew) end
function ChampionPerks:SetupCustomConfirmDialog() end
function ChampionPerks:ShowDialog(name, data, textParams) end
function ChampionPerks:PerformDeferredInitializationShared() end
function ChampionPerks:CreateCloseCloudsAnimation() end
function ChampionPerks:PerformDeferredInitializationKeyboard() end
function ChampionPerks:PerformDeferredInitializationGamepad() end
function ChampionPerks:InitializeKeyboardKeybindStripDescriptors() end
function ChampionPerks:InitializeSharedKeybindStripDescriptors() end
function ChampionPerks:InitializeGamepadKeybindStripDescriptors() end
function ChampionPerks:RefreshApplicableSharedKeybinds() end
function ChampionPerks:RemoveSharedKeybinds() end
function ChampionPerks:RefreshApplicableInputTypeKeybinds() end
function ChampionPerks:RemoveInputTypeKeybinds() end
function ChampionPerks:BuildStarSpirals() end
function ChampionPerks:BuildClouds() end
function ChampionPerks:BuildSceneGraph() end
function ChampionPerks:BuildCenterInfoPointCounters() end
function ChampionPerks:RegisterEvents() end
function ChampionPerks:BuildStyleTables() end
function ChampionPerks:SetupDescriptionLabels(constants, nameLabel, spentPointsLabel, descriptionLabel) end
function ChampionPerks:SetupEarnedPointCounter(constants, control) end
function ChampionPerks:ApplyCenterInfoStyle(constants) end
function ChampionPerks:ApplyInactiveAlertStyle(constants, control) end
function ChampionPerks:ApplyKeyboardStyle() end
function ChampionPerks:ApplyGamepadStyle() end
function ChampionPerks:GetStarTextControlPool() end
function ChampionPerks:AcquireSelectedStarIndicatorTexture() end
function ChampionPerks:ReleaseSelectedStarIndicatorTexture() end
function ChampionPerks:IsMouseOverConstellationDisc() end
function ChampionPerks:IsMouseOverLeftConstellation() end
function ChampionPerks:IsMouseOverRightConstellation() end
function ChampionPerks:UpdateZoomedInMouseoverPositions() end
function ChampionPerks:RefreshCursorAndPlayMouseover() end
function ChampionPerks:GetConstellationInfo(constellation) end
function ChampionPerks:RefreshConstellationInfo(constellation, nameLabel, spentPointsLabel, descriptionLabel) end
function ChampionPerks:RefreshChosenConstellationInfo() end
function ChampionPerks:GetChosenConstellation() end
function ChampionPerks:SetChosenConstellation(constellation, unchooseInstantly) end
function ChampionPerks:RefreshSelectedConstellationInfo() end
function ChampionPerks:SetSelectedConstellation(constellation) end
function ChampionPerks:LayoutRightTooltipChampionSkillAbility(disciplineIndex, skillIndex, pendingPoints) end
function ChampionPerks:GetNumPendingPoints(attributeType) end
function ChampionPerks:HasAnyPendingPoints() end
function ChampionPerks:HasAnyCommittedSpentPoints(attributeType) end
function ChampionPerks:GetNumCommittedSpentPoints(attributeType) end
function ChampionPerks:GetNumAvailablePoints(attributeType) end
function ChampionPerks:GetNumAvailablePointsUntilMaxSpendableCap(attributeType) end
function ChampionPerks:GetNumAvailablePointsThatCanBeSpent(attributeType) end
function ChampionPerks:RefreshUnspentPoints() end
function ChampionPerks:HasAnyUnspentPoints(attributeType) end
function ChampionPerks:HasAnySpendableUnspentPoints(attributeType) end
function ChampionPerks:RefreshChosenAttributePointCounter() end
function ChampionPerks:RefreshChosenAttributeEarnedPointCounter() end
function ChampionPerks:RefreshAvailablePointDisplays() end
function ChampionPerks:ResetPendingPoints() end
function ChampionPerks:SetPendingPointsToZero() end
function ChampionPerks:SpendPointsConfirmed(respecNeeded) end
function ChampionPerks:SpendPendingPoints() end
function ChampionPerks:RefreshConstellationStarStates() end
function ChampionPerks:RefreshConstellationSpentPoints() end
function ChampionPerks:RefreshChosenConstellationStarMinMax() end
function ChampionPerks:HasUnsavedChanges() end
function ChampionPerks:ToggleRespecMode() end
function ChampionPerks:SetInRespecMode(inRespecMode) end
function ChampionPerks:IsInRespecMode() end
function ChampionPerks:AcquireOneShotAnimation(animationInfo, onReleaseCallback) end
function ChampionPerks:SortConfirmStars(starA, starB) end
function ChampionPerks:PlayStarConfirmAnimations() end
function ChampionPerks:OnConfirmCameraShakeUpdate(timeline, progress) end
function ChampionPerks:OnConfirmCameraPrepUpdate(timeline, progress) end
function ChampionPerks:OnConfirmCameraPrepStop() end
function ChampionPerks:IsRespecNeeded() end
function ChampionPerks:ZoomOut() end
function ChampionPerks:ZoomIn(node) end
function ChampionPerks:ZoomedInRotate(node) end
function ChampionPerks:ZoomedOutRotate(node) end
function ChampionPerks:PlayEnterAnimation() end
function ChampionPerks:SetRootCameraX(x) end
function ChampionPerks:SetRootCameraY(y) end
function ChampionPerks:SetRootCameraZ(z) end
function ChampionPerks:SetDeltaCameraX(x) end
function ChampionPerks:SetDeltaCameraY(y) end
function ChampionPerks:SetDeltaCameraZ(z) end
function ChampionPerks:RefreshCameraPosition() end
function ChampionPerks:ResetToZoomedOut() end
function ChampionPerks:SetAnimation(animation) end
function ChampionPerks:ClearAnimation() end
function ChampionPerks:IsAnimating() end
function ChampionPerks:SetState(state) end
function ChampionPerks:IsZoomedIn() end
function ChampionPerks:UpdateAnimations(frameDeltaSecs) end
function ChampionPerks:UpdateCenterAlpha(timeSecs, frameDeltaSecs) end
function ChampionPerks:UpdateDirectionalInput() end
function ChampionPerks:DumpNormalizedCoordinates() end
function ChampionPerks:OnUpdate(timeSecs) end
function ChampionPerks:OnSpiralUpdate(animation, progress) end
function ChampionPerks:OnSpiralStop(timeline) end
function ChampionPerks:OnChampionPointGained() end
function ChampionPerks:OnChampionSystemUnlocked() end
function ChampionPerks:OnUnspentChampionPointsChanged() end
function ChampionPerks:MarkDirty() end
function ChampionPerks:CleanDirty() end
function ChampionPerks:OnChampionPurchaseResult(result) end
function ChampionPerks:OnSelectedStarChanged() end
function ChampionPerks:OnMoneyChanged() end
function ChampionPerks:OnPlayerActivated() end
function ChampionPerks:OnPowerUpdate(eventCode, unitTag, powerIndex, powerType, value, max, effectiveMax) end
function ChampionPerks:RefreshMenuIndicators() end
function ChampionPerks:RefreshMenus() end
function ChampionPerks:Canvas_OnMouseUp(button) end
function ZO_ChampionPerksGamepad_TooltipResizeHandler(control) end
function ZO_ChampionPerksCanvas_OnMouseUp(button) end
function ZO_ChampionPerks_OnInitialized(self) end
function ZO_ChampionStar:New(...) end
function ZO_ChampionStar:Initialize(constellation, texture, sceneNode, skillIndex, constellationWidth, constellationHeight, starDepth) end
function ZO_ChampionStar:GetNormalizedCoordinates() end
function ZO_ChampionStar:ResetPendingPoints() end
function ZO_ChampionStar:SetPendingPointsToZero() end
function ZO_ChampionStar:InitializePointSpending() end
function ZO_ChampionStar:RefreshPointsMinMax() end
function ZO_ChampionStar:HasUnsavedChanges() end
function ZO_ChampionStar:OnValueChanged() end
function ZO_ChampionStar:SpendPoints(points) end
function ZO_ChampionStar:RemovePoints(points) end
function ZO_ChampionStar:GetTexture() end
function ZO_ChampionStar:SetNumPendingPoints(numPoints) end
function ZO_ChampionStar:GetNumPendingPoints() end
function ZO_ChampionStar:GetNumSpentPoints() end
function ZO_ChampionStar:GetNumCommittedSpentPoints() end
function ZO_ChampionStar:GetNumPointsThatWillBeSpent() end
function ZO_ChampionStar:CanSpendPoints() end
function ZO_ChampionStar:IsPurchased() end
function ZO_ChampionStar:WouldBePurchased() end
function ZO_ChampionStar:SetStateLocked(locked) end
function ZO_ChampionStar:RefreshState() end
function ZO_ChampionStar:RefreshTexture() end
function ZO_ChampionStar:GetStarTextColorUnselected() end
function ZO_ChampionStar:UpdateVisuals(timeSecs, frameDeltaSecs) end
function ZO_ChampionStar:ArePointsAvailableToSpend() end
function ZO_ChampionStar:ReleaseTextControl() end
function ZO_ChampionStar:ResetTextControl() end
function ZO_ChampionStar:SetEnabled(enabled, instantly) end
function ZO_ChampionStar:RefreshText() end
function ZO_ChampionStar:CanAddPoints() end
function ZO_ChampionStar:StartAddingPoints() end
function ZO_ChampionStar:StopChangingPoints() end
function ZO_ChampionStar:CanRemovePoints() end
function ZO_ChampionStar:StartRemovingPoints() end
function ZO_ChampionStar:GetConstellation() end
function ZO_ChampionStar:ApplyButtonTemplatesToTextControl(template) end
function ZO_ChampionStar:ApplyGamepadButtonTemplatesToTextControl() end
function ZO_ChampionStar:ApplyGamepadTriggerButtonTemplatesToTextControl() end
function ZO_ChampionStar:PlayOneShotAnimation(animationInfo) end
function ZO_ChampionStar:OnMouseUp(control, button, upInside) end
function ZO_ChampionStar:OnMouseEnter(control) end
function ZO_ChampionStar:OnMouseExit(control) end
function ZO_ChampionStar:OnMouseWheel(control, delta) end
function ZO_ConstellationStarComponent_OnMouseEnter(self) end
function ZO_ConstellationStarComponent_OnMouseExit(self) end
function ZO_ConstellationStarComponent_OnMouseUp(self, button, upInside) end
function ZO_ConstellationStarComponent_OnMouseWheel(self, delta) end
--ingame\characterwindow
function ZO_Character_UpdateReadOnly() end
function ZO_Character_IsReadOnly() end
function ZO_Character_SetIsShowingReadOnlyFragment(isReadOnly) end
function ZO_Character_Initialize(control) end
function ZO_CharacterWindowStats_Initialize(control) end
function ZO_Character_EnumerateOrderedEquipSlots() end
function ZO_Character_GetEquipSlotToEquipTypesTable() end
function ZO_Character_EnumerateEquipSlotToEquipTypes() end
function ZO_Character_DoesEquipSlotUseEquipType(equipSlot, equipType) end
function ZO_Character_GetEquipSlotVisualCategory(equipSlot) end
function ZO_Character_GetEmptyEquipSlotTexture(equipSlot) end
--ingame\chatsystem
function ZO_ChatSystem_GetChannelInfo() end
function ZO_ChatSystem_GetEventCategoryMappings() end
function ZO_ChatSystem_GetTrialEventMappings() end
function ZO_ChatSystem_GetEventHandlers() end
function ZO_ChatEvent(eventId, ...) end
function ZO_ChatSystem_AddEventHandler(eventId, handler) end
function ShouldShowSocialErrorInChat(error) end
function ShouldShowGroupErrorInChat(error) end
function ChatOptions:New(...) end
function ChatOptions:Initialize(control) end
function ChatOptions:InitializeNameControl(control) end
function ChatOptions:UpdateTabName() end
function ChatOptions:UpdateGuildNames() end
function ChatOptions:GetCurrentTabIndex() end
function ChatOptions:GetCurrentContainer() end
function ChatOptions:Show(chatContainer, chatTabIndex) end
function ChatOptions:SetCurrentChannelSelections(container, chatTabIndex) end
function ChatOptions:ShowResetDialog() end
function ChatOptions:Reset() end
function ChatOptions:FadeOutCurrentContainer() end
function ChatOptions:Commit() end
function ZO_ChatOptions_OnInitialized(dialogControl) end
function ZO_ChatOptions_OnCommitClicked() end
function ZO_ChatOptions_OnResetClicked() end
function ZO_ChatOptions_ToggleChannel(buttonControl, checked) end
function GamepadChatContainer:New(...) end
function GamepadChatContainer:Initialize(control, windowPool, tabPool) end
function GamepadChatContainer:ShowRemoveTabDialog(index) end
function GamepadChatContainer:FadeOut(delay) end
function GamepadChatContainer:UpdateInteractivity(isInteractive) end
function GamepadChatContainer:FadeOutLines() end
function GamepadChatContainer:PerformLayout() end
function GamepadChatContainer:LoadSettings(settings) end
function GamepadChatContainer:AddEventMessageToWindow(...) end
function GamepadChatContainer:SetAsPrimary() end
function GamepadChatContainer:GetChatFont() end
function ZO_GamepadChatSystem:New(...) end
function ZO_GamepadChatSystem:Initialize(control) end
function ZO_GamepadChatSystem:LoadChatFromSettings() end
function ZO_GamepadChatSystem:InitializeSharedControlManagement(control) end
function ZO_GamepadChatSystem:IsWindowPinned() end
function ZO_GamepadChatSystem:SetWindowPinned(setPinned) end
function ZO_GamepadChatSystem:IsHUDEnabled() end
function ZO_GamepadChatSystem:SetHUDEnabled(setEnabled) end
function ZO_GamepadChatSystem:InitializeEventManagement() end
function ZO_GamepadChatSystem:StartTextEntry(text, channel, target, dontShowHUDWindow) end
function ZO_GamepadChatSystem:CloseTextEntry(keepText) end
function ZO_GamepadChatSystem:OnTextEntryFocusGained() end
function ZO_GamepadChatSystem:OnTextEntryChanged(newText) end
function ZO_GamepadChatSystem:ResetContainerPositionAndSize(container) end
function ZO_GamepadChatSystem:Maximize() end
function ZO_GamepadChatSystem:HideWhenDeactivated(fadeBgAlpha, fadeText, fadeTextAlpha) end
function ZO_GamepadChatSystem:Minimize() end
function ZO_GamepadChatSystem:HasFocus() end
function ZO_GamepadChatSystem:SetPinnedAndFaded(pinnedAndFaded) end
function ZO_GamepadChatSystem:FadeOutWindowContainers(minAlpha) end
function ZO_GamepadChatSystem:TryFadeOut() end
function ZO_GamepadChatSystem:TryFadeIn(forceFadeIn) end
function ZO_GamepadChatSystem:StartVisibilityTimer() end
function ZO_GamepadChatSystem:IsPinnable() end
function ZO_GamepadChatSystem:OnChatEvent(...) end
function ZO_GamepadChatSystem:GetFont() end
function ZO_GamepadChatSystem:GetFontSizeString(fontSize) end
function ZO_GamepadChatSystem:GetFontSizeFromSetting() end
function ZO_GamepadChatSystem:SetChannel(newChannel, channelTarget) end
function ZO_GamepadTextChat_OnInitialize(control) end
function ZO_ChatMenu_Gamepad:New(...) end
function ZO_ChatMenu_Gamepad:Initialize(control) end
function ZO_ChatMenu_Gamepad:InitializeFragment() end
function ZO_ChatMenu_Gamepad:InitializeControls() end
function ZO_ChatMenu_Gamepad:InitializeTextInputSection() end
function ZO_ChatMenu_Gamepad:InitializeChannelDropdown() end
function ZO_ChatMenu_Gamepad:InitializeTextEdit() end
function ZO_ChatMenu_Gamepad:InitializePassiveFocus() end
function ZO_ChatMenu_Gamepad:RegisterForEvents() end
function ZO_ChatMenu_Gamepad:InitializeFocusKeybinds() end
function ZO_ChatMenu_Gamepad:OnDeferredInitialize() end
function ZO_ChatMenu_Gamepad:PerformUpdate() end
function ZO_ChatMenu_Gamepad:OnShow() end
function ZO_ChatMenu_Gamepad:OnHiding() end
function ZO_ChatMenu_Gamepad:FocusTextInput() end
function ZO_ChatMenu_Gamepad:UpdateDirectionalInput() end
function ZO_ChatMenu_Gamepad:SetupLogMessage(control, data, selected, reselectingDuringRebuild, enabled, active) end
function ZO_ChatMenu_Gamepad:RefreshMoreBelow(targetSelectedIndex) end
function ZO_ChatMenu_Gamepad:RefreshChannelDropdown(reselectDuringRebuild) end
function ZO_ChatMenu_Gamepad:OnTargetChanged(list, targetData, oldTargetData, reachedTarget, targetSelectedIndex) end
function ZO_ChatMenu_Gamepad:RefreshTooltip(targetData) end
function ZO_ChatMenu_Gamepad:BuildChatList() end
function ZO_ChatMenu_Gamepad:SetupOptions(entryData) end
function ZO_ChatMenu_Gamepad:BuildOptionsList() end
function ZO_ChatMenu_Gamepad_OnInitialized(self) end
function ChatContainer:New(...) end
function ChatContainer:Initialize(control, windowPool, tabPool) end
function ChatContainer:UpdateInteractivity(isInteractive) end
function ChatContainer:PerformLayout(insertIndex, xOffset) end
function ChatContainer:UpdateNewWindowTab() end
function ChatContainer:ShowRemoveTabDialog(index) end
function ChatContainer:LoadSettings(settings) end
function ChatContainer:GetChatFont() end
function ZO_ChatSystem:New(...) end
function ZO_ChatSystem:Initialize(control) end
function ZO_ChatSystem:LoadChatFromSettings() end
function ZO_ChatSystem:SetupSavedVars(defaults) end
function ZO_ChatSystem:SaveLocalContainerSettings(container, containerControl) end
function ZO_ChatSystem:InitializeSharedControlManagement(control) end
function ZO_ChatSystem:TryNotificationAndMailBursts() end
function ZO_ChatSystem:ResetContainerPositionAndSize(container) end
function ZO_ChatSystem:RemoveSavedContainer(container) end
function ZO_ChatSystem:SetupNotifications(numNotifications) end
function ZO_ChatSystem:OnNumNotificationsChanged(numNotifications) end
function ZO_ChatSystem:OnNumUnreadMailChanged(numUnread) end
function ZO_ChatSystem:OnNumOnlineFriendsChanged(numOnline) end
function ZO_ChatSystem:ShowMinBar() end
function ZO_ChatSystem:HideMinBar() end
function ZO_ChatSystem:Minimize() end
function ZO_ChatSystem:Maximize() end
function ZO_ChatSystem:GetFont() end
function ZO_ChatSystem:GetFontSizeString(fontSize) end
function ZO_ChatSystem:GetFontSizeFromSetting() end
function ZO_ChatSystem_OnMinMaxClicked() end
function ZO_ChatSystem_OnInitialized(control) end
function GetChannelName(channelId) end
function ChannelTarget:New(...) end
function ChannelTarget:Initialize() end
function ChannelTarget:GetLastTarget() end
function ChannelTarget:AddTarget(target) end
function ChannelTarget:GetNextTarget() end
function ChannelTarget:GetPreviousTarget() end
function TextEntry:New(...) end
function TextEntry:Initialize(system, control, chatEditBufferTop, chatEditBufferBottom) end
function TextEntry:GetEditControl() end
function TextEntry:GetControl() end
function TextEntry:StartCommandAtIndex(index) end
function TextEntry:AutoCompleteTarget(target) end
function TextEntry:NextCommand() end
function TextEntry:PreviousCommand() end
function TextEntry:AddCommandHistory(text) end
function TextEntry:FadeOut(delay) end
function TextEntry:FadeIn() end
function TextEntry:Open(text) end
function TextEntry:Close(keepText) end
function TextEntry:IsOpen() end
function TextEntry:GetText() end
function TextEntry:SetText(text) end
function TextEntry:InsertText(text) end
function TextEntry:SetCursorPosition(pos) end
function TextEntry:GetCursorPosition(offset) end
function TextEntry:SetChannel(channelData, target) end
function TextEntry:SetColor(r, g, b) end
function TextEntry:InsertLink(link) end
function TextEntry:SetFont(font) end
function TextEntry:IsAutoCompleteOpen() end
function TextEntry:CloseAutoComplete() end
function SharedChatContainer:New(chatSystem, control, windowPool, tabPool) end
function SharedChatContainer:Initialize(control, windowPool, tabPool) end
function SharedChatContainer:ShowOverflowedTabsDropdown() end
function SharedChatContainer:LoadWindowSettings(window) end
function SharedChatContainer:SetTimestampsEnabled(tabIndex, areTimestampsEnabled) end
function SharedChatContainer:AreTimestampsEnabled(tabIndex) end
function SharedChatContainer:SetLocked(tabIndex, locked) end
function SharedChatContainer:IsLocked(tabIndex) end
function SharedChatContainer:AddFadeInReference() end
function SharedChatContainer:RemoveFadeInReference() end
function SharedChatContainer:SetBackgroundColor(r, g, b, minAlpha, maxAlpha) end
function SharedChatContainer:GetBackgroundColor() end
function SharedChatContainer:SetMinAlpha(minAlpha) end
function SharedChatContainer:GetMinAlpha() end
function SharedChatContainer:ResetMinAlphaToDefault() end
function SharedChatContainer:UpdateInteractivity(isInteractive) end
function SharedChatContainer:IsInteractive(tabIndex) end
function SharedChatContainer:ForceWindowIntoView(tabIndex) end
function SharedChatContainer:SetInteractivity(tabIndex, isInteractive) end
function SharedChatContainer:GetTabName(tabIndex) end
function SharedChatContainer:SetTabName(tabIndex, name) end
function SharedChatContainer:SetFontSize(tabIndex, fontSize) end
function SharedChatContainer:IsCombatLog(tabIndex) end
function SharedChatContainer:GetChatSystem() end
function SharedChatContainer:SetBufferColor(categoryId, red, green, blue) end
function SharedChatContainer:ResetToDefaults(tabIndex) end
function SharedChatContainer:ShowOptions(tabIndex) end
function SharedChatContainer:LoadSettings(settings) end
function SharedChatContainer:SetAllowSaveSettings(saveSettings) end
function SharedChatContainer:SaveWindowSettings(tabIndex) end
function SharedChatContainer:SaveSettings() end
function SharedChatContainer:ShowContextMenu(tabIndex) end
function SharedChatContainer:InitializeWindowManagement(control, windowPool, tabPool) end
function SharedChatContainer:OnDestroy() end
function SharedChatContainer:OnResizeStart() end
function SharedChatContainer:OnResizeStop() end
function SharedChatContainer:OnMoveStop() end
function SharedChatContainer:OnMouseEnter() end
function SharedChatContainer:IsMouseInside() end
function SharedChatContainer:MonitorForMouseExit() end
function SharedChatContainer:FadeOut(delay) end
function SharedChatContainer:FadeIn(delay, fadeOption) end
function SharedChatContainer:PerformLayout(insertIndex, xOffset) end
function SharedChatContainer:ApplyInsertIndicator(insertIndex) end
function SharedChatContainer:UpdateOverflowArrow() end
function SharedChatContainer:ShowRemoveTabDialog(index, dialogName) end
function SharedChatContainer:HandleTabClick(tab) end
function SharedChatContainer:AddRawTabForWindow(window, name, index, tab) end
function SharedChatContainer:TakeWindow(window, previousContainer) end
function SharedChatContainer:FinalizeWindowTransfer(window) end
function SharedChatContainer:AddRawWindow(window, name, tab, insertIndex, isCombatLog) end
function SharedChatContainer:RegisterCategoriesForWindow(tabIndex) end
function SharedChatContainer:UnregisterCategoriesForWindow(tabIndex) end
function SharedChatContainer:SetWindowFilterEnabled(tabIndex, category, enabled) end
function SharedChatContainer:IsScrolledUp() end
function SharedChatContainer:OnChatEvent(event, formattedEvent, category) end
function SharedChatContainer:AddMessageToWindow(window, message, r, g, b, category) end
function SharedChatContainer:AddEventMessageToWindow(window, message, category) end
function SharedChatContainer:AddDebugMessage(formattedEventText) end
function SharedChatContainer:AddWindow(name) end
function SharedChatContainer:AddCombatWindow(name) end
function SharedChatContainer:SetAsPrimary() end
function SharedChatContainer:IsPrimary() end
function SharedChatContainer:UpdateTabIndices(from) end
function SharedChatContainer:RemoveWindow(index, freeOption) end
function SharedChatContainer:TransferWindow(index, targetContainer) end
function SharedChatContainer:StartDraggingTab(index) end
function SharedChatContainer:PrepareTabDrop(controlToMonitor) end
function SharedChatContainer:StopTabDrop() end
function SharedChatContainer:CanTakeTabDrop() end
function SharedChatContainer:StopDraggingTab() end
function SharedChatContainer:InitializeScrolling(control) end
function SharedChatContainer:SetScroll(value) end
function SharedChatContainer:ScrollByOffset(offset) end
function SharedChatContainer:ScrollToBottom() end
function SharedChatContainer:GetCurrentMaxScroll() end
function SharedChatContainer:UpdateScrollVisibility() end
function SharedChatContainer:SyncScrollToBuffer() end
function SharedChatContainer:UpdateScrollButtons() end
function SharedChatContainer:GetChatFontFormatString(fontSize) end
function SharedChatContainer:GetChatFont() end
function SharedChatSystem:New(...) end
function SharedChatSystem:Initialize(control, platformSettings) end
function SharedChatSystem:CreateChannelData() end
function SharedChatSystem:InitializeSharedControlManagement(control, newContainerFn) end
function SharedChatSystem:InitializeEventManagement() end
function SharedChatSystem:TryNotificationAndMailBursts() end
function SharedChatSystem:LoadChatFromSettings(newContainerFn, defaults) end
function SharedChatSystem:SetupSavedVars(defaults) end
function SharedChatSystem:RedockContainersToPrimary() end
function SharedChatSystem:CanSaveSettings() end
function SharedChatSystem:SaveLocalContainerSettings(container, containerControl) end
function SharedChatSystem:AcquireInsertIndicator(container) end
function SharedChatSystem:ReleaseInsertIndicator(container) end
function SharedChatSystem:RegisterForCategory(container, category) end
function SharedChatSystem:StartNewChatNotification() end
function SharedChatSystem:UnregisterFromCategory(container, category) end
function SharedChatSystem:HandleNewTargetOnChannel(event, targetChannel, _, target) end
function SharedChatSystem:GetCategoryFromEvent(event, messageType) end
function SharedChatSystem:OnChatEvent(event, ...) end
function SharedChatSystem:UpdateContainerIndices(start) end
function SharedChatSystem:DestroyContainer(container) end
function SharedChatSystem:RemoveSavedContainer(container) end
function SharedChatSystem:TransferWindow(window, previousContainer, targetContainer) end
function SharedChatSystem:OnRawWindowCreated(container, name, isCombatLog) end
function SharedChatSystem:OnRawWindowDestroyed(container, tabIndex) end
function SharedChatSystem:AddCombatLog(name) end
function SharedChatSystem:SetCombatLogObject(combatLogObject) end
function SharedChatSystem:PrepareContainersTabDrop(initiator, controlToMonitor) end
function SharedChatSystem:StopContainersTabDrop(initiator) end
function SharedChatSystem:SetAllowMultipleContainers(allow) end
function SharedChatSystem:MultipleContainersAllowed() end
function SharedChatSystem:CreateChatContainer(container) end
function SharedChatSystem:ResetContainerPositionAndSize(container) end
function SharedChatSystem:HandleTryInsertLink(link) end
function SharedChatSystem:AddMessage(text) end
function SharedChatSystem:IsTextEntryOpen() end
function SharedChatSystem:ValidateChatChannel() end
function SharedChatSystem:SubmitTextEntry() end
function SharedChatSystem:CloseTextEntry(keepText) end
function SharedChatSystem:OnAutoCompleteEntrySelected(target) end
function SharedChatSystem:ValidateTargetName(name) end
function SharedChatSystem:ValidateSwitch(switch, text, firstSpaceStart) end
function SharedChatSystem:OnTextEntryChanged(newText) end
function SharedChatSystem:FindNextTargetForCurrentChannel() end
function SharedChatSystem:FindPreviousTargetForCurrentChannel() end
function SharedChatSystem:StartTextEntry(text, channel, target, dontShowHUDWindow) end
function SharedChatSystem:AutoSendTextEntry(text, channel, target, dontShowHUDWindow) end
function SharedChatSystem:ReplyToLastTarget(channelType) end
function SharedChatSystem:GetCategoryColorFromChannel(channel) end
function SharedChatSystem:SetChannel(newChannel, channelTarget) end
function SharedChatSystem:GetCurrentChannelData() end
function SharedChatSystem:SetContainerExtents(minWidth, maxWidth, minHeight, maxHeight) end
function SharedChatSystem:UpdateTextEntryChannel() end
function SharedChatSystem:AddCommandPrefix(prefixCharacter, callback) end
function SharedChatSystem:ShowPlayerContextMenu(playerName, rawName) end
function SharedChatSystem:OnLinkClicked(link, button, text, color, linkType, ...) end
function SharedChatSystem:CreateNewChatTab(container) end
function SharedChatSystem:SetTextEntryFont(font) end
function SharedChatSystem:SetChannelCategoryColor(categoryId, red, green, blue) end
function SharedChatSystem:ResetAllColorsToDefault() end
function SharedChatSystem:ResetChannelCategoryToDefault(categoryId) end
function SharedChatSystem:SetFontSize(fontSize) end
function SharedChatSystem:ResetFontSizeToDefault() end
function SharedChatSystem:SetMinAlpha(minAlpha) end
function SharedChatSystem:GetMinAlpha() end
function SharedChatSystem:ResetMinAlphaToDefault() end
function SharedChatSystem:ShowTextEntryMenu() end
function SharedChatSystem:IsAutoCompleteOpen() end
function SharedChatSystem:CloseAutoComplete() end
function SharedChatSystem:GetEditControl() end
function SharedChatSystem:OnNumNotificationsChanged(numNotifications) end
function SharedChatSystem:HasUnreadMail() end
function SharedChatSystem:OnNumUnreadMailChanged(numUnread) end
function SharedChatSystem:OnAgentChatActiveChanged() end
function SharedChatSystem:GetTextEntryFontString(fontSize) end
function SharedChatSystem:OnNumOnlineFriendsChanged() end
function SharedChatSystem:Minimize() end
function SharedChatSystem:Maximize() end
function SharedChatSystem:IsMinimized() end
function SharedChatSystem:IsPinnable() end
function SharedChatSystem:SetupFonts() end
function SharedChatSystem:GetFont() end
function SharedChatSystem:GetFontSizeString() end
function SharedChatSystem:GetFontSizeFromSetting() end
function StartChatInput(text, channel, target) end
function AutoSendChatInput(text, channel, target, dontShowHUDWindow) end
function ChatReplyToLastWhisper() end
function ZO_ChatSystem_OnMouseWheel(control, delta, ctrl, alt, shift) end
function ZO_ChatSystem_SetScroll(control, value) end
function ZO_ChatSystem_ScrollByOffset(control, offset) end
function ZO_ChatSystem_ScrollToBottom(control) end
function ZO_ChatSystem_OnDragStart(control) end
function ZO_ChatSystem_OnDragStop(control) end
function ZO_ChatSystem_OnResizeStart(control) end
function ZO_ChatSystem_OnResizeStop(control) end
function ZO_ChatSystem_OnMoveStop(control) end
function ZO_ChatSystem_OnMouseEnter(control) end
function ZO_ChatSystem_ShowOptions(control) end
function ZO_ChatSystem_OnFriendsEnter(control) end
function ZO_ChatSystem_OnFriendsExit(control) end
function ZO_ChatSystem_OnFriendsClicked(control) end
function ZO_ChatSystem_OnMailEnter(control) end
function ZO_ChatSystem_OnMailExit(control) end
function ZO_ChatSystem_OnMailClicked(control) end
function ZO_ChatSystem_OnAgentChatEnter(control) end
function ZO_ChatSystem_OnAgentChatExit(control) end
function ZO_ChatSystem_OnAgentChatClicked() end
function ZO_ChatSystem_OnNotificationsClicked(control) end
function ZO_ChatSystem_OnNotificationsEnter(control) end
function ZO_ChatSystem_OnNotificationsExit(control) end
function ZO_ChatWindow_OpenContextMenu(control) end
function ZO_ChatTextEntry_PreviousCommand(control) end
function ZO_ChatTextEntry_NextCommand(control) end
function ZO_ChatTextEntry_TextChanged(control, newText) end
function ZO_ChatTextEntry_Tab(control) end
function ZO_ChatTextEntry_Escape(control) end
function ZO_ChatTextEntry_FocusLost(control) end
function ZO_ChatTextEntry_Execute(control) end
function ZO_ChannelLabel_MouseUp(control) end
--ingame\collections
function CollectionsBook_Singleton:New(...) end
function CollectionsBook_Singleton:Initialize() end
function CollectionsBook_Singleton:BrowseToCollectible(...) end
function CollectionsBook_Singleton:RefreshDLCStateById(collectibleId) end
function CollectionsBook_Singleton:RefreshDLCStates() end
function CollectionsBook_Singleton:OnCollectibleUpdated(collectibleId, justUnlocked) end
function CollectionsBook_Singleton:OnCollectionUpdated(...) end
function CollectionsBook_Singleton:OnCollectiblesUpdated(...) end
function CollectionsBook_Singleton:OnCollectionNotificationRemoved(...) end
function CollectionsBook_Singleton:OnCollectibleNewStatusRemoved(...) end
function CollectionsBook_Singleton:OnUpdateCooldowns(...) end
function CollectionsBook_Singleton:IsCategoryIndexDLC(categoryIndex) end
function CollectionsBook_Singleton:IsDLCIdQuestPending(dlcId) end
function CollectionsBook_Singleton:DoesAnyDLCHaveQuestPending() end
function CollectionsBook_Singleton.DoesCollectibleListHaveVisibleCollectible(...) end
function CollectionsBook_Singleton.DoesCollectibleListHaveNewCollectible(...) end
function CollectionsBook_Singleton.GetCategoryCollectibleIds(categoryIndex, subCategoryIndex, index, ...) end
function CollectionsBook_Singleton.DoesCategoryHaveAnyNewCollectibles(categoryIndex, subcategoryIndex, getCollectiblesFunction) end
function ZO_GetCollectibleCategoryAndName(collectibleId) end
function ZO_CollectionsInventorySingleton:New() end
function ZO_CollectionsInventorySingleton:Initialize() end
function ZO_CollectionsInventorySingleton:RegisterForEvents() end
function ZO_CollectionsInventorySingleton:BuildQuickslotData() end
function ZO_CollectionsInventorySingleton:GetQuickslotData() end
function ZO_CollectionsInventorySingleton:GetCollectibleInventoryDisplayName(data) end
function ZO_GamepadCollectionsBook:New(...) end
function ZO_GamepadCollectionsBook:Initialize(control) end
function ZO_GamepadCollectionsBook:InitializeInfoPanel() end
function ZO_GamepadCollectionsBook:SetupList(list) end
function ZO_GamepadCollectionsBook:OnShowing() end
function ZO_GamepadCollectionsBook:OnHide() end
function ZO_GamepadCollectionsBook:RefreshHeader() end
function ZO_GamepadCollectionsBook:InitializeKeybindStripDescriptors() end
function ZO_GamepadCollectionsBook:ViewCategory(categoryIndex) end
function ZO_GamepadCollectionsBook:ViewSubcategory(categoryIndex, subcategoryIndex) end
function ZO_GamepadCollectionsBook:SelectCollectibleEntry(collectibleId) end
function ZO_GamepadCollectionsBook:PerformUpdate() end
function ZO_GamepadCollectionsBook:ShowList(list, dontUpdateTitle) end
function ZO_GamepadCollectionsBook:HideCurrentList() end
function ZO_GamepadCollectionsBook:OnCollectionUpdated() end
function ZO_GamepadCollectionsBook:OnCollectibleUpdated(collectibleId) end
function ZO_GamepadCollectionsBook:OnCollectibleStatusUpdated() end
function ZO_GamepadCollectionsBook:OnCollectionNotificationRemoved(notificationId, collectibleId) end
function ZO_GamepadCollectionsBook:OnCollectionNewStatusRemoved(collectibleId) end
function ZO_GamepadCollectionsBook:BuildCategoryList() end
function ZO_GamepadCollectionsBook:GetCollectibleIds(categoryIndex, subCategoryIndex, index, ...) end
function ZO_GamepadCollectionsBook:BuildSubcategoryList(categoryIndex) end
function ZO_GamepadCollectionsBook:BuildCollectionList(categoryIndex, subcategoryIndex) end
function ZO_GamepadCollectionsBook:UpdateCollectionListVisualLayer() end
function ZO_GamepadCollectionsBook:BuildCollectibleData(categoryIndex, subCategoryIndex, collectibleIndex) end
function ZO_GamepadCollectionsBook:BuildListFromTable(list, dataTable, header) end
function ZO_GamepadCollectionsBook:OnSelectionChanged(list, selectedData, oldSelectedData) end
function ZO_GamepadCollectionsBook:TrySetClearNewFlag(callId) end
function ZO_GamepadCollectionsBook:RefreshTooltip(entryData) end
function ZO_GamepadCollectionsBook:BrowseToCollectible(collectibleId, categoryIndex, subcategoryIndex) end
function ZO_GamepadCollectionsBook:InitializeActionsDialog() end
function ZO_GamepadCollectionsBook:InitializeRenameCollectibleDialog() end
function ZO_GamepadCollectionsBook:HasAnyNotifications(optionalCategoryIndexFilter, optionalSubcategoryIndexFilter) end
function ZO_GamepadCollectionsBook:DoesCategoryHaveAnyNewCollectibles(categoryIndex, subcategoryIndex) end
function ZO_GamepadCollectionsBook:HasAnyNewCollectibles() end
function ZO_GamepadCollectionsBook:GetNotificationIdForCollectible(collectibleId) end
function ZO_GamepadCollectionsBook:OnUpdateCooldowns() end
function ZO_GamepadCollectionsBook:UpdateActiveCollectibleCooldownTimer() end
function ZO_GamepadCollectionsBook_OnInitialize(control) end
function Collectible:New(...) end
function Collectible:Initialize(collectibleId) end
function Collectible:RefreshInfo() end
function Collectible:Show(control) end
function Collectible:RefreshVisualLayer() end
function Collectible:RefreshMultiIcon() end
function Collectible:GetId() end
function Collectible:GetCollectibleInfo() end
function Collectible:GetControl() end
function Collectible:SetHighlightHidden(hidden, dontAnimate) end
function Collectible:GetInteractionTextEnum() end
function Collectible:ShowCollectibleMenu() end
function Collectible:ShowKeybinds() end
function Collectible:HideKeybinds() end
function Collectible:OnMouseExit() end
function Collectible:RefreshMouseoverVisuals(dontAnimate) end
function Collectible:IsCurrentMouseTarget() end
function Collectible:OnClicked(button) end
function Collectible:OnMouseDoubleClick(button) end
function Collectible:OnEffectivelyHidden() end
function Collectible:OnUpdate() end
function Collectible:OnUpdateCooldowns() end
function Collectible:BeginCooldown() end
function Collectible:EndCooldown() end
function Collectible:UpdateCooldownEffect() end
function Collectible:SetBlockedState(isBlocked) end
function CollectionsBook:New(...) end
function CollectionsBook:InitializeControls() end
function CollectionsBook:InitializeEvents() end
function CollectionsBook:InitializeCategoryTemplates() end
function CollectionsBook:InitializeChildIndentAndSpacing() end
function CollectionsBook:InitializeStickerGrid(control) end
function CollectionsBook:HideSummary() end
function CollectionsBook:GetNumCategories() end
function CollectionsBook:GetCategoryInfo(categoryIndex) end
function CollectionsBook:GetCategoryIcons(categoryIndex) end
function CollectionsBook:GetSubCategoryInfo(categoryIndex, i) end
function CollectionsBook:BuildCategories() end
function CollectionsBook:AddTopLevelCategory(categoryIndex, name, numSubCategories, hidesUnearned, normalIcon, pressedIcon, mouseoverIcon) end
function CollectionsBook:UpdateCategoryStatus(categoryNode) end
function CollectionsBook:UpdateAllCategoryStatusIcons() end
function CollectionsBook:UpdateCategoryStatusIcon(categoryNode) end
function CollectionsBook:UpdateAllCategoryStatuses() end
function CollectionsBook:UpdateCategoryLabels(data, retainScrollPosition) end
function CollectionsBook:OnCollectionUpdated() end
function CollectionsBook:UpdateCollectionLater() end
function CollectionsBook:UpdateCollection() end
function CollectionsBook:OnCollectibleUpdated(collectibleId) end
function CollectionsBook:UpdateCollectible(collectibleId) end
function CollectionsBook:OnCollectibleStatusUpdated(collectibleId) end
function CollectionsBook:OnCollectionNotificationRemoved(notificationId, collectibleId) end
function CollectionsBook:OnCollectionNewStatusRemoved(collectibleId) end
function CollectionsBook:BrowseToCollectible(collectibleId, categoryIndex, subcategoryIndex) end
function CollectionsBook:UpdateCollectionVisualLayer() end
function CollectionsBook:SearchStart(searchString) end
function CollectionsBook:HasAnyNotifications(optionalCategoryIndexFilter, optionalSubcategoryIndexFilter) end
function CollectionsBook:DoesCategoryHaveAnyNewCollectibles(categoryIndex, subcategoryIndex) end
function CollectionsBook:HasAnyNewCollectibles() end
function CollectionsBook:GetNotificationIdForCollectible(collectibleId) end
function ZO_CollectionsBook_OnInitialize(control) end
function ZO_CollectionsBook_BeginSearch(editBox) end
function ZO_CollectionsBook_EndSearch(editBox) end
function ZO_CollectionsBook_OnSearchTextChanged(editBox) end
function ZO_CollectionsBook_OnSearchEnterKeyPressed(editBox) end
function DLCBook_Keyboard:New(...) end
function DLCBook_Keyboard:Initialize(control) end
function DLCBook_Keyboard:InitializeControls() end
function DLCBook_Keyboard:InitializeNavigationList() end
function DLCBook_Keyboard:RefreshListIfDirty() end
function DLCBook_Keyboard:InitializeEvents() end
function DLCBook_Keyboard:GetSelectedDLCData() end
function DLCBook_Keyboard:FocusDLCWithCollectibleId(id) end
function DLCBook_Keyboard:RefreshList() end
function DLCBook_Keyboard:RefreshDetails() end
function DLCBook_Keyboard:UseSelectedDLC() end
function DLCBook_Keyboard:SearchSelectedDLCInStore() end
function DLCBook_Keyboard:BrowseToCollectible(collectibleId) end
function DLCBook_Keyboard:OnCollectibleUpdated(collectibleId, justUnlocked) end
function DLCBook_Keyboard:OnCollectionNotificationRemoved(notificationId, collectibleId) end
function DLCBook_Keyboard:OnCollectionUpdated() end
function ZO_DLCBook_Keyboard_OnQuestAcceptClicked(control) end
function ZO_DLCBook_Keyboard_OnUnlockPermanentlyClicked(control) end
function ZO_DLCBook_Keyboard_OnSubscribeClicked(control) end
function ZO_DLCBook_Keyboard_OnInitialize(control) end
--ingame\compass
function Compass:New(...) end
function Compass:Initialize(control) end
function Compass:InitializeCenterOveredPins() end
function Compass:InitializePoiPins() end
function Compass:ApplyTemplateToAreaTexture(texture, template, restingAlpha, pinType) end
function Compass:SetAreaTexturePlatformTextures(areaTexture, pinType) end
function Compass:InitializeQuestPins() end
function Compass:SetCardinalDirections(font) end
function Compass:ApplyKeyboardStyle() end
function Compass:ApplyGamepadStyle() end
function Compass:OnGamepadPreferredModeChanged() end
function Compass:PerformFullAreaQuestUpdate() end
function Compass:UpdateInsidePoiState() end
function Compass:IsInsidePoi() end
function Compass:OnZoneChanged() end
function Compass:TryPlayingAnimationOnSinglePoi(zoneIndex, poiIndex, pinType) end
function Compass:PlayPoiPinOutAnimation() end
function Compass:TryPlayingAnimationOnAreaPin(journalIndex, stepIndex, conditionIndex, pinType) end
function Compass:PlayAreaOverrideAnimation(journalIndex, stepIndex, conditionIndex) end
function Compass:PlayAreaPinOutAnimation(journalIndex, stepIndex, conditionIndex) end
function Compass:StopAreaPinOutAnimation(journalIndex, stepIndex, conditionIndex) end
function ZO_Compass_OnInitialize(control) end
function ZO_CompassPoiPinAnimationOutUpdate(animation, progress, control) end
function CompassFrame:New(...) end
function CompassFrame:Initialize(control) end
function CompassFrame:ApplyStyle() end
function CompassFrame:OnGamepadPreferredModeChanged() end
function CompassFrame:UpdateWidth() end
function CompassFrame:RefreshVisible() end
function CompassFrame:SetBossBarHiddenForReason(reason, hidden) end
function CompassFrame:SetBossBarActive(active) end
function CompassFrame:SetCompassHidden(hidden) end
function CompassFrame:SetBossBarReady(ready) end
function CompassFrame:SetCompassReady(ready) end
function CompassFrame:OnPlayerActivated() end
function ZO_CompassFrame_OnInitialized(self) end
--ingame\console
function ZO_ShowGamerCardFromCharacterName(characterName) end
function ZO_ShowGamerCardFromDisplayName(displayName) end
function ZO_ShowGamerCardFromDisplayNameOrFallback(displayName, idRequestType, ...) end
function ZO_ShowConsoleAddFriendDialog(characterName) end
function ZO_ShowConsoleAddFriendDialogFromDisplayName(displayName) end
function ZO_ShowConsoleAddFriendDialogFromDisplayNameOrFallback(displayName, idRequestType, ...) end
function ZO_ShowConsoleIgnoreDialog(displayName) end
function ZO_ShowConsoleIgnoreDialogFromDisplayNameOrFallback(displayName, idRequestType, ...) end
function ZO_ShowConsoleAddFriendDialogFromUserListSelector() end
function ZO_DoesConsoleSupportTargetedIgnore() end
function ZO_ShowConsoleInviteToGroupFromUserListSelector() end
function ZO_ShowConsoleInviteToGuildFromUserListSelector(guildId) end
function ZO_ConsoleAttemptInteractOrError(callback, displayName, block, errorType, idRequestType, ...) end
function ZO_ConsoleAttemptCommunicateOrError(callback, displayName, block, errorType, idRequestType, ...) end
--ingame\contacts
function PlayerStatusManager:New(control) end
function PlayerStatusManager:Initialize() end
function PlayerStatusManager:SetSelectedStatus(status) end
function PlayerStatusManager:OnPlayerStatusChanged(oldStatus, newStatus) end
function PlayerStatusManager:Status_OnMouseEnter(control) end
function PlayerStatusManager:Status_OnMouseExit() end
function ZO_PlayerStatus_OnMouseEnter(control) end
function ZO_PlayerStatus_OnMouseExit(control) end
function ZO_DisplayName_OnInitialized(self) end
function ZO_FriendsList:New() end
function ZO_FriendsList:Initialize() end
function ZO_FriendsList:GetNumOnline() end
function ZO_FriendsList:SetupEntry(control, data, selected) end
function ZO_FriendsList:CreateFriendData(friendIndex, displayName, note, status) end
function ZO_FriendsList:UpdateFriendData(data, friendIndex) end
function ZO_FriendsList:BuildMasterList() end
function ZO_FriendsList:FindDataByDisplayName(displayName) end
function ZO_FriendsList:GetNoteEditedFunction() end
function ZO_FriendsList:OnSocialDataLoaded() end
function ZO_FriendsList:OnFriendAdded(displayName) end
function ZO_FriendsList:OnFriendRemoved(displayName) end
function ZO_FriendsList:OnFriendNoteUpdated(displayName, note) end
function ZO_FriendsList:OnFriendCharacterUpdated(displayName) end
function ZO_FriendsList:OnFriendDisplayNameChanged(oldDisplayName, newDisplayName) end
function ZO_FriendsList:OnFriendCharacterZoneChanged(displayName, characterName, zoneName) end
function ZO_FriendsList:OnFriendCharacterLevelChanged(displayName, characterName, level) end
function ZO_FriendsList:OnFriendCharacterChampionPointsChanged(displayName, characterName, championPoints) end
function ZO_FriendsList:OnFriendPlayerStatusChanged(displayName, characterName, oldStatus, newStatus) end
function ZO_FriendsList:OnNumTotalFriendsChanged() end
function ZO_FriendsList:OnNumOnlineChanged() end
function FriendsOnlineManager:New(control) end
function FriendsOnlineManager:Update() end
function ZO_FriendsOnline_OnInitialized(self) end
function ZO_GamepadContactsManager:New(...) end
function ZO_GamepadContactsManager:Initialize(control) end
function ZO_GamepadContactsManager:PerformDeferredInitialization() end
function ZO_GamepadContactsManager:UpdateOnline() end
function ZO_GamepadContactsManager:RefreshFooter() end
function ZO_GamepadContacts_OnInitialized(self) end
function FriendsList_Gamepad:New(...) end
function FriendsList_Gamepad:Initialize(control) end
function FriendsList_Gamepad:GetAddKeybind() end
function FriendsList_Gamepad:LayoutTooltip(tooltipManager, tooltip, data) end
function FriendsList_Gamepad:OnNumOnlineChanged() end
function FriendsList_Gamepad:OnNumTotalFriendsChanged() end
function FriendsList_Gamepad:OnShowing() end
function FriendsList_Gamepad:CommitScrollList() end
function FriendsList_Gamepad:OnHidden() end
function FriendsList_Gamepad:BuildOptionsList() end
function ZO_FriendsList_Gamepad_OnInitialized(self) end
function IgnoreList_Gamepad:New(...) end
function IgnoreList_Gamepad:Initialize(control) end
function IgnoreList_Gamepad:GetAddKeybind() end
function IgnoreList_Gamepad:OnShowing() end
function IgnoreList_Gamepad:BuildOptionsList() end
function IgnoreList_Gamepad:RefreshTooltip() end
function ZO_IgnoreList_Gamepad_OnInitialized(self) end
function ZO_GamepadFriendRequestProvider:New(notificationManager) end
function ZO_GamepadFriendRequestProvider:Decline(data, button, openedFromKeybind) end
function ZO_GamepadFriendRequestProvider:CanShowGamerCard() end
function ZO_GamepadFriendRequestProvider:ShowGamerCard(data) end
function ZO_GamepadGuildInviteProvider:New(notificationManager) end
function ZO_GamepadGuildInviteProvider:CreateMessage(guildAlliance, guildName, inviterDisplayName) end
function ZO_GamepadGuildInviteProvider:Decline(data, button, openedFromKeybind) end
function ZO_GamepadGuildInviteProvider:CanShowGamerCard() end
function ZO_GamepadGuildInviteProvider:ShowGamerCard(data) end
function ZO_GamepadGuildMotDProvider:New(notificationManager) end
function ZO_GamepadGuildMotDProvider:CreateMessage(guildAlliance, guildName) end
function ZO_GamepadCampaignQueueProvider:New(notificationManager) end
function ZO_GamepadCampaignQueueProvider:Accept(data) end
function ZO_GamepadResurrectProvider:New(notificationManager) end
function ZO_GamepadGroupInviteProvider:New(notificationManager) end
function ZO_GamepadTradeInviteProvider:New(notificationManager) end
function ZO_GamepadQuestShareProvider:New(notificationManager) end
function ZO_GamepadPledgeOfMaraProvider:New(notificationManager) end
function ZO_GamepadAgentChatRequestProvider:New(notificationManager) end
function ZO_AgentChatRequestProvider:CreateMessage() end
function ZO_GamepadLeaderboardRaidProvider:New(notificationManager) end
function ZO_GamepadLeaderboardRaidProvider:CreateMessage(raidName, raidScore, numMembers, hasFriend, hasGuildMember, notificationId) end
function ZO_GamepadLeaderboardRaidProvider:AppendRaidMemberHeaderText(messageText, headerText) end
function ZO_GamepadLeaderboardRaidProvider:AppendRaidMemberName(messageText, raidMemberName) end
function ZO_GamepadLeaderboardRaidProvider:AppendRaidMembers(messageText, numMembers, notificationId) end
function ZO_GamepadCollectionsUpdateProvider:New(notificationManager) end
function ZO_GamepadCollectionsUpdateProvider:Accept(entryData) end
function ZO_GamepadCollectionsUpdateProvider:GetMessage(hasMoreInfo, categoryName, collectibleName) end
function ZO_GamepadCollectionsUpdateProvider:ShowMoreInfo(data) end
function ZO_GamepadLFGUpdateProvider:New(notificationManager) end
function ZO_GamepadNotificationManager:New(control) end
function ZO_GamepadNotificationManager:Initialize(control) end
function ZO_GamepadNotificationManager:OnShowing() end
function ZO_GamepadNotificationManager:PerformUpdate() end
function ZO_GamepadNotificationManager:SetupList(list) end
function ZO_GamepadNotificationManager:InitializeNotificationList(control) end
function ZO_GamepadNotificationManager:InitializeKeybindStripDescriptors() end
function ZO_GamepadNotificationManager:RefreshTooltip(entryData) end
function ZO_GamepadNotificationManager:InitializeHeader() end
function ZO_GamepadNotificationManager:InitializeConfirmDeclineDialog() end
function ZO_GamepadNotificationManager:ClearNotificationList() end
function ZO_GamepadNotificationManager:RefreshVisible() end
function ZO_GamepadNotificationManager:AddDataEntry(dataType, data, isHeader) end
function ZO_GamepadNotificationManager:GetTargetData() end
function ZO_GamepadNotificationManager:FinishNotificationList() end
function ZO_GamepadNotificationManager:BuildEmptyList() end
function ZO_GamepadNotificationManager:OnSelectionChanged(_, selected) end
function ZO_GamepadNotificationManager:OnNumNotificationsChanged(totalNumNotifications) end
function ZO_GamepadNotificationManager:SetupRequest(control, entryData, selected) end
function ZO_GamepadNotificationManager:SetupAlert(control, entryData, selected) end
function ZO_GamepadNotificationManager:SetupWaiting(control, entryData, selected) end
function ZO_GamepadNotificationManager:SetupBaseRow(control, data, selected) end
function ZO_GamepadNotifications_OnInitialized(self) end
function ZO_GamepadSocialDialogs:New() end
function ZO_GamepadSocialDialogs:InitializeSocialOptionsDialog() end
function ZO_GamepadSocialDialogs:InitializeEditNoteDialog() end
function ZO_GamepadSocialDialogs:InitializeAddFriendDialog() end
function ZO_GamepadSocialDialogs:InitializeAddIgnoreDialog() end
function ZO_GamepadSocialDialogs:InitializeInviteMemberDialog() end
function ZO_GamepadSocialDialogs:InitializeGroupInviteDialog() end
function ZO_GamepadSocialDialogs:InitializeReportPlayerDialog() end
function ZO_GamepadSocialListPanel:New(...) end
function ZO_GamepadSocialListPanel:Initialize(control, socialManager, rowTemplate) end
function ZO_GamepadSocialListPanel:InitializeSearchFilter() end
function ZO_GamepadSocialListPanel:Deactivate() end
function ZO_GamepadSocialListPanel:ClearTooltip() end
function ZO_GamepadSocialListPanel:RefreshTooltip() end
function ZO_GamepadSocialListPanel:LayoutTooltip(tooltipManager, tooltip, data) end
function ZO_GamepadSocialListPanel:EntrySelectionCallback(oldData, newData) end
function ZO_GamepadSocialListPanel:SetupRow(control, data) end
function ZO_GamepadSocialListPanel:ColorRow(control, data, selected) end
function ZO_GamepadSocialListPanel:GetRowColors(data, selected) end
function ZO_GamepadSocialListPanel:InitializeKeybinds() end
function ZO_GamepadSocialListPanel:InitializeDropdownFilter() end
function ZO_GamepadSocialListPanel:GetAddKeybind() end
function ZO_GamepadSocialListPanel:FilterScrollList() end
function ZO_GamepadSocialListPanel:OnFilterDeactivated() end
function ZO_GamepadSocialListPanel:OnShowing() end
function ZO_GamepadSocialListPanel:OnHidden() end
function ZO_GamepadSocialListPanel:ForceStatusUpdate() end
function ZO_GamepadSocialListPanel:UpdateStatusDropdownSelection(status) end
function ZO_GamepadSocialListPanel:BuildGuildInviteOption(header, guildId) end
function ZO_GamepadSocialListPanel:AddInviteToGuildOptionTemplates() end
function ZO_SocialOptionsDialogGamepad:Initialize() end
function ZO_SocialOptionsDialogGamepad:ShowOptionsDialog() end
function ZO_SocialOptionsDialogGamepad:BuildOptionsList() end
function ZO_SocialOptionsDialogGamepad:AddOptionTemplateGroup(headerFunction) end
function ZO_SocialOptionsDialogGamepad:AddOptionTemplate(groupId, buildFunction, conditionFunction) end
function ZO_SocialOptionsDialogGamepad:PopulateOptionsList(list) end
function ZO_SocialOptionsDialogGamepad:CheckCondition(conditionFunction) end
function ZO_SocialOptionsDialogGamepad:HasAnyShownOptions() end
function ZO_SocialOptionsDialogGamepad:BuildOptionEntry(header, label, callback, finishedCallback, icon) end
function ZO_SocialOptionsDialogGamepad:AddOption(list, option) end
function ZO_SocialOptionsDialogGamepad:SetupOptions(socialData) end
function ZO_SocialOptionsDialogGamepad:AddSocialOptionsKeybind(descriptor, callback, keybind, name, sound, enabledCallback) end
function ZO_SocialOptionsDialogGamepad:SelectedDataIsPlayer() end
function ZO_SocialOptionsDialogGamepad:SelectedDataIsNotPlayer() end
function ZO_SocialOptionsDialogGamepad:SelectedDataIsLoggedIn() end
function ZO_SocialOptionsDialogGamepad:GetDefaultHeader() end
function ZO_SocialOptionsDialogGamepad:BuildEditNoteOption() end
function ZO_SocialOptionsDialogGamepad:BuildSendMailOption() end
function ZO_SocialOptionsDialogGamepad:ShouldAddWhisperOption() end
function ZO_SocialOptionsDialogGamepad:BuildWhisperOption() end
function ZO_SocialOptionsDialogGamepad:ShouldAddInviteToGroupOption() end
function ZO_SocialOptionsDialogGamepad:GetInviteToGroupCallback() end
function ZO_SocialOptionsDialogGamepad:BuildInviteToGroupOption() end
function ZO_SocialOptionsDialogGamepad:BuildTravelToPlayerOption(jumpFunc) end
function ZO_SocialOptionsDialogGamepad:BuildGamerCardOption() end
function ZO_SocialOptionsDialogGamepad:BuildInviteToGameOption() end
function ZO_SocialOptionsDialogGamepad:BuildIgnoreOption() end
function ZO_SocialOptionsDialogGamepad:ShouldAddRemoveFriendOption() end
function ZO_SocialOptionsDialogGamepad:BuildRemoveFriendOption() end
function ZO_SocialOptionsDialogGamepad:BuildRemoveIgnoreOption() end
function ZO_SocialOptionsDialogGamepad:ShouldAddFriendOption() end
function ZO_SocialOptionsDialogGamepad:BuildAddFriendOption() end
function ZO_IgnoreList:New() end
function ZO_IgnoreList:Initialize() end
function ZO_IgnoreList:SetupEntry(control, data, selected) end
function ZO_IgnoreList:BuildMasterList() end
function ZO_IgnoreList:GetNoteEditedFunction() end
function ZO_IgnoreList:OnSocialDataLoaded() end
function ZO_IgnoreList:OnIgnoreAdded(displayName) end
function ZO_IgnoreList:OnIgnoreRemoved(displayName) end
function ZO_IgnoreList:OnIgnoreNoteUpdated(displayName, note) end
function ZO_KeyboardFriendsListManager:New(...) end
function ZO_KeyboardFriendsListManager:Initialize(control) end
function ZO_KeyboardFriendsListManager:PerformDeferredInitialization() end
function ZO_KeyboardFriendsListManager:InitializeKeybindDescriptors() end
function ZO_KeyboardFriendsListManager:OnEffectivelyHidden() end
function ZO_KeyboardFriendsListManager:OnNumOnlineChanged() end
function ZO_KeyboardFriendsListManager:OnNumTotalFriendsChanged() end
function ZO_KeyboardFriendsListManager:FriendsButton_OnMouseEnter(control) end
function ZO_KeyboardFriendsListManager:FriendsButton_OnMouseExit(control) end
function ZO_KeyboardFriendsListManager:FriendsButton_OnClicked(control) end
function ZO_KeyboardFriendsListManager:BuildMasterList() end
function ZO_KeyboardFriendsListManager:FilterScrollList() end
function ZO_KeyboardFriendsListManager:SortScrollList() end
function ZO_KeyboardFriendsListManager:SetupRow(control, data) end
function ZO_KeyboardFriendsListManager:GetSearchTerm() end
function ZO_KeyboardFriendsListManager:CompareFriends(listEntry1, listEntry2) end
function ZO_KeyboardFriendsListManager:FriendsListRow_OnMouseUp(control, button, upInside) end
function ZO_KeyboardFriendsListManager:OnSearchTextChanged() end
function ZO_KeyboardFriendsListManager:UnlockSelection() end
function ZO_FriendsListRow_OnMouseEnter(control) end
function ZO_FriendsListRow_OnMouseExit(control) end
function ZO_FriendsListRow_OnMouseUp(control, button, upInside) end
function ZO_FriendsListRowNote_OnMouseEnter(control) end
function ZO_FriendsListRowNote_OnMouseExit(control) end
function ZO_FriendsListRowNote_OnClicked(control) end
function ZO_FriendsListRowDisplayName_OnMouseEnter(control) end
function ZO_FriendsListRowDisplayName_OnMouseExit(control) end
function ZO_FriendsListRowAlliance_OnMouseEnter(control) end
function ZO_FriendsListRowAlliance_OnMouseExit(control) end
function ZO_FriendsListRowStatus_OnMouseEnter(control) end
function ZO_FriendsListRowStatus_OnMouseExit(control) end
function ZO_FriendsListRowClass_OnMouseEnter(control) end
function ZO_FriendsListRowClass_OnMouseExit(control) end
function ZO_FriendsListRowChampion_OnMouseEnter(control) end
function ZO_FriendsListRowChampion_OnMouseExit(control) end
function ZO_FriendsList_OnInitialized(self) end
function ZO_FriendsList_ToggleHideOffline(self) end
function ZO_KeyboardIgnoreListManager:New(...) end
function ZO_KeyboardIgnoreListManager:Initialize(control) end
function ZO_KeyboardIgnoreListManager:PerformDeferredInitialization() end
function ZO_KeyboardIgnoreListManager:InitializeKeybindDescriptors() end
function ZO_KeyboardIgnoreListManager:FilterScrollList() end
function ZO_KeyboardIgnoreListManager:CompareIgnored(listEntry1, listEntry2) end
function ZO_KeyboardIgnoreListManager:BuildMasterList() end
function ZO_KeyboardIgnoreListManager:SortScrollList() end
function ZO_KeyboardIgnoreListManager:SetupIgnoreEntry(control, data) end
function ZO_KeyboardIgnoreListManager:IgnoreListPanelRow_OnMouseUp(control, button, upInside) end
function ZO_KeyboardIgnoreListManager:IgnoreListPanelRowNote_OnMouseEnter(control) end
function ZO_KeyboardIgnoreListManager:IgnoreListPanelRowNote_OnMouseExit(control) end
function ZO_KeyboardIgnoreListManager:IgnoreListPanelRowNote_OnClicked(control) end
function ZO_KeyboardIgnoreListManager:OnEffectivelyHidden() end
function ZO_IgnoreListRow_OnMouseEnter(control) end
function ZO_IgnoreListRow_OnMouseExit(control) end
function ZO_IgnoreListRow_OnMouseUp(control, button, upInside) end
function ZO_IgnoreListRowNote_OnMouseEnter(control) end
function ZO_IgnoreListRowNote_OnMouseExit(control) end
function ZO_IgnoreListRowNote_OnClicked(control) end
function ZO_IgnoreList_OnInitialized(self) end
function ZO_KeyboardFriendRequestProvider:New(notificationManager) end
function ZO_KeyboardFriendRequestProvider:Decline(data, button, openedFromKeybind) end
function ZO_KeyboardGuildInviteProvider:New(notificationManager) end
function ZO_KeyboardGuildInviteProvider:CreateMessage(guildAlliance, guildName, inviterDisplayName) end
function ZO_KeyboardGuildInviteProvider:Decline(data, button, openedFromKeybind) end
function ZO_KeyboardCampaignQueueProvider:New(notificationManager) end
function ZO_KeyboardCampaignQueueProvider:Accept(data) end
function ZO_KeyboardAgentChatRequestProvider:New(notificationManager) end
function ZO_KeyboardAgentChatRequestProvider:CreateMessage() end
function ZO_KeyboardLeaderboardRaidProvider:New(notificationManager) end
function ZO_KeyboardLeaderboardRaidProvider:ShowMessageTooltip(data, control) end
function ZO_KeyboardLeaderboardRaidProvider:HideMessageTooltip() end
function ZO_KeyboardCollectionsUpdateProvider:New(notificationManager) end
function ZO_KeyboardCollectionsUpdateProvider:Accept(entryData) end
function ZO_KeyboardCollectionsUpdateProvider:GetMessage(hasMoreInfo, categoryName, collectibleName) end
function ZO_KeyboardCollectionsUpdateProvider:ShowMoreInfo(entryData) end
function ZO_KeyboardNotificationManager:New(control) end
function ZO_KeyboardNotificationManager:InitializeNotificationList(control) end
function ZO_KeyboardNotificationManager:ClearNotificationList() end
function ZO_KeyboardNotificationManager:AddDataEntry(dataType, data) end
function ZO_KeyboardNotificationManager:GetSelectedData() end
function ZO_KeyboardNotificationManager:FinishNotificationList() end
function ZO_KeyboardNotificationManager:RefreshVisible() end
function ZO_KeyboardNotificationManager:OnNumNotificationsChanged(totalNumNotifications) end
function ZO_KeyboardNotificationManager:BuildEmptyList() end
function ZO_KeyboardNotificationManager:SetupNote(control, data) end
function ZO_KeyboardNotificationManager:SetupBaseRow(control, data) end
function ZO_KeyboardNotificationManager:SetupTwoButtonRow(control, data) end
function ZO_KeyboardNotificationManager:SetupRequest(control, data) end
function ZO_KeyboardNotificationManager:SetupWaiting(control, data) end
function ZO_KeyboardNotificationManager:SetupAlert(control, data) end
function ZO_KeyboardNotificationManager:SetupCollectibleRow(control, data) end
function ZO_KeyboardNotificationManager:OnNotificationsChatButtonEnter(control) end
function ZO_KeyboardNotificationManager:OnNotificationsChatButtonExit() end
function ZO_KeyboardNotificationManager:RowNote_OnMouseEnter(control) end
function ZO_KeyboardNotificationManager:RowNote_OnMouseExit(control) end
function ZO_KeyboardNotificationManager:Accept_OnClicked(control) end
function ZO_KeyboardNotificationManager:Decline_OnClicked(control) end
function ZO_KeyboardNotificationManager:Message_OnMouseEnter(control) end
function ZO_KeyboardNotificationManager:Message_OnMouseExit(control) end
function ZO_KeyboardNotificationManager:RowMoreInfo_OnMouseEnter(control) end
function ZO_KeyboardNotificationManager:RowMoreInfo_OnMouseExit(control) end
function ZO_KeyboardNotificationManager:RowMoreInfo_OnClicked(control) end
function ZO_NotificationsRowNote_OnMouseEnter(control) end
function ZO_NotificationsRowNote_OnMouseExit(control) end
function ZO_NotificationsBaseRow_OnMouseEnter(control) end
function ZO_NotificationsBaseRow_OnMouseExit(control) end
function ZO_NotificationsTwoButtonAccept_OnClicked(control) end
function ZO_NotificationsTwoButtonDecline_OnClicked(control) end
function ZO_NotificationsMessage_OnMouseEnter(control) end
function ZO_NotificationsMessage_OnMouseExit(control) end
function ZO_NotificationsRowMoreInfo_OnMouseEnter(control) end
function ZO_NotificationsRowMoreInfo_OnMouseExit(control) end
function ZO_NotificationsRowMoreInfo_OnClicked(control) end
function ZO_Notifications_OnInitialized(self) end
function ZO_RequestFriendDialog_OnInitialized(self) end
function ZO_EditNoteDialog_OnInitialized(self) end
function ZO_EditNoteDialog_Hide(owner) end
function ZO_CreateGuildDialog_OnInitialized(self) end
function ZO_CreateGuildDialogName_UpdateViolations(self) end
function ZO_CreateGuildDialogName_HideViolations(self) end
function ZO_GuildEditBox_FocusGained(editControl) end
function ZO_ReportPlayerDialog_OnInitialized(self) end
function ZO_ReportPlayerDialog_Show(playerName, reason, rawName, optionalCallback) end
function ZO_SocialListKeyboard:InitializeSortFilterList(control) end
function ZO_SocialListKeyboard:SetUpOnlineData(data, online, secsSinceLogoff) end
function ZO_SocialListKeyboard:GetRowColors(data, selected) end
function ZO_SocialListKeyboard:ColorRow(control, data, mouseIsOver) end
function ZO_SocialListKeyboard:SharedSocialSetup(control, data) end
function ZO_SocialListKeyboard:UpdateHideOfflineCheckBox(checkBox) end
function ZO_SocialListKeyboard:Note_OnMouseEnter(control) end
function ZO_SocialListKeyboard:Note_OnMouseExit(control) end
function ZO_SocialListKeyboard:Note_OnClicked(control, noteEditedFunction) end
function ZO_SocialListKeyboard:DisplayName_OnMouseEnter(control) end
function ZO_SocialListKeyboard:DisplayName_OnMouseExit(control) end
function ZO_SocialListKeyboard:CharacterName_OnMouseEnter(control) end
function ZO_SocialListKeyboard:CharacterName_OnMouseExit(control) end
function ZO_SocialListKeyboard:Alliance_OnMouseEnter(control) end
function ZO_SocialListKeyboard:Alliance_OnMouseExit(control) end
function ZO_SocialListKeyboard:Status_OnMouseEnter(control) end
function ZO_SocialListKeyboard:Status_OnMouseExit(control) end
function ZO_SocialListKeyboard:Class_OnMouseEnter(control) end
function ZO_SocialListKeyboard:Class_OnMouseExit(control) end
function ZO_SocialListKeyboard:Champion_OnMouseEnter(control) end
function ZO_SocialListKeyboard:Champion_OnMouseExit(control) end
function ZO_SocialListKeyboard:HideOffline_OnClicked() end
function ZO_NotificationProvider:New(notificationManager) end
function ZO_NotificationProvider:SetHasTimer(hasTimer) end
function ZO_NotificationProvider:GetHasTimer() end
function ZO_NotificationProvider:GetNumNotifications() end
function ZO_NotificationProvider:AddDataEntry(list, i, isHeader) end
function ZO_NotificationProvider:PushUpdateToNotificationManager() end
function ZO_NotificationProvider:RegisterUpdateEvent(event) end
function ZO_NotificationProvider:BuildNotificationList() end
function ZO_NotificationProvider:Accept(data) end
function ZO_NotificationProvider:Decline(data, button, openedFromKeybind) end
function ZO_NotificationProvider:ShowMoreInfo(data) end
function ZO_NotificationProvider:SetCanShowGamerCard(canShowGamerCard) end
function ZO_NotificationProvider:CanShowGamerCard() end
function ZO_NotificationProvider:ShowGamerCard(data) end
function ZO_FriendRequestProvider:New(notificationManager) end
function ZO_FriendRequestProvider:BuildNotificationList() end
function ZO_FriendRequestProvider:Accept(data) end
function ZO_FriendRequestProvider:CreateMessage(displayName) end
function ZO_GuildInviteProvider:New(notificationManager) end
function ZO_GuildInviteProvider:BuildNotificationList() end
function ZO_GuildInviteProvider:Accept(data) end
function ZO_GuildInviteProvider:Decline(data, button, openedFromKeybind) end
function ZO_GuildMotDProvider:New(notificationManager) end
function ZO_GuildMotDProvider:BuildNotificationList() end
function ZO_GuildMotDProvider:MarkMotDRead(data) end
function ZO_GuildMotDProvider:Decline(data) end
function ZO_GuildMotDProvider:OnAddOnLoaded(name) end
function ZO_GuildMotDProvider:CreateMessage(guildAlliance, guildName) end
function ZO_CampaignQueueProvider:New(notificationManager) end
function ZO_CampaignQueueProvider:BuildNotificationList() end
function ZO_CampaignQueueProvider:Decline(data, button, openedFromKeybind) end
function ZO_CampaignQueueProvider:CreateMessageFormat(isGroup) end
function ZO_CampaignQueueProvider:CreateLoadText() end
function ZO_ResurrectProvider:New(notificationManager) end
function ZO_ResurrectProvider:BuildNotificationList() end
function ZO_ResurrectProvider:Accept(data) end
function ZO_ResurrectProvider:Decline(data, button, openedFromKeybind) end
function ZO_ResurrectProvider:GetMessageFormat() end
function ZO_GroupInviteProvider:New(notificationManager) end
function ZO_GroupInviteProvider:BuildNotificationList() end
function ZO_GroupInviteProvider:Accept(data) end
function ZO_GroupInviteProvider:Decline(data, button, openedFromKeybind) end
function ZO_GroupInviteProvider:CreateMessage(inviterName) end
function ZO_GroupElectionProvider:New(notificationManager) end
function ZO_GroupElectionProvider:BuildNotificationList() end
function ZO_GroupElectionProvider:Accept(data) end
function ZO_GroupElectionProvider:Decline(data, button, openedFromKeybind) end
function ZO_TradeInviteProvider:New(notificationManager) end
function ZO_TradeInviteProvider:BuildNotificationList() end
function ZO_TradeInviteProvider:Accept(data) end
function ZO_TradeInviteProvider:Decline(data, button, openedFromKeybind) end
function ZO_TradeInviteProvider:CreateMessage(inviterName) end
function ZO_QuestShareProvider:New(notificationManager) end
function ZO_QuestShareProvider:BuildNotificationList() end
function ZO_QuestShareProvider:Accept(data) end
function ZO_QuestShareProvider:Decline(data, button, openedFromKeybind) end
function ZO_QuestShareProvider:CreateMessage(inviterName, questName) end
function ZO_PledgeOfMaraProvider:New(notificationManager) end
function ZO_PledgeOfMaraProvider:CreateParticipantMessage(targetName, isSender) end
function ZO_PledgeOfMaraProvider:CreateMessage(targetName) end
function ZO_PledgeOfMaraProvider:CreateSenderMessage(targetName) end
function ZO_PledgeOfMaraProvider:BuildNotificationList() end
function ZO_PledgeOfMaraProvider:Accept(data) end
function ZO_PledgeOfMaraProvider:Decline(data, button, openedFromKeybind) end
function ZO_AgentChatRequestProvider:New(notificationManager) end
function ZO_AgentChatRequestProvider:BuildNotificationList() end
function ZO_AgentChatRequestProvider:CreateMessage() end
function ZO_AgentChatRequestProvider:Accept(data) end
function ZO_AgentChatRequestProvider:Decline(data, button, openedFromKeybind) end
function ZO_LeaderboardRaidProvider:New(notificationManager) end
function ZO_LeaderboardRaidProvider:BuildNotificationList() end
function ZO_LeaderboardRaidProvider:CreateMessage(raidName, raidScore, numMembers, hasFriend, hasGuildMember, notificationId) end
function ZO_LeaderboardRaidProvider:Accept(data) end
function ZO_LeaderboardRaidProvider:Decline(data, button, openedFromKeybind) end
function ZO_CollectionsUpdateProvider:New(notificationManager) end
function ZO_CollectionsUpdateProvider:BuildNotificationList() end
function ZO_CollectionsUpdateProvider:CreateCollectibleNotificationData(notificationId, collectibleId) end
function ZO_CollectionsUpdateProvider:AddCollectibleNotification(data) end
function ZO_CollectionsUpdateProvider:AddNotification(message, data, hasMoreInfo) end
function ZO_CollectionsUpdateProvider:Accept(entryData) end
function ZO_CollectionsUpdateProvider:Decline(entryData) end
function ZO_CollectionsUpdateProvider:GetNotificationIdForCollectible(collectibleId) end
function ZO_CollectionsUpdateProvider:HasAnyNotifications(optionalCategoryIndexFilter, optionalSubcategoryIndexFilter) end
function ZO_LFGUpdateProvider:New(notificationManager) end
function ZO_LFGUpdateProvider:BuildNotificationList() end
function ZO_LFGUpdateProvider:AddJumpNotification(data) end
function ZO_LFGUpdateProvider:AddFindReplacementNotification(data) end
function ZO_LFGUpdateProvider:Accept(entryData) end
function ZO_LFGUpdateProvider:Decline(entryData) end
function ZO_CraftBagAutoTransferProvider:New(notificationManager) end
function ZO_CraftBagAutoTransferProvider:BuildNotificationList() end
function ZO_CraftBagAutoTransferProvider:AddNotification() end
function ZO_CraftBagAutoTransferProvider:Decline() end
function ZO_NotificationList:New(control, notificationManager) end
function ZO_NotificationList:BuildMasterList() end
function ZO_NotificationList:FilterScrollList() end
function ZO_NotificationList:CompareNotifications(listEntry1, listEntry2) end
function ZO_NotificationList:SortScrollList() end
function ZO_NotificationManager:New(control) end
function ZO_NotificationManager:Initialize(control) end
function ZO_NotificationManager:RefreshNotificationList() end
function ZO_NotificationManager:RefreshVisible() end
function ZO_NotificationManager:BuildNotificationList() end
function ZO_NotificationManager:OnNumNotificationsChanged(totalNumNotifications) end
function ZO_NotificationManager:CompareNotifications(listEntry1, listEntry2) end
function ZO_NotificationManager:SortNotificationList() end
function ZO_NotificationManager:AcceptRequest(data) end
function ZO_NotificationManager:DeclineRequest(data, button, openedFromKeybind) end
function ZO_NotificationManager:ShowMoreInfo(data) end
function ZO_NotificationManager:BuildMessageText(data) end
function ZO_NotificationManager:SetupMessage(message, data) end
function ZO_NotificationManager:GetNumNotifications() end
function ZO_NotificationManager:GetNumCollectionsNotifications() end
function ZO_NotificationManager:GetCollectionsProvider() end
function ZO_NotificationManager:InitializeNotificationList(control) end
function ZO_NotificationManager:AddDataEntry(template, data, headerText) end
function ZO_SocialList_GetRowColors(data, selected) end
function ZO_SocialList_ColorRow(control, data, displayNameTextColor, iconColor, otherTextColor) end
function ZO_SocialList_SetUpOnlineData(data, online, secsSinceLogoff) end
function ZO_SocialList_SharedSocialSetup(control, data, selected) end
function ZO_SocialManager:New() end
function ZO_SocialManager:Initialize() end
function ZO_SocialManager:GetMasterList() end
function ZO_SocialManager:BuildMasterList() end
function ZO_SocialManager:AddList(list) end
function ZO_SocialManager:CallFunctionOnLists(funcName, ...) end
function ZO_SocialManager:SetupEntry(control, data, selected) end
function ZO_SocialManager:RefreshSort() end
function ZO_SocialManager:RefreshFilters() end
function ZO_SocialManager:RefreshData() end
function ZO_SocialManager:RefreshVisible() end
function ZO_SocialManager:IsMatch(searchTerm, data) end
function ZO_SocialManager:ProcessDisplayName(stringSearch, data, searchTerm, cache) end
--ingame\contextual
function ZO_ContextualActionBar_OnMouseEnter() end
function ZO_ContextualActionBar_OnUpdate(control) end
function ZO_ContextualActionBar_AddReference() end
function ZO_ContextualActionBar_RemoveReference() end
function ZO_ContextualActionBar_OnInitialized(self) end
--ingame\crafting
function ZO_CraftingCreateSlotAnimation:New(...) end
function ZO_CraftingCreateSlotAnimation:Initialize(sceneName, visibilityPredicate) end
function ZO_CraftingCreateSlotAnimation:GetLockInSound(slot) end
function ZO_CraftingCreateSlotAnimation:GetAnimationOffset(slot) end
function ZO_CraftingCreateSlotAnimation:Play(sceneName) end
function ZO_CraftingCreateSlotAnimation:Stop(sceneName) end
function ZO_CraftingEnchantExtractSlotAnimation:New(...) end
function ZO_CraftingEnchantExtractSlotAnimation:Initialize(sceneName, visibilityPredicate) end
function ZO_CraftingEnchantExtractSlotAnimation:Play(sceneName) end
function ZO_CraftingInventory:New(...) end
function ZO_CraftingInventory:Initialize(control, slotType, noDragging) end
function ZO_CraftingInventory:InitializeList() end
function ZO_CraftingInventory:AddListDataTypes() end
function ZO_CraftingInventory:SetMousedOverRow(slot) end
function ZO_CraftingInventory:GetDefaultTemplateSetupFunction() end
function ZO_CraftingInventory:HandleVisibleDirtyEvent() end
function ZO_CraftingInventory:PerformFullRefresh() end
function ZO_CraftingInventory:CreateNewTabFilterData(filterType, name, normal, pressed, highlight, disabled, visible) end
function ZO_CraftingInventory:SetActiveFilterByDescriptor(descriptor) end
function ZO_CraftingInventory:SetFilters(filterData) end
function ZO_CraftingInventory:RefreshFilters() end
function ZO_CraftingInventory:SetCustomSortHeader(name, customDataGetFunction) end
function ZO_CraftingInventory:SetSortColumnHidden(columns, hidden) end
function ZO_CraftingInventory:AddItemData(bagId, slotIndex, totalStack, scrollDataType, data, customDataGetFunction, validItemIds) end
function ZO_CraftingInventory:EnumerateInventorySlotsAndAddToScrollData(predicate, filterFunction, filterType, data) end
function ZO_CraftingInventory:ChangeSort(sortKey, sortOrder) end
function ZO_CraftingInventory:Show() end
function ZO_CraftingInventory:Hide() end
function ZO_CraftingInventory:SortData() end
function ZO_CraftingInventory_FilterButtonOnMouseEnter(self) end
function ZO_CraftingInventory_FilterButtonOnMouseExit(self) end
function ZO_CraftingResults_Base_PlayPulse(control) end
function ZO_CraftingResults_Base:New(...) end
function ZO_CraftingResults_Base:Initialize(control, showInGamepadPreferredModeOnly) end
function ZO_CraftingResults_Base:SetCraftingTooltip(tooltipControl) end
function ZO_CraftingResults_Base:SetTooltipAnimationSounds(tooltipAnimationSuccessSound, tooltipAnimationFailureSound) end
function ZO_CraftingResults_Base:PlayCraftedSound(itemSoundCategory) end
function ZO_CraftingResults_Base:AssociateAnimations(tooltip) end
function ZO_CraftingResults_Base:ForceStop() end
function ZO_CraftingResults_Base:OnCraftStarted(craftingType) end
function ZO_CraftingResults_Base:PlayTooltipAnimation(failure) end
function ZO_CraftingResults_Base:OnCraftCompleted(craftingType) end
function ZO_CraftingResults_Base:OnAllEnchantSoundsFinished() end
function ZO_CraftingResults_Base:OnTooltipAnimationStopped() end
function ZO_CraftingResults_Base:SetForceCenterResultsText(forceCenterResultsText) end
function ZO_CraftingResults_Base:ModifyAnchor(control, newAnchor) end
function ZO_CraftingResults_Base:RestoreAnchor(control) end
function ZO_CraftingResults_Base:CheckCraftProcessCompleted() end
function ZO_CraftingResults_Base:IsCraftInProgress() end
function ZO_CraftingResults_Base:HasEntries() end
function ZO_CraftingSmithingExtractSlotAnimation:New(...) end
function ZO_CraftingSmithingExtractSlotAnimation:Initialize(sceneName, visibilityPredicate) end
function ZO_CraftingSmithingExtractSlotAnimation:Play(sceneName) end
function ZO_CraftingSmithingExtractSlotAnimation:Stop() end
function ZO_CraftingSlotBase:New(...) end
function ZO_CraftingSlotBase:Initialize(owner, control, slotType, emptyTexture, craftingInventory, emptySlotIcon) end
function ZO_CraftingSlotBase:ShowDropCallout(isCorrectType) end
function ZO_CraftingSlotBase:HideDropCallout() end
function ZO_CraftingSlotBase:OnPassedValidation() end
function ZO_CraftingSlotBase:OnFailedValidation() end
function ZO_CraftingSlotBase:ValidateItemId(validItemIds) end
function ZO_CraftingSlotBase:SetItem(bagId, slotIndex) end
function ZO_CraftingSlotBase:SetupItem(bagId, slotIndex) end
function ZO_CraftingSlotBase:AddAnimationRef() end
function ZO_CraftingSlotBase:RemoveAnimationRef() end
function ZO_CraftingSlotBase:HasAnimationRefs() end
function ZO_CraftingSlotBase:GetStackCount() end
function ZO_CraftingSlotBase:GetBagAndSlot() end
function ZO_CraftingSlotBase:IsBagAndSlot(bagId, slotIndex) end
function ZO_CraftingSlotBase:HasItem() end
function ZO_CraftingSlotBase:IsItemId(itemId) end
function ZO_CraftingSlotBase:GetItemId() end
function ZO_CraftingSlotBase:IsSlotControl(slotControl) end
function ZO_CraftingSlotBase:GetControl() end
function ZO_CraftingSlotBase:UpdateTooltip() end
function ZO_CraftingSlotBase:SetEmptyTexture(emptyTexture) end
function ZO_CraftingSlotBase:SetHidden(hidden) end
function ZO_CraftingSlotBase:ShowEmptySlotIcon(showIcon) end
function ZO_CraftingSlot_OnInitialized(self) end
function ZO_CraftingSlotAnimationBase:New(...) end
function ZO_CraftingSlotAnimationBase:Initialize(sceneName, visibilityPredicate) end
function ZO_CraftingSlotAnimationBase:AddSlot(slot) end
function ZO_CraftingSlotAnimationBase:Clear() end
function ZO_CraftingSlotAnimationBase:Play(sceneName) end
function ZO_CraftingSlotAnimationBase:Stop(sceneName) end
function ZO_CraftingUtils_GetCostToCraftString(cost) end
function ZO_CraftingUtils_ConnectMenuBarToCraftingProcess(menuBar) end
function ZO_CraftingUtils_ConnectKeybindButtonGroupToCraftingProcess(keybindStripDescriptor) end
function ZO_CraftingUtils_ConnectHorizontalScrollListToCraftingProcess(horizontalScrollList) end
function ZO_CraftingUtils_ConnectCheckBoxToCraftingProcess(checkBox) end
function ZO_CraftingUtils_ConnectSpinnerToCraftingProcess(spinner) end
function ZO_CraftingUtils_ConnectTreeToCraftingProcess(tree) end
function ZO_CraftingUtils_IsTraitAppliedToWeapons(traitType) end
function ZO_CraftingUtils_IsTraitAppliedToArmor(traitType) end
function ZO_CraftingUtils_IsCraftingWindowOpen() end
function ZO_GamepadCraftingIngredientBar:New(...) end
function ZO_GamepadCraftingIngredientBar:Initialize(control, slotSpacing) end
function ZO_GamepadCraftingIngredientBar:Clear() end
function ZO_GamepadCraftingIngredientBar:AddDataTemplate(templateName, setupFunction) end
function ZO_GamepadCraftingIngredientBar:AddEntry(templateName, data) end
function ZO_GamepadCraftingIngredientBar:Commit() end
function ZO_GamepadAlchemy:New(...) end
function ZO_GamepadAlchemy:Initialize(control) end
function ZO_AlchemyCraftingBarSlotTemplateSetup(control, data) end
function ZO_AlchemyCraftingBarSolventSlotTemplateSetup(control, data) end
function ZO_GamepadAlchemy:InitializeSlots() end
function ZO_GamepadAlchemy:UpdateThirdAlchemySlot() end
function ZO_GamepadAlchemy:InitializeInventory() end
function ZO_GamepadAlchemy:InitializeKeybindStripDescriptors() end
function ZO_GamepadAlchemy:InitializeScenes() end
function ZO_GamepadAlchemy:OnShowing() end
function ZO_GamepadAlchemy:OnHide() end
function ZO_GamepadAlchemy:InitializeTooltip() end
function ZO_GamepadAlchemy:IsSelectionOnWorkbench() end
function ZO_GamepadAlchemy:IsItemOnWorkbench(selectedBagId, selectedSlotIndex) end
function ZO_GamepadAlchemy:GetReagentSlotOffset(thirdSlotUnlocked) end
function ZO_GamepadAlchemy:OnWorkbenchUpdated() end
function ZO_GamepadAlchemy:UpdateActiveSlot() end
function ZO_GamepadAlchemy:UpdateItemOnWorkbench(data) end
function ZO_GamepadAlchemy:UpdateTooltip() end
function ZO_GamepadAlchemy:UpdateTooltipLayout() end
function ZO_GamepadAlchemy:GetAllSlots() end
function ZO_GamepadAlchemy:GetSlot(index) end
function ZO_GamepadAlchemy:GetActiveSlot() end
function ZO_GamepadAlchemyInventory:New(control, owner,...) end
function ZO_GamepadAlchemyInventory:Initialize(owner, control, ...) end
function ZO_GamepadAlchemyInventory:IsLocked(bagId, slotIndex) end
function ZO_GamepadAlchemyInventory:AddListDataTypes() end
function ZO_GamepadAlchemyInventory:GetListEntryTemplate(data) end
function ZO_GamepadAlchemyInventory:Refresh(data) end
function ZO_GamepadAlchemyInventory:ShowAppropriateSlotDropCallouts(bagId, slotIndex) end
function ZO_GamepadAlchemyInventory:HideAllSlotDropCallouts() end
function ZO_GamepadAlchemyInventory:SetAlignToScreenCenter(alignToScreenCenter, expectedEntryHeight) end
function ZO_GamepadAlchemyInventory:GetControl() end
function ZO_GamepadAlchemyInventory:IsActive() end
function ZO_GamepadAlchemyInventory:SetOnTargetDataChangedCallback(selectedDataCallback) end
function ZO_GamepadAlchemy_OnInitialized(control) end
function ZO_CraftingResults_Gamepad:New(...) end
function ZO_CraftingResults_Gamepad:Initialize(control) end
function ZO_CraftingResults_Gamepad:ModifyAnchor(newAnchor) end
function ZO_CraftingResults_Gamepad:RestoreAnchor() end
function ZO_CraftingResults_Gamepad:IsActive() end
function ZO_CraftingResults_Gamepad:DisplayCraftingResult(itemInfo) end
function ZO_CraftingResults_Gamepad:ClearAll() end
function ZO_CraftingResults_Gamepad:FadeAll() end
function ZO_CraftingResults_Gamepad:DisplayDiscoveryHelper(titleString, numDiscoveries, lastLearnedDiscoveryFn) end
function ZO_CraftingResults_Gamepad:DisplayDiscoveredTraits() end
function ZO_CraftingResults_Gamepad:DisplayTranslatedRunes() end
function ZO_CraftingResults_Gamepad:ShouldDisplayMessages() end
function ZO_CraftingResults_Gamepad_Initialize(control) end
function ZO_GamepadCraftingUtils_AddGenericCraftingBackKeybindsToDescriptor(keybindDescriptor) end
function ZO_GamepadCraftingUtils_AddListTriggerKeybindDescriptors(descriptor, list, optionalHeaderComparator) end
function ZO_GamepadCraftingUtils_GetLineNameForCraftingType(craftingType) end
function ZO_GamepadCraftingUtils_InitializeGenericHeader(craftingObject, createTabBar) end
function ZO_GamepadCraftingUtils_SetupGenericHeader(craftingObject, titleString, tabBarEntries, showCapacity) end
function ZO_GamepadCraftingUtils_SetGenericHeaderData2(craftingObject, headerText, text) end
function ZO_GamepadCraftingUtils_RefreshGenericHeader(craftingObject) end
function ZO_GamepadCraftingUtils_RefreshGenericHeaderData(craftingObject) end
function ZO_GamepadCraftingUtils_ScaleSlotBackground(slot) end
function ZO_GamepadCraftingUtils_RestoreSlotBackground(slot) end
function ZO_GamepadCraftingUtils_PlaySlotBounceAnimation(slot) end
function ZO_GamepadCraftingUtils_SelectOptionFromOptionList(craftingObject) end
function ZO_GamepadCraftingUtils_CraftingTooltip_StandardFloatingBottomScreenResizeHandler(control) end
function ZO_GamepadCraftingUtils_CraftingTooltip_StandardFloatingCenterScreenResizeHandler(control) end
function ZO_GamepadCraftingUtils_CraftingTooltip_Gamepad_Initialize(control, resizeHandler) end
function ZO_GamepadEnchanting:New(...) end
function ZO_GamepadEnchanting:Initialize(control) end
function ZO_GamepadEnchanting:InitializeModes() end
function ZO_GamepadEnchanting:InitializeInventory() end
function ZO_GamepadEnchanting:InitializeEnchantingScenes() end
function ZO_GamepadEnchanting:InitializeCreationSlots() end
function ZO_GamepadEnchanting:DataSelectionCallback(list, selectedData) end
function ZO_GamepadEnchantingRuneCraftingSlotTemplateSetup(control, data) end
function ZO_GamepadEnchantingRuneExtractionSlotTemplateSetup(control, data) end
function ZO_GamepadEnchanting:InitializeExtractionSlots() end
function ZO_GamepadEnchanting:InitializeKeybindStripDescriptors() end
function ZO_GamepadEnchanting:UpdateExtractionSlotTexture() end
function ZO_GamepadEnchanting:SelectMode() end
function ZO_GamepadEnchanting:SetEnchantingMode(enchantingMode) end
function ZO_GamepadEnchanting:UpdateSelection() end
function ZO_GamepadEnchanting:Select() end
function ZO_GamepadEnchanting:Remove() end
function ZO_GamepadEnchanting:IsCurrentSelected() end
function ZO_GamepadEnchanting:UpdateTooltip() end
function ZO_GamepadEnchantingInventory:New(...) end
function ZO_GamepadEnchantingInventory:Initialize(owner, control, ...) end
function ZO_GamepadEnchantingInventory:AddListDataTypes() end
function ZO_GamepadEnchantingInventory:IsLocked(bagId, slotIndex) end
function ZO_GamepadEnchantingInventory:Refresh(data) end
function ZO_GamepadEnchantingInventory:ShowAppropriateSlotDropCallouts(bagId, slotIndex) end
function ZO_GamepadEnchantingInventory:HideAllSlotDropCallouts() end
function ZO_GamepadEnchanting_Initialize(control) end
function ZO_EnchantExtractionSlot_Gamepad:New(...) end
function ZO_EnchantExtractionSlot_Gamepad:Initialize(owner, control, craftingInventory) end
function ZO_EnchantExtractionSlot_Gamepad:ClearDropCalloutTexture() end
function ZO_EnchantExtractionSlot_Gamepad:SetBackdrop(bagId, slotIndex) end
function ZO_GamepadCraftingInventory:New(...) end
function ZO_GamepadCraftingInventory:Initialize(control, slotType, connectInfoFn, connectInfoControl) end
function ZO_GamepadCraftingInventory:InitializeList() end
function ZO_GamepadCraftingInventory:AddListDataTypes() end
function ZO_GamepadCraftingInventory:AddVerticalScrollDataTypes(verticalScrollCraftEntryType, setupTemplate, setupHeaderTemplate) end
function ZO_GamepadCraftingInventory:SetVerticalScrollDataTypes(verticalScrollCraftEntryType) end
function ZO_GamepadCraftingInventory:Activate() end
function ZO_GamepadCraftingInventory:Deactivate() end
function ZO_GamepadCraftingInventory:HandleVisibleDirtyEvent() end
function ZO_GamepadCraftingInventory:PerformFullRefresh() end
function ZO_GamepadCraftingInventory_DefaultItemSortComparator(left, right) end
function ZO_GamepadCraftingInventory:SetCustomExtraData(customExtraDataFunction) end
function ZO_GamepadCraftingInventory:SetCustomSort(customDataSortFunction) end
function ZO_GamepadCraftingInventory:SetVerticalScrollCraftEntryType(type) end
function ZO_GamepadCraftingInventory:EnumerateInventorySlotsAndAddToScrollData(predicate, filterFunction, filterType, data) end
function ZO_GamepadCraftingInventory:GetListEntryTemplate(data) end
function ZO_GamepadCraftingInventory:Show() end
function ZO_GamepadCraftingInventory:Hide() end
function ZO_GamepadCraftingInventory:CurrentSelection() end
function ZO_GamepadCraftingInventory:CurrentSelectionBagAndSlot() end
function ZO_GamepadProvisioner:New(...) end
function ZO_GamepadProvisioner:Initialize(control) end
function ZO_GamepadProvisioner:OnSceneShowing() end
function ZO_GamepadProvisioner:OnSceneHidden() end
function ZO_GamepadProvisioner:ShouldShowForControlScheme() end
function ZO_GamepadProvisioner:PerformDeferredInitialization() end
function ZO_GamepadProvisioner:InitializeKeybindStripDescriptors() end
function ZO_GamepadProvisioner:ShowOptions() end
function ZO_GamepadProvisioner:InitializeRecipeList() end
function ZO_GamepadProvisioner:InitializeOptionList() end
function ZO_GamepadProvisioner:SaveFilters() end
function ZO_GamepadProvisioner:BuildOptionList() end
function ZO_GamepadProvisioner:InitializeDetails() end
function ZO_GamepadProvisioner:SetDetailsEnabled(enabled) end
function ZO_GamepadProvisioner:RefreshRecipeList() end
function ZO_GamepadProvisioner:RefreshRecipeDetails(selectedData) end
function ZO_GamepadProvisioner:RefreshOptionList() end
function ZO_GamepadProvisioner:SelectOption() end
function ZO_GamepadProvisioner:IsCraftable() end
function ZO_GamepadProvisioner:Create() end
function ZO_GamepadProvisioner_Initialize(control) end
function ZO_GamepadProvisionRecipeEntryTemplateSetup(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_ProvisionerIngredientBarSlotTemplateSetup(control, data) end
function ZO_SmithingHorizontalScrollList_Gamepad:New(...) end
function ZO_SmithingHorizontalScrollList_Gamepad:SetToggleType(type) end
function ZO_SmithingHorizontalScrollList_Gamepad:GetToggleType() end
function ZO_GamepadSmithingCreation:New(...) end
function ZO_GamepadSmithingCreation:Initialize(panelControl, floatingControl, owner, scene) end
function ZO_GamepadSmithingCreation:PerformDeferredInitialization() end
function ZO_GamepadSmithingCreation:GenerateTabBarEntries() end
function ZO_GamepadSmithingCreation:SetupTabBar(tabBarEntries, savedFilter) end
function ZO_GamepadSmithingCreation:RefreshAvailableFilters(dontReselect) end
function ZO_GamepadSmithingCreation:InitializeKeybindStripDescriptors() end
function ZO_GamepadSmithingCreation:RefreshTooltips() end
function ZO_GamepadSmithingCreation:OnScrollExtentsChanged(scroll, horizontalExtents, verticalExtents) end
function ZO_GamepadSmithingCreation:RefreshScrollPanel() end
function ZO_GamepadSmithingCreation:UpdateBorderHighlight(focus, active) end
function ZO_GamepadSmithingCreation:UpdateUniversalStyleItemInfo() end
function ZO_GamepadSmithingCreation:InitializeOptionList() end
function ZO_GamepadSmithingCreation:UpdateOptionLeftTooltip(selectedData) end
function ZO_GamepadSmithingCreation:SetupSavedVars() end
function ZO_GamepadSmithingCreation:AddCheckedStateToOption(option, checkedState) end
function ZO_GamepadSmithingCreation:ShowOptions() end
function ZO_GamepadSmithingCreation:SetupOptionData() end
function ZO_GamepadSmithingCreation:RefreshOptionList() end
function ZO_GamepadSmithingCreation:SelectOption() end
function ZO_GamepadSmithingCreation:RefreshFilters() end
function ZO_GamepadSmithingCreation:UpdateTooltipInternal() end
function ZO_GamepadSmithingCreation:SetupResultTooltip(selectedPatternIndex, selectedMaterialIndex, selectedMaterialQuantity, selectedStyleIndex, selectedTraitIndex) end
function ZO_GamepadSmithingCreation:ActivateMaterialQuantitySpinner() end
function ZO_GamepadSmithingCreation:SetLabelHidden(label, hidden) end
function ZO_GamepadSmithingCreation:OnStyleChanged(selectedData) end
function ZO_GamepadSmithingExtraction:New(...) end
function ZO_GamepadSmithingExtraction:Initialize(panelControl, floatingControl, owner, refinementOnly, scene) end
function ZO_GamepadSmithingExtraction:ChangeMode(mode) end
function ZO_GamepadSmithingExtraction:AddEntry(name, mode, allowed, tabBarEntries) end
function ZO_GamepadSmithingExtraction:SetCraftingType(craftingType, oldCraftingType, isCraftingTypeDifferent) end
function ZO_GamepadSmithingExtraction:InitializeInventory(refinementOnly) end
function ZO_GamepadSmithingExtraction:IsCurrentSelected() end
function ZO_GamepadSmithingExtraction:UpdateSelection() end
function ZO_GamepadSmithingExtraction:AddItemToWorkbench() end
function ZO_GamepadSmithingExtraction:RemoveItemFromWorkbench() end
function ZO_GamepadSmithingExtraction:ConfirmRefineOrDestroy() end
function ZO_GamepadSmithingExtraction:HasEnoughToRefine() end
function ZO_GamepadSmithingExtraction:InitializeKeybindStripDescriptors() end
function ZO_GamepadExtractionInventory:New(...) end
function ZO_GamepadExtractionInventory:Initialize(owner, control, refinementOnly, ...) end
function ZO_GamepadExtractionInventory:Refresh(data) end
function ZO_GamepadExtractionInventory:GetCurrentFilterType() end
function ZO_GamepadSmithingImprovement:New(...) end
function ZO_GamepadSmithingImprovement:Initialize(panelControl, floatingControl, owner, scene) end
function ZO_GamepadSmithingImprovement:ChangeMode(mode) end
function ZO_GamepadSmithingImprovement:AddEntry(name, mode, allowed, tabBarEntries) end
function ZO_GamepadSmithingImprovement:InitializeSlots() end
function ZO_GamepadSmithingImprovement:InitializeInventory() end
function ZO_GamepadSmithingImprovement:IsCurrentSelected() end
function ZO_GamepadSmithingImprovement:UpdateSelection() end
function ZO_GamepadSmithingImprovement:AddItemToWorkbench() end
function ZO_GamepadSmithingImprovement:RemoveItemFromWorkbench() end
function ZO_GamepadSmithingImprovement:ConfirmImprove() end
function ZO_GamepadSmithingImprovement:CanImprove() end
function ZO_GamepadSmithingImprovement:InitializeKeybindStripDescriptors() end
function ZO_GamepadSmithingImprovement:RefreshImprovementChance() end
function ZO_GamepadSmithingImprovement:OnSlotChanged() end
function ZO_GamepadSmithingImprovement:Improve() end
function ZO_GamepadSmithingImprovement:HighlightBoosterRow(rowToHighlight) end
function ZO_GamepadSmithingImprovement:ClearBoosterRowHighlight() end
function ZO_GamepadSmithingImprovement:ColorizeText(qualityRow) end
function ZO_GamepadSmithingImprovement:SetupResultTooltip(...) end
function ZO_GamepadSmithingImprovement:SetInventoryActive(active) end
function ZO_GamepadSmithingImprovement_TooltipScreenResizeHandler(control) end
function ZO_GamepadImprovementInventory:New(...) end
function ZO_GamepadImprovementInventory:Initialize(owner, control, ...) end
function ZO_GamepadImprovementInventory:GetCurrentFilterType() end
function ZO_GamepadImprovementInventory:Refresh(data) end
function ZO_GamepadSmithingResearch:New(...) end
function ZO_GamepadSmithingResearch:Initialize(panelContent, owner, scene) end
function ZO_GamepadSmithingResearch:PerformDeferredInitialization() end
function ZO_GamepadSmithingResearch:AnchorTimerBar() end
function ZO_GamepadSmithingResearch:GenerateTabBarEntries() end
function ZO_GamepadSmithingResearch:SetupTabBar(tabBarEntries, savedFilter) end
function ZO_GamepadSmithingResearch:RefreshAvailableFilters(dontReselect) end
function ZO_GamepadSmithingResearch:RefreshCurrentResearchStatusDisplay(currentlyResearching, maxResearchable) end
function ZO_GamepadSmithingResearch:InitializeKeybindStripDescriptors() end
function ZO_GamepadSmithingResearch:AcceptResearch(bagId, slotIndex) end
function ZO_GamepadSmithingResearch:UpdateDirectionalInput() end
function ZO_GamepadSmithingResearch:InitializeConfirmList() end
function ZO_GamepadSmithingResearch:InitializeFocusItems() end
function ZO_GamepadSmithingResearch:RefreshFocusItems(focusIndex) end
function ZO_GamepadSmithingResearch:OnControlsAcquired() end
function ZO_GamepadSmithingResearch:SetupTooltip(row) end
function ZO_GamepadSmithingResearch:ClearTooltip(row) end
function ZO_GamepadSmithingResearch:Research() end
function ZO_GamepadSmithingResearch:GetResearchTimeString(...) end
function ZO_GamepadSmithingResearch:GetExtraInfoColor() end
function ZO_GamepadSmithingResearch:SetupTraitDisplay(slotControl, researchLine, known, duration, traitIndex) end
function ZO_Smithing_Gamepad:New(...) end
function ZO_Smithing_Gamepad:Initialize(control) end
function ZO_Smithing_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_Smithing_Gamepad:InitializeModeList() end
function ZO_Smithing_Gamepad:SetMode(mode) end
function ZO_Smithing_Gamepad:SetEnableSkillBar(enable) end
function ZO_Smithing_Gamepad_Initialize(control) end
function ZO_Alchemy:New(...) end
function ZO_Alchemy:Initialize(control) end
function ZO_Alchemy:InitializeInventory() end
function ZO_Alchemy:InitializeTooltip() end
function ZO_Alchemy:InitializeScenes() end
function ZO_Alchemy:InitializeModeBar() end
function ZO_Alchemy:GetReagentSlotOffset(thirdSlotUnlocked) end
function ZO_Alchemy:InitializeKeybindStripDescriptors() end
function ZO_Alchemy:UpdateTooltipLayout() end
function ZO_Alchemy:OnItemReceiveDrag(slotControl, bagId, slotIndex) end
function ZO_AlchemyInventory:New(...) end
function ZO_AlchemyInventory:Initialize(owner, control, ...) end
function ZO_AlchemyInventory:IsLocked(bagId, slotIndex) end
function ZO_AlchemyInventory:AddListDataTypes() end
function ZO_AlchemyInventory:GetScrollDataType(bagId, slotIndex) end
function ZO_AlchemyInventory:ChangeFilter(filterData) end
function ZO_AlchemyInventory:Refresh(data) end
function ZO_AlchemyInventory:ShowAppropriateSlotDropCallouts(bagId, slotIndex) end
function ZO_AlchemyInventory:HideAllSlotDropCallouts() end
function ZO_Alchemy_Initialize(control) end
function ZO_CraftingResults_Keyboard:New(...) end
function ZO_CraftingResults_SetupAlchemyDialogLayout(control, options) end
function ZO_CraftingResults_Keyboard:Initialize(control) end
function ZO_CraftingResults_Keyboard:ModifyAnchor(newAnchor) end
function ZO_CraftingResults_Keyboard:RestoreAnchor() end
function ZO_CraftingResults_Keyboard:IsActive() end
function ZO_CraftingResults_Keyboard:DisplayCraftingResult(itemInfo) end
function ZO_CraftingResults_Keyboard:ClearAll() end
function ZO_CraftingResults_Keyboard:HasEntries() end
function ZO_CraftingResults_Keyboard:FadeAll() end
function ZO_CraftingResults_Keyboard:DisplayDiscoveredTraits() end
function ZO_CraftingResults_Keyboard:DisplayTranslatedRunes() end
function ZO_CraftingResults_Keyboard:ShouldDisplayMessages() end
function ZO_CraftingResults_Keyboard_Initialize(control) end
function ZO_Enchanting:New(...) end
function ZO_Enchanting:Initialize(control) end
function ZO_Enchanting:InitializeInventory() end
function ZO_Enchanting:InitializeEnchantingScenes() end
function ZO_Enchanting:InitializeModes() end
function ZO_Enchanting:InitializeExtractionSlots() end
function ZO_Enchanting:InitializeKeybindStripDescriptors() end
function ZO_Enchanting:SetEnchantingMode(enchantingMode) end
function ZO_Enchanting:UpdateTooltip() end
function ZO_Enchanting:OnItemReceiveDrag(slotControl, bagId, slotIndex) end
function ZO_EnchantingInventory:New(...) end
function ZO_EnchantingInventory:Initialize(owner, control, ...) end
function ZO_EnchantingInventory:ChangeMode(enchantingMode) end
function ZO_EnchantingInventory:ChangeFilter(filterData) end
function ZO_EnchantingInventory:IsLocked(bagId, slotIndex) end
function ZO_EnchantingInventory:Refresh(data) end
function ZO_EnchantingInventory:ShowAppropriateSlotDropCallouts(bagId, slotIndex) end
function ZO_EnchantingInventory:HideAllSlotDropCallouts() end
function ZO_Enchanting_Initialize(control) end
function ZO_Provisioner:New(...) end
function ZO_Provisioner:Initialize(control) end
function ZO_Provisioner:OnSceneShowing() end
function ZO_Provisioner:OnSceneHidden() end
function ZO_Provisioner:ShouldShowForControlScheme() end
function ZO_Provisioner:InitializeTabs() end
function ZO_Provisioner:OnTabFilterChanged(filterData) end
function ZO_Provisioner:InitializeFilters() end
function ZO_Provisioner:InitializeKeybindStripDescriptors() end
function ZO_Provisioner:InitializeRecipeTree() end
function ZO_Provisioner:InitializeDetails() end
function ZO_Provisioner:SetDetailsEnabled(enabled) end
function ZO_Provisioner:RefreshRecipeList() end
function ZO_Provisioner:GetSelectedRecipeListIndex() end
function ZO_Provisioner:GetSelectedRecipeIndex() end
function ZO_Provisioner:RefreshRecipeDetails() end
function ZO_Provisioner:IsCraftable() end
function ZO_Provisioner:Create() end
function ZO_ProvisionerRow:New(...) end
function ZO_ProvisionerRow:Initialize(owner, control) end
function ZO_ProvisionerRow:SetItemIndices(recipeListIndex, recipeIndex, ingredientIndex) end
function ZO_ProvisionerRow:SetItem(name, icon, quantity, quality, ingredientCount) end
function ZO_ProvisionerRow:ClearItem() end
function ZO_ProvisionerRow:SetHidden(hidden) end
function ZO_ProvisionerRow:SetEnabled(enabled) end
function ZO_ProvisionerRow:UpdateEnabledState() end
function ZO_Provisioner_Initialize(control) end
function ZO_ProvisionerRow_GetTextColor(self) end
function ZO_SmithingCreation:New(...) end
function ZO_SmithingCreation:Initialize(control, owner) end
function ZO_SmithingCreation:SetHidden(hidden) end
function ZO_SmithingCreation:InitializeFilterTypeBar() end
function ZO_SmithingCreation:UpdateUniversalStyleItemCheckBox() end
function ZO_SmithingCreation:InitializeFilters() end
function ZO_SmithingCreation:SetupSavedVars(defaults) end
function ZO_SmithingCreation:RefreshAvailableFilters() end
function ZO_SmithingCreation:SetupResultTooltip(...) end
function ZO_SmithingCreation:OnRefreshAllLists() end
function ZO_SmithingCreation:InitializeMaterialList(...) end
function ZO_SmithingCreation:GetPlatformFormattedTextString(stringId, ...) end
function ZO_SmithingCreation:SetLabelHidden(label, hidden) end
function ZO_SmithingCreation:BuyCraftingItems() end
function ZO_SmithingCreation_HaveMaterialsOnMouseEnter(control) end
function ZO_SmithingCreation_HaveKnowledgeOnMouseEnter(control) end
function ZO_SmithingCreation_FilterOnMouseExit(control) end
function ZO_SmithingCreation_UniversalStyleItemOnMouseEnter(control) end
function ZO_SmithingCreation_UniversalStyleItemOnMouseExit(control) end
function ZO_SmithingExtraction:New(...) end
function ZO_SmithingExtraction:Initialize(control, owner, refinementOnly) end
function ZO_SmithingExtraction:SetCraftingType(craftingType, oldCraftingType, isCraftingTypeDifferent) end
function ZO_SmithingExtraction:SetHidden(hidden) end
function ZO_SmithingExtractionInventory:New(...) end
function ZO_SmithingExtractionInventory:Initialize(owner, control, refinementOnly, ...) end
function ZO_SmithingExtractionInventory:AddListDataTypes() end
function ZO_SmithingExtractionInventory:IsLocked(bagId, slotIndex) end
function ZO_SmithingExtractionInventory:ChangeFilter(filterData) end
function ZO_SmithingExtractionInventory:GetCurrentFilterType() end
function ZO_SmithingExtractionInventory:Refresh(data) end
function ZO_SmithingExtractionInventory:ShowAppropriateSlotDropCallouts(bagId, slotIndex) end
function ZO_SmithingExtractionInventory:HideAllSlotDropCallouts() end
function ZO_SmithingImprovement:New(...) end
function ZO_SmithingImprovement:Initialize(control, owner) end
function ZO_SmithingImprovement:SetHidden(hidden) end
function ZO_SmithingImprovement:InitializeSlots() end
function ZO_SmithingImprovement:SetCraftingType(craftingType, oldCraftingType, isCraftingTypeDifferent) end
function ZO_SmithingImprovement:OnItemReceiveDrag(slotControl, bagId, slotIndex) end
function ZO_SmithingImprovement:OnMouseEnterInventoryRow(quality) end
function ZO_SmithingImprovement:OnMouseExitInventoryRow() end
function ZO_SmithingImprovement:OnSlotChanged() end
function ZO_SmithingImprovement:Improve() end
function ZO_SmithingImprovement:SetupResultTooltip(...) end
function ZO_SmithingImprovementInventory:New(...) end
function ZO_SmithingImprovementInventory:Initialize(owner, control, ...) end
function ZO_SmithingImprovementInventory:IsLocked(bagId, slotIndex) end
function ZO_SmithingImprovementInventory:ChangeFilter(filterData) end
function ZO_SmithingImprovementInventory:Refresh(data) end
function ZO_SmithingImprovementInventory:ShowAppropriateSlotDropCallouts(bagId, slotIndex) end
function ZO_SmithingImprovementInventory:HideAllSlotDropCallouts() end
function ZO_SmithingImprovementInventory:AddListDataTypes() end
function ZO_SmithingResearch:New(...) end
function ZO_SmithingResearch:Initialize(control, owner) end
function ZO_SharedSmithingResearch:SetHidden(hidden) end
function ZO_SmithingResearch:InitializeFilterTypeBar() end
function ZO_SmithingResearch:RefreshAvailableFilters() end
function ZO_SmithingResearch:SetupTooltip(row) end
function ZO_SmithingResearch:ClearTooltip(row) end
function ZO_SmithingResearch:Research(overrideRow) end
function ZO_SmithingResearch:GetResearchTimeString(...) end
function ZO_SmithingResearch:GetExtraInfoColor() end
function ZO_SmithingResearch:SetupTraitDisplay(slotControl, researchLine, known, duration, traitIndex) end
function ZO_SmithingResearch:RefreshCurrentResearchStatusDisplay(currentlyResearching, maxResearchable) end
function ZO_SmithingResearchSelect:New(...) end
function ZO_SmithingResearchSelect:Initialize(control) end
function ZO_SmithingResearchSelect:SetupDialog(craftingType, researchLineIndex, traitIndex) end
function ZO_SmithingResearchSelect_OnInitialize(control) end
function ZO_Smithing:New(...) end
function ZO_Smithing:Initialize(control) end
function ZO_Smithing:InitializeKeybindStripDescriptors() end
function ZO_Smithing:InitializeModeBar() end
function ZO_Smithing:OnItemReceiveDrag(slotControl, bagId, slotIndex) end
function ZO_Smithing:SetMode(mode) end
function ZO_Smithing_Initialize(control) end
function ZO_Alchemy_DoesAlchemyItemPassFilter(bagId, slotIndex, filterType) end
function ZO_Alchemy_GetTraitInfo(traitIndex, ...) end
function ZO_Alchemy_IsAlchemyItem(bagId, slotIndex) end
function ZO_Alchemy_IsThirdAlchemySlotUnlocked() end
function ZO_Alchemy_IsSceneShowing() end
function ZO_SharedAlchemy:Initialize(control) end
function ZO_SharedAlchemy:InitializeSharedEvents() end
function ZO_SharedAlchemy:InitializeInventory() end
function ZO_SharedAlchemy:InitializeTooltip() end
function ZO_SharedAlchemy:InitializeKeybindStripDescriptors() end
function ZO_SharedAlchemy:InitializeScenes() end
function ZO_SharedAlchemy:GetReagentSlotOffset(thirdSlotUnlocked) end
function ZO_SharedAlchemy:UpdateTooltipLayout() end
function ZO_SharedAlchemy:InitializeSlots() end
function ZO_SharedAlchemy:UpdateThirdAlchemySlot() end
function ZO_SharedAlchemy:CanItemBeAddedToCraft(bagId, slotIndex) end
function ZO_SharedAlchemy:CreateInteractScene(name) end
function ZO_SharedAlchemy:IsItemAlreadySlottedToCraft(bagId, slotIndex) end
function ZO_SharedAlchemy:AddItemToCraft(bagId, slotIndex) end
function ZO_SharedAlchemy:RemoveItemFromCraft(bagId, slotIndex) end
function ZO_SharedAlchemy:SetSolventItem(bagId, slotIndex) end
function ZO_SharedAlchemy:FindNextSlotToInsertReagent() end
function ZO_SharedAlchemy:SetReagentItem(reagentSlot, bagId, slotIndex) end
function ZO_SharedAlchemy:OnReagentSlotChanged() end
function ZO_SharedAlchemy:HasTraitMatch(traitName) end
function ZO_SharedAlchemy:HasTraitCancelled(traitName) end
function ZO_SharedAlchemy:SetupTraitIcon(textureControl, name, icon, matchIcon, conflictIcon, unknownTexture) end
function ZO_SharedAlchemy:FindAlreadySlottedReagent(bagId, slotIndex) end
function ZO_SharedAlchemy:ShowAppropriateSlotDropCallouts(craftingSubItemType, rankRequirement) end
function ZO_SharedAlchemy:HideAllSlotDropCallouts() end
function ZO_SharedAlchemy:OnInventoryUpdate(validItemIds) end
function ZO_SharedAlchemy:IsSlotted(bagId, slotIndex) end
function ZO_SharedAlchemy:ClearSelections() end
function ZO_SharedAlchemy:HasSelections() end
function ZO_SharedAlchemy:IsCraftable() end
function ZO_SharedAlchemy:Create() end
function ZO_SharedAlchemy:GetAllCraftingBagAndSlots() end
function ZO_SharedAlchemy:OnSlotChanged() end
function ZO_SharedAlchemy:FindReagentSlotIndexBySlotControl(slotControl) end
function ZO_SharedAlchemy:UpdateTooltip() end
function ZO_AlchemyReagentSlot:New(...) end
function ZO_AlchemyReagentSlot:Initialize(owner, control, emptyTexture, placeSound, removeSound, usabilityPredicate, craftingInventory, emptySlotIcon) end
function ZO_AlchemyReagentSlot:ShowDropCallout(isCorrectType) end
function ZO_AlchemyReagentSlot:ValidateItemId(validItemIds) end
function ZO_AlchemyReagentSlot:SetItem(bagId, slotIndex, suppressSound, ignoreUsabilityRequirement) end
function ZO_AlchemyReagentSlot:UpdateTraits() end
function ZO_AlchemyReagentSlot:SetTraits(unknownTraitTexture, ...) end
function ZO_AlchemyReagentSlot:ClearTraits(unknownTraitTexture) end
function ZO_AlchemyReagentSlot:MeetsUsabilityRequirement() end
function ZO_AlchemyReagentSlot:ShowSlotTraits(showTraits) end
function ZO_SharedCraftingInventory:New(...) end
function ZO_SharedCraftingInventory:Initialize(control, slotType, connectInfoFn, connectInfoControl) end
function ZO_SharedCraftingInventory:InitializeList() end
function ZO_SharedCraftingInventory:AddListDataTypes() end
function ZO_SharedCraftingInventory:OnShow() end
function ZO_SharedCraftingInventory:IsLocked(bagId, slotIndex) end
function ZO_SharedCraftingInventory:GetScrollDataType(bagId, slotIndex) end
function ZO_SharedCraftingInventory:HandleDirtyEvent() end
function ZO_SharedCraftingInventory:PerformFullRefresh() end
function ZO_SharedCraftingInventory:OnItemSelected(selectedData) end
function ZO_SharedCraftingInventory:ShowAppropriateSlotDropCallouts(bagId, slotIndex) end
function ZO_SharedCraftingInventory:HideAllSlotDropCallouts() end
function ZO_SharedCraftingInventory:Refresh(data) end
function ZO_SharedCraftingInventory:ChangeFilter(filterData) end
function ZO_SharedCraftingInventory:SetCustomExtraData(customExtraDataFunction) end
function ZO_SharedCraftingInventory:SetCustomSort(customDataSortFunction) end
function ZO_SharedCraftingInventory:SetVerticalScrollCraftEntryType(type) end
function ZO_SharedCraftingInventory:EnumerateInventorySlotsAndAddToScrollData(predicate, filterFunction, filterType, data) end
function ZO_SharedCraftingInventory:GetStackCount(bagId, slotIndex) end
function ZO_SharedCraftingInventory:Show() end
function ZO_SharedCraftingInventory:Hide() end
function ZO_SharedEnchanting:New(...) end
function ZO_Enchanting_IsSceneShowing() end
function ZO_Enchanting_GetVisibleEnchanting() end
function ZO_Enchanting_IsInCreationMode() end
function ZO_SharedEnchanting:Initialize(control) end
function ZO_SharedEnchanting:InitializeInventory() end
function ZO_SharedEnchanting:InitializeModes() end
function ZO_SharedEnchanting:InitializeEnchantingScenes() end
function ZO_SharedEnchanting:InitializeCreationSlots() end
function ZO_SharedEnchanting:InitializeExtractionSlots() end
function ZO_SharedEnchanting:InitializeKeybindStripDescriptors() end
function ZO_SharedEnchanting:GetEnchantingMode() end
function ZO_SharedEnchanting:GetLastRunestoneSoundParams() end
function ZO_SharedEnchanting:ClearSelections() end
function ZO_SharedEnchanting:HasSelections() end
function ZO_SharedEnchanting:IsCurrentSelected() end
function ZO_SharedEnchanting:IsCraftable() end
function ZO_SharedEnchanting:Create() end
function ZO_SharedEnchanting:GetAllCraftingBagAndSlots() end
function ZO_SharedEnchanting:OnMouseEnterCraftingComponent(bagId, slotIndex) end
function ZO_SharedEnchanting:OnMouseExitCraftingComponent() end
function ZO_SharedEnchanting:OnSlotChanged() end
function ZO_SharedEnchanting:UpdateTooltip() end
function DoesRunePassRequirements(runeType, rankRequirement, rarityRequirement) end
function ZO_SharedEnchanting:IsItemAlreadySlottedToCraft(bagId, slotIndex) end
function ZO_SharedEnchanting:CanItemBeAddedToCraft(bagId, slotIndex) end
function ZO_SharedEnchanting:AddItemToCraft(bagId, slotIndex) end
function ZO_SharedEnchanting:RemoveItemFromCraft(bagId, slotIndex) end
function ZO_SharedEnchanting:SetRuneSlotItem(runeType, bagId, slotIndex) end
function ZO_SharedEnchanting:SetExtractionSlotItem(bagId, slotIndex) end
function ZO_SharedEnchanting:ShowAppropriateSlotDropCallouts(craftingSubItemType, runeType, rankRequirement, rarityRequirement) end
function ZO_SharedEnchanting:HideAllSlotDropCallouts() end
function ZO_SharedEnchanting:OnInventoryUpdate(validItemIds) end
function ZO_SharedEnchanting:IsSlotted(bagId, slotIndex) end
function ZO_SharedEnchantRuneSlot:New(...) end
function ZO_SharedEnchantRuneSlot:Initialize(owner, control, emptyTexture, dropCalloutTexturePositive, dropCalloutTextureNegative, placeSound, removeSound, runeType, craftingInventory, emptySlotIcon) end
function ZO_SharedEnchantRuneSlot:SetItem(bagId, slotIndex) end
function ZO_SharedEnchantRuneSlot:ShowDropCallout(isCorrectType) end
function ZO_SharedEnchantRuneSlot:GetRuneType() end
function ZO_SharedEnchantExtractionSlot:New(...) end
function ZO_SharedEnchantExtractionSlot:Initialize(owner, control, craftingInventory) end
function ZO_SharedEnchantExtractionSlot:ClearDropCalloutTexture() end
function ZO_SharedEnchantExtractionSlot:SetItem(bagId, slotIndex) end
function ZO_SharedEnchantExtractionSlot:ShowDropCallout() end
function ZO_SharedEnchantExtractionSlot:HideDropCallout() end
function ZO_SharedEnchantExtractionSlot:SetBackdrop(bagId, slotIndex) end
function ZO_SharedEnchantingSlotAnimation:New(...) end
function ZO_SharedEnchantingSlotAnimation:Initialize(...) end
function ZO_SharedEnchantingSlotAnimation:GetAnimationOffset(slot) end
function ZO_SharedEnchantingSlotAnimation:GetLockInSound(slot) end
function ZO_Provisioner_AddSceneName(sceneName) end
function ZO_Provisioner_GetVisibleSceneName() end
function ZO_Provisioner_IsSceneShowing() end
function ZO_SharedProvisioner:New(...) end
function ZO_SharedProvisioner:Initialize(control) end
function ZO_SharedProvisioner:CreateInteractScene(sceneName) end
function ZO_SharedProvisioner:SetupMainInteractScene(mainInteractScene) end
function ZO_SharedProvisioner:PerformDeferredInitialization() end
function ZO_SharedProvisioner:DirtyRecipeList() end
function ZO_SharedProvisioner:ShouldShowForControlScheme() end
function ZO_SharedProvisioner:StartInteract() end
function ZO_SharedProvisioner:StartHide() end
function ZO_SharedProvisioner:SetDetailsEnabled(enabled) end
function ZO_SharedProvisioner:PassesProvisionerLevelReq(provisionerLevelReq) end
function ZO_SharedProvisioner:PassesQualityLevelReq(qualityReq) end
function ZO_SharedProvisioner:CalculateHowManyCouldBeCreated(recipeListIndex, recipeIndex, numIngredients) end
function ZO_SharedProvisioner:DoesRecipePassFilter(specialIngredientType, checkNumCreatable, numCreatable, checkSkills, provisionerLevelReq, qualityReq) end
function ZO_Provisioning_IsSceneShowing() end
function ZO_SharedSmithingCreation:New(...) end
function ZO_SharedSmithingCreation:Initialize(control, owner) end
function ZO_SharedSmithingCreation:OnUpdate() end
function ZO_SharedSmithingCreation:SetCraftingType(craftingType, oldCraftingType, isCraftingTypeDifferent) end
function ZO_SharedSmithingCreation:HandleDirtyEvent() end
function ZO_SharedSmithingCreation:GetCreateTooltipSound() end
function ZO_SharedSmithingCreation:RefreshVisiblePatterns() end
function ZO_SharedSmithingCreation:RefreshAllLists() end
function ZO_SharedSmithingCreation:OnRefreshAllLists() end
function ZO_SharedSmithingCreation:GetSelectedPatternIndex() end
function ZO_SharedSmithingCreation:GetSelectedMaterialIndex() end
function ZO_SharedSmithingCreation:GetSelectedMaterialQuantity() end
ZO_SharedSmithingCreation:GetSelectedItemStyleId()-- 2017-8-25 Assembler Maniac - was GetSelectedStyleIndex
function ZO_SharedSmithingCreation:GetSelectedTraitIndex() end
function ZO_SharedSmithingCreation:GetIsUsingUniversalStyleItem() end
function ZO_SharedSmithingCreation:GetAllCraftingParameters() end
function ZO_SharedSmithingCreation:GetAllNonTraitCraftingParameters() end
function ZO_SharedSmithingCreation:OnSelectedPatternChanged(patternData, selectedDuringRebuild) end
function ZO_SharedSmithingCreation:SelectValidKnowledgeIndices() end
function ZO_SharedSmithingCreation:OnFilterChanged(haveMaterialsChecked, haveKnowledgeChecked, useUniversalStyleItemChecked) end
function ZO_SharedSmithingCreation:ChangeTypeFilter(filterData) end
function ZO_SharedSmithingCreation:OnHorizonalScrollListCleared(list) end
function ZO_SharedSmithingCreation:IsInvalidMode() end
function ZO_SharedSmithingCreation:InitializePatternList(scrollListControl, listSlotTemplate) end
function ZO_SharedSmithingCreation:GetMaterialInformation(data) end
function ZO_SharedSmithingCreation:InitializeMaterialList(scrollListControl, spinnerControl, hideSpinnerWhenRankRequirementNotMet, listSlotTemplate) end
function ZO_SharedSmithingCreation:InitializeStyleList(scrollListControl, styleUnknownFont, notEnoughInInventoryFont, listSlotTemplate) end
function ZO_SharedSmithingCreation:OnStyleChanged(selectedData) end
function ZO_SharedSmithingCreation:InitializeTraitList(scrollListControl, traitUnknownFont, notEnoughInInventoryFont, listSlotTemplate) end
function ZO_SharedSmithingCreation:DoesPatternPassFilter(patternData) end
function ZO_SharedSmithingCreation:CreatePatternList() end
function ZO_SharedSmithingCreation:RefreshPatternList() end
function ZO_SharedSmithingCreation:DoesMaterialPassFilter(data) end
function ZO_SharedSmithingCreation:GenerateMaterialDataForPattern(patternIndex) end
function ZO_SharedSmithingCreation:RefreshMaterialList(patternData) end
function ZO_SharedSmithingCreation:DoesStylePassFilter(styleIndex, alwaysHideIfLocked) end
function ZO_SharedSmithingCreation:RefreshStyleList() end
function ZO_SharedSmithingCreation:DoesTraitPassFilter(traitIndex, traitType) end
function ZO_SharedSmithingCreation:RefreshTraitList() end
function ZO_SharedSmithingCreation:UpdateTooltip() end
function ZO_SharedSmithingCreation:UpdateTooltipInternal() end
function ZO_SharedSmithingCreation:AdjustCurrentMaterialQuantityForAllPatterns(updatedQuantity) end
function ZO_SharedSmithingCreation:SetMaterialQuantity(patternIndex, materialIndex, quantity) end
function ZO_SharedSmithingCreation:GetMaterialQuantity(patternIndex, materialIndex) end
function ZO_SharedSmithingCreation:AreSelectionsValid() end
function ZO_SharedSmithingCreation:IsCraftable() end
function ZO_SharedSmithingCreation:IsCraftableWithoutTrait() end
function ZO_SharedSmithingCreation:Create() end
function ZO_SharedSmithingCreation:GetUniversalStyleItemLink() end
function ZO_SharedSmithingCreation:TriggerUSITutorial() end
function ZO_SmithingExtractionSlot:New(...) end
function ZO_SmithingExtractionSlot:Initialize(owner, control, craftingInventory) end
function ZO_SmithingExtractionSlot:SetItem(bagId, slotIndex) end
function ZO_SmithingExtractionSlot:WouldBagAndSlotBeInRawMaterialMode(bagId, slotIndex) end
function ZO_SmithingExtractionSlot:SetupItem(bagId, slotIndex) end
function ZO_SmithingExtractionSlot:OnFilterChanged(filterType, inventoryFilerType) end
function ZO_SmithingExtractionSlot:ShowDropCallout() end
function ZO_SharedSmithingExtraction:New(...) end
function ZO_SharedSmithingExtraction:Initialize(extractionSlotControl, extractLabel, owner, refinementOnly) end
function ZO_SharedSmithingExtraction:InitExtractionSlot(sceneName) end
function ZO_SharedSmithingExtraction_GetRawMaterialItemTypeForCraftingType(craftingType) end
function ZO_SharedSmithingExtraction_DoesItemMeetRefinementStackRequirement(bagId, slotIndex, stackCount) end
function ZO_SharedSmithingExtraction_GetPrimaryFilterType(...) end
function ZO_SharedSmithingExtraction_GetFilterTypeFromItem(bagId, slotIndex) end
function ZO_SharedSmithingExtraction_IsExtractableOrRefinableItem(bagId, slotIndex) end
function ZO_SharedSmithingExtraction_DoesItemPassFilter(bagId, slotIndex, filterType) end
function ZO_SharedSmithingExtraction:OnInventoryUpdate(validItemIds) end
function ZO_SharedSmithingExtraction:ShowAppropriateSlotDropCallouts() end
function ZO_SharedSmithingExtraction:HideAllSlotDropCallouts() end
function ZO_SharedSmithingExtraction:OnSlotChanged() end
function ZO_SharedSmithingExtraction:OnItemReceiveDrag(slotControl, bagId, slotIndex) end
function ZO_SharedSmithingExtraction:IsItemAlreadySlottedToCraft(bagId, slotIndex) end
function ZO_SharedSmithingExtraction:CanItemBeAddedToCraft(bagId, slotIndex) end
function ZO_SharedSmithingExtraction:AddItemToCraft(bagId, slotIndex) end
function ZO_SharedSmithingExtraction:RemoveItemFromCraft(bagId, slotIndex) end
function ZO_SharedSmithingExtraction:SetExtractionSlotItem(bagId, slotIndex) end
function ZO_SharedSmithingExtraction:IsSlotted(bagId, slotIndex) end
function ZO_SharedSmithingExtraction:Extract() end
function ZO_SharedSmithingExtraction:IsExtractable() end
function ZO_SharedSmithingExtraction:HasSelections() end
function ZO_SharedSmithingExtraction:ClearSelections() end
function ZO_SharedSmithingExtraction:GetFilterType() end
function ZO_SharedSmithingImprovement:New(...) end
function ZO_SharedSmithingImprovement:Initialize(listControl, boosterContainerControl, resultTooltipControl, owner) end
function ZO_SharedSmithingImprovement:InitializeRows() end
function ZO_SharedSmithingImprovement:HandleDirtyEvent() end
function ZO_SharedSmithingImprovement:SetCraftingType(craftingType, oldCraftingType, isCraftingTypeDifferent) end
function ZO_SharedSmithingImprovement:Refresh() end
function ZO_SharedSmithingImprovement:GetBoosterRowForQuality(quality) end
function ZO_SharedSmithingImprovement:OnInventoryUpdate(validItemIds) end
function ZO_SharedSmithingImprovement:ShowAppropriateSlotDropCallouts() end
function ZO_SharedSmithingImprovement:HideAllSlotDropCallouts() end
function ZO_SharedSmithingImprovement:FindMaxBoostersToApply() end
function ZO_SharedSmithingImprovement:GetRowForSelection() end
function ZO_SharedSmithingImprovement:GetCurrentImprovementParams() end
function ZO_SharedSmithingImprovement:RefreshImprovementChance() end
function ZO_SharedSmithingImprovement:GetNumBoostersToApply() end
function ZO_SharedSmithingImprovement:IsItemAlreadySlottedToCraft(bagId, slotIndex) end
function ZO_SharedSmithingImprovement:CanItemBeAddedToCraft(bagId, slotIndex) end
function ZO_SharedSmithingImprovement:AddItemToCraft(bagId, slotIndex) end
function ZO_SharedSmithingImprovement:RemoveItemFromCraft(bagId, slotIndex) end
function ZO_SharedSmithingImprovement:SetImprovementSlotItem(bagId, slotIndex) end
function ZO_SharedSmithingImprovement:OnFilterChanged(filterType) end
function ZO_SharedSmithingImprovement:IsImprovable() end
function ZO_SharedSmithingImprovement:HasSelections() end
function ZO_SharedSmithingImprovement:ClearSelections() end
function ZO_SharedSmithingImprovement:IsSlotted(bagId, slotIndex) end
function ZO_SharedSmithingImprovement:SharedImprove(dialogName) end
function ZO_SmithingImprovementSlot:New(...) end
function ZO_SmithingImprovementSlot:Initialize(owner, control, slotType, craftingInventory) end
function ZO_SmithingImprovementSlot:SetItem(bagId, slotIndex) end
function ZO_SmithingImprovementSlot:OnFilterChanged(filterType) end
function ZO_SmithingImprovementSlot:ShowDropCallout() end
function ZO_SharedSmithingImprovement_GetBoosterChartStringForCraftingType(craftingType) end
function ZO_SharedSmithingImprovement_GetImprovementTooltipSounds() end
function ZO_SharedSmithingImprovement_CanItemBeImproved(bagId, slotIndex) end
function ZO_SharedSmithingImprovement_GetPrimaryFilterType(...) end
function ZO_SharedSmithingImprovement_DoesItemPassFilter(bagId, slotIndex, filterType) end
function ZO_SharedSmithingResearch:New(...) end
function ZO_SharedSmithingResearch:Initialize(control, owner, slotContainerName) end
function ZO_SharedSmithingResearch:ChangeTypeFilter(filterData) end
function ZO_SharedSmithingResearch:SetCraftingType(craftingType, oldCraftingType, isCraftingTypeDifferent) end
function ZO_SharedSmithingResearch:InitializeResearchLineList(scrollListControl, listSlotContainerName) end
function ZO_SharedSmithingResearch:OnControlsAcquired() end
function ZO_SharedSmithingResearch:HandleDirtyEvent() end
function ZO_SharedSmithingResearch:GenerateResearchTraitCounts(virtualInventoryList, craftingType, researchLineIndex, numTraits) end
function ZO_SharedSmithingResearch:FindResearchingTraitIndex(craftingType, researchLineIndex, numTraits) end
function ZO_SharedSmithingResearch:Refresh() end
function ZO_SharedSmithingResearch:RefreshCurrentResearchStatusDisplay(currentlyResearching, maxResearchable) end
function ZO_SharedSmithingResearch:ShowTraitsFor(data) end
function ZO_SharedSmithingResearch:ActivateHighlight(row) end
function ZO_SharedSmithingResearch:DeactivateHighlight(row) end
function ZO_SharedSmithingResearch:OnResearchRowActivate(row) end
function ZO_SharedSmithingResearch:OnResearchRowDeactivate(row) end
function ZO_SharedSmithingResearch:IsResearchable() end
function ZO_SharedSmithingResearch:GetSelectedData() end
function ZO_SharedSmithingResearchSelect:New(...) end
function ZO_SharedSmithingResearchSelect:Initialize(control) end
function ZO_SharedSmithingResearch:CanResearchCurrentTraitLine() end
function ZO_Smithing_AddScene(name, owner) end
function ZO_Smithing_IsSceneShowing() end
function ZO_Smithing_GetActiveObject() end
function ZO_Smithing_IsSmithingStation(craftingType) end
function ZO_Smithing_Common:New(...) end
function ZO_Smithing_Common:Initialize(control) end
function ZO_Smithing_Common:CreateInteractScene(sceneName) end
function ZO_Smithing_Common:GetTutorialTrigger(craftingType, mode) end
function ZO_Smithing_Common:DirtyAllPanels() end
function ZO_Smithing_Common:IsItemAlreadySlottedToCraft(bagId, slotIndex) end
function ZO_Smithing_Common:CanItemBeAddedToCraft(bagId, slotIndex) end
function ZO_Smithing_Common:AddItemToCraft(bagId, slotIndex) end
function ZO_Smithing_Common:RemoveItemFromCraft(bagId, slotIndex) end
function ZO_Smithing_Common:DoesCurrentModeHaveSlotAnimations() end
function ZO_Smithing_Common:IsImproving() end
function ZO_Smithing_Common:IsExtracting() end
function ZO_Smithing_Common:IsDeconstructing() end
function ZO_Smithing_Common:OnSelectedPatternChanged() end
function ZO_Smithing_Common:OnMaterialChanged() end
function ZO_Smithing_Common:OnSelectedStyleChanged() end
function ZO_Smithing_Common:OnSelectedTraitChanged() end
function ZO_Smithing_Common:OnImprovementSlotChanged() end
function ZO_Smithing_Common:OnExtractionSlotChanged() end
function ZO_Smithing_Common:OnResearchSlotChanged() end
function ZO_SmithingHorizontalListTemplate_OnInitialized(control) end
--ingame\currency
function ZO_CurrencyControl_InitializeDisplayTypes(control, ...) end
function ZO_CurrencyControl_SetCurrencyData(control, currencyType, amount, showAll, notEnough, entryIndex, offset) end
function ZO_CurrencyControl_FormatCurrency(amount, useShortFormat) end
function ZO_CurrencyControl_FormatCurrencyAndAppendIcon(amount, useShortFormat, currencyType, isGamepad) end
function ZO_CurrencyControl_BuildCurrencyString(currencyType, currencyAmount) end
function ZO_CurrencyTemplate_OnMouseEnter(control) end
function ZO_CurrencyTemplate_OnMouseExit(control) end
function ZO_CurrencyControl_SetSimpleCurrency(self, currencyType, amount, options, showAll, notEnough) end
function ZO_CurrencyControl_SetCurrency(self, options) end
function ZO_CurrencyControl_SetClickHandler(self, handler) end
function ZO_Currency_GetPlatformFormattedGoldIcon() end
function ZO_SetupInventoryItemOptionsCurrencyColor() end
function ZO_CurrencySelectorDigitSpinner_Gamepad:New(...) end
function ZO_CurrencySelectorDigitSpinner_Gamepad:Initialize(control, min, max, isGamepad, spinnerMode, accelerationTime, magnitudeQueryFunction, owner) end
function ZO_CurrencySelectorDigit_Gamepad:New(...) end
function ZO_CurrencySelectorDigit_Gamepad:Initialize(control, valueChangedCallback) end
function ZO_CurrencySelectorDigit_Gamepad:SetHidden(hidden) end
function ZO_CurrencySelectorDigit_Gamepad:SetValue(value) end
function ZO_CurrencySelectorDigit_Gamepad:GetValue() end
function ZO_CurrencySelectorDigit_Gamepad:SetAlpha(alpha) end
function ZO_CurrencySelectorDigit_Gamepad:SetTextColor(color) end
function ZO_CurrencySelectorDigit_Gamepad:UpdateTextColor() end
function ZO_CurrencySelectorDigit_Gamepad:SetActive(active) end
function ZO_CurrencySelectorDigit_Gamepad:Activate() end
function ZO_CurrencySelectorDigit_Gamepad:Deactivate() end
function ZO_CurrencySelectorDigit_Gamepad:AnimateButtons(previousValue, newValue, buttonReleased) end
function ZO_CurrencySelector_Gamepad:New(...) end
function ZO_CurrencySelector_Gamepad:Initialize(control) end
function ZO_CurrencySelector_Gamepad:SetTextColor(color) end
function ZO_CurrencySelector_Gamepad:SetValue(value) end
function ZO_CurrencySelector_Gamepad:GetValue() end
function ZO_CurrencySelector_Gamepad:UpdateDigits() end
function ZO_CurrencySelector_Gamepad:GetMaxValue() end
function ZO_CurrencySelector_Gamepad:SetMaxValue(maxValue) end
function ZO_CurrencySelector_Gamepad:SetClampValues(clampGreaterThanMax) end
function ZO_CurrencySelector_Gamepad:CalculateNumDigits() end
function ZO_CurrencySelector_Gamepad:UpdateDigitVisibility() end
function ZO_CurrencySelector_Gamepad:Clear() end
function ZO_CurrencySelector_Gamepad:Activate() end
function ZO_CurrencySelector_Gamepad:Deactivate() end
function ZO_CurrencySelector_Gamepad:SetActiveDigit(index) end
function ZO_CurrencySelector_Gamepad:UpdateDirectionalInput() end
--ingame\death
function DeathType:New(control) end
function DeathType:SetDeathRecapToggleButtonEnabled(enabled) end
function DeathType:ToggleDeathRecap() end
function DeathType:GetButtonByKeybind(keybind) end
function DeathType:GetButton(index) end
function DeathType:SetHidden(hidden) end
function DeathType:IsHidden() end
function DeathType:SelectOption(keybind) end
function DeathType:UpdateDisplay() end
function DeathType:UpdateCyclicTimer() end
function ZO_Death_GetResurrectSoulGemText(level) end
function ZO_Death_IsRaidReviveAllowed() end
function ZO_Death_DoesReviveCostRaidLife() end
function DeathType:LayoutHereButton(hereButton) end
function DeathType:LayoutWayshrineButton(wayshrineButton) end
function DeathType:UpdateButtonsEnabled() end
function LayoutDeathRecapToggleButton(deathRecapToggleButton) end
function AvADeath:New(control) end
function AvADeath:UpdateDisplay() end
function ImperialPvPDeath:New(control) end
function ImperialPvPDeath:UpdateDisplay() end
function CyclicRespawnDeath:New(control) end
function CyclicRespawnDeath:UpdateCyclicTimer(timeLeft) end
function ImperialPvEDeath:New(control) end
function ImperialPvEDeath:CheckUpdateTimer() end
function ImperialPvEDeath:UpdateDisplay() end
function BGDeath:New(control) end
function BGDeath:UpdateDisplay() end
function ReleaseOnlyDeath:New(control) end
function ReleaseOnlyDeath:UpdateDisplay() end
function TwoOptionDeath:New(control) end
function TwoOptionDeath:CheckUpdateTimer() end
function TwoOptionDeath:UpdateDisplay() end
function ResurrectPending:New(control) end
function ResurrectPending:UpdateDisplay() end
function InEncounter:New(control) end
function InEncounter:ApplyTemplateToMessage(template) end
function Death:New(control) end
function Death:GetDeathType() end
function Death:SetDeathRecapToggleButtonsEnabled(enabled) end
function Death:UpdateDisplay() end
function Death:UpdateBindingLayer() end
function Death:InitializeCyclicRespawnTimer() end
function Death:StartCyclicRespawnTimer() end
function Death:UpdateCyclicRespawnTimer() end
function Death:StopCyclicRespawnTimer() end
function Death:SelectOption(keybind) end
function ZO_Death_ToggleDeathRecapCallback() end
function Death:ToggleDeathRecap() end
function Death:OnPlayerAlive() end
function Death:OnPlayerDead() end
function Death:OnGamepadPreferredModeChanged() end
function ZO_Death_OnInitialized(self) end
function ZO_Death_OnEffectivelyHidden(self) end
function ZO_Death_OnEffectivelyShown(self) end
function HUDRaidLifeManager:New(...) end
function HUDRaidLifeManager:Initialize(control) end
function HUDRaidLifeManager:RefreshMode() end
function HUDRaidLifeManager:SetHiddenForReason(reason, hidden) end
function HUDRaidLifeManager:ApplyPlatformStyle() end
function ZO_HUDRaidLife_OnInitialized(self) end
function RaidLifeDisplay:New(...) end
function RaidLifeDisplay:Initialize(control) end
function RaidLifeDisplay:SetAnimatedShowHide(animatedShowHide) end
function RaidLifeDisplay:SetShowOnChange(showOnChange) end
function RaidLifeDisplay:SetHiddenForReason(reason, hidden) end
function RaidLifeDisplay:SetShownForReason(reason, shown) end
function RaidLifeDisplay:RefreshVisible(reason) end
function RaidLifeDisplay:RefreshApplicable() end
function RaidLifeDisplay:GetRaidReviveCount() end
function RaidLifeDisplay:GetRaidBonusScore() end
function RaidLifeDisplay:GetPartyTotalScore() end
function RaidLifeDisplay:RefreshCountInstantly() end
function RaidLifeDisplay:RefreshDisplay() end
function RaidLifeDisplay:UpdateTotalScore() end
function RaidLifeDisplay:RefreshCountAnimated() end
function RaidLifeDisplay:OnEffectivelyShown() end
function RaidLifeDisplay:OnPlayerActivated() end
function RaidLifeDisplay:OnRecentlyChangedExpired() end
function RaidLifeDisplay:OnRaidLifeCounterChanged() end
function RaidLifeDisplay:OnRaidTimerStateUpdate() end
function RaidLifeDisplay:OnRaidScoreUpdate() end
function RaidLifeDisplay:OnRaidTrialComplete() end
function RaidLifeDisplay:ApplyPlatformStyle() end
function ZO_RaidLifeDisplay_OnEffectivelyShown(self) end
function ZO_RaidLifeDisplay_OnInitialized(self) end
--ingame\deathrecap
function DeathRecapToggle:New(...) end
function DeathRecapToggle:Initialize(control) end
function DeathRecapToggle:RefreshEnabled() end
function DeathRecapToggle:Toggle() end
function DeathRecapToggle:Hide() end
function DeathRecap:New(...) end
function DeathRecap:Initialize(control) end
function DeathRecap:InitializeAttackPool() end
function DeathRecap:InitializeHintPool() end
function DeathRecap:InitializeTelvarStoneLossLabel() end
function DeathRecap:IsWindowOpen() end
function DeathRecap:SetWindowOpen(open) end
function DeathRecap:IsDeathRecapAvailable() end
function DeathRecap:SetDeathRecapAvailable(available) end
function DeathRecap:RefreshVisibility() end
function DeathRecap:RefreshBossBarVisibility() end
function DeathRecap:RefreshUnitFrameVisibility() end
function DeathRecap:SetupAttacks() end
function DeathRecap:AddHint(text, prevHintControl) end
function DeathRecap:SetupHints() end
function DeathRecap:SetupTelvarStoneLoss() end
function DeathRecap:SetupDeathRecap() end
function DeathRecap:Animate() end
function DeathRecap:OnPlayerAlive() end
function DeathRecap:OnPlayerDead() end
function DeathRecap:OnUnitFramesCreated() end
function DeathRecap:ApplyStyle() end
function DeathRecap:OnGamepadPreferredModeChanged() end
function DeathRecap:UpdateDirectionalInput() end
function DeathRecap:OnEffectivelyShown() end
function DeathRecap:OnEffectivelyHidden() end
function ZO_DeathRecap_OnInitialized(self) end
--ingame\dyeing
function ZO_DyeingToolBase:New(...) end
function ZO_DyeingToolBase:Initialize(owner) end
function ZO_DyeingToolBase:Activate(fromTool, suppressSounds) end
function ZO_DyeingToolBase:Deactivate() end
function ZO_DyeingToolBase:HasSwatchSelection() end
function ZO_DyeingToolBase:HasSavedSetSelection() end
function ZO_DyeingToolBase:GetHighlightRules(dyeSlot, dyeChannel) end
function ZO_DyeingToolBase:OnClicked(dyeableSlot, dyeChannel, button) end
function ZO_DyeingToolBase:OnLeftClicked(slot, dyeChannel) end
function ZO_DyeingToolBase:OnRightClicked(dyeableSlot, dyeChannel) end
function ZO_DyeingToolBase:OnSavedSetClicked(dyeSetIndex, dyeChannel, button) end
function ZO_DyeingToolBase:OnSavedSetLeftClicked(dyeSetIndex, dyeChannel) end
function ZO_DyeingToolBase:OnSavedSetRightClicked(dyeSetIndex, dyeChannel) end
function ZO_DyeingToolBase:GetCursorType(dyeableSlot, dyeChannel) end
function ZO_DyeingToolDye:New(...) end
function ZO_DyeingToolDye:Initialize(owner) end
function ZO_DyeingToolDye:Activate(fromTool, suppressSounds) end
function ZO_DyeingToolDye:OnLeftClicked(dyeableSlot, dyeChannel) end
function ZO_DyeingToolDye:OnSavedSetLeftClicked(dyeSetIndex, dyeChannel) end
function ZO_DyeingToolDye:GetCursorType(dyeableSlot, dyeChannel) end
function ZO_DyeingToolErase:New(...) end
function ZO_DyeingToolErase:Initialize(owner) end
function ZO_DyeingToolErase:Activate(fromTool, suppressSounds) end
function ZO_DyeingToolErase:HasSwatchSelection() end
function ZO_DyeingToolErase:OnLeftClicked(dyeableSlot, dyeChannel) end
function ZO_DyeingToolErase:OnSavedSetLeftClicked(dyeSetIndex, dyeChannel) end
function ZO_DyeingToolErase:GetCursorType(dyeableSlot, dyeChannel) end
function ZO_DyeingToolFill:New(...) end
function ZO_DyeingToolFill:Initialize(owner) end
function ZO_DyeingToolFill:Activate(fromTool, suppressSounds) end
function ZO_DyeingToolFill:GetHighlightRules(dyeableSlot, dyeChannel) end
function ZO_DyeingToolFill:OnLeftClicked(_, dyeChannel) end
function ZO_DyeingToolFill:OnSavedSetLeftClicked(_, dyeChannel) end
function ZO_DyeingToolFill:GetCursorType(dyeableSlot, dyeChannel) end
function ZO_DyeingToolSample:New(...) end
function ZO_DyeingToolSample:Initialize(owner) end
function ZO_DyeingToolSample:Activate(fromTool, suppressSounds) end
function ZO_DyeingToolSample:HasSwatchSelection() end
function ZO_DyeingToolSample:OnLeftClicked(dyeableSlot, dyeChannel) end
function ZO_DyeingToolSample:OnSavedSetLeftClicked(dyeSetIndex, dyeChannel) end
function ZO_DyeingToolSample:GetCursorType(dyeableSlot, dyeChannel) end
function ZO_DyeingToolSetFill:New(...) end
function ZO_DyeingToolSetFill:Initialize(owner) end
function ZO_DyeingToolSetFill:Activate(fromTool, suppressSounds) end
function ZO_DyeingToolSetFill:HasSwatchSelection() end
function ZO_DyeingToolSetFill:HasSavedSetSelection() end
function ZO_DyeingToolSetFill:GetHighlightRules(dyeableSlot, dyeChannel) end
function ZO_DyeingToolSetFill:OnLeftClicked(dyeableSlot, dyeChannel) end
function ZO_DyeingToolSetFill:OnSavedSetLeftClicked(dyeSetIndex, dyeChannel) end
function ZO_DyeingToolSetFill:GetCursorType(dyeableSlot, dyeChannel) end
function ZO_Dyeing_DyeableSlotGamepadSortComparator(left, right) end
function ZO_Dyeing_InitializeDyeableSlotsTables() end
function ZO_Dyeing_GetAchivementText(dyeKnown, achievementId, nonPlayerDye) end
function ZO_Dyeing_InitializeSwatchPool(owner, sharedHighlight, parentControl, template, canSelectLocked, highlightDimensions) end
function ZO_Dyeing_DyeSortComparator(left, right) end
function ZO_Dyeing_RefreshDyeableSlotControlDyes_Colors(slotControl, dyeableSlot, ...) end
function ZO_Dyeing_RefreshDyeableSlotControlDyes(slotControl, dyeableSlot) end
function ZO_Dyeing_GetActiveOffhandDyeableSlot() end
function ZO_DyeingUtils_SetSlotDyeSwatchDyeId(dyeChannel, dyeControl, dyeId, isDyeable) end
function ZO_DyeingUtils_GetHeaderTextFromSortType(sortStyleType, rarityOrHueCategory) end
function ZO_Dyeing_UniformRandomize(mode, getRandomUnlockedDyeIdFunction) end
function ZO_Dyeing_AreTherePendingDyes(mode) end
function ZO_Dyeing_AreAllItemsBound(mode) end
function ZO_Dyeing_GetOppositeOffHandDyeableSlot(activeWeaponPair) end
function ZO_Dyeing_GetSlotsForMode(mode) end
function ZO_Dyeing_LayoutSwatches(includeLocked, sortStyle, swatchPool, headerPool, layoutOptions, container) end
function ZO_DyeingSwatch_OnMouseEnter(swatch) end
function ZO_DyeingSwatch_OnMouseExit(swatch) end
function ZO_Dyeing_ClearTooltipOnMouseExit() end
function ZO_Character_GetEmptyDyeableSlotTexture(dyeableSlot) end
function Dyeing_Manager:New(...) end
function Dyeing_Manager:RegisterForDyeListUpdates(callback) end
function Dyeing_Manager:UpdateAllDyeLists() end
function ZO_DyeStamp_Confirmation_Base:New(...) end
function ZO_DyeStamp_Confirmation_Base:Initialize(control, scene) end
function ZO_DyeStamp_Confirmation_Base:PreviewDyeStamp() end
function ZO_DyeStamp_Confirmation_Base:InitializeKeybindStripDescriptors() end
function ZO_DyeStamp_Confirmation_Base:AddExitKey() end
function ZO_DyeStamp_Confirmation_Base:ShowPreviewedDyeStamp() end
function ZO_DyeStamp_Confirmation_Base:SetTargetItem(bagId, slotIndex) end
function ZO_DyeStamp_Confirmation_Base:OnShown() end
function ZO_DyeStamp_Confirmation_Base:OnHidden() end
function ZO_DyeStamp_Confirmation_Base:ShowConfirmationDialog() end
function ZO_DyeStamp_Confirmation_Base:ConfirmUseDyeStamp() end
function ZO_DyeStamp_Confirmation_Base:EndConfirmation() end
function ZO_Dyeing_Gamepad_Highlight(control, dyeControl) end
function ZO_Dyeing_RadialMenu_Gamepad:New(control, template, sharedHighlight) end
function ZO_Dyeing_RadialMenu_Gamepad:Initialize(sharedHighlight, ...) end
function ZO_Dyeing_RadialMenu_Gamepad:ResetToDefaultPositon() end
function ZO_Dyeing_RadialMenu_Gamepad:FocusAll() end
function ZO_Dyeing_RadialMenu_Gamepad:DefocusAll() end
function ZO_Dyeing_RadialMenu_Gamepad:HighlightAll(dyeSlot) end
function ZO_Dyeing_RadialMenu_Gamepad:OnSelectionChanged(entry) end
function ZO_Dyeing_RadialMenu_Gamepad:SetOnSelectionChangedCallback(callback) end
function ZO_Dyeing_RadialMenu_Gamepad:Activate(...) end
function ZO_Dyeing_RadialMenu_Gamepad:Deactivate(...) end
function ZO_Dyeing_RadialMenu_Gamepad:Show(...) end
function ZO_Dyeing_Gamepad:New(...) end
function ZO_Dyeing_Gamepad:Initialize(control) end
function ZO_Dyeing_Gamepad:SetMode(mode) end
function ZO_Dyeing_Gamepad:GetMode() end
function ZO_Dyeing_Gamepad:InitializeModeList() end
function ZO_Dyeing_Gamepad:UpdateOptionLeftTooltip(mode) end
function ZO_Dyeing_Gamepad:InitializeKeybindStripDescriptorsRoot() end
function ZO_Dyeing_Gamepad:CancelExit() end
function ZO_Dyeing_Gamepad:ExitWithoutSave() end
function ZO_Dyeing_Gamepad:UndoPendingChanges() end
function ZO_Dyeing_Gamepad:AttemptExit() end
function ZO_Dyeing_Gamepad:ConfirmCommitSelection() end
function ZO_Dyeing_Slots_Panel_Gamepad:New(...) end
function ZO_Dyeing_Slots_Panel_Gamepad:Initialize(control, owner, scene) end
function ZO_Dyeing_Slots_Panel_Gamepad:InitializeKeybindDescriptors() end
function ZO_GamepadDyeingSortRow_Setup(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_Dyeing_Slots_Panel_Gamepad:OnDropdownDeactivated() end
function ZO_Dyeing_Slots_Panel_Gamepad:UpdateDyeSortingDropdownOptions(dropdown) end
function ZO_Dyeing_Slots_Panel_Gamepad:UpdateDyeSortingDropdownSelection(dropdown) end
function ZO_Dyeing_Slots_Panel_Gamepad:InitializeOptionsDialog() end
function ZO_Dyeing_Slots_Panel_Gamepad:RefreshSavedSet(dyeSetIndex) end
function ZO_Dyeing_Slots_Panel_Gamepad:RefreshSavedSets() end
function ZO_Dyeing_Slots_Panel_Gamepad:SetupColorPresetControls(parent) end
function ZO_Dyeing_Slots_Panel_Gamepad:SavedSetSelected(control) end
function ZO_Dyeing_Slots_Panel_Gamepad:PerformDeferredInitialization() end
function ZO_Dyeing_Slots_Panel_Gamepad:ActivateDyeItemsHeader() end
function ZO_Dyeing_Slots_Panel_Gamepad:OnDyeingPaneFocusChanged(control, activated) end
function ZO_Dyeing_Slots_Panel_Gamepad:ResetScreen(retainSelections, retainBackgroundFocus) end
function ZO_Dyeing_Slots_Panel_Gamepad:RefreshPresetListEntry(control, dyeSetIndex) end
function ZO_Dyeing_Slots_Panel_Gamepad:SwitchToSetPresetList() end
function ZO_Dyeing_Slots_Panel_Gamepad:SwitchToSetPresetSwatch() end
function ZO_Dyeing_Slots_Panel_Gamepad:SwitchToSavedSelection() end
function ZO_Dyeing_Slots_Panel_Gamepad:SwitchToDyeSelection() end
function ZO_Dyeing_Slots_Panel_Gamepad:ShowRadialMenu(menu) end
function ZO_Dyeing_Slots_Panel_Gamepad:SwitchToRadialMenu(retainSelections, menu, mode, suppressSound) end
function ZO_Dyeing_Slots_Panel_Gamepad:SwitchToDyeableSlotsSelection(retainSelections, suppressSound) end
function ZO_Dyeing_Slots_Panel_Gamepad:SwitchToActiveRadialMenuMode(...) end
function ZO_Dyeing_Slots_Panel_Gamepad:SwitchToDyeableSlotDyeSelection(selectedControl) end
function ZO_Dyeing_Slots_Panel_Gamepad:SwitchToDyeableSlotDyeMultiSelection(retainPosition) end
function ZO_Dyeing_Slots_Panel_Gamepad:RefreshKeybindStrip() end
function ZO_Dyeing_Slots_Panel_Gamepad:UpdateUnlockedDyes() end
function ZO_Dyeing_Slots_Panel_Gamepad:GetSelectedSavedSetIndex() end
function ZO_Dyeing_Slots_Panel_Gamepad:GetSelectedDyeId() end
function ZO_Dyeing_Slots_Panel_Gamepad:SwitchToDyeingWithDyeId(...) end
function ZO_Dyeing_Slots_Panel_Gamepad:DoesDyeIdExistInPlayerDyes(dyeId) end
function ZO_Dyeing_Slots_Panel_Gamepad:SetSelectedSavedSetIndex(dyeSetIndex) end
function ZO_Dyeing_Slots_Panel_Gamepad:DefaultBack() end
function ZO_Dyeing_Slots_Panel_Gamepad:NavigateBack() end
function ZO_Dyeing_Slots_Panel_Gamepad:ActivateCurrentSelection() end
function ZO_Dyeing_Slots_Panel_Gamepad:CanActivateCurrentSelection() end
function ZO_Dyeing_Slots_Panel_Gamepad:UpdateDirectionalInput() end
function ZO_Dyeing_Slots_Panel_Gamepad:CommitSelection() end
function ZO_Dyeing_Slots_Panel_Gamepad:ConfirmCommitSelection() end
function ZO_Dyeing_Slots_Panel_Gamepad:SwitchToTab(tabIndex) end
function ZO_Dyeing_Slots_Panel_Gamepad:SwitchToTool(newTool) end
function ZO_Dyeing_Slots_Panel_Gamepad:OnDyeSelectionChanged(previousSwatch, newSwatch) end
function ZO_Dyeing_Slots_Panel_Gamepad:AttemptExit() end
function ZO_Dyeing_Slots_Panel_Gamepad:ExitWithoutSave() end
function ZO_Dyeing_Slots_Panel_Gamepad:UndoPendingChanges() end
function ZO_Dyeing_Slots_Panel_Gamepad:OnPendingDyesChanged() end
function ZO_Dyeing_Slots_Panel_Gamepad:OnSavedSetSlotChanged(dyeSetIndex) end
function ZO_Dyeing_Slots_Panel_Gamepad:ClearCenterSwatch() end
function ZO_Dyeing_Slots_Panel_Gamepad:SetupCenterSwatch() end
function ZO_Dyeing_Slots_Panel_Gamepad:SetupRandomizeSwatch() end
function ZO_Dyeing_Slots_Panel_Gamepad:RefreshVisibleRadialMenuSelection() end
function ZO_Dyeing_Slots_Panel_Gamepad:RadialMenuSelectionChanged(selectedEntry) end
function ZO_Dyeing_Slots_Panel_Gamepad:RefreshDyeableSlotDyes(dyeableSlot) end
function ZO_Dyeing_Slots_Panel_Gamepad:GetMode() end
function ZO_Dyeing_Gamepad_OnInitialized(control) end
function ZO_DyeingSavedSlot_Gamepad_Initialize(control) end
function ZO_DyeingSlot_Gamepad_Initialize(control) end
function ZO_Dyeing_Slots_Gamepad:New(control, sharedHighlight) end
function ZO_Dyeing_Slots_Gamepad:SetupDyeableSlot(control, data) end
function ZO_Dyeing_Slots_Gamepad:Populate() end
function ZO_Dyeing_Slots_Gamepad:SetMode(mode) end
function ZO_Dyeing_Swatches_Gamepad:New(...) end
function ZO_Dyeing_Swatches_Gamepad:Initialize(owner, control, sharedHighlight, savedVars, selectionChangedCallback, moveOutCallback, verticalController) end
function ZO_Dyeing_Swatches_Gamepad:Deactivate(retainSelection) end
function ZO_Dyeing_Swatches_Gamepad:Activate() end
function ZO_Dyeing_Swatches_Gamepad:UpdateRowVisible(direction) end
function ZO_Dyeing_Swatches_Gamepad:ChangeSelectedDyeRow(direction) end
function ZO_Dyeing_Swatches_Gamepad:SetSelectedDyeColumn(columnIndex) end
function ZO_Dyeing_Swatches_Gamepad:ChangeSelectedDyeColumn(direction) end
function ZO_Dyeing_Swatches_Gamepad:OnSelectionChanged(previousSwatch, newSwatch, suppressSound) end
function ZO_Dyeing_Swatches_Gamepad:UpdateDirectionalInput() end
function ZO_Dyeing_Swatches_Gamepad:SwitchToDyeingWithDyeId(dyeId) end
function ZO_Dyeing_Swatches_Gamepad:DoesDyeIdExistInPlayerDyes(dyeId) end
function ZO_Dyeing_Swatches_Gamepad:GetSelectedDyeId() end
function ZO_Dyeing_Swatches_Gamepad:GetSelectedSwatch() end
function ZO_Dyeing_Swatches_Gamepad:GetNumUnlockedDyes() end
function ZO_Dyeing_Swatches_Gamepad:GetRandomUnlockedDyeId() end
function ZO_Dyeing_Swatches_Gamepad:RefreshDyeLayout() end
function ZO_Dyeing_Swatches_Gamepad:RefreshDyeLayout_Internal() end
function ZO_DyeStamp_Confirmation_Gamepad:New(...) end
function ZO_DyeStamp_Confirmation_Gamepad:Initialize(control) end
function ZO_DyeStamp_Confirmation_Base:AddExitKey() end
function ZO_DyeStamp_Confirmation_Gamepad:OnShown() end
function ZO_DyeStamp_Confirmation_Gamepad:OnHidden() end
function ZO_DyeStamp_Confirmation_Gamepad:UpdateDirectionalInput() end
function ZO_DyeStamp_Confirmation_Gamepad_OnInitialize(control) end
function ZO_Dyeing:New(...) end
function ZO_Dyeing:Initialize(control) end
function ZO_Dyeing:OnTabFilterChanged(tabData) end
function ZO_Dyeing:SetMode(mode) end
function ZO_Dyeing:HandleTabChange(tabData, nextMode) end
function ZO_Dyeing:InitializeTabs() end
function ZO_Dyeing:LayoutCollectionAppearanceTooltip(tooltip) end
function ZO_Dyeing:OnToolChanged(tool) end
function ZO_Dyeing:InitializeTools() end
function ZO_Dyeing:InitializeSavedSets() end
function ZO_Dyeing:InitializeSwatchPool() end
function ZO_Dyeing:InitializeHeaderPool() end
function ZO_Dyeing:InitializeEquipmentSheet() end
function ZO_Dyeing:InitializeCollectibleSheet() end
function ZO_Dyeing:InitializeSortsAndFilters() end
function ZO_Dyeing:UpdateOptionControls() end
function ZO_Dyeing:InitializeKeybindStripDescriptors() end
function ZO_Dyeing:DirtyDyeLayout() end
function ZO_Dyeing:OnDyeSlotClicked(dyeableSlot, dyeChannel, button) end
function ZO_Dyeing:OnSavedSetDyeSlotClicked(dyeSetIndex, dyeChannel, button) end
function ZO_Dyeing:OnSavedSetDyeSlotExit(dyeSetIndex, dyeChannel) end
function ZO_Dyeing:GetSelectedDyeId() end
function ZO_Dyeing:GetSelectedSavedSetIndex() end
function ZO_Dyeing:GetMousedOverSavedSetInfo() end
function ZO_Dyeing:OnPendingDyesChanged(dyeableSlot) end
function ZO_Dyeing:OnSavedSetSlotChanged(dyeSetIndex) end
function ZO_Dyeing:AttemptExit(exitingToAchievementId) end
function ZO_Dyeing:ConfirmExit(applyChanges) end
function ZO_Dyeing:ConfirmSwitchMode(applyChanges) end
function ZO_Dyeing:CommitSelection() end
function ZO_Dyeing:ConfirmCommitSelection() end
function ZO_Dyeing:CancelExitToAchievements() end
function ZO_Dyeing:CancelExit() end
function ZO_Dyeing:UniformRandomize() end
function ZO_Dyeing:GetRandomUnlockedDyeId() end
function ZO_Dyeing:UndoPendingChanges() end
function ZO_Dyeing:SwitchToDyeingWithDyeId(dyeId, suppressSounds) end
function ZO_Dyeing:DoesDyeIdExistInPlayerDyes(dyeId) end
function ZO_Dyeing:SetSelectedDyeId(dyeId, becauseOfRebuild, becauseToolChange) end
function ZO_Dyeing:SetSelectedSavedSetIndex(dyeSetIndex) end
function ZO_Dyeing:ToggleSavedSetHightlightBySlotControl(slotControl, isHighlighted, dyeChannel) end
function ZO_Dyeing:ToggleSavedSetHightlight(dyeSetIndex, isHighlighted, dyeChannel) end
function ZO_Dyeing:LayoutDyes() end
function ZO_Dyeing:RefreshSavedSet(dyeSetIndex) end
function ZO_Dyeing:RefreshSavedSets() end
function ZO_Dyeing:GetCurrentSheet() end
function ZO_Dyeing:GetMode() end
function ZO_DyeingSlotsSheet:New(...) end
function ZO_DyeingSlotsSheet:Initialize(control, onSlotClickedCallback, onSlotEnterCallback, onSlotExitCallback) end
function ZO_DyeingSlotsSheet:InitializeOnSlotCallbacks(onSlotClickedCallback, onSlotEnterCallback, onSlotExitCallback) end
function ZO_DyeingSlotsSheet:GetMousedOverDyeableSlotInfo() end
function ZO_DyeingSlotsSheet:MarkViewDirty() end
function ZO_DyeingSlotsSheet:RefreshView() end
function ZO_DyeingSlotsSheet:RefreshDyeableSlotDyes(dyeableSlot) end
function ZO_DyeingSlotsSheet:ToggleDyeableSlotHightlightBySlotControl(slotControl, isHighlighted, dyeChannel) end
function ZO_DyeingSlotsSheet:ToggleDyeableSlotHightlight(dyeableSlot, isHighlighted, dyeChannel) end
function ZO_Dyeing_OnInitialized(control) end
function ZO_DyeableSlot_OnMouseEnter(control) end
function ZO_DyeableSlot_OnMouseExit(control) end
function ZO_DyeStamp_Confirmation_Keyboard:New(...) end
function ZO_DyeStamp_Confirmation_Keyboard:Initialize(control) end
function ZO_DyeStamp_Confirmation_Base:AddExitKey() end
function ZO_DyeStamp_Confirmation_Keyboard_OnInitialize(control) end
--ingame\enchanting
function ZO_ApplyEnchant_Gamepad:New(...) end
function ZO_ApplyEnchant_Gamepad:Initialize(control) end
function ZO_ApplyEnchant_Gamepad:SetupScene() end
function ZO_ApplyEnchant_Gamepad:OnSelectionChanged(list, selectedData, oldSelectedData) end
function ZO_ApplyEnchant_Gamepad:OnTargetChanged(list, targetData, oldTargetData, reachedTarget, targetSelectedIndex) end
function ZO_ApplyEnchant_Gamepad:ClearTooltip() end
function ZO_ApplyEnchant_Gamepad:InitializeDefaultTooltip(tooltip) end
function ZO_ApplyEnchant_Gamepad:CheckEmptyList() end
function ZO_ApplyEnchant_Gamepad:ResetTooltipToDefault() end
function ZO_ApplyEnchant_Gamepad:BuildEnumeratedImprovementKitList(itemList) end
function ZO_ApplyEnchant_Gamepad:GetItemName(itemInfo) end
function ZO_ApplyEnchant_Gamepad:PerformItemImprovement() end
function ZO_ApplyEnchant_Gamepad:GetItemTemplateName() end
function ZO_Gamepad_ApplyEnchant_OnInitialize(control) end
function ZO_ApplyEnchant:New(...) end
function ZO_ApplyEnchant:Initialize(control) end
function ZO_ApplyEnchant:SetupDialog(bag, index) end
function ZO_ApplyEnchant:SetItemInfo(bag, index) end
function ZO_ApplyEnchant:OnEnchantSelected(itemBagId, itemSlotIndex, enchantmentBagId, enchantmentSlotIndex) end
function ZO_ApplyEnchant:BeginItemImprovement(bag, index) end
function ZO_ApplyEnchant_OnInitialize(control) end
--ingame\fence
function ZO_Fence_Base:New(...) end
function ZO_Fence_Base:Initialize(control) end
function ZO_Fence_Base:OnOpened(enableSell, enableLaunder) end
function ZO_Fence_Base:OnClosed() end
function ZO_Fence_Base:OnSellSuccess() end
function ZO_Fence_Base:OnLaunderSuccess() end
function ZO_Fence_Base:OnInventoryUpdate() end
function ZO_Fence_Base:OnFenceStateUpdated(totalSells, sellsUsed, totalLaunders, laundersUsed) end
function ZO_Fence_Base:OnEnterSell(totalSells, sellsUsed) end
function ZO_Fence_Base:OnEnterLaunder(totalLaunders, laundersUsed) end
function ZO_Fence_Base:IsLaundering() end
function ZO_Fence_Base:IsSellingStolenItems() end
function ZO_Fence_Manager:New(...) end
function ZO_Fence_Manager:Initialize() end
function ZO_Fence_Manager:OnFenceOpened(enableSell, enableLaunder) end
function ZO_Fence_Manager:OnFenceClosed() end
function ZO_Fence_Manager:OnSellSuccess() end
function ZO_Fence_Manager:OnLaunderResult(result) end
function ZO_Fence_Manager:OnInventoryUpdated() end
function ZO_Fence_Manager:OnFenceStateUpdated(sellsUsed, laundersUsed) end
function ZO_Fence_Manager:OnEnterSell() end
function ZO_Fence_Manager:OnEnterLaunder() end
function ZO_Fence_Manager:GetNumTotalTransactions(mode) end
function ZO_Fence_Manager:GetNumTransactionsUsed(mode) end
function ZO_Fence_Manager:GetNumTransactionsRemaining(mode) end
function ZO_Fence_Manager:HasBonusToSellingStolenItems() end
function ZO_Fence_Manager:GetHagglingBonus() end
function ZO_GamepadFenceComponent:New(...) end
function ZO_GamepadFenceComponent:Initialize(mode, title) end
function ZO_GamepadFenceComponent:RegisterEvents() end
function ZO_GamepadFenceComponent:UnregisterEvents() end
function ZO_GamepadFenceComponent:InitializeKeybindStrip(forwardText) end
function ZO_GamepadFenceComponent:SelectItem(ignoreInvalidCost) end
function ZO_GamepadFenceComponent:UnselectItem() end
function ZO_GamepadFenceComponent:SetupEntry(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadFenceComponent:OnSelectedItemChanged(inventoryData) end
function ZO_GamepadFenceComponent:Confirm() end
function ZO_GamepadFenceComponent:OnSuccess() end
function ZO_GamepadFenceComponent:RefreshFooter() end
function ZO_GamepadFenceComponent:ShowFenceBar() end
function ZO_GamepadFenceComponent:HideFenceBar() end
function ZO_GamepadFenceComponent:ClearFooter() end
function ZO_GamepadFenceLaunder:New(...) end
function ZO_GamepadFenceLaunder:Initialize() end
function ZO_GamepadFenceLaunder:GetRemainingLaunders() end
function ZO_GamepadFenceLaunder:Confirm() end
function ZO_GamepadFenceLaunder:SetupEntry(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadFenceLaunder:OnSuccess() end
function ZO_GamepadFenceLaunder:RefreshFooter() end
function ZO_GamepadFenceLaunder_Initialize() end
function ZO_GamepadFenceSell:New(...) end
function ZO_GamepadFenceSell:Initialize() end
function ZO_GamepadFenceSell:GetRemainingSells() end
function ZO_GamepadFenceSell:RefreshFooter() end
function ZO_GamepadFenceSell:SetupEntry(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadFenceSell_Initialize() end
function ZO_GamepadFenceSell:GetCurrencyOptions() end
function ZO_Fence_Gamepad:New(...) end
function ZO_Fence_Gamepad:Initialize(control) end
function ZO_Fence_Gamepad:OnOpened(enableSell, enableLaunder) end
function ZO_Fence_Gamepad:OnSellSuccess() end
function ZO_Fence_Gamepad:OnLaunderSuccess() end
function ZO_Fence_Gamepad:IsLaundering() end
function ZO_Fence_Gamepad:IsSellingStolenItems() end
function ZO_Fence_Gamepad_Initialize(control) end
function ZO_Fence_Keyboard:New(...) end
function ZO_Fence_Keyboard:Initialize(control) end
function ZO_Fence_Keyboard:InitializeModeBar(enableSell, enableLaunder) end
function ZO_Fence_Keyboard:OnOpened(enableSell, enableLaunder) end
function ZO_Fence_Keyboard:OnClosed() end
function ZO_Fence_Keyboard:OnFenceStateUpdated(totalSells, sellsUsed, totalLaunders, laundersUsed) end
function ZO_Fence_Keyboard:OnEnterSell(totalSells, sellsUsed) end
function ZO_Fence_Keyboard:OnEnterLaunder(totalLaunders, laundersUsed) end
function ZO_Fence_Keyboard:UpdateTransactionLabel(totalTransactions, usedTransactions, transactionsRemainingString, transactionsFullString) end
function ZO_Fence_Keyboard:UpdateHagglingLabel(skillLevel) end
function ZO_Fence_Keyboard:IsLaundering() end
function ZO_Fence_Keyboard:IsSellingStolenItems() end
function ZO_Fence_Keyboard:RefreshFooter() end
function ZO_Fence_Keyboard_Initialize(control) end
--ingame\fishing
function ZO_Fishing:New(...) end
function ZO_Fishing:PrepareForInteraction() end
function ZO_Fishing:SetupEntryControl(entryControl, lureIndex) end
function ZO_Fishing:InteractionCanceled() end
function ZO_Fishing:PopulateMenu() end
function FishingManager:New() end
function FishingManager:StartInteraction() end
function FishingManager:StopInteraction() end
function ZO_Fishing_Gamepad_Initialize(control) end
function ZO_Fishing_Keyboard_Initialize(control) end
--ingame\gamemenu_ingame
function ZO_GameMenu_InGame_Initialize(self) end
--ingame\gamepad
function GetGamerCardStringId() end
function ZO_GamepadCheckboxOptionTemplate_Setup(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadQuantitySpinner:InitializeSpinner(valueChangedCallback, direction) end
function ZO_GamepadQuantitySpinner:SetValueChangedCallback(callback) end
function ZO_GamepadQuantitySpinner:SetMinMax(min, max) end
function ZO_GamepadQuantitySpinner:SetValue(value) end
function ZO_GamepadQuantitySpinner:GetValue(value) end
function ZO_GamepadQuantitySpinner:SetupCurrency(unitPrice, currencyType) end
function ZO_GamepadQuantitySpinner:Activate() end
function ZO_GamepadQuantitySpinner:Deactivate() end
function ZO_GamepadQuantitySpinner:OnValueChanged(newValue) end
function ZO_GamepadQuantitySpinner:AttachAndShowSpinner(list, targetControl) end
function ZO_GamepadQuantitySpinner:AttachToTargetListEntry(list) end
function ZO_GamepadQuantitySpinner:DetachFromListEntry() end
function ZO_GamepadQuantitySpinner:SetIgnoreInvalidCost(ignoreInvalidCost) end
function ZO_GamepadLabeledQuantitySpinnerContainerTemplate_Initialize(control) end
--ingame\globals
function RecentPlayerTracker:New(...) end
function RecentPlayerTracker:Initialize(maxPlayers, optTableToUse) end
function RecentPlayerTracker:GetPlayers() end
function RecentPlayerTracker:RemoveOldPlayers() end
function RecentPlayerTracker:AddRecentPlayer(name) end
function GetAutoCompletion(input, maxResults, onlineOnly, includeFlags, excludeFlags, noMinScore) end
function ZO_GetNextBagSlotIndex(bagId, slotIndex) end
function ZO_ActionHandler_JumpOrInteractDown() end
function ZO_ActionHandler_JumpOrInteractUp() end
function ZO_FormatResourceBarCurrentAndMax(current, maximum) end
function GetAllianceTexture(alliance) end
function GetAllianceSymbolIcon(alliance) end
function GetLargeAllianceSymbolIcon(alliance) end
function GetPlatformAllianceSymbolIcon(alliance) end
function GetAllianceBannerIcon(alliance) end
function GetInstanceDisplayTypeIcon(instanceType) end
function GetSocketTexture(socketType) end
function GetPlayerStatusIcon(playerStatus) end
function GetGamepadPlayerStatusIcon(playerStatus) end
function GetChampionPointsIcon() end
function GetGamepadChampionPointsIcon() end
function GetVeteranIcon() end
function GetGamepadVeteranIcon() end
function GetColoredAvARankIconMarkup(avaRank, alliance, size) end
function GetChampionPointAttributeIcon(attribute) end
function GetChampionPointAttributeHUDIcon(attribute) end
function GetChampionPointAttributeActiveIcon(attribute) end
function GetKeyboardRoleIcon(role) end
function GetGamepadRoleIcon(role) end
function GetRoleIcon(role) end
function GetKeyboardDungeonDifficultyIcon(dungeonDifficulty) end
function GetGamepadDungeonDifficultyIcon(dungeonDifficulty) end
function GetChampionIconMarkupString(iconSize) end
function GetLevelOrChampionPointsString(level, championPoints, iconSize) end
--ingame\group
function GroupList_Gamepad:New(...) end
function GroupList_Gamepad:Initialize(control) end
function GroupList_Gamepad:GetBackKeybindCallback() end
function GroupList_Gamepad:SetupRow(control, data, selected) end
function GroupList_Gamepad:OnShown() end
function GroupList_Gamepad:RefreshData() end
function GroupList_Gamepad:RefreshTooltip() end
function GroupList_Gamepad:BuildOptionsList() end
function GroupList_Gamepad:BuildPromoteToLeaderOption() end
function GroupList_Gamepad:BuildKickMemberOption() end
function GroupList_Gamepad:BuildVoteKickMemberOption() end
function ZO_GroupList_Gamepad_OnInitialized(control) end
function ZO_GroupMenu_Gamepad:New(...) end
function ZO_GroupMenu_Gamepad:Initialize(control) end
function ZO_GroupMenu_Gamepad:InitializeScene() end
function ZO_GroupMenu_Gamepad:PerformDeferredInitialization() end
function ZO_GroupMenu_Gamepad:InitializeKeybindDescriptors() end
function ZO_GroupMenu_Gamepad:InitializeEvents() end
function ZO_GroupMenu_Gamepad:UpdateMenuList() end
function ZO_GroupMenu_Gamepad:SelectMenuList() end
function ZO_GroupMenu_Gamepad:SelectGroupList(sound) end
function ZO_GroupMenu_Gamepad:SetupList(list) end
function ZO_GroupMenu_Gamepad:EnableCurrentList() end
function ZO_GroupMenu_Gamepad:DisableCurrentList() end
function ZO_GroupMenu_Gamepad:ActivateCurrentList() end
function ZO_GroupMenu_Gamepad:DeactivateCurrentList() end
function ZO_GroupMenuGamepad_OnInitialized(control) end
function TryGroupInviteByName(characterOrDisplayName, sentFromChat, displayInvitedMessage) end
function ZO_ConvertToDungeonDifficulty(isVeteranDifficulty) end
function ZO_ConvertToIsVeteranDifficulty(dungeonDifficulty) end
function ZO_GetGroupDungeonDifficulty() end
function ZO_GetPlayerDungeonDifficulty() end
function ZO_GetEffectiveDungeonDifficulty() end
function ZO_IsGroupElectionTypeCustom(electionType) end
function ZO_GetSimplifiedGroupElectionResultType(resultType) end
function ZO_SendReadyCheck() end
function ZO_GroupList_Keyboard:New(...) end
function ZO_GroupList_Keyboard:Initialize(control) end
function ZO_GroupList_Keyboard:InitializeKeybindDescriptors() end
function ZO_GroupList_Keyboard:OnEffectivelyHidden() end
function ZO_GroupList_Keyboard:GroupListRow_OnMouseUp(control, button, upInside) end
function ZO_GroupList_Keyboard:TooltipIfTruncatedLabel_OnMouseEnter(control) end
function ZO_GroupList_Keyboard:Status_OnMouseEnter(control) end
function ZO_GroupList_Keyboard:Role_OnMouseEnter(control) end
function ZO_GroupList_Keyboard:UpdateHeaders(active) end
function ZO_GroupList_Keyboard:SetupGroupEntry(control, data) end
function ZO_GroupList_Keyboard:BuildMasterList() end
function ZO_GroupList_Keyboard:FilterScrollList() end
function ZO_GroupList_Keyboard:GetRowColors(data, mouseIsOver) end
function ZO_GroupList_Keyboard:RefreshData() end
function ZO_GroupListRow_OnMouseEnter(control) end
function ZO_GroupListRow_OnMouseExit(control) end
function ZO_GroupListRowChild_OnMouseExit(control) end
function ZO_GroupListRow_OnMouseUp(control, button, upInside) end
function ZO_GroupListRowCharacterName_OnMouseEnter(control) end
function ZO_GroupListRowCharacterName_OnMouseExit(control) end
function ZO_GroupListRowClass_OnMouseEnter(control) end
function ZO_GroupListRowClass_OnMouseExit(control) end
function ZO_GroupListRowChampion_OnMouseEnter(control) end
function ZO_GroupListRowChampion_OnMouseExit(control) end
function ZO_GroupListRowTooltipIfTruncatedLabel_OnMouseEnter(control) end
function ZO_GroupListRowStatus_OnMouseEnter(control) end
function ZO_GroupListRole_OnMouseEnter(control) end
function ZO_GroupList_OnInitialized(self) end
function GroupMenu_Keyboard:New(...) end
function GroupMenu_Keyboard:Initialize(control) end
function GroupMenu_Keyboard:InitializeCategories() end
function GroupMenu_Keyboard:InitializeKeybindDescriptors() end
function GroupMenu_Keyboard:OnUpdateGroupStatus() end
function GroupMenu_Keyboard:SetCurrentCategory(categoryFragment) end
function GroupMenu_Keyboard:AddCategory(data) end
function GroupMenu_Keyboard:RefreshCategories() end
function ZO_GroupMenuKeyboard_OnInitialized(control) end
function ZO_GroupList_Manager:New() end
function ZO_GroupList_Manager:Initialize() end
function ZO_GroupList_Manager:RegisterForEvents() end
function ZO_GroupList_Manager:BuildMasterList() end
--ingame\guild
function ZO_GuildHeraldryManager_Gamepad:New(...) end
function ZO_GuildHeraldryManager_Gamepad:SetMainList(list) end
function ZO_GuildHeraldryManager_Gamepad:SetOwningScreen(owningScreen) end
function ZO_GuildHeraldryManager_Gamepad:Initialize(control) end
function ZO_GuildHeraldryManager_Gamepad:PerformDeferredInitialization() end
function ZO_GuildHeraldryManager_Gamepad:RegisterEvents() end
function ZO_GuildHeraldryManager_Gamepad:UnregisterEvents() end
function ZO_GuildHeraldryManager_Gamepad:InitializeStyleCategoryLists(scrollList, scrollListTemplate) end
function ZO_GuildHeraldryManager_Gamepad:GetPurchaseDialogName() end
function ZO_GuildHeraldryManager_Gamepad:GetApplyChangesDialogName() end
function ZO_GuildHeraldryManager_Gamepad:IsCurrentBlockingScene() end
function ZO_GuildHeraldryManager_Gamepad:AttemptSaveAndExit(showBaseScene) end
function ZO_GuildHeraldryManager_Gamepad:ConfirmExit(showBaseScene) end
function ZO_GuildHeraldryManager_Gamepad:CancelExit() end
function ZO_GuildHeraldryManager_Gamepad:NoChoiceExitCallback() end
function ZO_GuildHeraldryManager_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_GuildHeraldryManager_Gamepad:UpdateKeybindGroups() end
function ZO_GuildHeraldryManager_Gamepad:OnTargetChanged(list, selectedData, oldSelectedData) end
function ZO_GuildHeraldryManager_Gamepad:GetPurchaseCost() end
function ZO_GuildHeraldryManager_Gamepad:InitializeColorList() end
function ZO_GuildHeraldryManager_Gamepad:PopulateCategories() end
function ZO_GuildHeraldryManager_Gamepad:SetViewedStyleCategory(index) end
function ZO_GuildHeraldryManager_Gamepad:SetActiveKeybindDescriptor(descriptor) end
function ZO_GuildHeraldryManager_Gamepad:SetMode_Category() end
function ZO_GuildHeraldryManager_Gamepad:SetMode_Color() end
function ZO_GuildHeraldryManager_Gamepad:SetMode_BGStyle() end
function ZO_GuildHeraldryManager_Gamepad:SetMode_CrestStyle() end
function ZO_GuildHeraldryManager_Gamepad:SetStyleSubMode(subMode) end
function ZO_GuildHeraldryManager_Gamepad:SwitchMode(mode) end
function ZO_GuildHeraldryManager_Gamepad:SelectMode(mode) end
function ZO_GuildHeraldryManager_Gamepad:SetSelectedHeraldryIndices() end
function ZO_GuildHeraldryManager_Gamepad:HighlightColor(newSwatch, becauseOfRebuild, data) end
function ZO_GuildHeraldryManager_Gamepad:HighlightStyle(newStyle, becauseOfRebuild, data) end
function ZO_GuildHeraldryManager_Gamepad:HideColorHighlight(data, resetToSelected) end
function ZO_GuildHeraldryManager_Gamepad:HideStyleHighlight(data, resetToSelected) end
function ZO_GuildHeraldryManager_Gamepad:EnableHighlight() end
function ZO_GuildHeraldryManager_Gamepad:SetDirectionalInputEnabled(enabled) end
function ZO_GuildHeraldryManager_Gamepad:HighlightColorWithDirection(direction) end
function ZO_GuildHeraldryManager_Gamepad:UpdateStyleWithDirection(direction) end
function ZO_GuildHeraldryManager_Gamepad:HighlightStyleWithDirection(direction) end
function ZO_GuildHeraldryManager_Gamepad:SelectColor(...) end
function ZO_GuildHeraldryManager_Gamepad:SelectStyle(...) end
function ZO_GuildHeraldryManager_Gamepad:SetupHeraldryDialog(control) end
function ZO_GuildHeraldryManager_Gamepad:ConfirmHeraldryPurchase() end
function ZO_GuildHeraldryManager_Gamepad:ConfirmHeraldryApplyChanges() end
function ZO_GuildHeraldry_Gamepad_OnInitialized(control) end
function ZO_GuildHistory_Gamepad:New(...) end
function ZO_GuildHistory_Gamepad:SetMainList(list) end
function ZO_GuildHistory_Gamepad:Initialize(control) end
function ZO_GuildHistory_Gamepad:OnTargetChanged(list, selectedData, oldSelectedData) end
function ZO_GuildHistory_Gamepad:NextPage() end
function ZO_GuildHistory_Gamepad:PreviousPage() end
function ZO_GuildHistory_Gamepad:OnActivityTargetChanged(focusedItem) end
function ZO_GuildHistory_Gamepad:InitializeActivityList() end
function ZO_GuildHistory_Gamepad:InitializeEvents() end
function ZO_GuildHistory_Gamepad:UninitializeEvents() end
function ZO_GuildHistory_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_GuildHistory_Gamepad:RefreshKeybinds() end
function ZO_GuildHistory_Gamepad:UpdateLogTriggerButtons() end
function ZO_GuildHistory_Gamepad:SelectCategoryList() end
function ZO_GuildHistory_Gamepad:SelectLogList() end
function ZO_GuildHistory_Gamepad:SetGuildId(guildId) end
function ZO_GuildHistory_Gamepad:RequestNewest() end
function ZO_GuildHistory_Gamepad:RequestOlder() end
function ZO_GuildHistory_Gamepad:IncrementRequestCount() end
function ZO_GuildHistory_Gamepad:DecrementRequestCount() end
function ZO_GuildHistory_Gamepad:ShowLoading() end
function ZO_GuildHistory_Gamepad:HideLoading() end
function ZO_GuildHistory_Gamepad:OnGuildHistoryCategoryUpdated(guildId, category) end
function ZO_GuildHistory_Gamepad:OnGuildHistoryResponseReceived() end
function ZO_GuildHistory_Gamepad:PopulateActivityList() end
function ZO_GuildHistory_Gamepad:PopulateCategories() end
function ZO_GuildHistory_Gamepad:RefreshFooter() end
function ZO_GuildHistory_Gamepad_Initialize(control) end
function ZO_GamepadGuildRosterManager:New(...) end
function ZO_GamepadGuildRosterManager:Initialize(control) end
function ZO_GamepadGuildRosterManager:InitializeHeader() end
function ZO_GamepadGuildRosterManager:PerformDeferredInitialization() end
function ZO_GamepadGuildRosterManager:GetAddKeybind() end
function ZO_GamepadGuildRosterManager:GetBackKeybindCallback() end
function ZO_GamepadGuildRosterManager:LayoutTooltip(tooltipManager, tooltip, data) end
function ZO_GamepadGuildRosterManager:ColorRow(control, data, selected) end
function ZO_GamepadGuildRosterManager:OnShowing() end
function ZO_GamepadGuildRosterManager:OnHidden() end
function ZO_GamepadGuildRosterManager:SetupOptions(socialData) end
function ZO_GamepadGuildRosterManager:BuildOptionsList() end
function ZO_GamepadGuildRosterManager:BuildPromoteOption() end
function ZO_GamepadGuildRosterManager:BuildPromoteToGuildMasterOption() end
function ZO_GamepadGuildRosterManager:BuildDemoteOption() end
function ZO_GamepadGuildRosterManager:BuildRemoveOption() end
function ZO_GamepadGuildRosterManager:BuildLeaveGuildOption() end
function ZO_GamepadGuildRosterManager:BuildAddFriendOption() end
function ZO_GamepadGuildRosterManager:BuildShowGamerCardOption() end
function ZO_GamepadGuildRoster_Initialize(control) end
function ZO_GuildSelector_Gamepad:New(...) end
function ZO_GuildSelector_Gamepad:Initialize(...) end
function ZO_SelectGuildDialog:SetGuildFilter(filterFunction) end
function ZO_GuildSelector_Gamepad:SelectGuild(selectedEntry) end
function ZO_GuildSelector_Gamepad:RefreshGuildList() end
function ZO_GuildSelector_Gamepad:SetOnGuildsRefreshed(OnGuildsRefreshed) end
function ZO_GuildSelector_Gamepad:OnGuildSelected(itemName, item) end
function ZO_GuildSelector_Gamepad:SetOnGuildSelectedCallback(OnGuildSelectedCallback) end
function ZO_GamepadGuildHome:New(...) end
function ZO_GamepadGuildHome:Initialize(control) end
function ZO_GamepadGuildHome:PerformDeferredInitializationHome() end
function ZO_GamepadGuildHome:PerformUpdate() end
function ZO_GamepadGuildHome:SetActivateScreenInfo(callback, title) end
function ZO_GamepadGuildHome:SetGuildId(guildId) end
function ZO_GamepadGuildHome:IsCurrentGuildId(guildId) end
function ZO_GamepadGuildHome:ValidateGuildId() end
function ZO_GamepadGuildHome:ShouldShowEditRankHeaderTitle() end
function ZO_GamepadGuildHome:InitializeHeader() end
function ZO_GamepadGuildHome:RefreshHeader(blockTabBarCallbacks) end
function ZO_GamepadGuildHome:InitializeFooter() end
function ZO_GamepadGuildHome:SetHeaderHidden(hide) end
function ZO_GamepadGuildHome:SetContentHeaderHidden(hide) end
function ZO_GamepadGuildHome:RefreshFooter() end
function ZO_GamepadGuildHome:OnTargetChanged(list, selectedData, oldSelectedData) end
function ZO_GamepadGuildHome:RemoveCurrentPage() end
function ZO_GamepadGuildHome:SetCurrentPage(fragment, screenObject) end
function ZO_GamepadGuildHome:ShowRoster() end
function ZO_GamepadGuildHome:ShowRanks() end
function ZO_GamepadGuildHome:ShowHeraldry() end
function ZO_GamepadGuildHome:ShowHistory() end
function ZO_GamepadGuildHome_OnInitialize(control) end
function ZO_GamepadGuildHub_OnInitialize(control) end
function ZO_GamepadGuildHub:New(...) end
function ZO_GamepadGuildHub:Initialize(control) end
function ZO_GamepadGuildHub:PerformDeferredInitializationHub() end
function ZO_GamepadGuildHub:PerformUpdate() end
function ZO_GamepadGuildHub:UpdateLists() end
function ZO_GamepadGuildHub:UpdateContent() end
function ZO_GamepadGuildHub:ValidateOptionsGuildId() end
function ZO_GamepadGuildHub:InitializeChangeMotdDialog() end
function ZO_GamepadGuildHub:InitializeChangeAboutUsDialog() end
function ZO_GamepadGuildHub:InitializeCreateGuildDialog() end
function ZO_GamepadGuildHub:RefreshGuildInfo() end
function ZO_GamepadGuildHub:InitializeCreateGuildExplanation() end
function ZO_GamepadGuildHub:RefreshCreateGuildExplanation() end
function ZO_GamepadGuildHub:InitializeHeader() end
function ZO_GamepadGuildHub:RefreshHeader() end
function ZO_GamepadGuildHub:InitializeKeybindStripDescriptors() end
function ZO_GamepadGuildHub:SetupList(list) end
function ZO_GamepadGuildHub:ActivateMainList(blockUpdate) end
function ZO_GamepadGuildHub:RefreshSingleGuildList() end
function ZO_GamepadGuildHub:ActivateSingleGuildList() end
function ZO_GamepadGuildHub:SetEnterInSingleGuildList(enterInSingleGuildList) end
function ZO_GamepadGuildHub:OnTargetChanged(list, selectedData, oldSelectedData) end
function ZO_GamepadGuildHub:RefreshGuildList() end
function ZO_GamepadGuildInfo:New(...) end
function ZO_GamepadGuildInfo:Initialize(control) end
function ZO_GamepadGuildInfo:PerformDeferredInitialization() end
function ZO_GamepadGuildInfo:RefreshScreen() end
function ZO_GamepadGuildInfo:SetGuildId(guildId) end
function ZO_GamepadGuildInfo:RefreshPrivileges() end
function ZO_GamepadGuildInfo:RefreshHeader() end
function ZO_GamepadGuildInfo:InitializeFooter() end
function ZO_GamepadGuildInfo:RefreshFooter() end
function ZO_GamepadGuildInfo:RefreshGuildMaster() end
function ZO_GamepadGuildInfo:RefreshMOTD() end
function ZO_GamepadGuildInfo:RefreshDescription() end
function ZO_GamepadGuildInfo:RefreshKeepOwnership() end
function ZO_GamepadGuildInfo:RefreshTraderOwnership() end
function ZO_GuildInfo_Gamepad_Initialize(control) end
function ZO_GuildRanks_Gamepad_Initialize(control) end
function ZO_GuildRanks_Gamepad:New(...) end
function ZO_GuildRanks_Gamepad:SetMainList(list) end
function ZO_GuildRanks_Gamepad:SetOptionsList(optionsList) end
function ZO_GuildRanks_Gamepad:SetOwningScreen(owningScreen) end
function ZO_GuildRanks_Gamepad:Initialize(control) end
function ZO_GuildRanks_Gamepad:ResetRankSelection() end
function ZO_GuildRanks_Gamepad:ActivateRankList(refreshScreen) end
function ZO_GuildRanks_Gamepad:ActivateOptionsList(refreshScreen) end
function ZO_GuildRanks_Gamepad:DeactivateOptionsList() end
function ZO_GuildRanks_Gamepad:PerformDeferredInitialization() end
function ZO_GuildRanks_Gamepad:ReloadAndRefreshScreen() end
function ZO_GuildRanks_Gamepad:RefreshScreen() end
function ZO_GuildRanks_Gamepad:RefreshLists() end
function ZO_GuildRanks_Gamepad:RefreshContent() end
function ZO_GuildRanks_Gamepad:SetCurrentDropdown(dropdown) end
function ZO_GuildRanks_Gamepad:InitializeAddRankDialog() end
function ZO_GuildRanks_Gamepad:InitializeRenameRankDialog() end
function ZO_GuildRanks_Gamepad:InitializeDeleteRankDialog() end
function ZO_GuildRanks_Gamepad:IsDisplayingRankList() end
function ZO_GuildRanks_Gamepad:IsDisplayingOptionsList() end
function ZO_GuildRanks_Gamepad:IsDisplayingIconSelector() end
function ZO_GuildRanks_Gamepad:IsDisplayingChangePermissions() end
function ZO_GuildRanks_Gamepad:RemoveUnusedFragments(fragmentBeingAdded) end
function ZO_GuildRanks_Gamepad:ActivateFragment(fragment) end
function ZO_GuildRanks_Gamepad:GetMessageText() end
function ZO_GuildRanks_Gamepad:IsEditingRank() end
function ZO_GuildRanks_Gamepad:InitializeIconSelector() end
function ZO_GuildRanks_Gamepad:RefreshIconSelector() end
function ZO_GuildRanks_Gamepad:SelectHighlightedIcon() end
function ZO_GuildRanks_Gamepad:InitializeChangePermissions() end
function ZO_GuildRanks_Gamepad:UpdateDirectionalInput() end
function ZO_GuildRanks_Gamepad:IsPositionSelectable(x, y) end
function ZO_GuildRanks_Gamepad:GetNearestSelectablePosition(currentX, currentY, direction, axis) end
function ZO_GuildRanks_Gamepad:MoveChangePermissionSelection(deltaX, deltaY) end
function ZO_GuildRanks_Gamepad:GetSelectedPermissionControl() end
function ZO_GuildRanks_Gamepad:SetChangePermissionsEnabled(state) end
function ZO_GuildRanks_Gamepad:RefreshChangePermissions() end
function ZO_GuildRanks_Gamepad:InitializePermissionsFragment() end
function ZO_GuildRanks_Gamepad:RefreshPermissionsSummary(rank) end
function ZO_GuildRanks_Gamepad:GetSelectedRankIndex() end
function ZO_GuildRanks_Gamepad:IsGuildMasterSelected() end
function ZO_GuildRanks_Gamepad:IsLastRankSelected() end
function ZO_GuildRanks_Gamepad:InSecondRankSelected() end
function ZO_GuildRanks_Gamepad:ReorderSelectedRank(up) end
function ZO_GuildRanks_Gamepad:DeleteSelectedRank() end
function ZO_GuildRanks_Gamepad:InitializeKeybindStrip() end
function ZO_GuildRanks_Gamepad:AddRank(rankName, copyPermissionsFromRankIndex) end
function ZO_GuildRanks_Gamepad:OnTargetChanged(list, selectedData, oldSelectedData) end
function ZO_GuildRanks_Gamepad:CancelDialog() end
function ZO_GuildRanks_Gamepad:PopulateRanks() end
function ZO_GuildRanks_Gamepad:RefreshRankList() end
function ZO_GuildHeraldryManager_Shared:New(...) end
function ZO_GuildHeraldryManager_Shared:Initialize(control, currencyOptions) end
function ZO_GuildHeraldryManager_Shared:InitializeStyleCategoryLists(scrollList, scrollListTemplate) end
function ZO_GuildHeraldryManager_Shared:PopulateStyleCategoryLists() end
function ZO_GuildHeraldryManager_Shared:InitializeSwatchPool(template, parent) end
function ZO_GuildHeraldryManager_Shared:InitializeStylePool(template) end
function ZO_GuildHeraldryManager_Shared:OnCategorySelected(data) end
function ZO_GuildHeraldryManager_Shared:SelectColor(colorIndex, becauseOfRebuild) end
function ZO_GuildHeraldryManager_Shared:SetSelectedHeraldryIndices() end
function ZO_GuildHeraldryManager_Shared:SetGuildId(guildId) end
function ZO_GuildHeraldryManager_Shared:IsEnabled() end
function ZO_GuildHeraldryManager_Shared:LayoutColors() end
function ZO_GuildHeraldryManager_Shared:SetViewedStyleCategory(index) end
function ZO_GuildHeraldryManager_Shared:SetSelectedStyleCategory(index) end
function ZO_GuildHeraldryManager_Shared:SetPendingIndices() end
function ZO_GuildHeraldryManager_Shared:SelectStyle(styleIndex, becauseOfRebuild) end
function ZO_GuildHeraldryManager_Shared:LayoutStyles(anchorFunction) end
function ZO_GuildHeraldryManager_Shared:CanSave() end
function ZO_GuildHeraldryManager_Shared:SetPendingExit(isPendingExit) end
function ZO_GuildHeraldryManager_Shared:IsPendingExit() end
function ZO_GuildHeraldryManager_Shared:AttemptSaveIfBlocking(showBaseScene) end
function ZO_GuildHeraldryManager_Shared:AttemptSaveAndExit(showBaseScene) end
function ZO_GuildHeraldryManager_Shared:ConfirmExit(showBaseScene) end
function ZO_GuildHeraldryManager_Shared:CancelExit() end
function ZO_GuildHeraldryManager_Shared:NoChoiceExitCallback() end
function ZO_GuildHeraldryManager_Shared:GetPurchaseDialogName() end
function ZO_GuildHeraldryManager_Shared:GetApplyChangesDialogName() end
function ZO_GuildHeraldryManager_Shared:PurchaseHeraldryDialogInitialize(control) end
function ZO_GuildHeraldryManager_Shared:ApplyChangesHeraldryDialogInitialize(control) end
function ZO_GuildHeraldryManager_Shared:ConfirmHeraldryPurchase(control, showDialogFunc) end
function ZO_GuildHeraldryManager_Shared:ConfirmHeraldryApplyChanges(control, showDialogFunc) end
function ComputeGuildHistoryEventSubcategory(eventType, category) end
function GetFinalGuildRankTextureSmall(guildId, rankIndex) end
function GetFinalGuildRankTextureLarge(guildId, rankIndex) end
function GetFinalGuildRankHighlight(guildId, rankIndex) end
function GetFinalGuildRankTextureListDown(guildId, rankIndex) end
function GetFinalGuildRankTextureListUp(guildId, rankIndex) end
function GetDefaultGuildRankName(guildId, rankIndex) end
function GetFinalGuildRankName(guildId, rankIndex) end
function ZO_GuildRosterManager:New() end
function ZO_GuildRosterManager:Initialize() end
function ZO_GuildRosterManager:MatchesGuild(guildId) end
function ZO_GuildRosterManager:SetGuildId(guildId) end
function ZO_GuildRosterManager:RefreshAll() end
function ZO_GuildRosterManager:RefreshRankDependentControls() end
function ZO_GuildRosterManager:ColorRow(control, data, textColor, iconColor, textColor2) end
function ZO_GuildRosterManager:SetupEntry(control, data, selected) end
function ZO_GuildRosterManager:BuildMasterList() end
function ZO_GuildRosterManager:GetNoteEditedFunction() end
function ZO_GuildRosterManager:GetGuildId() end
function ZO_GuildRosterManager:GetGuildName() end
function ZO_GuildRosterManager:GetGuildAlliance() end
function ZO_GuildRosterManager:GetPlayerData() end
function ZO_GuildRosterManager:FindDataByDisplayName(displayName) end
function ZO_GuildRosterManager:OnGuildDataLoaded() end
function ZO_GuildRosterManager:OnGuildMemberAdded(guildId, displayName) end
function ZO_GuildRosterManager:OnGuildSelfJoined() end
function ZO_GuildRosterManager:OnGuildMemberRemoved(guildId, rawCharacterName, displayName) end
function ZO_GuildRosterManager:OnGuildMemberCharacterUpdated(displayName) end
function ZO_GuildRosterManager:OnGuildMemberCharacterZoneChanged(displayName, characterName, zone) end
function ZO_GuildRosterManager:OnGuildMemberCharacterLevelChanged(displayName, characterName, level) end
function ZO_GuildRosterManager:OnGuildMemberCharacterChampionPointsChanged(displayName, characterName, championPoints) end
function ZO_GuildRosterManager:OnGuildMemberRankChanged(displayName, rankIndex) end
function ZO_GuildRosterManager:OnGuildMemberPlayerStatusChanged(displayName, oldStatus, newStatus) end
function ZO_GuildRosterManager:OnGuildMemberNoteChanged(displayName, note) end
function ZO_GuildRosterManager:OnGuildRanksChanged() end
function ZO_GuildRosterManager:OnUpdate(control, currentTime) end
function ZO_GuildRosterManager:OnGuildIdChanged() end
function GuildSharedInfo:New(control) end
function GuildSharedInfo:SetGuildId(guildId) end
function GuildSharedInfo:Refresh(guildId) end
function ZO_GuildSharedInfoBank_OnMouseEnter(control) end
function ZO_GuildSharedInfoBank_OnMouseExit(control) end
function ZO_GuildSharedInfoTradingHouse_OnMouseEnter(control) end
function ZO_GuildSharedInfoTradingHouse_OnMouseExit(control) end
function ZO_GuildSharedInfoHeraldry_OnMouseEnter(control) end
function ZO_GuildSharedInfoHeraldry_OnMouseExit(control) end
function ZO_GuildSharedInfo_OnInitialized(self) end
function GuildCreateManager:New(control) end
function GuildCreateManager:InitializeKeybindDescriptor() end
function GuildCreateManager:RefreshGuildCreateStatus() end
function ZO_GuildCreate_OnInitialized(self) end
function ZO_GuildHeraldryManager_Keyboard:New(...) end
function ZO_GuildHeraldryManager_Keyboard:Initialize(control) end
function ZO_GuildHeraldryManager_Keyboard:InitializeHeaderPool() end
function ZO_GuildHeraldryManager_Keyboard:GetPurchaseDialogName() end
function ZO_GuildHeraldryManager_Keyboard:GetApplyChangesDialogName() end
function ZO_GuildHeraldryManager_Keyboard:ChangeSelectedGuild(changeGuildCallback, changeGuildParams) end
function ZO_GuildHeraldryManager_Keyboard:IsCurrentBlockingScene() end
function ZO_GuildHeraldryManager_Keyboard:ConfirmExit() end
function ZO_GuildHeraldryManager_Keyboard:CancelExit() end
function ZO_GuildHeraldryManager_Keyboard:NoChoiceExitCallback() end
function ZO_GuildHeraldryManager_Keyboard:InitializeKeybindStripDescriptors() end
function ZO_GuildHeraldryManager_Keyboard:UpdateKeybindGroups() end
function ZO_GuildHeraldryManager_Keyboard:InitializeNavigationTree() end
function ZO_GuildHeraldryManager_Keyboard:InitializeCategories() end
function ZO_GuildHeraldryManager_Keyboard:SwitchMode(mode) end
function ZO_GuildHeraldryManager_Keyboard:SetSelectedHeraldryIndices() end
function ZO_GuildHeraldryManager_Keyboard:PopulateColors(activeSwatches, sortedCategories) end
function ZO_GuildHeraldryManager_Keyboard:SetupHeraldryDialog(control) end
function ZO_GuildHeraldryManager_Keyboard:ConfirmHeraldryPurchase() end
function ZO_GuildHeraldryManager_Keyboard:ConfirmHeraldryApplyChanges() end
function ZO_GuildHeraldry_OnInitialized(control) end
function GuildHistoryManager:New(control) end
function GuildHistoryManager:InitializeKeybindDescriptors() end
function GuildHistoryManager:CreateCategoryTree() end
function GuildHistoryManager:SetGuildId(guildId) end
function GuildHistoryManager:SetupGuildEvent(control, data) end
function GuildHistoryManager:FormatEvent(eventType, ...) end
function GuildHistoryManager:ShouldShowEventType(eventType) end
function GuildHistoryManager:BuildMasterList() end
function GuildHistoryManager:FilterScrollList() end
function GuildHistoryManager:CompareGuildEvents(listEntry1, listEntry2) end
function GuildHistoryManager:SortScrollList() end
function GuildHistoryManager:RequestNewest(force) end
function GuildHistoryManager:RequestOlder(force) end
function GuildHistoryManager:IncrementRequestCount() end
function GuildHistoryManager:DecrementRequestCount() end
function GuildHistoryManager:OnGuildHistoryCategoryUpdated(guildId, category) end
function GuildHistoryManager:OnGuildHistoryResponseReceived() end
function ZO_GuildHistory_OnInitialized(self) end
function GuildHomeManager:New(control) end
function GuildHomeManager:InitializeKeybindDescriptors() end
function GuildHomeManager:SetGuildId(guildId) end
function GuildHomeManager:RefreshGuildMaster() end
function GuildHomeManager:RefreshMotD() end
function GuildHomeManager:RefreshDescription() end
function GuildHomeManager:RefreshPermissions() end
function GuildHomeManager:RefreshFoundedDate() end
function GuildHomeManager:RefreshKeepOwnership() end
function GuildHomeManager:RefreshTraderOwnership() end
function GuildHomeManager:RefreshReleaseKeep() end
function GuildHomeManager:RefreshAll() end
function GuildHomeManager:OnGuildMotDChanged() end
function GuildHomeManager:OnGuildDescriptionChanged() end
function GuildHomeManager:OnProfanityFilterChanged() end
function GuildHomeManager:OnGuildRanksChanged() end
function GuildHomeManager:OnGuildMemberRankChanged() end
function GuildHomeManager:OnGuildRankChanged() end
function GuildHomeManager:OnGuildKeepClaimUpdated() end
function GuildHomeManager:OnGuildTraderHiredUpdated() end
function ZO_GuildHome_OnInitialized(self) end
function ZO_KeyboardGuildRosterManager:New(...) end
function ZO_KeyboardGuildRosterManager:Initialize(control) end
function ZO_KeyboardGuildRosterManager:PerformDeferredInitialization() end
function ZO_KeyboardGuildRosterManager:InitializeKeybindDescriptor() end
function ZO_KeyboardGuildRosterManager:OnGuildIdChanged(guildId) end
function ZO_KeyboardGuildRosterManager:BuildMasterList() end
function ZO_KeyboardGuildRosterManager:FilterScrollList() end
function ZO_KeyboardGuildRosterManager:CompareGuildMembers(listEntry1, listEntry2) end
function ZO_KeyboardGuildRosterManager:SortScrollList() end
function ZO_KeyboardGuildRosterManager:ColorRow(control, data, selected) end
function ZO_KeyboardGuildRosterManager:SetupRow(control, data) end
function ZO_KeyboardGuildRosterManager:UnlockSelection() end
function ZO_KeyboardGuildRosterManager:OnEffectivelyHidden() end
function ZO_KeyboardGuildRosterManager:OnSearchTextChanged() end
function ZO_KeyboardGuildRosterManager:GuildRosterRow_OnMouseUp(control, button, upInside) end
function ZO_KeyboardGuildRosterManager:GuildRosterRowRank_OnMouseEnter(control) end
function ZO_KeyboardGuildRosterManager:GuildRosterRowRank_OnMouseExit(control) end
function ZO_KeyboardGuildRosterRow_OnMouseEnter(control) end
function ZO_KeyboardGuildRosterRow_OnMouseExit(control) end
function ZO_KeyboardGuildRosterRow_OnMouseUp(control, button, upInside) end
function ZO_KeyboardGuildRosterRowNote_OnMouseEnter(control) end
function ZO_KeyboardGuildRosterRowNote_OnMouseExit(control) end
function ZO_KeyboardGuildRosterRowNote_OnClicked(control) end
function ZO_KeyboardGuildRosterRowDisplayName_OnMouseEnter(control) end
function ZO_KeyboardGuildRosterRowDisplayName_OnMouseExit(control) end
function ZO_KeyboardGuildRosterRowAlliance_OnMouseEnter(control) end
function ZO_KeyboardGuildRosterRowAlliance_OnMouseExit(control) end
function ZO_KeyboardGuildRosterRowStatus_OnMouseEnter(control) end
function ZO_KeyboardGuildRosterRowStatus_OnMouseExit(control) end
function ZO_KeyboardGuildRosterRowClass_OnMouseEnter(control) end
function ZO_KeyboardGuildRosterRowClass_OnMouseExit(control) end
function ZO_KeyboardGuildRosterRowChampion_OnMouseEnter(control) end
function ZO_KeyboardGuildRosterRowChampion_OnMouseExit(control) end
function ZO_KeyboardGuildRosterRowRank_OnMouseEnter(control) end
function ZO_KeyboardGuildRosterRowRank_OnMouseExit(control) end
function ZO_KeyboardGuildRoster_OnInitialized(control) end
function ZO_KeyboardGuildRoster_ToggleHideOffline(self) end
function GuildSelector:New(...) end
function GuildSelector:Initialize(control) end
function GuildSelector:SetGuildWindowsToId(guildId) end
function GuildSelector:IsGuildRelatedSceneShowing() end
function GuildSelector:InitializeGuilds() end
function GuildSelector:SetGuildIcon(guildId) end
function GuildSelector:SelectGuild(selectedEntry) end
function GuildSelector:SelectGuildByIndex(index) end
function GuildSelector:OnScenesCreated() end
function ZO_GuildSelector_OnInitialized(self) end
function ZO_GuildRank_Keyboard:New(control, poolKey, guildId, index, customName) end
function ZO_GuildRank_Keyboard:SetIconIndex(iconIndex) end
function ZO_GuildRank_Keyboard:GetHeaderControl() end
function ZO_GuildRank_Keyboard:RefreshAnchor(prevRank) end
function ZO_GuildRank_Keyboard:SetSelected(selected) end
function ZO_GuildRank_Keyboard:SetName(name) end
function ZO_GuildRanks_Keyboard:New(...) end
function ZO_GuildRanks_Keyboard:Initialize(control) end
function ZO_GuildRanks_Keyboard:InitializeKeybindDescriptor() end
function ZO_GuildRanks_Keyboard:Save() end
function ZO_GuildRanks_Keyboard:CreatePermissions() end
function ZO_GuildRanks_Keyboard:CreateIconSelectors() end
function ZO_GuildRanks_Keyboard:SetGuildId(guildId) end
function ZO_GuildRanks_Keyboard:RefreshRanksFromGuildData() end
function ZO_GuildRanks_Keyboard:RefreshRankIndices() end
function ZO_GuildRanks_Keyboard:AddRank(rankName, copyPermissionsFromRankIndex) end
function ZO_GuildRanks_Keyboard:RemoveRank(rankId) end
function ZO_GuildRanks_Keyboard:StartDragging(rank) end
function ZO_GuildRanks_Keyboard:UpdateRankOrder() end
function ZO_GuildRanks_Keyboard:StopDragging() end
function ZO_GuildRanks_Keyboard:RefreshRankHeaderLayout() end
function ZO_GuildRanks_Keyboard:SelectRank(rankId, playSound) end
function ZO_GuildRanks_Keyboard:RefreshEditPermissions() end
function ZO_GuildRanks_Keyboard:RefreshAddRank() end
function ZO_GuildRanks_Keyboard:RefreshRemoveRank() end
function ZO_GuildRanks_Keyboard:RefreshRankInfo() end
function ZO_GuildRanks_Keyboard:RefreshRankIcon() end
function ZO_GuildRanks_Keyboard:RefreshPermissions(rank, setType) end
function ZO_GuildRanks_Keyboard:ClearPermissionIcons() end
function ZO_GuildRanks_Keyboard:RefreshIconSelectors() end
function ZO_GuildRanks_Keyboard:GetSelectedRankId() end
function ZO_GuildRanks_Keyboard:DoAllRanksHaveAName() end
function ZO_GuildRanks_Keyboard:Cancel() end
function ZO_GuildRanks_Keyboard:CanSave() end
function ZO_GuildRanks_Keyboard:IsCurrentBlockingScene() end
function ZO_GuildRanks_Keyboard:AttemptSaveIfBlocking() end
function ZO_GuildRanks_Keyboard:AttemptSaveAndExit() end
function ZO_GuildRanks_Keyboard:ConfirmExit(applyChanges) end
function ZO_GuildRanks_Keyboard:CancelExit() end
function ZO_GuildRanks_Keyboard:RefreshSaveEnabled() end
function ZO_GuildRanks_Keyboard:ShowRankSaveChangesDialog(dialogCallback, dialogParams) end
function ZO_GuildRanks_Keyboard:ChangeSelectedGuild(dialogCallback, dialogParams) end
function ZO_GuildRanks_Keyboard:IsGuildPendingChanges(guildId) end
function ZO_GuildRanks_Keyboard:ClearSavePending() end
function ZO_GuildRanks_Keyboard:OnGuildDataLoaded() end
function ZO_GuildRanks_Keyboard:OnSaveGuildRanksResponse(result, guildId) end
function ZO_GuildRanks_Keyboard:OnGuildRanksChanged(guildId) end
function ZO_GuildRanks_Keyboard:OnGuildRankChanged(rankIndex, guildId) end
function ZO_GuildRanks_Keyboard:OnGuildMemberRankChanged(displayName) end
function ZO_GuildRanks_Keyboard:OnRankNameEdited(name) end
function ZO_GuildRanks_Keyboard:GuildRankHeader_OnMouseEnter(header) end
function ZO_GuildRanks_Keyboard:GuildRankHeader_OnMouseExit(header) end
function ZO_GuildRanks_Keyboard:GuildRankHeader_OnMouseDown(header) end
function ZO_GuildRanks_Keyboard:GuildRankHeader_OnMouseUp(header) end
function ZO_GuildRanks_Keyboard:GuildRankHeader_OnDragStart(header) end
function ZO_GuildRanks_Keyboard:GuildPermission_OnToggled(permission, checked) end
function ZO_GuildRanks_Keyboard:GuildRankIconSelector_OnMouseEnter(control) end
function ZO_GuildRanks_Keyboard:GuildRankIconSelector_OnMouseExit(control) end
function ZO_GuildRanks_Keyboard:GuildRankIconSelector_OnMouseClicked(control) end
function ZO_GuildRanks_Keyboard:GuildRankNameEdit_OnTextChanged(control) end
function ZO_GuildRankNameEdit_OnTextChanged(self) end
function ZO_GuildRankIconSelector_OnMouseEnter(self) end
function ZO_GuildRankIconSelector_OnMouseExit(self) end
function ZO_GuildRankIconSelector_OnMouseClicked(self) end
function ZO_GuildPermissionCheck_OnToggled(self, checked) end
function ZO_GuildRankHeaderChild_OnDragStart(self) end
function ZO_GuildRankHeader_OnMouseDown(self) end
function ZO_GuildRankHeader_OnMouseUp(self, upInside) end
function ZO_GuildRankHeader_OnMouseEnter(self) end
function ZO_GuildRankHeader_OnMouseExit(self) end
function ZO_GuildRanks_OnInitialized(self) end
function ZO_SelectGuildDialog:New(...) end
function ZO_SelectGuildDialog:Initialize(control, dialogName, acceptFunction, declineFunction) end
function ZO_SelectGuildDialog:GetSelectedGuildId() end
function ZO_SelectGuildDialog:OnGuildSelected(entry) end
function ZO_SelectGuildDialog:SetTitle(title) end
function ZO_SelectGuildDialog:SetButtonText(index, text) end
function ZO_SelectGuildDialog:SetPrompt(prompt) end
function ZO_SelectGuildDialog:SetGuildFilter(filterFunction) end
function ZO_SelectGuildDialog:SetCurrentStateSource(currentStateFunction) end
function ZO_SelectGuildDialog:SetSelectedCallback(selectedCallback) end
function ZO_SelectGuildDialog:SetDialogUpdateFn(updateFunction) end
function ZO_SelectGuildDialog:HasEntries() end
function ZO_SelectGuildDialog:RefreshGuildList() end
function ZO_SelectGuildDialog:OnGuildInformationChanged() end
function ZO_SelectGuildDialog:Setup(control) end
function ZO_GuildRank_Shared:New(guildRanksObject, guildId, index, customName) end
function ZO_GuildRank_Shared:SetName(name) end
function ZO_GuildRank_Shared:GetName() end
function ZO_GuildRank_Shared:GetRankId() end
function ZO_GuildRank_Shared:GetIconIndex() end
function ZO_GuildRank_Shared:SetIconIndex(index) end
function ZO_GuildRank_Shared:GetSmallIcon() end
function ZO_GuildRank_Shared:GetLargeIcon() end
function ZO_GuildRank_Shared:IsPermissionSet(permission) end
function ZO_GuildRank_Shared:SetPermission(permission, enabled) end
function ZO_GuildRank_Shared:GetPermissions() end
function ZO_GuildRank_Shared:GetSaveName() end
function ZO_GuildRank_Shared:IsNewRank() end
function ZO_GuildRank_Shared:NeedsSave() end
function ZO_GuildRank_Shared:CopyPermissionsFrom(copyRank) end
function ZO_GuildRank_Shared:Save() end
function ZO_GuildRanks_Shared:New(...) end
function ZO_GuildRanks_Shared:Initialize(control) end
function ZO_GuildRanks_Shared:SetGuildId(guildId) end
function ZO_GuildRanks_Shared:CancelDialog() end
function ZO_GuildRanks_Shared:ShowAddRankDialog(dialogName) end
function ZO_GuildRanks_Shared:InitializeAddRankDialog(dialogName) end
function ZO_GuildRanks_Shared:Save() end
function ZO_GuildRanks_Shared:GetUniqueRankId() end
function ZO_GuildRanks_Shared:GetUnusedIconIndex() end
function ZO_GuildRanks_Shared:IsRankOccupied(selectedRank) end
function ZO_GuildRanks_Shared:MatchesGuild(guildId) end
function ZO_GuildRanks_Shared:NeedsSave() end
function ZO_GuildRanks_Shared_RefreshIcon(control, index, selectedIconIndex) end
function ZO_GuildRanks_Shared:InsertRank(newRank, copyPermissionsFromRankIndex) end
function ZO_GuildRanks_Shared:GetRankById(rankId) end
function ZO_GuildRanks_Shared:GetRankIndexById(rankId) end
function ZO_AddLeaveGuildMenuItem(playerGuildId) end
function ZO_ShowLeaveGuildDialog(playerGuildId, data, isGamepad) end
function ZO_CanPlayerCreateGuild() end
function ZO_UpdateGuildStatusDropdownSelection(dropdown) end
function ZO_UpdateGuildStatusDropdown(dropdown) end
function ZO_GetGuildCreateError() end
function ZO_SetGuildCreateError(label) end
function ZO_ValidatePlayerGuildId(guildIdToValidate) end
function ZO_TryGuildInvite(guildId, displayName) end
--ingame\guildkiosk
function ZO_GuildKiosk_Purchase_Gamepad:New(...) end
function ZO_GuildKiosk_Purchase_Gamepad:Initialize(control) end
function ZO_GuildKiosk_Purchase_Gamepad:OnUpdate(_, gameTimeSecs) end
function ZO_GuildKiosk_Purchase_Gamepad:SetupDialogLabels(control, data) end
function ZO_GuildKiosk_Purchase_Gamepad:PerformDeferredInitialize() end
function ZO_GuildKiosk_Purchase_Gamepad:FocusDropDown() end
function ZO_GuildKiosk_Purchase_Gamepad:UnfocusDropDown() end
function ZO_GuildKiosk_Purchase_Gamepad:OnGuildsRefreshed(guildEntry) end
function ZO_GuildKiosk_Purchase_Gamepad:OnGuildSelected(guildEntry) end
function ZO_GuildKiosk_Purchase_Gamepad:OnGuildKioskConsiderPurchaseStart() end
function ZO_GuildKiosk_Purchase_Gamepad:OnGuildKioskConsiderPurchaseStop() end
function ZO_GuildKiosk_Purchase_Gamepad:Hide() end
function ZO_GuildKiosk_Purchase_Gamepad:Show() end
function ZO_GuildKiosk_Purchase_Gamepad:OnShowing() end
function ZO_GuildKiosk_Purchase_Gamepad:OnHide() end
function ZO_GuildKiosk_Purchase_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_GuildKiosk_Purchase_Gamepad:SetTitle(title) end
function ZO_Gamepad_GuildKiosk_Purchase_OnInitialize(control) end
function ZO_GuildKiosk_Bid_Gamepad:New(...) end
function ZO_GuildKiosk_Bid_Gamepad:Initialize(control) end
function ZO_GuildKiosk_Bid_Gamepad:OnShowing() end
function ZO_GuildKiosk_Bid_Gamepad:OnHide() end
function ZO_GuildKiosk_Bid_Gamepad:SetupDialogLabels(control, data) end
function ZO_GuildKiosk_Bid_Gamepad:OnUpdate(gameTimeSecs) end
function ZO_GuildKiosk_Bid_Gamepad:CleanDropDown() end
function ZO_GuildKiosk_Bid_Gamepad:ValidateBidSelectorValue(value) end
function ZO_GuildKiosk_Bid_Gamepad:SetupList(list) end
function ZO_GuildKiosk_Bid_Gamepad:PerformDeferredInitialize() end
function ZO_GuildKiosk_Bid_Gamepad:RepopulateItemList(createBidSelector) end
function ZO_GuildKiosk_Bid_Gamepad:FocusDropDown() end
function ZO_GuildKiosk_Bid_Gamepad:UnfocusDropDown() end
function ZO_GuildKiosk_Bid_Gamepad:FocusBidSelector() end
function ZO_GuildKiosk_Bid_Gamepad:UnfocusBidSelector() end
function ZO_GuildKiosk_Bid_Gamepad:OnGuildsRefreshed(guildEntry) end
function ZO_GuildKiosk_Bid_Gamepad:OnGuildSelected(guildEntry) end
function ZO_GuildKiosk_Bid_Gamepad:SetHasError(hasError) end
function ZO_GuildKiosk_Bid_Gamepad:SetBidAmount(bidAmount) end
function ZO_GuildKiosk_Bid_Gamepad:OnGuildKioskConsiderBidStart() end
function ZO_GuildKiosk_Bid_Gamepad:OnGuildKioskConsiderBidStop() end
function ZO_GuildKiosk_Bid_Gamepad:Hide() end
function ZO_GuildKiosk_Bid_Gamepad:Show() end
function ZO_GuildKiosk_Bid_Gamepad:PerformUpdate() end
function ZO_GuildKiosk_Bid_Gamepad:OnHiding() end
function ZO_GuildKiosk_Bid_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_GuildKiosk_Bid_Gamepad:SetTitle(title) end
function ZO_Gamepad_GuildKiosk_Bid_OnInitialize(control) end
function ZO_GuildKiosk_Purchase_Shared:New(...) end
function ZO_GuildKiosk_Purchase_Shared:Initialize() end
function ZO_GuildKiosk_Purchase_OnUpdate(descriptionLabel, gameTimeSecs) end
function ZO_GuildKiosk_Bid_Shared:New(...) end
function ZO_GuildKiosk_Bid_Shared:Initialize() end
function PurchaseKioskDialog:New(...) end
function PurchaseKioskDialog:Initialize(control) end
function PurchaseKioskDialog:OnGuildSelected(guildId) end
function PurchaseKioskDialog:OnGuildKioskConsiderPurchaseStart() end
function PurchaseKioskDialog:OnGuildKioskConsiderPurchaseStop() end
function ZO_GuildKioskPurchaseDialog_OnInitialized(self) end
function BidOnKioskDialog:New(...) end
function BidOnKioskDialog:Initialize(control) end
function BidOnKioskDialog:OnUpdate(gameTimeSecs) end
function BidOnKioskDialog:OnGuildSelected(guildId) end
function BidOnKioskDialog:RefreshUpdateBidEnabled(bidAmount) end
function BidOnKioskDialog:OnMoneyChanged(money) end
function BidOnKioskDialog:OnGuildKioskConsiderBidStart() end
function BidOnKioskDialog:OnGuildKioskConsiderBidStop() end
function ZO_GuildKioskBidDialog_OnInitialized(self) end
--ingame\help
function HelpTutorialsCategoriesGamepad:New(...) end
function HelpTutorialsCategoriesGamepad:Initialize(control) end
function HelpTutorialsCategoriesGamepad:InitializeKeybindStripDescriptors() end
function HelpTutorialsCategoriesGamepad:AddListEntry(categoryIndex) end
function HelpTutorialsCategoriesGamepad:IsCategoryEmpty(categoryIndex) end
function HelpTutorialsCategoriesGamepad:PerformUpdate() end
function ZO_Gamepad_Tutorials_Categories_OnInitialize(control) end
function ZO_HelpTutorialsGamepad:New(...) end
function ZO_HelpTutorialsGamepad:Initialize(control, activateOnShow) end
function ZO_HelpTutorialsGamepad:InitializeEvents() end
function ZO_HelpTutorialsGamepad:SetupSearchHeaderData(searchString, headerData) end
function ZO_Help_Customer_Service_Gamepad:New(...) end
function ZO_Help_Customer_Service_Gamepad:Initialize(control) end
function ZO_Help_Customer_Service_Gamepad:OnShowing() end
function ZO_Help_Customer_Service_Gamepad:OnHide() end
function ZO_Help_Customer_Service_Gamepad:AnchorTextHelper(anchorDest, controlToAnchor) end
function ZO_Help_Customer_Service_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_Help_Customer_Service_Gamepad:AddKeybindsBasedOnState() end
function ZO_Help_Customer_Service_Gamepad:TrySubmitTicket() end
function ZO_Help_Customer_Service_Gamepad:ValidateTicketFields() end
function ZO_Help_Customer_Service_Gamepad:SubmitTicket() end
function ZO_Help_Customer_Service_Gamepad:ResetTicket() end
function ZO_Help_Customer_Service_Gamepad:OnCustomerServiceTicketSubmitted(eventCode, response, success) end
function ZO_Help_Customer_Service_Gamepad:SetReportPlayerTargetByDisplayName(displayName) end
function ZO_Help_Customer_Service_Gamepad:SetQuestTargetByName(questName) end
function ZO_Help_Customer_Service_Gamepad:SetItemTargetByName(itemName) end
function ZO_Help_Customer_Service_Gamepad:SetItemTargetByItemLink(itemLink) end
function ZO_Help_Customer_Service_Gamepad:SetBodyText(bodyText) end
function ZO_Help_Customer_Service_Gamepad:SetCategory(categoryId) end
function ZO_Help_Customer_Service_Gamepad:SetSubcategory(subcategoryId) end
function ZO_Help_Customer_Service_Gamepad:SetRequiredInfoProvidedInternally(isProvidedInternally) end
function ZO_Help_Customer_Service_Gamepad:PrefillContactEmail() end
function ZO_Help_Customer_Service_Gamepad:GetCurrentCategory() end
function ZO_Help_Customer_Service_Gamepad:GetCategoryIdFromIndex(categoryIndex) end
function ZO_Help_Customer_Service_Gamepad:OnTextFieldFocusLost(control, fieldType) end
function ZO_Help_Customer_Service_Gamepad:SetupList(list) end
function ZO_Help_Customer_Service_Gamepad:DropdownItemCallback(selectionIndex, fieldType, ticketCategoryId) end
function ZO_Help_Customer_Service_Gamepad:BuildDropdownList(dropdown, data) end
function ZO_Help_Customer_Service_Gamepad:UpdateDropdownSelection(dropdown, fieldType) end
function ZO_Help_Customer_Service_Gamepad:SetCurrentDropdown(dropdown) end
function ZO_Help_Customer_Service_Gamepad:ActivateCurrentDropdown(fieldType) end
function ZO_Help_Customer_Service_Gamepad:DeactivateItemList() end
function ZO_Help_Customer_Service_Gamepad:ActivateItemList() end
function ZO_Help_Customer_Service_Gamepad:AddTextFieldEntry(fieldType, header, required, locked) end
function ZO_Help_Customer_Service_Gamepad:AddDropdownEntry(fieldType, header, list) end
function ZO_Help_Customer_Service_Gamepad:AddSubmitEntry() end
function ZO_Help_Customer_Service_Gamepad:PerformUpdate() end
function ZO_Help_Customer_Service_Gamepad:UpdateFields() end
function ZO_Help_Customer_Service_Gamepad:OnSelectionChanged(list, selectedData, oldSelectedData) end
function ZO_Help_Customer_Service_Gamepad_OnInitialize(control) end
function ZO_Help_Customer_Service_Gamepad_SetupReportPlayerTicket(displayName) end
function ZO_Help_Customer_Service_Gamepad_SetupItemIssueTicket(itemLink) end
function ZO_Help_Customer_Service_Gamepad_SetupQuestIssueTicket(questName) end
function ZO_Help_Customer_Service_Gamepad_SubmitReportPlayerSpammingTicket(displayName) end
function HelpTutorialsEntriesGamepad:New(...) end
function HelpTutorialsEntriesGamepad:Initialize(control) end
function HelpTutorialsEntriesGamepad:Push(categoryIndex, helpIndex) end
function HelpTutorialsEntriesGamepad:InitializeKeybindStripDescriptors() end
function HelpTutorialsEntriesGamepad:AddHelpEntry(categoryIndex, helpIndex) end
function HelpTutorialsEntriesGamepad:PerformUpdate() end
function HelpTutorialsEntriesGamepad:SelectHelpEntry(helpIndex) end
function HelpTutorialsEntriesGamepad:OnSelectionChanged(list, selectedData, oldSelectedData) end
function HelpTutorialsEntriesGamepad:OnHide() end
function ZO_Gamepad_Tutorials_Entries_OnTextureLoaded(control) end
function ZO_Gamepad_Tutorials_Entries_OnInitialize(control) end
function ZO_GamepadHelpLegal:New(...) end
function ZO_GamepadHelpLegal:Initialize(control) end
function ZO_GamepadHelpLegal:InitializeKeybindDescriptors() end
function ZO_GamepadHelpLegal:SetupText() end
function ZO_GamepadHelpLegal_OnInitialize(control) end
function ZO_Help_Root_Gamepad:New(...) end
function ZO_Help_Root_Gamepad:Initialize(control) end
function ZO_Help_Root_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_Help_Root_Gamepad:OnDeferredInitialize() end
function ZO_Help_Root_Gamepad:OnPlayerActivated() end
function ZO_Help_Root_Gamepad:OnStuckBegin() end
function ZO_Help_Root_Gamepad:OnStuckCanceled() end
function ZO_Help_Root_Gamepad:OnStuckComplete() end
function ZO_Help_Root_Gamepad:OnStuckErrorAlreadyInProgress() end
function ZO_Help_Root_Gamepad:OnStuckErrorInvalidLocation() end
function ZO_Help_Root_Gamepad:OnStuckErrorInCombat() end
function ZO_Help_Root_Gamepad:OnStuckErrorOnCooldown() end
function ZO_Help_Root_Gamepad:OnShowing() end
function ZO_Help_Root_Gamepad:InitializeDialogs() end
function ZO_Help_Root_Gamepad:InitializeUnstuckConfirmDialog() end
function ZO_Help_Root_Gamepad:InitializeUnstuckCooldownDialog() end
function ZO_Help_Root_Gamepad:InitializeUnstuckLoadingDialog() end
function ZO_Help_Root_Gamepad:InitializeUnstuckErrorDialog(dialogName, dialogText) end
function ZO_Help_Root_Gamepad:InitializeCSDisabledDialog() end
function ZO_Help_Root_Gamepad:PopulateList() end
function ZO_Help_Root_Gamepad:PerformUpdate() end
function ZO_Gamepad_Help_Root_OnInitialize(control) end
function HelpAskForHelp_Keyboard:New(...) end
function HelpAskForHelp_Keyboard:Initialize(control) end
function HelpAskForHelp_Keyboard:InitializeComboBoxes() end
function HelpAskForHelp_Keyboard:InitializeTextBoxes() end
function HelpAskForHelp_Keyboard:InitializeDialogs() end
function HelpAskForHelp_Keyboard:UpdateSubcategories() end
function HelpAskForHelp_Keyboard:UpdateDetailsComponents() end
function HelpAskForHelp_Keyboard:UpdateExtraInfo() end
function HelpAskForHelp_Keyboard:SetSubcategoryContentHidden(shouldHide) end
function HelpAskForHelp_Keyboard:SetDetailsContentHidden(shouldHide) end
function HelpAskForHelp_Keyboard:SetExtraInfoContentHidden(shouldHide) end
function HelpAskForHelp_Keyboard:UpdateSubmitButton() end
function HelpAskForHelp_Keyboard:ClearFields() end
function HelpAskForHelp_Keyboard:SelectCategory(category) end
function HelpAskForHelp_Keyboard:SelectSubcategory(subcategory) end
function HelpAskForHelp_Keyboard:GetSavedItemLink() end
function HelpAskForHelp_Keyboard:SetDetailsText(text) end
function HelpAskForHelp_Keyboard:SetDetailsFromItemLink(itemLink) end
function HelpAskForHelp_Keyboard:SetDetailsFromQuestName(questName) end
function HelpAskForHelp_Keyboard:OpenAskForHelp(category, subcategory) end
function HelpAskForHelp_Keyboard:AttemptToSendTicket() end
function HelpAskForHelp_Keyboard:OnCustomerServiceTicketSubmitted(eventCode, response, success) end
function ZO_HelpAskForHelp_Keyboard_OnInitialized(self) end
function ZO_HelpAskForHelp_Keyboard_AttemptToSendTicket() end
function ZO_HelpAskForHelp_OnForumLinkClicked() end
function HelpCharacterStuck_Keyboard:New(...) end
function HelpCharacterStuck_Keyboard:Initialize(control) end
function HelpCharacterStuck_Keyboard:UpdateCost() end
function ZO_HelpCharacterStuck_Keyboard_OnInitialized(self) end
function ZO_HelpCharacterStuck_Keyboard_UnstuckPlayer(self) end
function HelpCustomerService_Keyboard:New(...) end
function HelpCustomerService_Keyboard:Initialize(control) end
function HelpCustomerService_Keyboard:InitializeTree() end
function HelpCustomerService_Keyboard:InitializeHelpDialogs() end
function HelpCustomerService_Keyboard:AddCategory(data) end
function HelpCustomerService_Keyboard:ShowCategory(data) end
function HelpCustomerService_Keyboard:OpenScreen(fragment) end
function ZO_HelpCustomerService_Keyboard_Initialize(control) end
function HelpOverview_Keyboard:New(...) end
function HelpOverview_Keyboard:Initialize(control) end
function HelpOverview_Keyboard:InitializeQuestionsAndAnswers() end
function ZO_HelpOverview_Keyboard_OnInitialized(self) end
function ZO_HelpScreenTemplate_Keyboard:New(...) end
function ZO_HelpScreenTemplate_Keyboard:Initialize(control, data) end
function HelpSubmitFeedback_Keyboard:New(...) end
function HelpSubmitFeedback_Keyboard:Initialize(control) end
function HelpSubmitFeedback_Keyboard:InitializeComboBoxes() end
function HelpSubmitFeedback_Keyboard:InitializeTextBox() end
function HelpSubmitFeedback_Keyboard:InitializeCheckButton() end
function HelpSubmitFeedback_Keyboard:InitializeDialogs() end
function HelpSubmitFeedback_Keyboard:UpdateSubcategories() end
function HelpSubmitFeedback_Keyboard:UpdateDetailsComponents() end
function HelpSubmitFeedback_Keyboard:SetSubcategoryContentHidden(shouldHide) end
function HelpSubmitFeedback_Keyboard:SetDetailsContentHidden(shouldHide) end
function HelpSubmitFeedback_Keyboard:UpdateSubmitButton() end
function HelpSubmitFeedback_Keyboard:ClearFields() end
function HelpSubmitFeedback_Keyboard:AttemptToSendFeedback() end
function HelpSubmitFeedback_Keyboard:OnCustomerServiceFeedbackSubmitted(eventCode, response, success) end
function ZO_HelpSubmitFeedback_Keyboard_OnInitialized(self) end
function ZO_HelpSubmitFeedback_Keyboard_AttemptToSendFeedback() end
function ZO_HelpManager:New(...) end
function ZO_HelpManager:Initialize(control) end
function ZO_HelpManager:ShowSpecificHelp(helpCategoryIndex, helpIndex) end
function ZO_HelpManager:OnShow() end
function ZO_HelpManager:OnHide() end
function ZO_HelpManager:InitializeTree() end
function ZO_HelpManager:SelectHelp(helpCategoryIndex, helpIndex) end
function ZO_HelpManager:AddHelpEntry(helpCategoryIndex, helpIndex) end
function ZO_HelpManager:AddTrialEntry() end
function ZO_HelpManager:RefreshList() end
function ZO_HelpManager:Refresh() end
function ZO_HelpManager:RefreshDetails() end
function ZO_HelpManager:SearchStart(searchString) end
function ZO_Help_BeginSearch(editBox) end
function ZO_Help_EndSearch(editBox) end
function ZO_Help_OnSearchTextChanged(editBox) end
function ZO_Help_OnSearchEnterKeyPressed(editBox) end
function ZO_Tutorials_Entries_OnTextureLoaded(control) end
function ZO_Help_Initialize(control) end
function ZO_Help_OnShow(control) end
function ZO_Help_OnHide(control) end
--ingame\housingeditor
function ZO_HousingFurnitureBrowser_Gamepad:New(...) end
function ZO_HousingFurnitureBrowser_Gamepad:Initialize(control) end
function ZO_HousingFurnitureBrowser_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_HousingFurnitureBrowser_Gamepad:OnShowing() end
function ZO_HousingFurnitureBrowser_Gamepad:OnHiding() end
function ZO_HousingFurnitureBrowser_Gamepad:RefreshMainList() end
function ZO_HousingFurnitureBrowser_Gamepad:OnTargetChanged(list, targetData, oldTargetData) end
function ZO_HousingFurnitureBrowser_Gamepad_OnInitialize(control) end
function ZO_HousingEditorHUDFragment:New(control) end
function ZO_HousingEditorHUDFragment:Show() end
function ZO_HousingEditorHUDFragment:Hide() end
function ZO_HousingEditorHUDFragment:UpdateVisibility() end
function ZO_HousingEditorHud:New(...) end
function ZO_HousingEditorHud:Initialize(control) end
function ZO_HousingEditorHud:OnHousingModeEnabled() end
function ZO_HousingEditorHud:OnHousingModeDisabled() end
function ZO_HousingEditorHud:OnHousingModeChanged(oldMode, newMode) end
function ZO_HousingEditorHud:OnDeferredInitialization() end
function ZO_HousingEditorHud:UpdateKeybinds() end
function ZO_HousingEditorHud:CleanDirty() end
function ZO_HousingEditorHud:SetupSceneFragments() end
function ZO_HousingEditorHud_OnInitialize(control) end
function ZO_HousingFurnitureBrowser_Base:New(...) end
function ZO_HousingFurnitureBrowser_Base:Initialize(control) end
function ZO_HousingFurnitureBrowser_Base:RefreshMainList() end
function ZO_HousingFurnitureBrowser_Keyboard:New(...) end
function ZO_HousingFurnitureBrowser_Keyboard:Initialize(control) end
function ZO_HousingFurnitureBrowser_Keyboard:OnDeferredInitialization() end
function ZO_HousingFurnitureBrowser_Keyboard:InitializeKeybindStripDescriptors() end
function ZO_HousingFurnitureBrowser_Keyboard:OnShowing() end
function ZO_HousingFurnitureBrowser_Keyboard:RefreshMainList() end
function ZO_HousingFurnitureBrowser_Keyboard_OnMouseClick(self) end
function ZO_HousingFurnitureBrowser_Keyboard_OnMouseDoubleClick(self) end
function ZO_HousingFurnitureBrowser_Keyboard_OnInitialize(control) end
function ZO_SharedFurnitureManager:New(...) end
function ZO_SharedFurnitureManager:Initialize() end
function ZO_SharedFurnitureManager:OnFullInventoryUpdate(bagId) end
function ZO_SharedFurnitureManager:OnSingleSlotInventoryUpdate(bagId, slotIndex) end
function ZO_SharedFurnitureManager:GetFurnitureCache(type) end
function ZO_SharedFurnitureManager:CreateOrUpdateItemCache(bagId) end
function ZO_SharedFurnitureManager:CreateTestCache() end
function ZO_SharedFurnitureManager:CreateOrUpdateItemDataEntry(bagId, slotIndex) end
function ZO_SharedFurnitureManager:CreateTestDataEntry(index) end
--ingame\hud
function HUDIndicator:New(control, data) end
function HUDIndicator:Initialize(control, data) end
function HUDIndicator:Refresh() end
function HUDIndicator:TryPlayNotifySound() end
function HUDIndicator:SetTooltip() end
function HUDIndicator:ClearTooltip() end
function ZO_HUDEquipmentStatus_Indicator_OnMouseEnter(control) end
function ZO_HUDEquipmentStatus_Indicator_OnMouseExit(control) end
function ZO_HUDEquipmentStatus:New(...) end
function ZO_HUDEquipmentStatus:Initialize(control) end
function ZO_HUDEquipmentStatus:OnShow() end
function ZO_HUDEquipmentStatus:UpdateAllIndicators() end
function ZO_HUDEquipmentStatus:ApplyPlatformStyle(styleTable) end
function ZO_HUDEquipmentStatus_Initialize(control) end
function ZO_HUDInfamyMeter:New(...) end
function ZO_HUDInfamyMeter:UpdateInfamyMeterState(infamy, bounty, isKOS, isTrespassing) end
function ZO_HUDInfamyMeter:GetOldInfamyMeterState() end
function ZO_HUDInfamyMeter:Initialize(control) end
function ZO_HUDInfamyMeter:ShouldProcessUpdateEvent() end
function ZO_HUDInfamyMeter:Update(time) end
function ZO_HUDInfamyMeter:OnInfamyUpdated(updateType) end
function ZO_HUDInfamyMeter:AnimateCenterIcon(wasKOS, wasTrespassing) end
function ZO_HUDInfamyMeter:UpdateBar(bar, newValue, updateType) end
function ZO_HUDInfamyMeter:AnimateMeter(progress) end
function ZO_HUDInfamyMeter:SetBarValue(bar, percentFilled) end
function ZO_HUDInfamyMeter:RequestHidden(hidden) end
function ZO_HUDInfamyMeter_Initialize(control) end
function ZO_HUDInfamyMeter_Update(time) end
function ZO_HUDInfamyMeter_AnimateMeter(progress) end
function ZO_HUDTelvarMeter:New(...) end
function ZO_HUDTelvarMeter:Initialize(control) end
function ZO_HUDTelvarMeter:SetHiddenForReason(reason, hidden) end
function ZO_HUDTelvarMeter:OnTelvarStonesUpdated(event, newTelvarStones, oldTelvarStones, reason) end
function ZO_HUDTelvarMeter:UpdateMeterBar() end
function ZO_HUDTelvarMeter:UpdateMultiplier() end
function ZO_HUDTelvarMeter:AnimateMeter(progress) end
function ZO_HUDTelvarMeter:SetBarValue(percentFilled) end
function ZO_HUDTelvarMeter:UpdatePlatformStyle(styleTable) end
function ZO_HUDTelvarMeter:OnMeterAnimationComplete() end
function ZO_HUDTelvarMeter:CalculateMeterFillPercentage() end
function ZO_HUDTelvarMeter_Initialize(control) end
function ZO_HUDTelvarMeter_UpdateMeterToAnimationProgress(progress) end
function ZO_HUDTelvarMeter_OnMeterAnimationComplete(animation) end
--ingame\instancekickwarning
function ZO_InstanceKickWarning:New(control) end
function ZO_InstanceKickWarning:OnInstanceKickTimeUpdate(timeRemaining, totalTime) end
function ZO_InstanceKickWarning:SetHidden(hidden) end
function ZO_InstanceKickWarning_Alive:Initialize(control) end
function ZO_InstanceKickWarning_Alive:UpdateVisibility() end
function ZO_InstanceKickWarning_Dead:Initialize(control) end
function ZO_InstanceKickWarning_Dead:UpdateVisibility() end
function ZO_InstanceKickWarning_Dead:RefreshVisible() end
function ZO_InstanceKickWarning_Dead:SetHiddenForReason(reason, hidden) end
function ZO_InstanceKickWarning_Alive_OnInitialized(control) end
function ZO_InstanceKickWarning_Dead_OnInitialized(control) end
--ingame\interactwindow
function ZO_GamepadInteraction:New(...) end
function ZO_GamepadInteraction:Initialize(control) end
function ZO_GamepadInteraction:InitInteraction() end
function ZO_GamepadInteraction:InitializeKeybindStripDescriptors() end
function ZO_GamepadInteraction:ResetInteraction(bodyText) end
function ZO_GamepadInteraction:EndInteraction() end
function ZO_GamepadInteraction:SelectChatterOptionByIndex(optionIndex) end
function ZO_GamepadInteraction:SelectLastChatterOption() end
function ZO_GamepadInteraction:PopulateChatterOption(controlID, optionIndex, optionText, optionType, optionalArg, isImportant, chosenBefore) end
function ZO_GamepadInteraction:FinalizeChatterOptions(optionCount) end
function ZO_GamepadInteraction:UpdateChatterOptions(optionCount, backToTOCOption) end
function ZO_GamepadInteraction:ShowQuestRewards(journalQuestIndex) end
function ZO_GamepadInteraction:RefreshList() end
function ZO_GamepadInteraction:GetInteractGoldIcon() end
function ZO_GamepadInteraction:UpdateClemencyOnTimeComplete(control, data) end
function ZO_GamepadInteraction:UpdateShadowyConnectionsOnTimeComplete(control, data) end
function ZO_GamepadInteraction:OnShowing() end
function ZO_GamepadInteraction:OnHidden() end
function ZO_InteractWindow_Gamepad_Initialize(control) end
function ZO_InteractionManager:New() end
function ZO_InteractionManager:OnBeginInteraction(interaction) end
function ZO_InteractionManager:OnEndInteraction(interaction) end
function ZO_InteractionManager:TerminateClientInteraction(interaction) end
function ZO_InteractionManager:IsInteracting(interaction) end
function ZO_InteractionManager:ShowInteractWindow(bodyText) end
function ZO_InteractionManager:IsShowingInteraction() end
function ZO_InteractionManager:SelectChatterOptionByIndex(optionIndex) end
function ZO_InteractionManager:SelectLastChatterOption(optionIndex) end
function ZO_SharedInteraction:Initialize(control) end
function ZO_SharedInteraction:InitializeSharedEvents() end
function ZO_SharedInteraction:CreateInteractScene(name) end
function ZO_SharedInteraction:CloseChatter() end
function ZO_SharedInteraction:CloseChatterAndDismissAssistant() end
function ZO_SharedInteraction:InitializeInteractWindow(bodyText) end
function ZO_SharedInteraction:OnHidden() end
function ZO_SharedInteraction:UpdateClemencyChatterOption(control, data) end
function ZO_SharedInteraction:UpdateShadowyConnectionsChatterOption(control, data) end
function ZO_SharedInteraction:GetChatterOptionData(optionIndex, optionText, optionType, optionalArg, isImportant, chosenBefore) end
function ZO_SharedInteraction:PopulateChatterOptions(optionCount, backToTOCOption) end
function ZO_QuestReward_GetSkillPointText(numPartialSkillPoints) end
function ZO_SharedInteraction:IsCurrencyReward(rewardType) end
function ZO_SharedInteraction:GetCurrencyTypeFromReward(rewardType) end
function ZO_SharedInteraction:TryGetMaxCurrencyWarningText(rewardType, rewardAmount) end
function ZO_SharedInteraction:GetRewardCreateFunc(rewardType) end
function ZO_SharedInteraction:GetRewardData(journalQuestIndex) end
function ZO_SharedInteraction:OnScreenResized() end
function ZO_SharedInteraction:InitInteraction() end
function ZO_SharedInteraction:ResetInteraction(bodyText) end
function ZO_SharedInteraction:EndInteraction() end
function ZO_SharedInteraction:SelectChatterOptionByIndex(optionIndex) end
function ZO_SharedInteraction:UpdateChatterOptions(optionCount, backToTOCOption) end
function ZO_SharedInteraction:PopulateChatterOption(optionCount, backToTOCOption) end
function ZO_SharedInteraction:FinalizeChatterOptions(optionCount) end
function ZO_SharedInteraction:ShowQuestRewards(journalQuestIndex) end
function ZO_SharedInteraction:UpdateClemencyOnTimeComplete(control, data) end
function ZO_SharedInteraction:UpdateShadowyConnectionsOnTimeComplete(control, data) end
function ZO_KeepClaimDialog:New(control) end
function ZO_KeepClaimDialog:Show() end
function ZO_KeepClaimDialog:UpdateClaimAvailable() end
function ZO_KeepClaimDialog:OnUpdate(time) end
function ZO_KeepClaimDialog:OnGuildSelected(entry) end
function ZO_SelectGuildKeepClaimDialog_OnInitialized(self) end
function ZO_KeepClaimDialog:SetCurrentDropdown(dropdown) end
function ZO_KeepClaimDialog:InitializeGamepadDialogs() end
function ZO_KeepClaimDialog:InitializeGamepadReleaseKeepDialog() end
function ZO_KeepClaimDialog:InitializeGamepadClaimKeepDialog() end
function ZO_Interaction:New(...) end
function ZO_Interaction:Initialize(control) end
function ZO_Interaction:InitInteraction() end
function ZO_Interaction:ResetInteraction(bodyText) end
function ZO_Interaction:OnScreenResized() end
function ZO_Interaction:DimOtherImportantOptions(chatterControl) end
function ZO_Interaction:RestoreOtherImportantOptions(chatterControl) end
function ZO_Interaction:PopulateChatterOption(controlID, optionIndex, optionText, optionType, optionalArg, isImportant, chosenBefore, importantOptions) end
function ZO_Interaction:AnchorBottomBG(optionControl) end
function ZO_Interaction:FinalizeChatterOptions(optionCount) end
function ZO_Interaction:UpdateChatterOptions(optionCount, backToTOCOption) end
function ZO_Interaction:SelectChatterOptionByIndex(optionIndex) end
function ZO_Interaction:SelectLastChatterOption() end
function ZO_Interaction:ShowQuestRewards(journalQuestIndex) end
function ZO_Interaction:GetInteractGoldIcon() end
function ZO_SharedInteraction:UpdateClemencyOnTimeComplete(control, data) end
function ZO_SharedInteraction:UpdateShadowyConnectionsOnTimeComplete(control, data) end
function ZO_ChatterOption_MouseUp(label, button, upInside) end
function ZO_ChatterOption_MouseEnter(label) end
function ZO_ChatterOption_MouseExit(label) end
function ZO_QuestReward_MouseEnter(control) end
function ZO_QuestReward_MouseExit(control) end
function ZO_InteractWindow_Initialize(control) end
--ingame\inventory
function ZO_BackpackLayoutFragment:New(...) end
function ZO_BackpackLayoutFragment:Initialize(layoutData) end
function ZO_BackpackLayoutFragment:Show() end
function ZO_BackpackLayoutFragment:Hide() end
function ZO_BuyBagSpace_Gamepad:New(...) end
function ZO_BuyBagSpace_Gamepad:Initialize(control) end
function ZO_BuyBagSpace_Gamepad:Show(cost) end
function ZO_BuyBagSpace_Gamepad:Hide() end
function ZO_BuyBagSpace_Gamepad_Initialize(control) end
function ZO_BuySpaceGamepad:New(...) end
function ZO_BuySpaceGamepad:Initialize(control, infoTextCanAfford, infoTextCanNotAfford, buyFunc) end
function ZO_BuySpaceGamepad:PerformDeferredInitialization() end
function ZO_BuySpaceGamepad:InitializeKeybindStripDescriptors() end
function ZO_BuySpaceGamepad:Activate(cost) end
function ZO_BuySpaceGamepad:Deactivate() end
function ZO_GamepadInventory:New(...) end
function ZO_GamepadInventory:Initialize(control) end
function ZO_GamepadInventory:OnDeferredInitialize() end
function ZO_GamepadInventory:OnStateChanged(oldState, newState) end
function ZO_GamepadInventory:OnUpdate(currentFrameTimeSeconds) end
function ZO_GamepadInventory:OnInventoryShown() end
function ZO_GamepadInventory:SwitchActiveList(listDescriptor) end
function ZO_GamepadInventory:InitializeConfirmDestroyDialog() end
function ZO_GamepadInventory:InitializeSplitStackDialog() end
function ZO_GamepadInventory:ActionsDialogSetup(dialog) end
function ZO_GamepadInventory:InitializeActionsDialog() end
function ZO_GamepadInventory:InitializeKeybindStrip() end
function ZO_GamepadInventory:RemoveKeybinds() end
function ZO_GamepadInventory:AddKeybinds() end
function ZO_GamepadInventory:SetActiveKeybinds(keybindDescriptor) end
function ZO_GamepadInventory:ClearActiveKeybinds() end
function ZO_GamepadInventory:RefreshActiveKeybinds() end
function ZO_GamepadInventory:InitializeItemActions() end
function ZO_GamepadInventory:RefreshItemActions() end
function ZO_GamepadInventory:SetSelectedItemUniqueId(selectedData) end
function ZO_GamepadInventory:SetSelectedInventoryData(inventoryData) end
function ZO_GamepadInventory:ClearSelectedInventoryData() end
function ZO_GamepadInventory:UpdateCategoryLeftTooltip(selectedData) end
function ZO_GamepadInventory:InitializeCategoryList() end
function ZO_GamepadInventory:RefreshCategoryList() end
function ZO_GamepadInventory:UpdateItemLeftTooltip(selectedData) end
function ZO_GamepadInventory:InitializeItemList() end
function ZO_GamepadInventory_DefaultItemSortComparator(left, right) end
function ZO_GamepadInventory:IsItemListEmpty(filteredEquipSlot, nonEquipableFilterType) end
function ZO_GamepadInventory:GetNumSlots(bag) end
function ZO_GamepadInventory:RefreshItemList() end
function ZO_GamepadInventory:GenerateItemSlotData(item) end
function ZO_GamepadInventory:InitializeCraftBagList() end
function ZO_GamepadInventory:RefreshCraftBagList() end
function ZO_GamepadInventory:LayoutCraftBagTooltip() end
function ZO_GamepadInventory:RefreshHeader(blockCallback) end
function ZO_GamepadInventory:InitializeHeader() end
function ZO_GamepadInventory:TryEquipItem(inventorySlot) end
function ZO_GamepadInventory:ActivateHeader() end
function ZO_GamepadInventory:DeactivateHeader() end
function ZO_GamepadInventory:MarkSelectedItemAsNotNew() end
function ZO_GamepadInventory:TryClearNewStatus() end
function ZO_GamepadInventory:TryClearNewStatusOnHidden() end
function ZO_GamepadInventory:PrepareNextClearNewStatus(selectedData) end
function ZO_GamepadInventory:IsClearNewItemActuallyNew() end
function ZO_GamepadInventory:TrySetClearNewFlag(callId) end
function ZO_GamepadInventory:UpdateRightTooltip() end
function ZO_GamepadInventory:UpdateTooltipEquippedIndicatorText(tooltipType, equipSlot) end
function ZO_GamepadInventory:Select() end
function ZO_GamepadInventory:ShowQuickslot() end
function ZO_GamepadInventory:ShowActions() end
function ZO_GamepadInventory_OnInitialize(control) end
function GuildBankError_Gamepad:New(...) end
function GuildBankError_Gamepad:Initialize(control) end
function GuildBankError_Gamepad:PerformDeferredInitialization() end
function GuildBankError_Gamepad:InitializeKeybindStripDescriptors() end
function GuildBankError_Gamepad:SetupMessage() end
function GuildBankError_Gamepad:Show(error) end
function ZO_GamepadGuildBankError_Initialize(control) end
function ZO_GamepadGuildBankInventoryList:New(...) end
function ZO_GuildBank_Gamepad:New(...) end
function ZO_GuildBank_Gamepad:Initialize(control) end
function ZO_GuildBank_Gamepad:OnSceneShowing() end
function ZO_GuildBank_Gamepad:AddKeybinds() end
function ZO_GuildBank_Gamepad:RemoveKeybinds() end
function ZO_GuildBank_Gamepad:OnSelectionChangedCallback() end
function ZO_GuildBank_Gamepad:OnWithdrawDepositStateChanged(oldState, newState) end
function ZO_GuildBank_Gamepad:SetWithdrawLoadingControlShown(shouldShow) end
function ZO_GuildBank_Gamepad:CreateEventTable() end
function ZO_GuildBank_Gamepad:RegisterForEvents() end
function ZO_GuildBank_Gamepad:UnregisterForEvents() end
function ZO_GuildBank_Gamepad:OnDeferredInitialization() end
function ZO_GuildBank_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_GuildBank_Gamepad:CanDeposit() end
function ZO_GuildBank_Gamepad:CanWithdraw() end
function ZO_GuildBank_Gamepad:ConfirmDeposit() end
function ZO_GuildBank_Gamepad:ConfirmWithdrawal() end
function ZO_GuildBank_Gamepad:SetMaxAndShowSelector(maxInputFunction) end
function ZO_GuildBank_Gamepad:GetWithdrawMoneyAmount() end
function ZO_GuildBank_Gamepad:GetMaxBankedFunds(currencyType) end
function ZO_GuildBank_Gamepad:GetDepositMoneyAmount() end
function ZO_GuildBank_Gamepad:DepositFunds(currencyType, amount) end
function ZO_GuildBank_Gamepad:WithdrawFunds(currencyType, amount) end
function ZO_GuildBank_Gamepad:OnCategoryChangedCallback(selectedData) end
function ZO_GuildBank_Gamepad:InitializeHeader() end
function ZO_GuildBank_Gamepad:RefreshGuildBank() end
function ZO_GuildBank_Gamepad:ChangeGuildBank(guildBankId) end
function ZO_GuildBank_Gamepad:IsLoadingGuildBank() end
function ZO_GuildBank_Gamepad:OnRefreshHeaderData() end
function ZO_GuildBank_Gamepad:UpdateGuildBankList() end
function ZO_GuildBank_Gamepad:SetSelectedInventoryData(_, inventoryData) end
function ZO_GuildBank_Gamepad:ClearAllGuildBankItems() end
function ZO_GuildBank_Gamepad_Initialize(control) end
function ZO_InventoryItemImprovement_Gamepad:New(...) end
function ZO_InventoryItemImprovement_Gamepad:Initialize(control, title, sceneName, message, noItemMessage, confirmString, improvementSound, end
function ZO_InventoryItemImprovement_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_InventoryItemImprovement_Gamepad:PerformDeferredInitialization() end
function ZO_InventoryItemImprovement_Gamepad:GetScene() end
function ZO_InventoryItemImprovement_Gamepad:SetupList(list) end
function ZO_InventoryItemImprovement_Gamepad:OnSelectionChanged(list, selectedData, oldSelectedData) end
function ZO_InventoryItemImprovement_Gamepad:Hide() end
function ZO_InventoryItemImprovement_Gamepad:Show() end
function ZO_InventoryItemImprovement_Gamepad:SetMessage(message) end
function ZO_InventoryItemImprovement_Gamepad:SetMessageHidden(isHidden) end
function ZO_InventoryItemImprovement_Gamepad:CheckEmptyList() end
function ZO_InventoryItemImprovement_Gamepad:AddEntry(entry) end
function ZO_InventoryItemImprovement_Gamepad:CommitList() end
function ZO_InventoryItemImprovement_Gamepad:BuildList() end
function ZO_InventoryItemImprovement_Gamepad:UpdateList() end
function ZO_InventoryItemImprovement_Gamepad:PerformUpdate() end
function ZO_InventoryItemImprovement_Gamepad:ImproveItem() end
function ZO_InventoryItemImprovement_Gamepad:BeginItemImprovement(bag, index) end
function ZO_InventoryItemImprovement_Gamepad:AddSubLabel(subLabelText) end
function ZO_InventoryItemImprovement_Gamepad:AddEmptySubLabel() end
function ZO_InventoryItemImprovement_Gamepad:AddItemKitSubLabelsToCurrentEntry(itemLink) end
function ZO_InventoryItemImprovement_Gamepad:ClearTooltip() end
function ZO_InventoryItemImprovement_Gamepad:ResetTooltipToDefault() end
function ZO_InventoryItemImprovement_Gamepad:GetItemTemplateName() end
function ZO_InventoryItemImprovement_Gamepad:BuildEnumeratedImprovementKitList(itemList) end
function ZO_InventoryItemImprovement_Gamepad:InitializeImprovementKitVisualData(entry, ...) end
function ZO_InventoryItemImprovement_Gamepad:GetItemName(itemInfo) end
function ZO_InventoryItemImprovement_Gamepad:UpdateTooltipOnSelectionChanged() end
function ZO_InventoryItemImprovement_Gamepad:SetupScene() end
function ZO_InventoryItemImprovement_Gamepad:PerformItemImprovement() end
function ZO_GamepadInventoryList:New(...) end
function ZO_GamepadInventoryList:Initialize(control, inventoryType, slotType, selectedDataCallback, entrySetupCallback, categorizationFunction, sortFunction, useTriggers, template, templateSetupFunction) end
function ZO_GamepadInventoryList:SetInventoryType(inventoryType) end
function ZO_GamepadInventoryList:SetOnSelectedDataChangedCallback(selectedDataCallback) end
function ZO_GamepadInventoryList:RemoveOnSelectedDataChangedCallback(selectedDataCallback) end
function ZO_GamepadInventoryList:SetCategorizationFunction(categorizationFunction) end
function ZO_GamepadInventoryList:SetSortFunction(sortFunction) end
function ZO_GamepadInventoryList:SetEntrySetupCallback(entrySetupCallback) end
function ZO_GamepadInventoryList:SetItemFilterFunction(itemFilterFunction) end
function ZO_GamepadInventoryList:SetUseTriggers(useTriggers) end
function ZO_GamepadInventoryList:GetTargetData() end
function ZO_GamepadInventoryList:GetParametricList() end
function ZO_GamepadInventoryList:MoveNext() end
function ZO_GamepadInventoryList:MovePrevious() end
function ZO_GamepadInventoryList:SetFirstIndexSelected(...) end
function ZO_GamepadInventoryList:SetLastIndexSelected(...) end
function ZO_GamepadInventoryList:SetPreviousSelectedDataByEval(...) end
function ZO_GamepadInventoryList:SetNextSelectedDataByEval(...) end
function ZO_GamepadInventoryList:SetSelectedIndex(...) end
function ZO_GamepadInventoryList:Activate() end
function ZO_GamepadInventoryList:Deactivate() end
function ZO_GamepadInventoryList:SetupItemEntry(entry, itemData) end
function ZO_GamepadInventoryList:AddSlotDataToTable(slotsTable, slotIndex) end
function ZO_GamepadInventoryList:GenerateSlotTable() end
function ZO_GamepadInventoryList:RefreshList() end
function ZO_GamepadInventoryList:RefreshVisible() end
function ZO_GamepadInventoryList:SetDirectionalInputEnabled(enable) end
function ZO_GamepadInventoryList:SetAlignToScreenCenter(alignToScreenCenter, expectedEntryHeight) end
function ZO_GamepadInventoryList:GetControl() end
function ZO_GamepadInventoryList:IsActive() end
function ZO_GamepadInventoryList:SetNoItemText(noItemText) end
function ZO_GamepadInventoryList:ClearList() end
function ZO_InventoryUtils_Gamepad_GetBestItemCategoryDescription(itemData) end
function ZO_InventoryUtils_DoesNewItemMatchFilterType(itemData, currentFilter) end
function ZO_InventoryUtils_DoesNewItemMatchSupplies(itemData) end
function ZO_InventoryUtils_UpdateTooltipEquippedIndicatorText(tooltipType, equipSlot) end
function ZO_InventoryUtils_GetEquipSlotForEquipType(equipType) end
function ItemTransferDialog_Gamepad:New(...) end
function ItemTransferDialog_Gamepad:Initialize() end
function ItemTransferDialog_Gamepad:ShowDialog() end
function ZO_ItemTransferDialog_OnInitialize() end
function ZO_Inventory_GetDefaultHeaderSortKeys() end
function ZO_InventoryManager:New() end
function ZO_InventoryManager:ChangeSort(newSortKey, inventoryType, newSortOrder) end
function ZO_InventoryManager:ApplySort(inventoryType) end
function ZO_InventoryManager:GetDisplayInventoryTable(inventoryType) end
function ZO_InventoryManager:GetTabFilterInfo(inventoryType, tabControl) end
function ZO_InventoryManager:UpdateColumnText(inventory) end
function ZO_InventoryManager:ChangeFilter(filterTab) end
function ZO_InventoryManager:SlotForInventoryControl(inventorySlotControl) end
function ZO_InventoryManager:UpdateSortOrderButtonTextures(sortButton, inventoryType) end
function ZO_InventoryManager:ToggleSortOrder(sortButton, inventoryType) end
function ZO_InventoryManager:ShowToggleSortOrderTooltip(anchorControl, inventoryType) end
function ZO_InventoryManager:HideToggleSortOrderTooltip() end
function ZO_InventoryManager:RefreshMoney() end
function ZO_InventoryManager:RefreshTelvarStones() end
function ZO_InventoryManager:UpdateFreeSlots(inventoryType) end
function ZO_InventoryManager:SetupInitialFilter() end
function ZO_InventoryManager:SetTradingHouseModeEnabled(enabled) end
function ZO_InventoryManager:PlayItemAddedAlert(filterData, tabFilters) end
function ZO_InventoryManager:UpdateApparelSection() end
function ZO_InventoryManager:AddInventoryItem(inventoryType, slotIndex) end
function ZO_InventoryManager:UpdateNewStatus(inventoryType, slotIndex) end
function ZO_InventoryManager:GetNumSlots(inventoryType) end
function ZO_InventoryManager:OnInventoryItemRemoved(inventoryType, bagId, slotIndex, oldSlotData) end
function ZO_InventoryManager:OnInventoryItemAdded(inventoryType, bagId, slotIndex, newSlotData) end
function ZO_InventoryManager:DoesBagHaveEmptySlot(bagId) end
function ZO_InventoryManager:ShouldAddSlotToList(inventory, slot) end
function ZO_InventoryManager:UpdateList(inventoryType, updateEvenIfHidden) end
function ZO_InventoryManager:RefreshAllInventorySlots(inventoryType) end
function ZO_InventoryManager:RefreshInventorySlot(inventoryType, slotIndex) end
function ZO_InventoryManager:LayoutInventoryItems(inventoryType) end
function ZO_InventoryManager:RefreshAllInventoryOverlays(inventoryType) end
function ZO_InventoryManager:RefreshInventorySlotLocked(inventoryType, slotIndex, locked) end
function ZO_InventoryManager:RefreshInventorySlotOverlay(inventoryType, slotIndex) end
function ZO_InventoryManager:UpdateItemCooldowns(inventoryType) end
function ZO_InventoryManager:IsSlotOccupied(bagId, slotIndex) end
function ZO_InventoryManager:GetNumBackpackSlots() end
function ZO_InventoryManager:GetBackpackItem(slotIndex) end
function ZO_InventoryManager:IsShowingBackpack() end
function ZO_InventoryManager:ApplyBackpackLayout(layoutData) end
function ZO_InventoryManager:ApplySharedBagLayout(inventoryControl, layoutData) end
function ZO_InventoryManager:AddQuestItem(questItem, searchType) end
function ZO_InventoryManager:RefreshAllQuests() end
function ZO_InventoryManager:RefreshQuest(questIndex, doLayout) end
function ZO_InventoryManager:ResetQuest(questIndex) end
function ZO_InventoryManager:RefreshBackpackWithFenceData(callback) end
function ZO_BankGenericCurrencyDepositWithdrawDialog:New(...) end
function ZO_BankGenericCurrencyDepositWithdrawDialog:Initialize(prefix, control, queryFunction, depositFunction, withdrawFunction, maxDepositFunction, maxWithdrawalFunction) end
function ZO_BankGenericCurrencyDepositWithdrawDialog:UpdateDepositWithdrawCurrency() end
function ZO_BankGenericCurrencyDepositWithdrawDialog:OnCurrencyInputAmountChanged(currencyAmount) end
function ZO_BankGenericCurrencyDepositWithdrawDialog:SetupDeposit(dialog) end
function ZO_BankGenericCurrencyDepositWithdrawDialog:SetupWithdraw() end
function ZO_BankGenericCurrencyDepositWithdrawDialog:ChangeCurrencyType() end
function ZO_InventoryManager:CreateBankScene() end
function ZO_InventoryManager:IsBanking() end
function ZO_InventoryManager:RefreshUpgradePossible() end
function ZO_InventoryManager:GetBankItem(slotIndex) end
function ZO_InventoryManager:RefreshBankedGold() end
function ZO_InventoryManager:RefreshBankedTelvarStones() end
function ZO_InventoryManager:CreateGuildBankScene() end
function ZO_InventoryManager:OpenGuildBank() end
function ZO_InventoryManager:IsGuildBanking() end
function ZO_InventoryManager:CloseGuildBank() end
function ZO_InventoryManager:RefreshAllGuildBankItems() end
function ZO_InventoryManager:ClearAllGuildBankItems() end
function ZO_InventoryManager:SetGuildBankLoading(guildId) end
function ZO_InventoryManager:SetGuildBankLoaded() end
function ZO_InventoryManager:OnGuildBankOpenError(error) end
function ZO_InventoryManager:OnGuildBankDeselected() end
function ZO_InventoryManager:RefreshGuildBankedMoney() end
function ZO_InventoryManager:RefreshGuildBankMoneyOperationsPossible(guildId) end
function ZO_InventoryManager:GuildSizeChanged() end
function ZO_InventoryManager:UpdateEmptyBagLabel(inventoryType, isEmptyList) end
function ZO_InventoryManager:CreateCraftBagFragment() end
function ZO_InventoryManager_SetQuestToolData(slotControl, questIndex, toolIndex) end
function ZO_PlayerInventory_OnSearchTextChanged(editBox) end
function ZO_PlayerInventory_BeginSearch(editBox) end
function ZO_PlayerInventory_EndSearch(editBox) end
function ZO_PlayerInventory_OnSearchEnterKeyPressed(editBox) end
function ZO_PlayerInventory_FilterButtonOnMouseEnter(self) end
function ZO_PlayerInventory_FilterButtonOnMouseExit(self) end
function ZO_PlayerInventory_InitSortHeader(header, stringId, textAlignment, sortKey) end
function ZO_PlayerInventory_InitSortHeaderIcon(header, icon, sortUpIcon, sortDownIcon, mouseoverIcon, sortKey) end
function ZO_PlayerInventory_Initialize() end
function ZO_SelectGuildBankDialog_OnInitialized(self) end
function ZO_InventoryLandingArea_DropCursor(landingArea) end
function ZO_InventoryLandingArea_DropCursorInBag(bagId) end
function ZO_InventoryLandingArea_ShowHintTooltip(landingArea) end
function ZO_InventoryLandingArea_HideHintTooltip(landingArea) end
function ZO_InventoryLandingArea_SetHidden(landingArea, hidden, hintTextStringId) end
function ZO_InventoryLandingArea_Initialize(landingArea, descriptor, bagId, customOffset) end
function ZO_InventoryMenuBar:New(...) end
function ZO_InventoryMenuBar:ToggleQuickslotsTab() end
function ZO_InventoryMenuBar:SetStartingFragmentQuickslots() end
function ZO_InventoryMenuBar:UpdateInventoryKeybinds() end
function ZO_InventoryMenuBar:RemoveAllTabs() end
function ZO_InventoryMenuBar:OnButtonClicked() end
function ZO_InventoryMenuBar:LayoutCraftBagTooltip(tooltip) end
function ZO_InventoryMenuBar:AddTab(tabType, keybinds, additionalFragment) end
function ZO_InventoryMenuBar:GetFragment() end
function ZO_InventoryMenuBar:OnFragmentShowing() end
function ZO_InventoryMenuBar:OnFragmentShown() end
function ZO_InventoryMenuBar:OnFragmentHiding() end
function ZO_InventoryMenuBar:OnFragmentHidden() end
function PlayerInventoryMenuBar:New(...) end
function PlayerInventoryMenuBar:Initialize(control) end
function PlayerInventoryMenuBar:OnFragmentShown() end
function ZO_PlayerInventoryMenu_OnInitialized(control) end
function VendorInventoryMenuBar:New(...) end
function VendorInventoryMenuBar:Initialize(control) end
function ZO_VendorInventoryMenu_OnInitialized(control) end
function ZO_InventorySlot_SetType(slotControl, slotType) end
function ZO_InventorySlot_GetType(slotControl) end
function ZO_InventorySlot_GetStackCount(slotControl) end
function ZO_InventorySlot_IsSplittableType(slotControl) end
function ZO_ItemSlot_SetupIconUsableAndLockedColor(control, meetsUsageRequirement, locked) end
function ZO_ItemSlot_SetupTextUsableAndLockedColor(control, meetsUsageRequirement, locked) end
function ZO_ItemSlot_SetupUsableAndLockedColor(slotControl, meetsUsageRequirement, locked) end
function ZO_ItemSlot_SetupSlotBase(slotControl, stackCount, iconFile, meetsUsageRequirement, locked) end
function ZO_ItemSlot_SetupSlot(slotControl, stackCount, iconFile, meetsUsageRequirement, locked) end
function ZO_ItemSlot_SetAlwaysShowStackCount(slotControl, alwaysShowStackCount, minStackCount) end
function ZO_ItemSlot_GetAlwaysShowStackCount(slotControl) end
function ZO_Inventory_SlotReset(slotControl) end
function ZO_Inventory_BindSlot(slotControl, slotType, slotIndex, bagId) end
function ZO_Inventory_GetBagAndIndex(slotControl) end
function ZO_Inventory_GetSlotIndex(slotControl) end
function ZO_Inventory_SetupSlot(slotControl, stackCount, iconFile, meetsUsageRequirement, locked) end
function ZO_Inventory_SetupQuestSlot(slotControl, questIndex, toolIndex, stepIndex, conditionIndex) end
function ZO_PlayerInventorySlot_SetupUsableAndLockedColor(slotControl, meetsUsageRequirement, locked) end
function ZO_PlayerInventorySlot_SetupSlot(slotControl, stackCount, iconFile, meetsUsageRequirement, locked) end
function ZO_InventorySlot_OnPoolReset(inventorySlot) end
function ZO_InventorySlot_UpdateCooldowns(inventorySlot) end
function ZO_GamepadItemSlot_UpdateCooldowns(inventorySlot, remaining, duration) end
function ZO_InventorySlot_CanSplitItemStack(inventorySlot) end
function ZO_InventorySlot_TrySplitStack(inventorySlot) end
function TryPlaceInventoryItemInEmptySlot(targetBag) end
function ZO_InventorySlot_CanDestroyItem(inventorySlot) end
function ZO_InventorySlot_InitiateDestroyItem(inventorySlot) end
function TakeLoot(slot) end
function ZO_InventorySlot_DiscoverSlotActionsFromActionList(inventorySlot, slotActions) end
function ZO_InventorySlot_ShowContextMenu(inventorySlot) end
function ZO_InventorySlot_DoPrimaryAction(inventorySlot) end
function ItemSlotHasFilterType(slotFilterData, itemFilterType) end
function ZO_InventorySlot_OnSlotClicked(inventorySlot, button) end
function UpdateMouseoverCommand(inventorySlot) end
function ZO_InventorySlot_SetUpdateCallback(callback) end
function ZO_PlayShowAnimationOnComparisonTooltip(tooltip) end
function ZO_InventorySlot_OnMouseEnter(inventorySlot) end
function ZO_InventorySlot_HandleInventoryUpdate(slotControl) end
function ZO_PlayHideAnimationOnComparisonTooltip(tooltip) end
function ZO_InventorySlot_OnMouseExit(inventorySlot) end
function ZO_InventorySlot_OnDragStart(inventorySlot) end
function ZO_InventorySlot_OnReceiveDrag(inventorySlot) end
function ZO_InventorySlot_RemoveMouseOverKeybinds() end
function ZO_InventorySlot_Status_OnMouseEnter(control) end
function ZO_InventorySlotActions:New(useContextMenu) end
function ZO_InventorySlotActions:Clear() end
function ZO_InventorySlotActions:SetContextMenuMode(useContextMenu) end
function ZO_InventorySlotActions:SetInventorySlot(inventorySlot) end
function ZO_InventorySlotActions:Show() end
function ZO_InventorySlotActions:GetAction(actionKey, actionType, options) end
function ZO_InventorySlotActions:DoPrimaryAction(options) end
function ZO_InventorySlotActions:DoKeybindAction(keybindIndex, options) end
function ZO_InventorySlotActions:DoAction(action) end
function ZO_InventorySlotActions:GetPrimaryActionName(options) end
function ZO_InventorySlotActions:GetKeybindActionName(keybindIndex, options) end
function ZO_InventorySlotActions:GetRawActionName(action) end
function ZO_InventorySlotActions:CheckPrimaryActionVisibility(options) end
function ZO_InventorySlotActions:CheckKeybindActionVisibility(keybindIndex, options) end
function ZO_InventorySlotActions:AddSlotAction(actionStringId, actionCallback, actionType, visibilityFunction, options) end
function ZO_InventorySlotActions:GetNumSlotActions() end
function ZO_InventorySlotActions:GetSlotAction(index) end
function InventoryWalletManager:New(...) end
function InventoryWalletManager:Initialize(container) end
function InventoryWalletManager:RegisterEvents() end
function InventoryWalletManager:SetUpEntry(control, data) end
function InventoryWalletManager:SortData() end
function InventoryWalletManager:ApplySort() end
function InventoryWalletManager:RefreshCurrency() end
function InventoryWalletManager:UpdateFreeSlots() end
function InventoryWalletManager:UpdateList() end
function InventoryWalletManager:CreateAndAddCurrencyEntry(scrollData, currencyType) end
function ZO_InventoryWallet_OnInitialize(control) end
function ZO_ItemSlotActionsController:New(...) end
function ZO_ItemSlotActionsController:Initialize(alignmentOverride, additionalMouseOverbinds) end
function ZO_ItemSlotActionsController:AddSubCommand(command, hasBind, activateCallback) end
function ZO_ItemSlotActionsController:RefreshKeybindStrip() end
function ZO_ItemSlotActionsController:SetInventorySlot(inventorySlot) end
function ZO_ItemSlotActionsController:GetSlotActions() end
function ZO_ItemSlotActionsController:SetSelectedAction(action) end
function ZO_ItemSlotActionsController:HasSelectedAction() end
function ZO_ItemSlotActionsController:GetSelectedAction() end
function ZO_ItemSlotActionsController:DoSelectedAction() end
function ZO_ItemSlotActionsController:GetActions() end
function ZO_ItemTransferDialog_Base:New(...) end
function ZO_ItemTransferDialog_Base:Initialize() end
function ZO_ItemTransferDialog_Base:GetTransferMaximum() end
function ZO_ItemTransferDialog_Base:StartTransfer(bag, slotIndex, targetBag) end
function ZO_ItemTransferDialog_Base:Transfer(quantity) end
function ZO_ItemTransferDialog_Base:ShowDialog() end
function ItemTransferDialog_Keyboard:New(...) end
function ItemTransferDialog_Keyboard:Initialize(control) end
function ItemTransferDialog_Keyboard:ShowDialog() end
function ItemTransferDialog_Keyboard:Refresh() end
function ItemTransferDialog_Keyboard:GetSpinnerValue() end
function ZO_ItemTransferDialog_OpenTransferDialog(bag, slotIndex, targetBag) end
function ZO_ItemTransferDialog_OnInitialize(control) end
function ZO_SharedInventoryManager:New(...) end
function ZO_SharedInventoryManager:Initialize() end
function ZO_SharedInventoryManager:RefreshInventory(bagId) end
function ZO_SharedInventoryManager:RefreshSingleSlot(bagId, slotIndex, isNewItem, itemSoundCategory, updateReason) end
function ZO_SharedInventoryManager:GenerateFullSlotData(optFilterFunction, ...) end
function ZO_SharedInventoryManager:GenerateSingleSlotData(bagId, slotIndex) end
function ZO_SharedInventoryManager:IsFilteredSlotDataEmpty(optFilterFunction, ...) end
function ZO_SharedInventoryManager:RefreshAllQuests() end
function ZO_SharedInventoryManager:RefreshSingleQuest(questIndex) end
function ZO_SharedInventoryManager:GenerateSingleQuestCache(questIndex) end
function ZO_SharedInventoryManager:GenerateFullQuestCache() end
function ZO_SharedInventoryManager:AreAnyItemsNew(optFilterFunction, currentFilter, ...) end
function ZO_SharedInventoryManager:ClearNewStatus(bagId, slotIndex) end
function ZO_SharedInventoryManager:IsItemNew(bagId, slotIndex) end
function ZO_SharedInventoryManager:GetItemUniqueId(bagId, slotIndex) end
function ZO_SharedInventory_SelectAccessibleGuildBank(lastSuccessfulGuildBankId) end
function ZO_SharedInventoryManager:GetOrCreateBagCache(bagId) end
function ZO_SharedInventoryManager:HasBagCache(bagId) end
function ZO_SharedInventoryManager:GetBagCache(bagId) end
function ZO_SharedInventoryManager:PerformFullUpdateOnBagCache(bagId) end
function ZO_SharedInventoryManager:HandleSlotCreationOrUpdate(bagCache, bagId, slotIndex, isNewItem) end
function ZO_SharedInventoryManager:CreateOrUpdateSlotData(existingSlotData, bagId, slotIndex, isNewItem) end
function ZO_SharedInventoryManager:GetOrCreateQuestCache(questIndex) end
function ZO_SharedInventoryManager:PerformFullUpdateOnQuestCache() end
function ZO_SharedInventoryManager:PerformSingleUpdateOnQuestCache(questIndex) end
function ZO_SharedInventoryManager:CreateQuestData(iconFile, stackCount, questIndex, toolIndex, stepIndex, conditionIndex, name, questItemId, searchType) end
function ZO_GetStatDeltaLookupFromItemComparisonReturns(...) end
function ZO_Inventory_EnumerateEquipSlots(f) end
function ZO_StackSplit_SplitItem(inventorySlotControl) end
function ZO_Stack_Initialize(self) end
--ingame\journalprogresssummary
function ZO_JournalProgressBook_Common:New(...) end
function ZO_JournalProgressBook_Common:Initialize(control) end
function ZO_JournalProgressBook_Common:InitializeControls() end
function ZO_JournalProgressBook_Common:InitializeEvents() end
function ZO_JournalProgressBook_Common:InitializeCategoryTemplates() end
function ZO_JournalProgressBook_Common:InitializeChildIndentAndSpacing() end
function ZO_JournalProgressBook_Common:InitializeFilters(filterData, startingStringId) end
function ZO_JournalProgressBook_Common:InitializeSummary(control, totalLabel, recentTitle) end
function ZO_JournalProgressBook_Common:InitializeCategories(control) end
function ZO_JournalProgressBook_Common:ResetFilters() end
function ZO_JournalProgressBook_Common:UpdateSummary() end
function ZO_JournalProgressBook_Common:ShowSummary() end
function ZO_JournalProgressBook_Common:HideSummary() end
function ZO_JournalProgressBook_Common:IsSummaryOpen() end
function ZO_JournalProgressBook_Common:UpdateStatusBar(statusBar, category, earned, total, numEntries, hidesUnearned, hideProgressText) end
function ZO_JournalProgressBook_Common:GetNumCategories() end
function ZO_JournalProgressBook_Common:GetCategoryInfo(categoryIndex) end
function ZO_JournalProgressBook_Common:GetCategoryIcons(categoryIndex) end
function ZO_JournalProgressBook_Common:GetSubCategoryInfo(categoryIndex, i) end
function ZO_JournalProgressBook_Common:GetCategoryInfoFromData(data, parentData) end
function ZO_JournalProgressBook_Common:GetLookupNodeByCategory(categoryIndex, subcategoryIndex) end
function ZO_JournalProgressBook_Common:BuildCategories() end
function ZO_JournalProgressBook_Common:UpdateCategoryLabels(data) end
function ZO_JournalProgressBook_Common:BuildContentList(data) end
function ZO_JournalProgressBook_Common:OnCategorySelected(data) end
function ZO_JournalProgressBook_Common:RefreshVisibleCategoryFilter() end
--ingame\keep
function ZO_MultiLevelStatusBar:New(control, numLevels, color, projectedColor, width) end
function ZO_MultiLevelStatusBar:UpdateSections() end
function ZO_MultiLevelStatusBar:SetProgress(level) end
function ZO_MultiLevelStatusBar:ProjectProgress(level) end
function ZO_KeepUpgradeManager:New(control, numLevels, color, projectedColor, upgradeType, upgradePath, owningWindow, width) end
function ZO_KeepUpgradeManager:OnUpdate() end
function ZO_KeepUpgradeManager:Initialize() end
function ZO_KeepUpgradeManager:Refresh() end
function ZO_KeepUpgradeManager:SetName(name) end
function ZO_KeepUpgradeManager:SetUpgradePath(upgradePath) end
function ZO_KeepUpgradeManager:GetUpgradeLevel() end
function ZO_KeepUpgradeManager:GetUpgradeInfo(level) end
function ZO_KeepUpgradeManager:GetNumLevelUpgrades(level) end
function ZO_KeepUpgradeManager:GetLevelUpgradeInfo(level, index) end
function ZO_KeepUpgradeManager:UpdateProgress() end
function ZO_KeepUpgradeManager:ScrollToLevel(level) end
function ZO_KeepUpgradeManager:GetUpgradeLabel(isHeader) end
function ZO_KeepUpgradeManager:AnchorUpgradeLabel(label, prevLabel, isHeader) end
function ZO_KeepUpgradeManager:UpdateLevels() end
function ZO_KeepUpgradeManager:ProjectProgress(additionalTokens) end
function ZO_KeepUpgradeManager:GetStatus() end
function ZO_KeepWindowManager:New(window) end
function ZO_KeepWindowManager:GetKeepId() end
function ZO_KeepWindowManager:GetBattlegroundContext() end
function ZO_KeepWindowManager:ShowKeep(keepId, battlegroundContext) end
function ZO_KeepWindowManager:ShowClosestKeep() end
function ZO_KeepWindowManager:Toggle() end
function ZO_KeepWindowManager:UpdateKeepInfo(keepId, battlegroundContext) end
function ZO_KeepWindowManager:ChangeMode(mode) end
function ZO_KeepWindowManager:ComputeRemainingTime(current, forNextLevel, resourceRate, level) end
function ZO_KeepWindowManager:UpdateResourceSummaryRow(row, keepId, resourceKeepId, battlegroundContext, resourceType) end
function ZO_KeepWindowManager:UpdateSummaryView() end
function ZO_KeepWindowManager:UpdateResourceView() end
function ZO_KeepWindowManager:SetMainKeepTab(tab) end
function ZO_KeepWindowManager:SetResourceKeepTab(tab) end
function ZO_KeepWindowManager:ShowMainKeep(keepId) end
function ZO_KeepWindowManager:ShowResourceKeep(keepId) end
function ZO_KeepWindowManager:GetUpgradeForPath(path) end
function ZO_KeepWindowManager:GetKeepSwitchTarget() end
function ZO_KeepWindowManager:OnShow() end
function ZO_KeepWindowManager:OnHide() end
function ZO_KeepWindowManager:OnUpdate(currentTime) end
function ZO_KeepWindowManager:OnTabClicked(tabControl) end
function ZO_KeepWindowManager:OnKeepStartInteraction() end
function ZO_KeepWindowManager:OnKeepEndInteraction() end
function ZO_KeepWindowManager:OnKeepAllianceOwnerChanged(keepId) end
function ZO_KeepWindowManager:OnKeepGuildClaimUpdate(keepId) end
function ZO_KeepWindowManager:HandleFullUpdate() end
function ZO_KeepWindowManager:OnKeepInitialized(keepId) end
function ZO_KeepWindowManager:OnKeepsInitialized() end
function ZO_KeepWindowManager:OnKeepBattleTokensUpdate(keepId) end
function ZO_KeepWindowManager:OnTotalChanged(path, total) end
function ZO_KeepWindowManager:OnSwitchEnter(button) end
function ZO_KeepWindowManager:OnTooltipExit() end
function ZO_KeepWindowManager:OnSwitchClicked() end
function ZO_KeepWindowManager:OnSummaryRowRateEnter(texture) end
function ZO_KeepWindowSummaryRowRate_OnMouseEnter(texture) end
function ZO_KeepWindowSummaryRowRate_OnMouseExit() end
function ZO_KeepWindowSwitch_OnMouseEnter(button) end
function ZO_KeepWindowSwitch_OnMouseExit() end
function ZO_KeepWindowSwitch_OnClicked() end
function ZO_KeepWindow_OnShow() end
function ZO_KeepWindow_OnHide() end
function ZO_KeepWindow_OnInitialized(window) end
--ingame\keybindings
function KeybindingsManager:New() end
function KeybindingsManager:Initialize() end
function KeybindingsManager:New(...) end
function KeybindingsManager:Initialize(control) end
function KeybindingsManager:InitializeList() end
function KeybindingsManager:RefreshList() end
function KeybindingsManager:HandleBindingSet(layerIndex, categoryIndex, actionIndex, bindingIndex, keyCode, mod1, mod2, mod3, mod4) end
function KeybindingsManager:HandleBindingCleared(layerIndex, categoryIndex, actionIndex, bindingIndex) end
function KeybindingsManager:HandleBindingsLoaded() end
function KeybindingsManager:SetChordingAlwaysEnabled(alwaysEnabled) end
function KeybindingsManager:IsChordingAlwaysEnabled() end
function BindKeyDialog:New(...) end
function BindKeyDialog:Initialize(control) end
function BindKeyDialog:OnBindClicked() end
function BindKeyDialog:OnUnbindClicked() end
function BindKeyDialog:SetupDialog(data) end
function BindKeyDialog:OnMouseDown(button, ctrl, alt, shift, command) end
function BindKeyDialog:OnMouseUp(button, ctrl, alt, shift, command) end
function BindKeyDialog:OnMouseWheel(delta, ctrl, alt, shift, command) end
function BindKeyDialog:OnKeyDown(key, ctrl, alt, shift, command) end
function BindKeyDialog:OnKeyUp(key, ctrl, alt, shift, command) end
function BindKeyDialog:SetCurrentKeys(key, ctrl, alt, shift, command) end
function BindKeyDialog:ClearCurrentKeys() end
function BindKeyDialog:GetCurrentKeys() end
function BindKeyDialog:HasValidKeyToBind() end
function BindKeyDialog:UpdateCurrentKeyLabel() end
function ZO_BindKeyDialog_OnInitialized(control) end
function KeybindsScrollList:New(...) end
function KeybindsScrollList:Initialize(control, owner) end
function KeybindsScrollList:SortScrollList() end
function KeybindsScrollList:BuildMasterList() end
function KeybindsScrollList:FilterScrollList() end
function ZO_Keybindings_OnInitialize(control) end
--ingame\leaderboards
function ZO_LeaderboardCampaignSelector_Shared:New(control) end
function ZO_LeaderboardCampaignSelector_Shared:Initialize(control) end
function ZO_LeaderboardCampaignSelector_Shared:SetCampaignWindows() end
function ZO_LeaderboardCampaignSelector_Shared:NeedsData() end
function ZO_LeaderboardCampaignSelector_Shared:RefreshQueryTypes() end
function ZO_LeaderboardCampaignSelector_Shared:OnQueryTypeChanged(tabData) end
function ZO_LeaderboardCampaignSelector_Shared:IsHomeSelectable() end
function ZO_LeaderboardCampaignSelector_Shared:IsGuestSelectable() end
function ZO_CampaignLeaderboardsManager_Shared:New(...) end
function ZO_CampaignLeaderboardsManager_Shared:Initialize(...) end
function ZO_CampaignLeaderboardsManager_Shared:InitializeTimer() end
function ZO_CampaignLeaderboardsManager_Shared:UpdatePlayerInfo(points, rank) end
function ZO_CampaignLeaderboardsManager_Shared:GetScoreAndRankTexts() end
function ZO_CampaignLeaderboardsManager_Shared:AddCategoriesToParentSystem() end
function ZO_CampaignLeaderboardsManager_Shared:SetCampaignAndQueryType(campaignId, queryType) end
function ZO_LeaderboardCampaignSelector_Gamepad:New(control) end
function ZO_LeaderboardCampaignSelector_Gamepad:Initialize(control) end
function ZO_LeaderboardCampaignSelector_Gamepad:SetCampaignWindows() end
function ZO_LeaderboardCampaignSelector_Gamepad:NeedsData() end
function ZO_LeaderboardCampaignSelector_Gamepad:RefreshQueryTypes() end
function ZO_LeaderboardCampaignSelector_Gamepad:OnQueryTypeChanged(tabData) end
function ZO_LeaderboardCampaignSelector_Gamepad:SetActiveCampaign(campaignName, tabData) end
function ZO_CampaignLeaderboardsManager_Gamepad:New(...) end
function ZO_CampaignLeaderboardsManager_Gamepad:Initialize(control) end
function ZO_CampaignLeaderboardsManager_Gamepad:PerformDeferredInitialization(control) end
function ZO_CampaignLeaderboardsManager_Gamepad:RefreshHeaderPlayerInfo() end
function ZO_CampaignLeaderboardsManager_Gamepad:RefreshHeaderTimer() end
function ZO_CampaignLeaderboardsManager_Gamepad:SetActiveCampaign() end
function ZO_CampaignLeaderboardsManager_Gamepad:InitializeKeybindStripDescriptor() end
function ZO_CampaignLeaderboardsInformationArea_Gamepad_OnInitialized(self) end
function LeaderboardList_Gamepad:New(...) end
function LeaderboardList_Gamepad:Initialize(control) end
function LeaderboardList_Gamepad:InitializeHeader() end
function LeaderboardList_Gamepad:InitializeKeybinds() end
function LeaderboardList_Gamepad:InitializeDropdownFilter() end
function LeaderboardList_Gamepad:InitializeSearchFilter() end
function LeaderboardList_Gamepad:GetBackKeybindCallback() end
function LeaderboardList_Gamepad:FilterScrollList() end
function LeaderboardList_Gamepad:EntrySelectionCallback(oldData, newData) end
function LeaderboardList_Gamepad:SetupLeaderboardPlayerEntry(control, data) end
function LeaderboardList_Gamepad:BuildOptionsList() end
function LeaderboardList_Gamepad:ColorName(control, data, textColor) end
function LeaderboardList_Gamepad:RepopulateFilterDropdown() end
function ZO_LeaderboardList_Gamepad_OnInitialized(control) end
function ZO_LeaderboardsManager_Gamepad:New(...) end
function ZO_LeaderboardsManager_Gamepad:Initialize(control) end
function ZO_LeaderboardsManager_Gamepad:InitializeCategoryList(control) end
function ZO_LeaderboardsManager_Gamepad:SetupList(list) end
function ZO_LeaderboardsManager_Gamepad:OnSelectionChanged(list, selectedLeaderboard) end
function ZO_LeaderboardsManager_Gamepad:GetSelectedEntry() end
function ZO_LeaderboardsManager_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_LeaderboardsManager_Gamepad:InitializeScenes() end
function ZO_LeaderboardsManager_Gamepad:PerformUpdate() end
function ZO_LeaderboardsManager_Gamepad:OnShow() end
function ZO_LeaderboardsManager_Gamepad:OnHide() end
function ZO_LeaderboardsManager_Gamepad:InitializeHeader() end
function ZO_LeaderboardsManager_Gamepad:OnDeferredInitialize() end
function ZO_LeaderboardsManager_Gamepad:AddCategory(name, normalIcon, pressedIcon, mouseoverIcon) end
function ZO_LeaderboardsManager_Gamepad:AddEntry(leaderboardObject, name, titleName, parent, subType, countFunction, maxRankFunction, infoFunction, pointsFormatFunction, pointsHeaderString, consoleIdRequestParamsFunction, iconPath, leaderboardRankType) end
function ZO_LeaderboardsManager_Gamepad:UpdateCategories() end
function ZO_LeaderboardsManager_Gamepad:SetSelectedLeaderboardObject(leaderboardObject, subType) end
function ZO_LeaderboardsManager_Gamepad:SetActiveLeaderboardTitle(titleName) end
function ZO_LeaderboardsManager_Gamepad:SetActiveCampaign(campaignName, icon) end
function ZO_LeaderboardsManager_Gamepad:RefreshData() end
function ZO_LeaderboardsManager_Gamepad:ActivateLeaderboard() end
function ZO_LeaderboardsManager_Gamepad:DeactivateLeaderboard() end
function ZO_LeaderboardsManager_Gamepad:ActivateCategories() end
function ZO_LeaderboardsManager_Gamepad:ActivateLeaderboardList() end
function ZO_LeaderboardsManager_Gamepad:SelectNode(leaderboardNode) end
function ZO_LeaderboardsManager_Gamepad:GetSelectedLeaderboardData() end
function ZO_LeaderboardsManager_Gamepad:RefreshCategoryList() end
function ZO_LeaderboardsManager_Gamepad:RepopulateFilterDropdown() end
function ZO_LeaderboardsManager_Gamepad:SetKeybindButtonGroup(descriptor) end
function ZO_Leaderboards_Gamepad_OnInitialized(self) end
function ZO_RaidLeaderboardsManager_Gamepad:New(...) end
function ZO_RaidLeaderboardsManager_Gamepad:Initialize(control) end
function ZO_RaidLeaderboardsManager_Gamepad:PerformDeferredInitialization(control) end
function ZO_RaidLeaderboardsManager_Gamepad:RefreshHeaderPlayerInfo() end
function ZO_RaidLeaderboardsManager_Gamepad:RefreshHeaderTimer() end
function ZO_RaidLeaderboardsManager_Gamepad:UpdateRaidScore() end
function ZO_RaidLeaderboardsInformationArea_Gamepad_OnInitialized(self) end
function ZO_LeaderboardCampaignSelector_Keyboard:New(control) end
function ZO_LeaderboardCampaignSelector_Keyboard:Initialize(control) end
function ZO_LeaderboardCampaignSelector_Keyboard:SetCampaignWindows() end
function ZO_LeaderboardCampaignSelector_Keyboard:NeedsData() end
function ZO_LeaderboardCampaignSelector_Keyboard:RefreshQueryTypes() end
function ZO_CampaignLeaderboardSelector_ButtonOnMouseEnter(self) end
function ZO_LeaderboardCampaignSelector_Keyboard:OnQueryTypeChanged(tabData) end
function ZO_CampaignLeaderboardSelector_ButtonOnMouseExit(self) end
function ZO_CampaignLeaderboardsManager_Keyboard:New(...) end
function ZO_CampaignLeaderboardsManager_Keyboard:Initialize(control) end
function ZO_CampaignLeaderboardsManager_Keyboard:RefreshHeaderPlayerInfo() end
function ZO_CampaignLeaderboardsManager_Keyboard:RefreshHeaderTimer() end
function ZO_CampaignLeaderboardsInformationArea_OnInitialized(self) end
function ZO_LeaderboardsManager_Keyboard:New(...) end
function ZO_LeaderboardsManager_Keyboard:Initialize(control, leaderboardControl) end
function ZO_LeaderboardsManager_Keyboard:InitializeFilters() end
function ZO_LeaderboardsManager_Keyboard:InitializeLeaderboard() end
function ZO_LeaderboardsManager_Keyboard:InitializeCategoryList() end
function ZO_LeaderboardsManager_Keyboard:InitializeScenes() end
function ZO_LeaderboardsManager_Keyboard:AddCategory(name, normalIcon, pressedIcon, mouseoverIcon) end
function ZO_LeaderboardsManager_Keyboard:AddEntry(leaderboardObject, name, titleName, parent, subType, countFunction, maxRankFunction, infoFunction, pointsFormatFunction, pointsHeaderString, consoleIdRequestParamsFunction, iconPath, leaderboardRankType) end
function ZO_LeaderboardsManager_Keyboard:GetSelectedLeaderboardData() end
function ZO_LeaderboardsManager_Keyboard:UpdateCategories() end
function ZO_LeaderboardsManager_Keyboard:SetSelectedLeaderboardObject(leaderboardObject, subType) end
function ZO_LeaderboardsManager_Keyboard:SetActiveLeaderboardTitle(titleName) end
function ZO_LeaderboardsManager_Keyboard:ActivateLeaderboard() end
function ZO_LeaderboardsManager_Keyboard:DeactivateLeaderboard() end
function ZO_LeaderboardsManager_Keyboard:SelectNode(node) end
function ZO_LeaderboardsManager_Keyboard:SetupLeaderboardPlayerEntry(control, data) end
function ZO_LeaderboardsManager_Keyboard:SortScrollList() end
function ZO_LeaderboardsManager_Keyboard:BuildMasterList() end
function ZO_LeaderboardsManager_Keyboard:FilterScrollList() end
function ZO_LeaderboardsManager_Keyboard:ColorRow(control, data) end
function ZO_LeaderboardsManager_Keyboard:RepopulateFilterDropdown() end
function ZO_LeaderboardsRowName_OnMouseEnter(control) end
function ZO_LeaderboardsRowName_OnMouseExit(control) end
function ZO_LeaderboardsRowClass_OnMouseEnter(control) end
function ZO_LeaderboardsRowClass_OnMouseExit(control) end
function ZO_LeaderboardsRowAlliance_OnMouseEnter(control) end
function ZO_LeaderboardsRowAlliance_OnMouseExit(control) end
function ZO_Leaderboards_OnInitialized(self) end
function ZO_LeaderboardsNavigationEntry_OnMouseEnter(control) end
function ZO_LeaderboardsNavigationEntry_OnMouseExit(control) end
function ZO_RaidLeaderboardsManager_Keyboard:New(...) end
function ZO_RaidLeaderboardsManager_Keyboard:Initialize(control) end
function ZO_RaidLeaderboardsManager_Keyboard:RefreshHeaderPlayerInfo(isWeekly) end
function ZO_RaidLeaderboardsManager_Keyboard:RefreshHeaderTimer() end
function ZO_RaidLeaderboardsManager_Keyboard:UpdateRaidScore() end
function ZO_RaidLeaderboardsInformationArea_CurrentRankHelp_OnMouseEnter(control) end
function ZO_RaidLeaderboardsInformationArea_CurrentRankHelp_OnMouseExit(control) end
function ZO_RaidLeaderboardsInformationArea_ScoringInfoHelp_OnMouseEnter(control) end
function ZO_RaidLeaderboardsInformationArea_ScoringInfoHelp_OnMouseExit(control) end
function ZO_RaidLeaderboardsInformationArea_OnInitialized(self) end
function ZO_LeaderboardBase_Shared:New(...) end
function ZO_LeaderboardBase_Shared:Initialize(control, leaderboardSystem, leaderboardScene, fragment) end
function ZO_LeaderboardBase_Shared:OnDataChanged() end
function ZO_LeaderboardBase_Shared:OnSelected() end
function ZO_LeaderboardBase_Shared:OnUnselected() end
function ZO_LeaderboardBase_Shared:OnSubtypeSelected(subType) end
function ZO_LeaderboardBase_Shared:TryAddKeybind() end
function ZO_LeaderboardBase_Shared:TryRemoveKeybind() end
function ZO_LeaderboardsListManager_Shared:New() end
function ZO_LeaderboardsListManager_Shared:Initialize() end
function ZO_LeaderboardsListManager_Shared:SetSelectedLeaderboard(data) end
function ZO_LeaderboardsListManager_Shared:BuildMasterList() end
function ZO_LeaderboardsListManager_Shared:SetupDataTable(dataTable) end
function ZO_LeaderboardsListManager_Shared:FilterScrollList(list, filteredClass, preAddCallback, searchCallback) end
function ZO_LeaderboardsListManager_Shared:GetConsoleIdRequestParams(index) end
function ZO_LeaderboardsListManager_Shared:GetMasterList() end
function ZO_LeaderboardsManager_Shared:New(control, leaderboardControl) end
function ZO_LeaderboardsManager_Shared:Initialize(control, leaderboardControl) end
function ZO_LeaderboardsManager_Shared:InitializeScenes() end
function ZO_LeaderboardsManager_Shared:SetSelectedLeaderboardObject(leaderboardObject, subType) end
function ZO_LeaderboardsManager_Shared:RegisterMasterListUpdatedCallback(scene) end
function ZO_LeaderboardsManager_Shared:GetLeaderboardTitleName(titleName, subType) end
function ZO_LeaderboardsManager_Shared:OnLeaderboardSelected(data) end
function ZO_LeaderboardsManager_Shared:OnLeaderboardDataChanged(leaderboardObject) end
function ZO_LeaderboardsManager_Shared:SetupLeaderboardPlayerEntry(control, data) end
function ZO_LeaderboardsManager_Shared:CommitScrollList() end
function ZO_LeaderboardsManager_Shared:GetRowColors(data) end
function ZO_Leaderboards_PopulateDropdownFilter(dropdown, changedCallback, includeAllFilter, defaultToPlayerClass) end
function ZO_RaidLeaderboardsManager_Shared:New(...) end
function ZO_RaidLeaderboardsManager_Shared:Initialize(...) end
function ZO_RaidLeaderboardsManager_Shared:RegisterForEvents(control) end
function ZO_RaidLeaderboardsManager_Shared:SelectRaidById(raidId, selectOption, openLeaderboards) end
function ZO_RaidLeaderboardsManager_Shared:UpdatePlayerParticipationStatus() end
function ZO_RaidLeaderboardsManager_Shared:UpdateRaidScore() end
function ZO_RaidLeaderboardsManager_Shared:OnSubtypeSelected(subType) end
function ZO_RaidLeaderboardsManager_Shared:UpdateAllInfo() end
--ingame\lfg
function ActivityTracker:New(...) end
function ActivityTracker:Initialize(control) end
function ActivityTracker:RegisterEvents() end
function ActivityTracker:Update() end
function ActivityTracker:ApplyPlatformStyle(style) end
function ZO_ActivityTracker_OnInitialized(control) end
function ActivityFinderRoot_Gamepad:New(...) end
function ActivityFinderRoot_Gamepad:Initialize(control) end
function ActivityFinderRoot_Gamepad:InitializeKeybindStripDescriptors() end
function ActivityFinderRoot_Gamepad:OnDeferredInitialize() end
function ActivityFinderRoot_Gamepad:SetupList(list) end
function ActivityFinderRoot_Gamepad:PerformUpdate() end
function ActivityFinderRoot_Gamepad:OnShowing() end
function ActivityFinderRoot_Gamepad:AddRolesMenuEntry() end
function ActivityFinderRoot_Gamepad:AddCategory(categoryData) end
function ActivityFinderRoot_Gamepad:RefreshCategories() end
function ZO_ActivityFinderRoot_Gamepad_OnInitialize(control) end
function ZO_ActivityFinderTemplate_Gamepad:New(...) end
function ZO_ActivityFinderTemplate_Gamepad:Initialize(dataManager, categoryData) end
function ZO_ActivityFinderTemplate_Gamepad:InitializeControls() end
function ZO_ActivityFinderTemplate_Gamepad:InitializeFragment() end
function ZO_ActivityFinderTemplate_Gamepad:InitializeFilters() end
function ZO_ActivityFinderTemplate_Gamepad:InitializeLists() end
function ZO_ActivityFinderTemplate_Gamepad:InitializeSingularPanelControls(rewardsTemplate) end
function ZO_ActivityFinderTemplate_Gamepad:RegisterEvents() end
function ZO_ActivityFinderTemplate_Gamepad:OnDeferredInitialize() end
function ZO_ActivityFinderTemplate_Gamepad:SetupList(list) end
function ZO_ActivityFinderTemplate_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_ActivityFinderTemplate_Gamepad:FilterByActivity(activityType) end
function ZO_ActivityFinderTemplate_Gamepad:PerformUpdate() end
function ZO_ActivityFinderTemplate_Gamepad:AddRolesMenuEntry(list) end
function ZO_ActivityFinderTemplate_Gamepad:RefreshSelections() end
function ZO_ActivityFinderTemplate_Gamepad:RefreshHeaderAndView(headerData) end
function ZO_ActivityFinderTemplate_Gamepad:RefreshView() end
function ZO_ActivityFinderTemplate_Gamepad:RefreshSpecificFilters() end
function ZO_ActivityFinderTemplate_Gamepad:RefreshFilters() end
function ZO_ActivityFinderTemplate_Gamepad:OnActivityFinderStatusUpdate() end
function ZO_ActivityFinderTemplate_Gamepad:OnShowing() end
function ZO_ActivityFinderTemplate_Gamepad:OnShow() end
function ZO_ActivityFinderTemplate_Gamepad:OnHiding() end
function ZO_ActivityFinderTemplate_Gamepad:SetNavigationMode(navigationMode) end
function ZO_ActivityFinderTemplate_Gamepad:OnCooldownsUpdate() end
function ZO_ActivityFinderTemplate_Gamepad:GetScene() end
function ActivityQueueData_Gamepad:New(...) end
function ActivityQueueData_Gamepad:Initialize(control) end
function ActivityQueueData_Gamepad:IsShowing() end
function ActivityQueueData_Gamepad:GetFooterData() end
function ZO_ActivityQueueDataGamepad_OnInitialized(self) end
function ZO_GroupRolesBar_Gamepad:New(...) end
function ZO_GroupRolesBar_Gamepad:Initialize(control) end
function ZO_GroupRolesBar_Gamepad:InitializeEvents() end
function ZO_GroupRolesBar_Gamepad:ToggleSelected() end
function ZO_GroupRolesBar_Gamepad:SetRoleSelected(roleType, isSelected) end
function ZO_GroupRolesBar_Gamepad:RefreshRoles() end
function ZO_GroupRolesBar_Gamepad:SetIsManuallyDimmed(isDimmed) end
function ZO_GroupRolesBar_Gamepad:UpdateDimming() end
function ZO_GroupRolesBar_Gamepad:GetRoles() end
function ZO_GroupRolesBar_Gamepad:IsRoleSelected() end
function ZO_GroupRolesBar_Gamepad:Activate() end
function ZO_GroupRolesBar_Gamepad:Deactivate() end
function ZO_GroupRolesBar_Gamepad_OnInitialized(control) end
function ZO_ActivityFinderTemplate_Keyboard:New(...) end
function ZO_ActivityFinderTemplate_Keyboard:Initialize(dataManager, categoryData) end
function ZO_ActivityFinderTemplate_Keyboard:InitializeControls() end
function ZO_ActivityFinderTemplate_Keyboard:InitializeFilters() end
function ZO_ActivityFinderTemplate_Keyboard:InitializeNavigationList() end
function ZO_ActivityFinderTemplate_Keyboard:InitializeFragment() end
function ZO_ActivityFinderTemplate_Keyboard:RegisterEvents() end
function ZO_ActivityFinderTemplate_Keyboard:RefreshView() end
function ZO_ActivityFinderTemplate_Keyboard:RefreshFilters() end
function ZO_ActivityFinderTemplate_Keyboard:RefreshJoinQueueButton() end
function ZO_ActivityFinderTemplate_Keyboard:OnFilterChanged(comboBox, entryText, entry) end
function ZO_ActivityFinderTemplate_Keyboard:OnActivityFinderStatusUpdate() end
function ZO_ActivityFinderTemplate_Keyboard:OnCooldownsUpdate() end
function ZO_ActivityFinderTemplate_Keyboard:ShowPrimaryControls() end
function ZO_ActivityFinderTemplate_Keyboard:HidePrimaryControls() end
function ZO_ActivityFinderTemplate_Keyboard:ResetLFMPrompt() end
function ZO_ActivityFinderTemplate_Keyboard:OnHandleLFMPromptResponse() end
function ZO_ActivityFinderTemplate_Keyboard:GetFragment() end
function ZO_ActivityFinderTemplate_Keyboard.ShowActivityTooltip(control) end
function ZO_ActivityFinderTemplate_Keyboard.HideActivityTooltip() end
function ZO_ActivityFinderTemplateNavigationEntryKeyboard_OnClicked(control, button) end
function ZO_ActivityFinderTemplateNavigationEntryKeyboard_OnMouseEnter(control) end
function ZO_ActivityFinderTemplateNavigationEntryKeyboard_OnMouseExit(control) end
function ZO_ActivityFinderTemplateQueueButtonKeyboard_OnClicked(control) end
function ZO_ActivityFinderTemplateNavigationEntryKeyboard_OnInitialized(control) end
function PreferredRolesManager:New(...) end
function PreferredRolesManager:Initialize(control) end
function PreferredRolesManager:InitializeRoles() end
function PreferredRolesManager:RefreshRoles() end
function PreferredRolesManager:SetRoleToggled(role, selected, userRequested) end
function PreferredRolesManager:DisableRoleButtons(isDisabled) end
function PreferredRolesManager:GetSelectedRoleCount() end
function PreferredRolesManager:GetRoles() end
function PreferredRolesManager:IsRoleSelected() end
function ZO_PreferredRolesButton_OnMouseEnter(control) end
function ZO_PreferredRolesButton_OnMouseExit(control) end
function ZO_PreferredRolesButton_OnClicked(buttonControl, mouseButton) end
function ZO_PreferredRoles_OnInitialized(self) end
function SearchingForGroupManager:New(...) end
function ZO_SearchingForGroup_OnInitialized(self) end
function ZO_SearchingForGroupQueueButton_OnClicked(self, button) end
function ZO_VeteranDifficultySettings_OnInitialized(self) end
function ZO_VeteranDifficultyButton_OnMouseEnter(self) end
function ZO_VeteranDifficultyButton_OnMouseExit(self) end
function ZO_VeteranDifficultyButton_OnClicked(self) end
function ZO_VeteranDifficultyHelp_OnMouseEnter(self) end
function ZO_VeteranDifficultyHelp_OnMouseExit(self) end
function ActivityFinderRoot_Manager:New(...) end
function ActivityFinderRoot_Manager:Initialize() end
function ActivityFinderRoot_Manager:RegisterForEvents() end
function ActivityFinderRoot_Manager:InitializeLocationData() end
function ActivityFinderRoot_Manager:OnUpdate() end
function ActivityFinderRoot_Manager:MarkDataDirty() end
function ActivityFinderRoot_Manager:UpdateGroupStatus() end
function ActivityFinderRoot_Manager:GetGroupStatus() end
function ActivityFinderRoot_Manager:UpdateLocationData() end
function ActivityFinderRoot_Manager:ClearSelections() end
function ActivityFinderRoot_Manager:ClearAndUpdate() end
function ActivityFinderRoot_Manager:OnActivityFinderStatusUpdate(status) end
function ActivityFinderRoot_Manager:GetLocationsData(activityType) end
function ActivityFinderRoot_Manager:GetLocation(activityType, lfgIndex) end
function ActivityFinderRoot_Manager:GetAverageRoleTime(role) end
function ActivityFinderRoot_Manager:GetIsCurrentlyInQueue() end
function ActivityFinderRoot_Manager:ToggleLocationSelected(location) end
function ActivityFinderRoot_Manager:SetLocationSelected(location, selected) end
function ActivityFinderRoot_Manager:ToggleActivityTypeSelected(activityType) end
function ActivityFinderRoot_Manager:SetActivityTypeSelected(activityType, selected) end
function ActivityFinderRoot_Manager:IsActivityTypeSelected(activityType) end
function ActivityFinderRoot_Manager:IsAnyLocationSelected() end
function ActivityFinderRoot_Manager:CanChooseRandomForActivityType(activityType) end
function ActivityFinderRoot_Manager:GetLockReasonForActivityType(activityType) end
function ActivityFinderRoot_Manager:GetGroupSizeRangeForActivityType(activityType) end
function ActivityFinderRoot_Manager:IsActivityQueueOnCooldown() end
function ActivityFinderRoot_Manager:GetActivityQueueCooldownExpireTimeS() end
function ActivityFinderRoot_Manager:StartSearch() end
function ActivityFinderRoot_Manager:HandleLFMPromptResponse(accept) end
function ZO_ActivityFinderFilterModeData:New(...) end
function ZO_ActivityFinderFilterModeData:Initialize(...) end
function ZO_ActivityFinderFilterModeData:GetActivityTypes() end
function ZO_ActivityFinderFilterModeData:AddRandomInfo(activityType, description, keyboardBackground, gamepadBackground) end
function ZO_ActivityFinderFilterModeData:GetRandomInfo(activityType) end
function ZO_ActivityFinderFilterModeData:SetSubmenuFilterNames(specificFilterName, randomFilterName) end
function ZO_ActivityFinderFilterModeData:SetSpecificsInSubmenu(areSpecificsInSubmenu) end
function ZO_ActivityFinderFilterModeData:AreSpecificsInSubmenu() end
function ZO_ActivityFinderFilterModeData:GetSpecificFilterName() end
function ZO_ActivityFinderFilterModeData:GetRandomFilterName() end
function ZO_ActivityFinderTemplate_Manager:New(...) end
function ZO_ActivityFinderTemplate_Manager:Initialize(name, categoryData, filterModeData) end
function ZO_ActivityFinderTemplate_Manager:GetName() end
function ZO_ActivityFinderTemplate_Manager:GetFilterModeData() end
function ZO_ActivityFinderTemplate_Manager:GetKeyboardObject() end
function ZO_ActivityFinderTemplate_Manager:GetGamepadObject() end
function ZO_ActivityFinderTemplate_Shared:New(...) end
function ZO_ActivityFinderTemplate_Shared:Initialize(control, dataManager, categoryData) end
function ZO_ActivityFinderTemplate_Shared:InitializeControls(rewardsTemplate) end
function ZO_ActivityFinderTemplate_Shared:InitializeFilters() end
function ZO_ActivityFinderTemplate_Shared:InitializeFragment() end
function ZO_ActivityFinderTemplate_Shared:RegisterEvents() end
function ZO_ActivityFinderTemplate_Shared:InitializeSingularPanelControls(rewardsTemplate) end
function ZO_ActivityFinderTemplate_Shared:RefreshView() end
function ZO_ActivityFinderTemplate_Shared:RefreshFilters() end
function ZO_ActivityFinderTemplate_Shared:OnActivityFinderStatusUpdate() end
function ZO_ActivityFinderTemplate_Shared:OnHandleLFMPromptResponse() end
function ZO_ActivityFinderTemplate_Shared:OnCooldownsUpdate() end
function ZO_ActivityFinderTemplate_Shared.SetGroupSizeRangeText(labelControl, entryData, groupIconFormat) end
function ZO_ActivityFinderTemplate_Shared:GetLFMPromptInfo() end
function ZO_ActivityFinderTemplate_Shared:GetLevelLockInfoByActivity(activityType) end
function ZO_ActivityFinderTemplate_Shared:GetLevelLockInfo() end
function ZO_ActivityFinderTemplate_Shared:GetGlobalLockInfo() end
function ZO_ActivityFinderTemplate_Shared:GetGlobalLockText() end
function ZO_ActivityFinderTemplate_Shared:GetLevelLockTextByActivity(activityType) end
function ZO_ActivityFinderTemplate_Shared:GetLockTextByActivity(activityType) end
function AllianceWarFinder_Manager:New(...) end
function AllianceWarFinder_Manager:Initialize() end
function DungeonFinder_Manager:New(...) end
function DungeonFinder_Manager:Initialize() end
--ingame\lockpick
function ZO_Lockpick:New(...) end
function ZO_Lockpick:Initialize(control) end
function ZO_Lockpick:PlayVibration(coarseMotor, fineMotor) end
function ZO_Lockpick:GetLockpickXValues(chamberIndex) end
function ZO_Lockpick:OnUpdate(ending) end
function ZO_Lockpick:EndLockpickBreak() end
function ZO_Lockpick:IsPickBroken() end
function ZO_Lockpick:UpdateVirtualMousePosition() end
function ZO_Lockpick:OnVirtualLockpickPositionChanged() end
function ZO_Lockpick:FindClosestChamberIndexToLockpick() end
function ZO_Lockpick:OnLockpickBroke(inactivityDuration) end
function ZO_Lockpick:UpdatePinAlpha(alpha, ingoreIndex, allowHighlights) end
function ZO_Lockpick:StartDepressingPin() end
function ZO_Lockpick:EndDepressingPin() end
function ZO_Lockpick:PlayHighlightOnPin(pin) end
function ZO_Lockpick:RemoveHighlightOnPin(pin) end
function ZO_Lockpick:CreateKeybindStripDescriptor() end
function ZO_Lockpick:SetHidden(hidden) end
function ZO_Lockpick:ApplyPlatformStyle(style) end
function ZO_Lockpick_OnInitialized(control) end
function ZO_Lockpick_OnMouseDown(control) end
function ZO_Lockpick_OnMouseUp(control) end
--ingame\lorelibrary
function BookSetGamepad:New(...) end
function BookSetGamepad:Initialize(control) end
function BookSetGamepad:InitializeKeybindStripDescriptors() end
function BookSetGamepad:SetupList(list) end
function BookSetGamepad:Push(libraryData) end
function BookSetGamepad:PerformUpdate() end
function BookSetGamepad:OnSelectionChanged(_, selectedData) end
function ZO_Gamepad_BookSet_OnInitialize(control) end
function ZO_LoreLibraryBookSetGamepad:New(...) end
function ZO_LoreLibraryBookSetGamepad:Initialize(control) end
function ZO_LoreLibraryBookSetGamepad:InitializeEvents() end
function LoreLibraryGamepad:New(...) end
function LoreLibraryGamepad:Initialize(control) end
function LoreLibraryGamepad:InitializeKeybindStripDescriptors() end
function LoreLibraryGamepad:SetupList(list) end
function LoreLibraryGamepad:PerformUpdate() end
function ZO_Gamepad_LoreLibrary_OnInitialize(control) end
function LoreLibrary:New(...) end
function LoreLibrary:Initialize(control) end
function LoreLibrary:InitializeCategoryList(control) end
function LoreLibrary:InitializeBookList(control) end
function LoreLibrary:InitializeEvents(control) end
function LoreLibrary:RefreshCollectedInfo() end
function LoreLibrary:OnShow() end
function LoreLibrary:GetSelectedCategoryIndex() end
function LoreLibrary:GetSelectedCollectionIndex() end
function LoreLibrary:BuildBookList() end
function LoreLibrary:BuildCategoryList() end
function LoreLibrary:InitializeKeybindStripDescriptors() end
function ZO_LoreLibrary_OnInitialize(control) end
function LoreLibraryScrollList:New(...) end
function LoreLibraryScrollList:Initialize(control, owner) end
function LoreLibraryScrollList:GetRowColors(data, mouseIsOver, control) end
function LoreLibraryScrollList:ColorRow(control, data, mouseIsOver) end
function LoreLibraryScrollList:BuildMasterList() end
function LoreLibraryScrollList:FilterScrollList() end
function LoreLibraryScrollList:OnRowMouseUp(control, button) end
function LoreLibraryScrollList:OnMouseDoubleClick(control, button) end
function LoreLibraryScrollList:GetMouseOverRow() end
function ZO_LoreLibrary_ReadBook(categoryIndex, collectionIndex, bookIndex) end
--ingame\lorereader
function LoreReader:New(...) end
function LoreReader:Initialize(control) end
function LoreReader:InitializeKeybindStripDescriptors() end
function LoreReader:Show(title, body, medium, showTitle) end
function LoreReader:SetupBook(title, body, medium, showTitle, isGamepad) end
function LoreReader:OnHide() end
function LoreReader:ApplyMedium(medium, isGamepad) end
function LoreReader:LayoutText() end
function LoreReader:SetText(title, body, showTitle) end
function LoreReader:ChangePage(offset) end
function LoreReader:UpdatePagingButtons() end
function ZO_LoreReader_OnInitialize(control) end
function ZO_LoreReader_OnHide(control) end
function ZO_LoreReader_OnClicked(control, button) end
function ZO_LoreReader_OnPagePreviousClicked(control) end
function ZO_LoreReader_OnPageNextClicked(control) end
--ingame\mail
function ZO_MailInbox_Gamepad:New(...) end
function ZO_MailInbox_Gamepad:InitializeInbox(control) end
function ZO_MailInbox_Gamepad:OnShowing() end
function ZO_MailInbox_Gamepad:OnShown() end
function ZO_MailInbox_Gamepad:OnHidden() end
function ZO_MailInbox_Gamepad:PerformDeferredInitialization() end
function ZO_MailInbox_Gamepad:InitializeFragment() end
function ZO_MailInbox_Gamepad:InitializeControls() end
function ZO_MailInbox_Gamepad:AttachmentSelectionChanged(list, selectedData, oldSelectedData) end
function ZO_MailInbox_Gamepad:InitializeAttachmentsList() end
function ZO_MailInbox_Gamepad:InitializeOptionsList() end
function ZO_MailInbox_Gamepad:InitializeMailList() end
function ZO_MailInbox_Gamepad:InitializeHeader() end
function ZO_MailInbox_Gamepad:InitializeKeybindDescriptors() end
function ZO_MailInbox_Gamepad:InitializeEvents() end
function ZO_MailInbox_Gamepad:MailboxUpdated() end
function ZO_MailInbox_Gamepad:HideAll() end
function ZO_MailInbox_Gamepad:Delete() end
function ZO_MailInbox_Gamepad:EnterLoading() end
function ZO_MailInbox_Gamepad:EnterMailList() end
function ZO_MailInbox_Gamepad:EnterOptionsList() end
function ZO_MailInbox_Gamepad:EnterViewAttachments() end
function ZO_MailInbox_Gamepad:GetActiveMailId() end
function ZO_MailInbox_Gamepad:GetActiveMailData() end
function ZO_MailInbox_Gamepad:GetActiveMailSender() end
function ZO_MailInbox_Gamepad:ReportPlayer() end
function ZO_MailInbox_Gamepad:ReturnToSender() end
function ZO_MailInbox_Gamepad:ExitReturnDialog() end
function ZO_MailInbox_Gamepad:CanDeleteActiveMail() end
function ZO_MailInbox_Gamepad:GetActiveMailHasAttachedGold() end
function ZO_MailInbox_Gamepad:GetActiveMailHasAttachedItems() end
function ZO_MailInbox_Gamepad:TryTakeAll() end
function ZO_MailInbox_Gamepad:TakeAll() end
function ZO_MailInbox_Gamepad:OnMailTargetChanged(list, targetData) end
function ZO_MailInbox_Gamepad:UpdateMailColors() end
function ZO_MailInbox_Gamepad:RefreshMailList() end
function ZO_MailInbox_Gamepad:ShowMailItem(mailId) end
function ZO_MailView_Initialize_Gamepad(control, addressText, emptyAttachmentSlotIcon, outbox, codMoneyOptions, attachedMoneyOptions, maxAttachments) end
function ZO_MailView_GetAddress_Gamepad(control) end
function ZO_MailView_GetSubject_Gamepad(control) end
function ZO_MailView_GetBody_Gamepad(control) end
function ZO_MailView_Display_Gamepad(control, codFee, attachedMoney, address, subject, body, isSystem, noAttachments) end
function ZO_MailView_Clear_Gamepad(control) end
function ZO_MailView_SetupAttachment_Gamepad(control, attachmentIndex, stack, icon) end
function ZO_MailView_ClearAttachment_Gamepad(control, attachmentIndex) end
function MailManager_Gamepad:New(...) end
function MailManager_Gamepad:Initialize(control) end
function MailManager_Gamepad:OnStateChanged(oldState, newState) end
function MailManager_Gamepad:SwitchToFragment(fragment) end
function MailManager_Gamepad:PerformDeferredInitialization() end
function MailManager_Gamepad:InitializeControls() end
function MailManager_Gamepad:RefreshHeader() end
function MailManager_Gamepad:SetupInitialTab(tabIndex) end
function MailManager_Gamepad:ShowTab(tabIndex, pushScene) end
function MailManager_Gamepad:SwitchToHeader(headerData) end
function MailManager_Gamepad:RefreshKeybind() end
function MailManager_Gamepad:SwitchToKeybind(keybindDescriptor) end
function MailManager_Gamepad:GetSend() end
function ZO_MailManager_Gamepad_OnInitialized(control) end
function ZO_MailSend_Gamepad:New(...) end
function ZO_MailSend_Gamepad:Initialize(control) end
function ZO_MailSend_Gamepad:OnShowing() end
function ZO_MailSend_Gamepad:OnHidden() end
function ZO_MailSend_Gamepad:PerformDeferredInitialization() end
function ZO_MailSend_Gamepad:InitializeControls() end
function ZO_MailSend_Gamepad:InitializeFragment() end
function ZO_MailSend_Gamepad:ConnectShownEvents() end
function ZO_MailSend_Gamepad:DisconnectShownEvent() end
function ZO_MailSend_Gamepad:InitializeEvents() end
function ZO_MailSend_Gamepad:ComposeMailTo(address) end
function ZO_MailSend_Gamepad:IsMailValid() end
function ZO_MailSend_Gamepad:InitializeKeybindDescriptors() end
function ZO_MailSend_Gamepad:InitializeHeader() end
function ZO_MailSend_Gamepad:InitializeInventoryList() end
function ZO_MailSend_Gamepad:AddMainListEntry(text, header, icon, callback, secondaryCallbackName, secondaryCallback) end
function ZO_MailSend_Gamepad:PopulateMainList() end
function ZO_MailSend_Gamepad:InitializeMainList() end
function ZO_MailSend_Gamepad:OnListMovement(list, isMoving) end
function ZO_MailSend_Gamepad:HighlightActiveTextField() end
function ZO_MailSend_Gamepad:InitializeContactsList() end
function ZO_MailSend_Gamepad:ClearFields() end
function ZO_MailSend_Gamepad:Reset() end
function ZO_MailSend_Gamepad:EnterSending() end
function ZO_MailSend_Gamepad:EnterOutbox() end
function ZO_MailSend_Gamepad:AddContact(text, header, callback) end
function ZO_MailSend_Gamepad:EnterContactsList() end
function ZO_MailSend_Gamepad:ShowSliderControl(mode, value, maxValue) end
function ZO_MailSend_Gamepad:EnterInventoryList() end
function ZO_MailSend_Gamepad:InventorySelectionChanged(list, inventoryData) end
function ZO_MailSend_Gamepad:Clear() end
function ZO_MailSend_Gamepad:UpdateMoneyAttachment() end
function ZO_MailSend_Gamepad:IsAttachingItems() end
function ZO_MailSend_Gamepad:UpdatePostageMoney() end
function ZO_MailSend_Gamepad:OnMailAttachmentAdded(attachSlot) end
function ZO_MailSend_Gamepad:OnMailAttachmentRemoved(attachSlot) end
function ZO_MailSend_Gamepad:OnMailSendSuccess() end
function ZO_MailSend_Gamepad:OnMailSendFailure(failureReason) end
function ZO_MailView_Initialize_Send_Fields_Gamepad(control) end
function MailInbox:New(...) end
function MailInbox:Initialize(control) end
function MailInbox:InitializeKeybindDescriptors() end
function MailInbox:CreateAttachmentSlots() end
function MailInbox:SetNumUnread(numUnread) end
function MailInbox:GetMailData(mailId) end
function MailInbox:GetRowColors(data, mouseIsOver, control) end
function MailInbox:SetupInboxEntry(control, data) end
function MailInbox:BuildMasterList() end
function MailInbox:FilterScrollList() end
function MailInbox:CompareInboxEntries(listEntry1, listEntry2) end
function MailInbox:SortScrollList() end
function MailInbox:OnSelectionChanged(previouslySelected, selected, reselectingDuringRebuild) end
function MailInbox:EndRead() end
function MailInbox:RequestReadMessage(mailId) end
function MailInbox:ShowTakeAttachmentsWithCODDialog(codAmount) end
function MailInbox:Return() end
function MailInbox:Delete() end
function MailInbox:TryTakeAll() end
function MailInbox:IsMailDeletable() end
function MailInbox:GetOpenMailId() end
function MailInbox:ConfirmAcceptCOD() end
function MailInbox:ConfirmDelete(mailId) end
function MailInbox:OnInboxUpdate() end
function MailInbox:OnMailReadable(mailId) end
function MailInbox:RefreshMailFrom() end
function MailInbox:RefreshAttachmentSlots() end
function MailInbox:RefreshMoneyControls() end
function MailInbox:RefreshAttachmentsHeaderShown() end
function MailInbox:OnTakeAttachedItemSuccess(mailId) end
function MailInbox:OnTakeAttachedMoneySuccess(mailId) end
function MailInbox:OnMailRemoved(mailId) end
function MailInbox:OnMailNumUnreadChanged(numUnread) end
function MailInbox:HasAlreadyReportedSelectedMail() end
function MailInbox:RecordSelectedMailAsReported() end
function MailInbox:MessageFrom_OnMouseEnter(control) end
function MailInbox:MessageFrom_OnMouseExit() end
function MailInbox:Row_OnMouseEnter(control) end
function MailInbox:Row_OnMouseExit(control) end
function MailInbox:Row_OnMouseUp(control) end
function MailInbox:Unread_OnMouseEnter(control) end
function MailInbox:Unread_OnMouseExit(control) end
function ZO_MailInboxMessageFrom_OnMouseEnter(control) end
function ZO_MailInboxMessageFrom_OnMouseExit() end
function ZO_MailInboxRow_OnMouseEnter(control) end
function ZO_MailInboxRow_OnMouseExit(control) end
function ZO_MailInboxRow_OnMouseUp(control) end
function ZO_MailInboxUnread_OnMouseEnter(control) end
function ZO_MailInboxUnread_OnMouseExit(control) end
function ZO_MailInbox_OnInitialized(self) end
function MailSend:New(control) end
function MailSend:ComposeMailTo(address) end
function MailSend:InitializeKeybindDescriptors() end
function MailSend:CreateAttachmentSlots() end
function MailSend:IsHidden() end
function MailSend:ClearFields() end
function MailSend:UpdateMoneyAttachment() end
function MailSend:UpdateCOD() end
function MailSend:UpdatePostageMoney() end
function MailSend:SetSendMoneyMode(sendMoneyMode) end
function MailSend:AttachMoney(moneyInput, money) end
function MailSend:Send() end
function MailSend:SetReply(to, subject) end
function MailSend:OnMoneyUpdate() end
function MailSend:OnMailSendSuccess() end
function MailSend:OnMailAttachmentAdded(attachSlot) end
function MailSend:OnMailAttachmentRemoved(attachSlot) end
function MailSend:SetCoDMode() end
function MailSend:SetMoneyAttachmentMode() end
function ZO_MailSend_SetMoneyAttachmentMode() end
function ZO_MailSend_SetCoDMode() end
function ZO_MailSend_OnInitialized(self) end
function ZO_MailInboxShared_PopulateMailData(dataTable, mailId) end
function ZO_GetNextMailIdIter(state, var1) end
function ZO_MailInboxShared_TakeAll(mailId) end
function ZO_MailInboxShared_UpdateInbox(mailData, fromControl, subjectControl, expiresControl, recievedControl, bodyControl) end
function ZO_MailInteractionFragment:New() end
function ZO_SceneFragment:Show() end
function ZO_SceneFragment:Hide() end
function ZO_MailSendShared_AddAttachedItem(attachSlot, slot) end
function ZO_MailSendShared_RemoveAttachedItem(attachSlot, slot) end
function ZO_MailSendShared_SavePendingMail() end
function ZO_MailSendShared_RestorePendingMail(manager) end
--ingame\mainmenu
function ZO_MainMenuManager_Gamepad:New(control) end
function ZO_MainMenuManager_Gamepad:Initialize(control) end
function ZO_MainMenuManager_Gamepad:OnShowing() end
function ZO_MainMenuManager_Gamepad:OnHiding() end
function ZO_MainMenuManager_Gamepad:RefreshLists() end
function ZO_MainMenuManager_Gamepad:OnDeferredInitialize() end
function ZO_MainMenuManager_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_MainMenuManager_Gamepad:SwitchToSelectedScene(list) end
function ZO_MainMenuManager_Gamepad:Exit() end
function ZO_MainMenuManager_Gamepad:RefreshMainList() end
function ZO_MainMenuManager_Gamepad:RefreshSubList(mainListEntry) end
function ZO_MainMenuManager_Gamepad:IsShowing() end
function ZO_MainMenuManager_Gamepad:ShowLastCategory() end
function ZO_MainMenuManager_Gamepad:MarkNewnessDirty() end
function ZO_MainMenuManager_Gamepad:OnNumNotificationsChanged(numNotifications) end
function ZO_MainMenuManager_Gamepad:IsEntrySceneShowing(entryData) end
function ZO_MainMenuManager_Gamepad:ToggleCategory(category) end
function ZO_MainMenuManager_Gamepad:ShowCategory(category) end
function ZO_MainMenuManager_Gamepad:ShowScene(sceneName) end
function ZO_MainMenuManager_Gamepad:ToggleScene(sceneName) end
function ZO_MainMenuManager_Gamepad:AttemptShowBaseScene() end
function ZO_MainMenu_Gamepad_OnInitialized(self) end
function MainMenu_Keyboard:SetCategoriesEnabled(categoryFilterFunction, shouldBeEnabled) end
function MainMenu_Keyboard:New(control) end
function MainMenu_Keyboard:Initialize(control) end
function MainMenu_Keyboard:AddCategories() end
function MainMenu_Keyboard:AddCategoryAreaFragment(fragment) end
function MainMenu_Keyboard:AddRawScene(sceneName, category, categoryInfo, sceneGroupName) end
function MainMenu_Keyboard:SetLastSceneName(categoryInfo, sceneName) end
function MainMenu_Keyboard:SetLastSceneGroupName(categoryInfo, sceneGroupName) end
function MainMenu_Keyboard:HasLast(categoryInfo) end
function MainMenu_Keyboard:AddScene(category, sceneName) end
function MainMenu_Keyboard:SetSceneEnabled(sceneName, enabled) end
function MainMenu_Keyboard:AddSceneGroup(category, sceneGroupName, menuBarIconData, sceneGroupPreferredSceneFunction) end
function MainMenu_Keyboard:EvaluateSceneGroupVisibilityOnEvent(sceneGroupName, event) end
function MainMenu_Keyboard:EvaluateSceneGroupVisibilityOnCallback(sceneGroupName, callbackName) end
function MainMenu_Keyboard:RefreshCategoryIndicators() end
function MainMenu_Keyboard:RefreshCategoryBar() end
function MainMenu_Keyboard:AddButton(category, name, callback) end
function MainMenu_Keyboard:IsShowing() end
function MainMenu_Keyboard:Hide() end
function MainMenu_Keyboard:UpdateSceneGroupBarEnabledStates(sceneGroupName) end
function MainMenu_Keyboard:UpdateSceneGroupButtons(groupName) end
function MainMenu_Keyboard:SetupSceneGroupBar(category, sceneGroupName) end
function MainMenu_Keyboard:Update(category, sceneName) end
function MainMenu_Keyboard:ShowScene(sceneName) end
function MainMenu_Keyboard:ToggleScene(sceneName) end
function MainMenu_Keyboard:SetPreferredActiveScene(sceneGroupInfo, sceneGroup) end
function MainMenu_Keyboard:ShowSceneGroup(sceneGroupName, specificScene) end
function MainMenu_Keyboard:ToggleSceneGroup(sceneGroupName, specificScene) end
function MainMenu_Keyboard:ShowCategory(category) end
function MainMenu_Keyboard:ToggleLastCategory() end
function MainMenu_Keyboard:OnCategoryClicked(category) end
function MainMenu_Keyboard:OnSceneGroupTabClicked(sceneGroupName) end
function MainMenu_Keyboard:OnSceneGroupBarLabelTextChanged() end
function ZO_MainMenuCategoryBarButton_OnMouseEnter(self) end
function ZO_MainMenuCategoryBarButton_OnMouseExit(self) end
function ZO_MainMenu_OnSceneGroupBarLabelTextChanged() end
function ZO_MainMenu_OnInitialized(self) end
function MainMenu_Manager:New(...) end
function MainMenu_Manager:Initialize() end
function MainMenu_Manager:OnPlayerAliveStateChanged(isAlive) end
function MainMenu_Manager:OnPlayerCombatStateChanged(inCombat) end
function MainMenu_Manager:OnPlayerRevivingStateChanged(isReviving) end
function MainMenu_Manager:OnPlayerStateUpdate() end
function MainMenu_Manager:RefreshPlayerState() end
function MainMenu_Manager:IsPlayerDead() end
function MainMenu_Manager:IsPlayerInCombat() end
function MainMenu_Manager:IsPlayerReviving() end
function MainMenu_Manager:SetBlockingScene(sceneName, callback, arg) end
function MainMenu_Manager:ClearBlockingScene(callback) end
function MainMenu_Manager:ForceClearBlockingScenes() end
function MainMenu_Manager:CancelBlockingSceneNextScene() end
function MainMenu_Manager:ClearBlockingSceneOnGamepadModeChange() end
function MainMenu_Manager:ActivatedBlockingScene_Scene(nextSceneData, activatedByMouseClick) end
function MainMenu_Manager:ActivatedBlockingScene_BaseScene(activatedByMouseClick) end
function MainMenu_Manager:HasBlockingScene() end
function MainMenu_Manager:HasBlockingSceneNextScene() end
function MainMenu_Manager:GetBlockingSceneName() end
--ingame\map
function CMapHandlers:New() end
function CMapHandlers:Initialize() end
function CMapHandlers:InitializeRefresh() end
function CMapHandlers:InitializeEvents() end
function CMapHandlers:RefreshAll() end
function CMapHandlers:AddKeep(keepId, bgContext) end
function CMapHandlers:RefreshKeeps() end
function CMapHandlers:RefreshKeep(keepId, bgContext) end
function CMapHandlers:RefreshAvAObjectives() end
function CMapHandlers:AddMapPin(pinType, keepId, objectiveId) end
function CMapHandlers:ValidateAVAPinAllowed(pinType) end
function WorldMapFilterPanel_Gamepad:New(...) end
function WorldMapFilterPanel_Gamepad:Initialize(control, mapFilterType, savedVars) end
function WorldMapFilterPanel_Gamepad:SetMapMode(mapMode) end
function WorldMapFilterPanel_Gamepad:ShouldShowSelectButton() end
function WorldMapFilterPanel_Gamepad:OnSelect() end
function WorldMapFilterPanel_Gamepad:AddHeader(header) end
function WorldMapFilterPanel_Gamepad:AddPinFilterCheckBox(mapPinGroup, refreshFunction) end
function WorldMapFilterPanel_Gamepad:AddPinFilterComboBox(optionsPinGroup, refreshFunction, header, optionsEnumStringName, ...) end
function WorldMapFilterPanel_Gamepad:SetupDropDown(control, data, selected, reselectingDuringRebuild, enabled, active) end
function WorldMapFilterPanel_Gamepad:FocusDropDown(dropDown) end
function WorldMapFilterPanel_Gamepad:UnfocusDropDown() end
function WorldMapFilterPanel_Gamepad:HideDropDown() end
function WorldMapFilterPanel_Gamepad:PreBuildControls() end
function WorldMapFilterPanel_Gamepad:PostBuildControls() end
function PvEWorldMapFilterPanel_Gamepad:New(...) end
function PvPWorldMapFilterPanel_Gamepad:New(...) end
function ImperialPvPWorldMapFilterPanel_Gamepad:New(...) end
function WorldMapFilters_Gamepad:New(...) end
function WorldMapFilters_Gamepad:Initialize(control) end
function WorldMapFilters_Gamepad:SwitchToKeybind(keybindStripDescriptor) end
function WorldMapFilters_Gamepad:RefreshKeybind() end
function WorldMapFilters_Gamepad:SelectKeybind() end
function WorldMapFilters_Gamepad:InitializeKeybindDescriptor() end
function ZO_WorldMapFilters_Gamepad_OnInitialized(self) end
function WorldMapInfo_Gamepad:New(...) end
function WorldMapInfo_Gamepad:Initialize(control) end
function WorldMapInfo_Gamepad:Show() end
function WorldMapInfo_Gamepad:Hide() end
function WorldMapInfo_Gamepad:ShowCurrentFragments() end
function WorldMapInfo_Gamepad:RemoveCurrentFragments() end
function WorldMapInfo_Gamepad:SwitchToFragment(fragment, usesRightSideContent) end
function WorldMapInfo_Gamepad:InitializeTabs() end
function ZO_WorldMapInfo_Gamepad_Initialize() end
function ZO_WorldMapInfo_OnBackPressed() end
function WorldMapKeepInfo_Gamepad:New(...) end
function WorldMapKeepInfo_Gamepad:Initialize(control) end
function WorldMapKeepInfo_Gamepad:SwitchToFragments(fragments) end
function WorldMapKeepInfo_Gamepad:BeginBar() end
function WorldMapKeepInfo_Gamepad:AddBar(text, fragments, buttonData) end
function WorldMapKeepInfo_Gamepad:FinishBar() end
function ZO_WorldMapKeepInfo_Gamepad_OnInitialize(control) end
function MapKeepSummary_Gamepad:New(...) end
function MapKeepSummary_Gamepad:GetKeepUpgradeObject() end
function MapKeepSummary_Gamepad:Initialize(control) end
function ZO_WorldMapKeepSummary_Gamepad_OnInitialized(self) end
function MapKeepUpgrade_Gamepad:New(...) end
function MapKeepUpgrade_Gamepad:Initialize(control) end
function MapKeepUpgrade_Gamepad:RefreshAll() end
function MapKeepUpgrade_Gamepad:RefreshData() end
function MapKeepUpgrade_Gamepad:ClearButtonHighlight() end
function MapKeepUpgrade_Gamepad:GetGridItems() end
function MapKeepUpgrade_Gamepad:RefreshGridHighlight() end
function ZO_WorldMapKeepUpgrade_Gamepad_OnInitialized(self) end
function WorldMapKey_Gamepad:New(...) end
function WorldMapKey_Gamepad:Initialize(control) end
function WorldMapKey_Gamepad:InitializeKeybindStripDescriptor() end
function WorldMapKey_Gamepad:RefreshKey() end
function ZO_WorldMapKey_Gamepad_OnInitialized(self) end
function MapLocations_Gamepad:New(...) end
function MapLocations_Gamepad:Initialize(control) end
function MapLocations_Gamepad:UpdateSideContentVisibility(showingTooltips) end
function MapLocations_Gamepad:InitializeList(control) end
function MapLocations_Gamepad:UpdateSelectedMap() end
function MapLocations_Gamepad:SetListDisabled(disabled) end
function MapLocations_Gamepad:BuildLocationList() end
function MapLocations_Gamepad:SetupLocation(control, data, selected, selectedDuringRebuild, enable, activated) end
function MapLocations_Gamepad:SetupLocationDetails(data) end
function MapLocations_Gamepad:SwitchToKeybind(keybindStripDescriptor) end
function MapLocations_Gamepad:RefreshKeybind() end
function MapLocations_Gamepad:InitializeKeybindDescriptor() end
function ZO_WorldMapLocations_Gamepad_OnInitialized(self) end
function WorldMapQuests_Gamepad:New(...) end
function WorldMapQuests_Gamepad:Initialize(control) end
function WorldMapQuests_Gamepad:LayoutList() end
function WorldMapQuests_Gamepad:RefreshHeaders() end
function WorldMapQuests_Gamepad:SetupQuestDetails(selectedData) end
function WorldMapQuests_Gamepad:RefreshKeybind() end
function WorldMapQuests_Gamepad:InitializeKeybindDescriptor() end
function ZO_WorldMapQuests_Gamepad_OnInitialized(self) end
function ZO_KeepTooltip_OnInitialized(self) end
function ZO_ImperialCityTooltip_OnInitialized(self) end
function ZO_KeepTooltip_Gamepad_OnInitialized(self) end
function ZO_WorldMapCorner_OnInitialized(self) end
function ZO_WorldMapCorner_OnUpdate(self, time) end
function WorldMapFilterPanel:New(...) end
function WorldMapFilterPanel:Initialize(control, mapFilterType, savedVars) end
function WorldMapFilterPanel:SetMapMode(mapMode) end
function WorldMapFilterPanel:RefreshDependentComboBox(checkBox) end
function WorldMapFilterPanel:AddPinFilterCheckBox(mapPinGroup, refreshFunction, header) end
function WorldMapFilterPanel:AddPinFilterComboBox(optionsPinGroup, refreshFunction, header, optionsEnumStringName, ...) end
function WorldMapFilterPanel:LoadInitialState() end
function PvEWorldMapFilterPanel:New(...) end
function PvPWorldMapFilterPanel:New(...) end
function ImperialPvPWorldMapFilterPanel:New(...) end
function WorldMapFilters:New(...) end
function WorldMapFilters:Initialize(control) end
function ZO_WorldMapFilters_OnInitialized(self) end
function WorldMapInfo:New(...) end
function WorldMapInfo:Initialize(control) end
function WorldMapInfo:InitializeTabs() end
function WorldMapInfo:SelectTab(name) end
function ZO_WorldMapInfo_Initialize() end
function WorldMapKeepInfo:New(...) end
function WorldMapKeepInfo:Initialize(control) end
function WorldMapKeepInfo:PreShowKeep() end
function WorldMapKeepInfo:PostShowKeep() end
function WorldMapKeepInfo:BeginBar() end
function WorldMapKeepInfo:AddBar(text, fragments, buttonData) end
function WorldMapKeepInfo:FinishBar() end
function ZO_WorldMapKeepInfo_OnInitialize(control) end
function MapKeepSummary:New(...) end
function MapKeepSummary:GetKeepUpgradeObject() end
function MapKeepSummary:Initialize(control) end
function ZO_WorldMapKeepAlliance_OnMouseEnter(self) end
function ZO_WorldMapKeepAlliance_OnMouseExit(self) end
function ZO_WorldMapKeepSummary_OnInitialized(self) end
function MapKeepUpgrade:New(...) end
function MapKeepUpgrade:Initialize(control) end
function MapKeepUpgrade:RefreshAll() end
function MapKeepUpgrade:RefreshData() end
function ZO_WorldMapKeepUpgradeButton_OnMouseEnter(button) end
function ZO_WorldMapKeepUpgradeButton_OnMouseExit(button) end
function ZO_WorldMapKeepUpgradeTime_OnMouseEnter(self) end
function ZO_WorldMapKeepUpgradeTime_OnMouseExit(self) end
function ZO_WorldMapKeepUpgradeBar_OnMouseEnter(self) end
function ZO_WorldMapKeepUpgradeBar_OnMouseExit(self) end
function ZO_WorldMapKeepUpgrade_OnInitialized(self) end
function WorldMapKey:New(...) end
function WorldMapKey:Initialize(control) end
function WorldMapKey:Symbol_OnMouseEnter(symbol) end
function WorldMapKey:Symbol_OnMouseExit(symbol) end
function ZO_WorldMapKeySymbol_OnMouseEnter(self) end
function ZO_WorldMapKeySymbol_OnMouseExit(self) end
function ZO_WorldMapKey_OnInitialized(self) end
function MapLocations:New(...) end
function MapLocations:Initialize(control) end
function MapLocations:InitializeList(control) end
function MapLocations:UpdateSelectedMap() end
function MapLocations:SetListDisabled(disabled) end
function MapLocations:BuildLocationList() end
function MapLocations:SetupLocation(control, data) end
function MapLocations:RowLocation_OnMouseDown(label, button) end
function MapLocations:RowLocation_OnMouseUp(label, button, upInside) end
function ZO_WorldMapLocationRowLocation_OnMouseDown(label, button) end
function ZO_WorldMapLocationRowLocation_OnMouseUp(label, button, upInside) end
function ZO_WorldMapLocations_OnInitialized(self) end
function WorldMapQuests:New(...) end
function WorldMapQuests:Initialize(control) end
function WorldMapQuests:LayoutList() end
function WorldMapQuests:RefreshHeaders() end
function WorldMapQuests:SetupQuestHeader(control, data) end
function WorldMapQuests:QuestHeader_OnClicked(header, button) end
function WorldMapQuests:QuestHeader_OnMouseEnter(header) end
function ZO_WorldMapQuestHeader_OnMouseEnter(header) end
function ZO_WorldMapQuestHeader_OnMouseExit(header) end
function ZO_WorldMapQuestHeader_OnMouseDown(header, button) end
function ZO_WorldMapQuestHeader_OnMouseUp(header, button, upInside) end
function ZO_WorldMapQuests_OnInitialized(self) end
function ZO_MapLocationTooltip_OnCleared(self) end
function ZO_MapLocationTooltip_OnInitialized(self) end
function ZO_MapLocationTooltip_Gamepad_OnInitialized(self) end
function ZO_PinBlobManager:New(blobContainer) end
function ZO_WorldMapTiles:New(...) end
function ZO_WorldMapTiles:Initialize(parent) end
function ZO_WorldMapTiles:GetTile(i) end
function ZO_WorldMapTiles:GetOrCreateTile(i) end
function ZO_WorldMapTiles:ReleaseTiles() end
function ZO_WorldMapTiles:UpdateMapData() end
function ZO_WorldMapTiles:LayoutTiles() end
function ZO_WorldMapTiles:UpdateTextures() end
function InformationTooltipMixin:AddDivider() end
function InformationTooltipMixin:AddMoney(tooltip, cost, text, hasEnough) end
function ZO_WorldMap_GetWayshrineTooltipCollectibleLockedText(pin) end
function InformationTooltipMixin:AppendWayshrineTooltip(pin) end
function WorldMapStickyPin:New(...) end
function WorldMapStickyPin:Initialize() end
function WorldMapStickyPin:SetEnabled(enabled) end
function WorldMapStickyPin:UpdateThresholdDistance(minZoom, maxZoom, currentZoom) end
function WorldMapStickyPin:SetStickyPin(pin) end
function WorldMapStickyPin:GetStickyPin() end
function WorldMapStickyPin:ClearStickyPin(mover) end
function WorldMapStickyPin:MoveToStickyPin(mover) end
function WorldMapStickyPin:SetStickyPinFromNearestCandidate() end
function WorldMapStickyPin:ClearNearestCandidate() end
function WorldMapStickyPin:ConsiderPin(pin, x, y) end
function ZO_WorldMap_InvalidateTooltip() end
function GetReviveKeybindText(pinHandlers) end
function ZO_WorldMap_WouldPinHandleClick(pinControl, button, ctrl, alt, shift) end
function ZO_WorldMap_GetPinHandleTravel() end
function ZO_WorldMap_GetPinHandleQuests() end
function ZO_WorldMap_GetPinHandlers(button) end
function ZO_WorldMap_HandlePinClicked(pinControl, button, ctrl, alt, shift) end
function ZO_MapPin.GetMapPinForControl(control) end
function ZO_MapPin:New() end
function ZO_MapPin.HidePulseAfterFadeOut(control) end
function ZO_MapPin.DoFinalFadeInAfterPing(control) end
function ZO_MapPin.DoFinalFadeOutAfterPing(control) end
function ZO_MapPin.CreateQuestPinTag(questIndex, stepIndex, conditionIndex) end
function ZO_MapPin.CreatePOIPinTag(zoneIndex, poiIndex, icon, linkedCollectibleIsLocked) end
function ZO_MapPin.CreateLocationPinTag(locationIndex, icon) end
function ZO_MapPin.CreateAvAObjectivePinTag(keepId, objectiveId, battlegroundContext) end
function ZO_MapPin.CreateImperialCityPinTag(battlegroundContext, linkedCollectibleIsLocked) end
function ZO_MapPin.CreateKeepPinTag(keepId, battlegroundContext, isUnderAttackPin) end
function ZO_MapPin.CreateKeepTravelNetworkPinTag(keepId) end
function ZO_MapPin.CreateRestrictedLinkTravelNetworkPinTag(restrictedAlliance, battlegroundContext) end
function ZO_MapPin.CreateTravelNetworkPinTag(nodeIndex, icon, glowIcon, linkedCollectibleIsLocked) end
function ZO_MapPin.CreateForwardCampPinTag(forwardCampIndex) end
function ZO_MapPin.CreateAvARespawnPinTag(id) end
function ZO_MapPin:StopTextureAnimation() end
function ZO_MapPin:PlayTextureAnimation(loopCount) end
function ZO_MapPin:ResetAnimation(resetOptions, loopCount, pulseIcon, overlayIcon, postPulseCallback, min, max) end
function ZO_MapPin:PingMapPin(animation) end
function ZO_MapPin:GetPinType() end
function ZO_MapPin:GetPinTypeAndTag() end
function ZO_MapPin:SetQuestIndex(newQuestIndex) end
function ZO_MapPin:GetQuestIndex() end
function ZO_MapPin:IsAvAObjective() end
function ZO_MapPin:IsImperialCityGate() end
function ZO_MapPin:IsKeep() end
function ZO_MapPin:IsDistrict() end
function ZO_MapPin:IsKeepOrDistrict() end
function ZO_MapPin:IsUnit() end
function ZO_MapPin:IsGroup() end
function ZO_MapPin:IsQuest() end
function ZO_MapPin:IsPOI() end
function ZO_MapPin:IsAssisted() end
function ZO_MapPin:IsMapPing() end
function ZO_MapPin:IsKillLocation() end
function ZO_MapPin:IsFastTravelKeep() end
function ZO_MapPin:IsFastTravelWayShrine() end
function ZO_MapPin:IsForwardCamp() end
function ZO_MapPin:IsAvARespawn() end
function ZO_MapPin:IsRestrictedLink() end
function ZO_MapPin:IsImperialCityPin() end
function ZO_MapPin:IsCyrodiilPin() end
function ZO_MapPin:IsAvAPin() end
function ZO_MapPin:GetQuestData() end
function ZO_MapPin:ValidateAVAPinAllowed() end
function ZO_MapPin:GetPOIIndex() end
function ZO_MapPin:GetPOIZoneIndex() end
function ZO_MapPin:GetPOIIcon() end
function ZO_MapPin:IsLocation() end
function ZO_MapPin:GetLocationIndex() end
function ZO_MapPin:GetLocationIcon() end
function ZO_MapPin:GetFastTravelIcons() end
function ZO_MapPin:GetUnitTag() end
function ZO_MapPin:GetAvAObjectiveKeepId() end
function ZO_MapPin:GetAvAObjectiveObjectiveId() end
function ZO_MapPin:GetKeepId() end
function ZO_MapPin:IsUnderAttackPin() end
function ZO_MapPin:GetFastTravelKeepId() end
function ZO_MapPin:IsLockedByLinkedCollectible() end
function ZO_MapPin:GetBattlegroundContext() end
function ZO_MapPin:GetRestrictedAlliance() end
function ZO_MapPin:GetFastTravelCost() end
function ZO_MapPin:IsForwardCampUsable() end
function ZO_MapPin:GetFastTravelNodeIndex() end
function ZO_MapPin:GetForwardCampIndex() end
function ZO_MapPin:GetAvARespawnId() end
function ZO_MapPin:GetControl() end
function ZO_MapPin:GetLevel() end
function ZO_MapPin:GetBlobPinControl() end
function ZO_MapPin:MouseIsOver(isInGamepadPreferredMode, mapCenterX, mapCenterY) end
function ZO_MapPin:NeedsContinuousTooltipUpdates() end
function ZO_MapPin:ClearData() end
function ZO_MapPin:ResetScale() end
function ZO_MapPin:UpdateLocation() end
function ZO_MapPin:GetCenter() end
function ZO_MapPin:DistanceToSq(x, y) end
function ZO_MapPin:UpdateAreaPinTexture() end
function ZO_MapPin:SetLocation(xLoc, yLoc, radius) end
function ZO_MapPin:SetRotation(angle) end
function ZO_MapPin:GetNormalizedPosition() end
function ZO_MapPin:SetTargetScale(targetScale) end
function ZO_WorldMapPins:New() end
function ZO_WorldMapPins:ClearPendingTasks() end
function ZO_WorldMapPins:ClearPendingTasksForQuest(questIndex) end
function ZO_WorldMapPins:AddTask(taskId, data) end
function ZO_WorldMapPins:GetNextCustomPinType() end
function ZO_WorldMapPins:CreateCustomPinType(pinType) end
function ZO_WorldMapPins:AddCustomPin(pinType, pinTypeAddCallback, pinTypeOnResizeCallback, pinLayoutData, pinTooltipCreator) end
function ZO_WorldMapPins:SetCustomPinEnabled(pinType, enabled) end
function ZO_WorldMapPins:IsCustomPinEnabled(pinType) end
function ZO_WorldMapPins:RefreshCustomPins(optionalPinType) end
function ZO_WorldMapPins:MapPinLookupToPinKey(lookupType, majorIndex, keyIndex, pinKey) end
function ZO_WorldMapPins:CreatePin(pinType, pinTag, xLoc, yLoc, radius) end
function ZO_WorldMapPins:PingQuest(questIndex, animation) end
function ZO_WorldMapPins:HasPinForQuest(questIndex) end
function ZO_WorldMapPins:SetQuestPinsAssisted(questIndex, assisted) end
function ZO_WorldMapPins:FindPin(lookupType, majorIndex, keyIndex) end
function ZO_WorldMapPins:RemovePins(lookupType, majorIndex, keyIndex) end
function ZO_WorldMapPins:UpdatePinsForMapSizeChange() end
function ZO_WorldMapPins:GetQuestConditionPin(questIndex) end
function ZO_WorldMapPins:GetPlayerPin() end
function ZO_MouseoverMapBlobManager:New(blobContainer) end
function ZO_MouseoverMapBlobManager:Update(normalizedMouseX, normalizedMouseY) end
function ZO_MouseoverMapBlobManager:IsShowingMapRegionBlob() end
function ZO_MouseoverMapBlobManager:HideBlob(textureName) end
function ZO_MouseoverMapBlobManager:HideCurrent() end
function ZO_MouseoverMapBlobManager:ClearLocation() end
function ZO_MapLocations:New(container) end
function ZO_MapLocations:SetFontScale(scale) end
function ZO_MapLocations:GetFontString(size) end
function ZO_MapLocations:AddLocationTextInternal(locationIndex, ...) end
function ZO_MapLocations:AddLocation(locationIndex) end
function ZO_MapLocations:RefreshLocations() end
function ZO_KeepNetwork:New(container) end
function ZO_KeepNetwork:SetOpenNetwork(keepId) end
function ZO_KeepNetwork:ClearOpenNetwork() end
function ZO_WorldMap_OnResizeStart(self) end
function ZO_WorldMap_OnResizeStop(self) end
function ZO_MapZoomKeybindStrip:New(...) end
function ZO_MapZoomKeybindStrip:Initialize(control, descriptor) end
function ZO_MapZoomKeybindStrip:GetDescriptor() end
function ZO_MapZoomKeybindStrip:MarkDirty() end
function ZO_MapZoomKeybindStrip:CleanDirty() end
function ZO_MapMouseoverKeybindStrip:New(...) end
function ZO_MapMouseoverKeybindStrip:Initialize(control, descriptor) end
function ZO_MapMouseoverKeybindStrip:GetDescriptor() end
function ZO_MapMouseoverKeybindStrip:MarkDirty() end
function ZO_MapMouseoverKeybindStrip:CleanDirty() end
function ZO_MapMouseoverKeybindStrip:DoMouseEnterForPinType(pinType) end
function ZO_MapMouseoverKeybindStrip:DoMouseExitForPinType(pinType) end
function ZO_MapMouseoverKeybindStrip:IsOverPinType(pinType) end
function ZO_MapMouseoverKeybindStrip:SetIsOverPinType(pinType, isOver) end
function ZO_MapPanAndZoom:New(...) end
function ZO_MapPanAndZoom:Initialize(zoomControl) end
function ZO_MapPanAndZoom:SetAllowPanPastMapEdge(allowed) end
function ZO_MapPanAndZoom:ClearLockPoint() end
function ZO_MapPanAndZoom:ClearTargetOffset() end
function ZO_MapPanAndZoom:ClearTargetZoom() end
function ZO_MapPanAndZoom:SetTargetZoom(zoom) end
function ZO_MapPanAndZoom:ComputeMinZoom() end
function ZO_MapPanAndZoom:ComputeMaxZoom() end
function ZO_MapPanAndZoom:CanInitializeMap() end
function ZO_MapPanAndZoom:SetZoomAndOffsetInNewMap(zoom) end
function ZO_MapPanAndZoom:InitializeMap(wasNavigateIn) end
function ZO_MapPanAndZoom:SetCustomZoomMinMax(minZoom, maxZoom) end
function ZO_MapPanAndZoom:ClearCustomZoomMinMax() end
function ZO_MapPanAndZoom:SetMapZoomMinMax(minZoom, maxZoom) end
function ZO_MapPanAndZoom:RefreshZoom() end
function ZO_MapPanAndZoom:SetZoomMinMax(minZoom, maxZoom) end
function ZO_MapPanAndZoom:GetCurrentZoom() end
function ZO_MapPanAndZoom:SetCurrentZoom(zoom) end
function ZO_MapPanAndZoom:SetCurrentZoomInternal(zoom) end
function ZO_MapPanAndZoom:RefreshZoomButtonsEnabled() end
function ZO_MapPanAndZoom:CanZoomInFurther() end
function ZO_MapPanAndZoom:CanZoomOutFurther() end
function ZO_MapPanAndZoom:Step(amount) end
function ZO_MapPanAndZoom:AddZoomDelta(delta, mouseX, mouseY) end
function ZO_MapPanAndZoom:SetLockedZoom(zoom, mouseX, mouseY) end
function ZO_MapPanAndZoom:AddCurrentOffsetDelta(deltaX, deltaY) end
function ZO_MapPanAndZoom:SetCurrentOffset(offsetX, offsetY) end
function ZO_MapPanAndZoom:SetTargetOffset(offsetX, offsetY) end
function ZO_MapPanAndZoom:AddTargetOffsetDelta(deltaX, deltaY) end
function ZO_MapPanAndZoom:SetFinalTargetOffset(offsetX, offsetY, targetZoom) end
function ZO_MapPanAndZoom:HasLockPoint() end
function ZO_MapPanAndZoom:HasTargetOffset() end
function ZO_MapPanAndZoom:HasTargetZoom() end
function ZO_MapPanAndZoom:GetPinFocusZoomAndOffset(pin, useCurrentZoom) end
function ZO_MapPanAndZoom:PanToPin(pin, useCurrentZoom) end
function ZO_MapPanAndZoom:JumpToPin(pin, useCurrentZoom) end
function ZO_MapPanAndZoom:JumpToPinWhenAvailable(findPinFunction) end
function ZO_MapPanAndZoom:ClearJumpToPinWhenAvailable() end
function ZO_MapPanAndZoom:Update(currentTime) end
function ZO_MapPanAndZoom:ReachedTargetOffset() end
function ZO_MapPanAndZoom:CanMapZoom() end
function ZO_MapPanAndZoom:OnPinCreated() end
function ZO_MapPanAndZoom:OnWorldMapChanged(wasNavigateIn) end
function ZO_MapPanAndZoom:OnWorldMapShowing() end
function GamepadMap:New(...) end
function GamepadMap:Initialize() end
function GamepadMap:UpdateDirectionalInput() end
function GamepadMap:TryZoom(normalizedFrameDelta, dx, dy, navigateInAt, navigateOutAt) end
function GamepadMap:DisableZoomingFor(seconds) end
function GamepadMap:IsZoomDisabledForDuration() end
function GamepadMap:RefreshZoomDelta() end
function GamepadMap:SetZoomIn(magnitude) end
function GamepadMap:SetZoomOut(magnitude) end
function GamepadMap:StopMotion() end
function ZO_MapPanAndZoom:OnMouseWheel(delta) end
function ZO_WorldMapZoomMinus_OnClicked() end
function ZO_WorldMapZoomPlus_OnClicked() end
function ZO_WorldMapZoom_OnMouseWheel(delta) end
function ZO_WorldMapZoom_OnInitialized(self) end
function ZO_WorldMap_RefreshMapFrameAnchor() end
function ZO_WorldMap_PushSpecialMode(mode) end
function ZO_WorldMap_PopSpecialMode() end
function ZO_WorldMap_GetMode() end
function ZO_WorldMap_IsMapChangingAllowed(zoomDirection) end
function ZO_WorldMap_GetFilterValue(option) end
function ZO_WorldMap_IsPinGroupShown(pinGroup) end
function ZO_WorldMap_RefreshImperialCity(bgContext) end
function ZO_WorldMap_IsObjectiveShown(keepId, objectiveId, bgContext) end
function ZO_WorldMap_RefreshKillLocations() end
function ZO_WorldMap_RefreshRespawnTimer(currentTime) end
function ZO_WorldMap_RefreshForwardCamps() end
function ZO_WorldMap_RefreshAccessibleAvAGraveyards() end
function ZO_WorldMap_RefreshGroupPins() end
function ZO_WorldMap_GetUnderAttackPinForKeepPin(keepPinType) end
function ZO_WorldMap_RefreshAllPOIs() end
function ZO_WorldMap_GetMapTitle() end
function ZO_WorldMap_GetMapDungeonDifficulty() end
function ZO_WorldMap_UpdateMap() end
function ZO_Map_GetFastTravelNode() end
function ZO_WorldMapHistorySlider_OnValueChanged(slider, value, eventReason) end
function ZO_WorldMap_ResetHistorySlider() end
function ZO_WorldMap_OnHide() end
function ZO_WorldMap_OnShow() end
function ZO_WorldMapTitleBar_OnDragStart() end
function ZO_WorldMapTitleBar_OnMouseUp(button, upInside) end
function ZO_WorldMap_ToggleSize() end
function ZO_WorldMap_MouseDown(button, ctrl, alt, shift) end
function ZO_WorldMap_MouseUp(mapControl, mouseButton, upInside) end
function ZO_WorldMap_MouseWheel(delta) end
function ZO_WorldMap_HandlePinEnter() end
function ZO_WorldMap_HandlePinExit() end
function ZO_WorldMap_ChangeFloor(self) end
function ZO_WorldMap_ShowDungeonFloorTooltip(self) end
function ZO_WorldMap_ShowAvARespawns() end
function ZO_WorldMap_AddCustomPin(pinType, pinTypeAddCallback, pinTypeOnResizeCallback, pinLayoutData, pinTooltipCreator) end
function ZO_WorldMap_SetCustomPinEnabled(pinType, enabled) end
function ZO_WorldMap_IsCustomPinEnabled(pinType) end
function ZO_WorldMap_ResetCustomPinsOfType(pinTypeString) end
function ZO_WorldMap_RefreshCustomPinsOfType(pinType) end
function ZO_WorldMap_GetMapDimensions() end
function ZO_WorldMap_SetCustomZoomLevels(minZoom, maxZoom) end
function ZO_WorldMap_ClearCustomZoomLevels() end
function ZO_WorldMap_GetBattlegroundQueryType() end
function ZO_WorldMap_SetMapByIndex(mapIndex) end
function ZO_WorldMap_PanToQuest(questIndex) end
function ZO_WorldMap_PanToPlayer() end
function ZO_WorldMap_RefreshKeepNetwork() end
function ZO_WorldMap_ShowQuestOnMap(questIndex) end
function ZO_WorldMap_ShowKeepOnMap(keepId) end
function ZO_WorldMap_RefreshKeeps() end
function ZO_WorldMap_RefreshAvAObjectives() end
function ZO_WorldMap_RemovePlayerWaypoint() end
function SetCampaignHistoryEnabled(enabled) end
function ZO_WorldMap_InteractKeybindForceHidden(hidden) end
function ZO_WorldMap_SetKeepMode(active) end
function ZO_WorldMap_HandlersContain(handlers, types) end
function ZO_WorldMap_CountHandlerTypes(handlers) end
function ZO_WorldMap_UpdateInteractKeybind_Gamepad() end
function ZO_WorldMap_SetDirectionalInputActive(active) end
function ZO_WorldMap_SetGamepadKeybindsShown(enabled) end
function ZO_WorldMap_HideAllTooltips() end
function ZO_WorldMap_ShowGamepadTooltip(resetScroll) end
function ZO_WorldMap_IsTooltipShowing() end
function ZO_WorldMap_GetZoomText_Gamepad() end
function ZO_WorldMap_IsWorldMapInfoShowing() end
function ZO_WorldMap_IsKeepInfoShowing() end
function ZO_WorldMap_IsWorldMapShowing() end
function ZO_WorldMap_ShowWorldMap() end
function ZO_WorldMap_HideWorldMap() end
function ZO_WorldMapChoice_Gamepad_Initialize(control) end
function ZO_WorldMap_AddActiveQuestDialogItems(list, pins, handlers, header) end
function ZO_WorldMap_AddRespawnDialogItems(list, pins, handlers, header) end
function ZO_WorldMap_SetupChoiceDialog(pins, handlers) end
function ZO_WorldMapFilterPanel_Shared:New(...) end
function ZO_WorldMapFilterPanel_Shared:Initialize(control, mapFilterType, savedVars) end
function ZO_WorldMapFilterPanel_Shared:AnchorControl(control, offsetX) end
function ZO_WorldMapFilterPanel_Shared:SetHidden(hidden) end
function ZO_WorldMapFilterPanel_Shared:GetPinFilter(mapPinGroup) end
function ZO_WorldMapFilterPanel_Shared:SetPinFilter(mapPinGroup, shown) end
function ZO_WorldMapFilterPanel_Shared:FindCheckBox(mapPinGroup) end
function ZO_WorldMapFilterPanel_Shared:FindComboBox(mapPinGroup) end
function ZO_WorldMapFilterPanel_Shared:ComboBoxDependsOn(childPinGroup, parentPinGroup) end
function ZO_WorldMapFilterPanel_Shared:FindDependentCheckBox(mapPinGroup) end
function ZO_WorldMapFilterPanel_Shared:PreBuildControls() end
function ZO_WorldMapFilterPanel_Shared:BuildControls() end
function ZO_WorldMapFilterPanel_Shared:PostBuildControls() end
function ZO_WorldMapFilters_Shared:New(...) end
function ZO_WorldMapFilters_Shared:Initialize(control) end
function ZO_PvEWorldMapFilterPanel_Shared:BuildControls() end
function ZO_PvPWorldMapFilterPanel_Shared:BuildControls() end
function ZO_ImperialPvPWorldMapFilterPanel_Shared:BuildControls() end
function ZO_WorldMapInfo_Shared:New(...) end
function ZO_WorldMapInfo_Shared:Initialize(control) end
function KeepUpgradeType_Shared:SetKeep(keepId) end
function KeepUpgradeType_Shared:SetBGQueryType(bgQueryType) end
function KeepUpgradeType_Shared:SetUpgradeTooltip(level, index) end
function KeepUpgradeType_Shared:GetAlliance() end
function KeepUpgradeType_Shared:GetGuildOwner() end
function KeepUpgradeType_Shared:GetKeep() end
function KeepUpgradeType_Shared:GetBGQueryType() end
function KeepUpgradeType_Shared:GetRate() end
function ZO_KeepUpgrade_Shared:New() end
function ZO_KeepUpgrade_Shared:SetResourceType(resourceType) end
function ZO_KeepUpgrade_Shared:GetUpgradeLevel() end
function ZO_KeepUpgrade_Shared:GetUpgradeLevelProgress(level) end
function ZO_KeepUpgrade_Shared:GetNumLevelUpgrades(level) end
function ZO_KeepUpgrade_Shared:GetLevelUpgradeInfo(level, index) end
function ZO_KeepUpgrade_Shared:GetUpgradeTypeName() end
function ZO_KeepUpgrade_Shared:GetNumUpgradeTypes() end
function ZO_KeepUpgrade_Shared:IsInputEnemyControlled() end
function ZO_KeepUpgrade_Shared:SetRateTooltip() end
function ZO_ResourceUpgrade_Shared:New() end
function ZO_ResourceUpgrade_Shared:SetUpgradePath(path) end
function ZO_ResourceUpgrade_Shared:GetUpgradeLevel() end
function ZO_ResourceUpgrade_Shared:GetUpgradeLevelProgress(level) end
function ZO_ResourceUpgrade_Shared:GetNumLevelUpgrades(level) end
function ZO_ResourceUpgrade_Shared:GetLevelUpgradeInfo(level, index) end
function ZO_ResourceUpgrade_Shared:GetUpgradeTypeName() end
function ZO_ResourceUpgrade_Shared:GetNumUpgradeTypes() end
function ZO_ResourceUpgrade_Shared:IsInputEnemyControlled() end
function ZO_ResourceUpgrade_Shared:SetRateTooltip() end
function ZO_KeepResourceTypeFragment_Shared:New(resourceType, keepInfoObject) end
function ZO_KeepResourceTypeFragment_Shared:Show() end
function ZO_KeepResourceTypeFragment_Shared:Hide() end
function ZO_KeepUpgradePathFragment_Shared:New(upgradePath, keepInfoObject) end
function ZO_KeepUpgradePathFragment_Shared:Show() end
function ZO_KeepUpgradePathFragment_Shared:Hide() end
function ZO_WorldMapKeepInfo_Shared:New(...) end
function ZO_WorldMapKeepInfo_Shared:Initialize(control) end
function ZO_WorldMapKeepInfo_Shared:GetKeepUpgradeObject() end
function ZO_WorldMapKeepInfo_Shared:SetKeepResourceType(resourceType) end
function ZO_WorldMapKeepInfo_Shared:SetKeepUpgradePath(upgradePath) end
function ZO_WorldMapKeepInfo_Shared:ToggleKeep(keepId) end
function ZO_WorldMapKeepInfo_Shared:PreShowKeep() end
function ZO_WorldMapKeepInfo_Shared:PostShowKeep() end
function ZO_WorldMapKeepInfo_Shared:ShowKeep(keepId) end
function ZO_WorldMapKeepInfo_Shared:HideKeep() end
function ZO_WorldMapKeepInfo_Shared:CreateButtonData(normal, pressed, highlight) end
function ZO_WorldMapKeepInfo_Shared:BeginBar() end
function ZO_WorldMapKeepInfo_Shared:AddBar(text, fragments, buttonData) end
function ZO_WorldMapKeepInfo_Shared:FinishBar() end
function ZO_WorldMapKeepInfo_Shared:InitializeTabs() end
function ZO_WorldMapKeepInfo_Shared:AddKeepTabs() end
function ZO_WorldMapKeepInfo_Shared:AddResourceTabs() end
function ZO_WorldMapKeepInfo_Shared:SetFragment(name, fragment) end
function ZO_MapKeepSummary_Shared:New(...) end
function ZO_MapKeepSummary_Shared:Initialize(control) end
function ZO_MapKeepSummary_Shared:InitializeRows() end
function ZO_MapKeepSummary_Shared:RefreshAll() end
function ZO_MapKeepSummary_Shared:GetFragment() end
function ZO_MapKeepSummary_Shared:GetKeepUpgradeObject() end
function ZO_MapKeepSummary_Shared:RefreshData() end
function ZO_MapKeepSummary_Shared:RefreshAlliance() end
function ZO_MapKeepSummary_Shared:RefreshGuildOwner() end
function ZO_MapKeepSummary_Shared:GenerateRemainingTimeLabel(current, forNextLevel, resourceRate, level) end
function ZO_MapKeepSummary_Shared:RefreshTimeDependentControls() end
function ZO_MapKeepUpgrade_Shared:New(...) end
function ZO_MapKeepUpgrade_Shared:Initialize(control) end
function ZO_MapKeepUpgrade_Shared:GetFragment() end
function ZO_MapKeepUpgrade_Shared:RefreshAll() end
function ZO_MapKeepUpgrade_Shared:RefreshData() end
function ZO_MapKeepUpgrade_Shared:RefreshBarLabel() end
function ZO_MapKeepUpgrade_Shared:GenerateRemainingTimeLabel(current, forNextLevel, resourceRate, level) end
function ZO_MapKeepUpgrade_Shared:RefreshBar() end
function ZO_MapKeepUpgrade_Shared:RefreshLevels() end
function ZO_MapKeepUpgrade_Shared:RefreshLevelsEnabled() end
function ZO_MapKeepUpgrade_Shared:RefreshTimeDependentControls() end
function ZO_MapKeepUpgrade_Shared:Button_OnMouseEnter(button) end
function ZO_MapKeepUpgrade_Shared:Button_OnMouseExit(button) end
function ZO_MapKeepUpgrade_Shared:Time_OnMouseEnter(label) end
function ZO_MapKeepUpgrade_Shared:Time_OnMouseExit(label) end
function ZO_MapKeepUpgrade_Shared:Bar_OnMouseEnter(bar) end
function ZO_MapKeepUpgrade_Shared:Bar_OnMouseExit(bar) end
function ZO_WorldMapKey_Shared:New(...) end
function ZO_WorldMapKey_Shared:Initialize(control) end
function ZO_WorldMapKey_Shared:RefreshKey() end
function ZO_MapLocations_Shared:New(...) end
function ZO_MapLocations_Shared:Initialize(control) end
function ZO_MapLocations_Shared:InitializeList() end
function ZO_MapLocations_Shared:UpdateSelectedMap() end
function ZO_MapLocations_Shared:BuildLocationList() end
function ZO_MapLocations_Shared:GetDisabled() end
function ZO_MapLocationsData_Singleton:New(...) end
function ZO_MapLocationsData_Singleton:GetLocationList() end
function ZO_MapLocationsData_Singleton:RefreshLocationList() end
function ZO_MapLocationsData_Singleton_Initialize(control) end
function ZO_WorldMapQuests_Shared:New(...) end
function ZO_WorldMapQuests_Shared:Initialize(control) end
function ZO_WorldMapQuestsData_Singleton:New(...) end
function ZO_WorldMapQuestsData_Singleton:Initialize(control) end
function ZO_WorldMapQuestsData_Singleton:RefreshList() end
function ZO_WorldMapQuestsData_Singleton:LayoutList(forceLayout) end
function ZO_WorldMapQuestsData_Singleton:ClearPendingTasks() end
function ZO_WorldMapQuestsData_Singleton:AddTask(taskId, questIndex) end
function ZO_WorldMapQuestsData_Singleton:AddQuestToList(questIndex) end
function ZO_WorldMapQuestsData_Singleton:MarkTaskCompleted(taskId, shouldAddToList) end
function ZO_WorldMapQuestsData_Singleton:GetNumRemainingTasks() end
function ZO_WorldMapQuestsData_Singleton:BuildMasterList() end
function ZO_WorldMapQuestsData_Singleton:Sort() end
function ZO_WorldMapQuestsData_Singleton_Initialize(control) end
function ZO_WorldMapQuests_Shared_SetupQuestDetails(self, questIndex) end
--ingame\namechange
function ZO_NameChange:New() end
function ZO_NameChange:Initialize() end
function ZO_NameChange:DidNameChange() end
function ZO_NameChange:GetOldCharacterName() end
--ingame\notificationicons
function NotificationIcons_Console:New(...) end
function NotificationIcons_Console:Initialize(control) end
function NotificationIcons_Console:OnNumUnreadMailChanged(numUnread) end
function NotificationIcons_Console:OnNumNotificationsChanged(numNotifications) end
function NotificationIcons_Console:OnUpdate() end
function ZO_NotificationIcons_Gamepad_Initialize(control) end
--ingame\objectivecapturemeter
function ZO_ObjectiveCaptureMeter:New(...) end
function ZO_ObjectiveCaptureMeter:Initialize(control) end
function ZO_ObjectiveCaptureMeter:ServerUpdate(eventCode, keepId, objectiveId, battlegroundContext, capturePoolValue, capturePoolSize, capturingPlayers, contestingPlayers, owningAlliance) end
function ZO_ObjectiveCaptureMeter:VelocityArrowUpdate(captureBarFillPercentage, visibleArrows) end
function ZO_ObjectiveCaptureMeter:UpdateCaptureBar(progress) end
function ZO_ObjectiveCaptureMeter:EasingAnimationStopped() end
function ZO_ObjectiveCaptureMeter:Hide(eventCode) end
function ZO_ObjectiveCaptureMeter:SetHiddenForReason(reason, hidden) end
function ZO_ObjectiveCaptureMeter:HideShowArrows(numArrows) end
function ZO_ObjectiveCaptureMeter:GetVisibleArrows() end
function ZO_ObjectiveCaptureMeter:ApplyPlatformStyle(style) end
function ZO_ObjectiveCapture_Initialize(self) end
function ZO_ObjectiveCapture_UpdateCaptureBar(progress) end
function ZO_ObjectiveCapture_EasingAnimationStopped() end
--ingame\optionspanels
function ZO_OptionsPanel_Interface_ChatBubbleSpeedSliderValueFunc(value) end
function ZO_OptionsPanel_Interface_ChatBubbleChannel_OnInitialized(self) end
function ZO_OptionsPanel_Social_OnColorOptionEnter(colorControl) end
function ZO_OptionsPanel_Social_OnColorOptionExit(colorControl) end
function ZO_OptionsPanel_Social_ResetColorToDefault(control) end
function ZO_OptionsPanel_Social_InitializeGuildLabel(control) end
function ZO_OptionsPanel_Social_TextSizeOnShow(control) end
function ZO_OptionsPanel_Social_ResetTextSizeToDefault(control) end
function ZO_OptionsPanel_Social_MinAlphaOnShow(control) end
function ZO_OptionsPanel_Social_ResetMinAlphaToDefault(control) end
--ingame\performance
function PerformanceMeters:New(...) end
function PerformanceMeters:Initialize(control) end
function PerformanceMeters:OnUpdate() end
function PerformanceMeters:SetFramerate(framerate) end
function PerformanceMeters:SetLatency(latency) end
function PerformanceMeters:UpdateMovable() end
function PerformanceMeters:UpdateVisibility() end
function PerformanceMeters:ResetPosition() end
function PerformanceMeters:OnMoveStop() end
function PerformanceMeters:Meter_OnMouseEnter(control) end
function PerformanceMeters:Meter_OnMouseExit(control) end
function ZO_PerformanceMeters_OnMouseEnter(control) end
function ZO_PerformanceMeters_OnMouseExit(control) end
function ZO_PerformanceMeters_OnMoveStop(control) end
function ZO_PerformanceMeters_OnInitialized(control) end
--ingame\playerattributebars
function ZO_PlayerAttributeBar:New(control, barControls, powerType, unitOverride, secondPriorityUnitTag) end
function ZO_PlayerAttributeBar:GetEffectiveUnitTag() end
function ZO_PlayerAttributeBar:IsUnitTag(unitTag) end
function ZO_PlayerAttributeBar:RefreshColor() end
function ZO_PlayerAttributeBar:UpdateStatusBar(current, max, effectiveMax) end
function ZO_PlayerAttributeBar:ResetFadeOutDelay() end
function ZO_PlayerAttributeBar:ShouldContextuallyShow(excludeLinkCheck) end
function ZO_PlayerAttributeBar:LinkVisibility(otherAttributeBar) end
function ZO_PlayerAttributeBar:SetExternalVisibilityRequirement(externalVisibilityRequirement) end
function ZO_PlayerAttributeBar.IsTextEnabled() end
function ZO_PlayerAttributeBar.IsPlayerFrameFadingEnabled() end
function ZO_PlayerAttributeBar:UpdateContextualFading() end
function ZO_PlayerAttributeBar:AddForcedVisibleReference() end
function ZO_PlayerAttributeBar:RemoveForcedVisibleReference() end
function ZO_PlayerAttributeBar:SetForceVisible(forceVisible) end
function ZO_PlayerAttributeBar:SetTextEnabled(enabled) end
function ZO_PlayerAttributeBar:UpdateResourceNumbersLabel(current, maximum) end
function ZO_PlayerAttributeBar:OnPowerUpdate(unitTag, powerPoolIndex, powerType, current, max, effectiveMax) end
function ZO_PlayerAttributeBar:OnPlayerActivated() end
function ZO_PlayerAttributeBar:OnInterfaceSettingChanged(settingType, settingId) end
function ZO_PlayerAttributeBars:New(control) end
function ZO_PlayerAttributeBars:ApplyStyle() end
function ZO_PlayerAttributeBars:OnGamepadPreferredModeChanged() end
function ZO_PlayerAttributeBars:ForceShow(forceShow) end
function ZO_PlayerAttributeBars:ResizeToFitScreen() end
function ZO_PlayerAttributeBars:OnScreenResized() end
function ZO_PlayerAttribute_OnInitialized(self) end
--ingame\playeremote
function ZO_EmoteItem:New(...) end
function ZO_EmoteItem:Initialize(control) end
function ZO_EmoteItem:SetAnchor(column, row) end
function ZO_EmoteItem:SetVisible(visible) end
function ZO_EmoteItem:SetHighlightVisible(visible) end
function ZO_EmoteItem:Reset() end
function ZO_EmoteItem:SetEmoteInfo(emoteId) end
function ZO_EmoteItem:SetQuickChatInfo(quickChatId) end
function ZO_EmoteItem:SetName(name) end
function ZO_EmoteItem:GetName() end
function ZO_EmoteItem:GetId() end
function ZO_EmoteItem:GetItemType() end
function ZO_GamepadEmoteGrid:New(...) end
function ZO_GamepadEmoteGrid:Initialize(control, footerControl) end
function ZO_GamepadEmoteGrid:InitializeEmoteItemGrid() end
function ZO_GamepadEmoteGrid:ResetGridItem(column, row, visible) end
function ZO_GamepadEmoteGrid:ResetPageInfo() end
function ZO_GamepadEmoteGrid:ChangeEmoteListForEmoteType(emoteType) end
function ZO_GamepadEmoteGrid:ChangeEmoteListForQuickChat() end
function ZO_GamepadEmoteGrid:GetCurrentSelectedEmote() end
function ZO_GamepadEmoteGrid:GetSelectedEmoteName() end
function ZO_GamepadEmoteGrid:GetSelectedEmoteId() end
function ZO_GamepadEmoteGrid:GetSelectedEmoteType() end
function ZO_GamepadEmoteGrid:SetAllowHighlight(allow) end
function ZO_GamepadEmoteGrid:GetNumEmoteItems() end
function ZO_GamepadEmoteGrid:GetGridItems() end
function ZO_GamepadEmoteGrid:RefreshGridHighlight() end
function ZO_GamepadEmoteGrid:Activate() end
function ZO_GamepadEmoteGrid:Deactivate() end
function ZO_GamepadPlayerEmote:New(...) end
function ZO_GamepadPlayerEmote:Initialize(control) end
function ZO_GamepadPlayerEmote:OnDeferredInitialize() end
function ZO_GamepadPlayerEmote:OnSelectionChanged() end
function ZO_GamepadPlayerEmote:SetupList(list) end
function ZO_GamepadPlayerEmote:CreateCategoryList() end
function ZO_GamepadPlayerEmote:MarkDirty() end
function ZO_GamepadPlayerEmote:InitializeHeader() end
function ZO_GamepadPlayerEmote:InitializeEmoteGrid() end
function ZO_GamepadPlayerEmote:InitializeRadialMenu(control) end
function ZO_GamepadPlayerEmote:PerformUpdate() end
function ZO_GamepadPlayerEmote:RefreshHeader() end
function ZO_GamepadPlayerEmote:InitializeKeybindStripDescriptors() end
function ZO_GamepadPlayerEmote:DeselectCurrentMode() end
function ZO_GamepadPlayerEmote:SelectMode(mode) end
function ZO_GamepadPlayerEmote:ChangeCurrentMode(mode) end
function ZO_GamepadPlayerEmote:ShowQuickslotMenu() end
function ZO_GamepadPlayerEmote:HideQuickslotMenu() end
function ZO_GamepadPlayerEmote:GetEmoteIconForCategory(category) end
function ZO_GamepadPlayerEmote:GetPersonalityEmoteIconForCategory(category) end
function ZO_GamepadPlayerEmote:PopulateRadialMenu() end
function ZO_GamepadPlayerEmote:RefreshQuickslotMenu() end
function ZO_GamepadPlayerEmote:AssignSelectedQuickslot() end
function ZO_GamepadPlayerEmote:OnShowing() end
function ZO_GamepadPlayerEmote:OnHide() end
function ZO_GamepadPlayerEmote_OnInitialized(control) end
function PlayerEmote_Keyboard:New(...) end
function PlayerEmote_Keyboard:Initialize(control) end
function PlayerEmote_Keyboard:InitializeTree() end
function PlayerEmote_Keyboard:InitializeEmoteControlPool() end
function PlayerEmote_Keyboard:UpdateCategories() end
function PlayerEmote_Keyboard:MarkDirty() end
function PlayerEmote_Keyboard:UpdateEmotes(category) end
function ZO_PlayerEmote_Keyboard_Initialize(control) end
function ZO_PlayerEmoteManager:New(...) end
function ZO_PlayerEmoteManager:Initialize() end
function ZO_PlayerEmoteManager:CompareEmotes(emoteA, emoteB) end
function ZO_PlayerEmoteManager:CompareEmotesGamepad(emoteA, emoteB) end
function ZO_PlayerEmoteManager:CompareEmotesKeyboard(emoteA, emoteB) end
function ZO_PlayerEmoteManager:GetEmoteItemInfo(emoteId) end
function ZO_PlayerEmoteManager:InitializeEmoteList() end
function ZO_PlayerEmoteManager:RefreshPersonalityEmotes() end
function ZO_PlayerEmoteManager:GetEmoteListForType(emoteType, optFilterFunction) end
function ZO_PlayerEmoteManager:GetEmoteCategories() end
function ZO_PlayerEmoteManager:GetSlottedEmotes() end
function ZO_PlayerEmoteQuickslot:New(...) end
function ZO_PlayerEmoteQuickslot:Initialize(control, entryTemplate, animationTemplate, entryAnimationTemplate) end
function ZO_PlayerEmoteQuickslot:PrepareForInteraction() end
function ZO_PlayerEmoteQuickslot:SetupEntryControl(control, data) end
function ZO_PlayerEmoteQuickslot:PopulateMenu() end
function ZO_PlayerEmoteRadialMenuEntryTemplate_OnInitialized(self) end
function ZO_PlayerEmoteQuickslot_Initialize(control) end
--ingame\playerprogressbar
function ZO_GamepadPlayerProgressBarHideNameLocationFragment:New(...) end
function ZO_GamepadPlayerProgressBarHideNameLocationFragment:Show() end
function ZO_GamepadPlayerProgressBarHideNameLocationFragment:Hide() end
function ZO_GamepadPlayerProgressBarNameLocation:New(...) end
function ZO_GamepadPlayerProgressBarNameLocation:Initialize(control) end
function ZO_GamepadPlayerProgressBarNameLocation:Refresh() end
function ZO_GamepadPlayerProgressBarNameLocation_OnInitialized(control) end
function ZO_GamepadPlayerProgressBarNameLocationAnchor_Initialize(nameLocation, progressBar) end
function ZO_PlayerProgressBarFragment:New(...) end
function ZO_PlayerProgressBarFragment:Initialize() end
function ZO_PlayerProgressBarFragment:Show() end
function ZO_PlayerProgressBarFragment:Hide() end
function ZO_PlayerProgressBarCurrentFragment:New(...) end
function ZO_PlayerProgressBarCurrentFragment:RefreshBaseType() end
function ZO_PlayerProgressBarCurrentFragment:Show() end
function ZO_PlayerProgressBarCurrentFragment:Hide() end
function PlayerProgressBarType:New(barTypeClass, barTypeId, ...) end
function PlayerProgressBarType:Initialize(barTypeClass, barTypeId, ...) end
function PlayerProgressBarType:InitializeLastValues() end
function PlayerProgressBarType:GetEnlightenedPool() end
function PlayerProgressBarType:GetEnlightenedTooltip() end
function PlayerProgressBarType:Equals(barTypeClass, ...) end
function PlayerProgressBarType:GetBarGradient() end
function PlayerProgressBarType:SetBarGradient(barGradient) end
function PlayerProgressBarType:GetBarGlow() end
function PlayerProgressBarType:SetBarGlow(barGlow) end
function PlayerProgressBarType:GetIcon() end
function PlayerProgressBarType:GetLevelTypeText() end
function PlayerProgressBarType:SetLevelTypeText(text) end
function PlayerProgressBarType:SetTooltipCurrentMaxFormat(format) end
function PlayerProgressBarType:SetBarLevelColor(color) end
function PlayerProgressBarType:GetBarLevelColor() end
function XPBarType:New(barTypeId) end
function XPBarType:Initialize(barTypeClass, barTypeId, ...) end
function XPBarType:GetLevelSize(rank) end
function XPBarType:GetLevel() end
function XPBarType:GetCurrent() end
function CPBarType:New(barTypeId) end
function CPBarType:Initialize(barTypeClass, barTypeId, ...) end
function CPBarType:GetShownAttribute(overrideLevel) end
function CPBarType:GetBarGradient(specificLevel) end
function CPBarType:GetBarGlow(specificLevel) end
function CPBarType:GetIcon(overrideLevel) end
function CPBarType:GetEnlightenedPool() end
function CPBarType:GetLevel() end
function CPBarType:GetLevelTypeText() end
function CPBarType:GetEnlightenedTooltip() end
function CPBarType:GetLevelSize(rank) end
function CPBarType:GetCurrent() end
function SkillBarType:New(barTypeId, ...) end
function SkillBarType:Initialize(barTypeClass, barTypeId, skillType, skillIndex, ...) end
function SkillBarType:GetLevelSize(rank) end
function SkillBarType:GetLevel() end
function SkillBarType:GetCurrent() end
function PlayerProgressBar:New(...) end
function PlayerProgressBar:Initialize(control) end
function PlayerProgressBar:InstantiateBarType(barTypeClass, ...) end
function PlayerProgressBar:InitializeBarTypeClasses() end
function PlayerProgressBar:GetBarType(barTypeClass, ...) end
function PlayerProgressBar:InitializeBarTypes() end
function PlayerProgressBar:InitializeLastValues() end
function PlayerProgressBar:GetLevelSize(level) end
function PlayerProgressBar:GetBarTypeInfo() end
function PlayerProgressBar:GetCurrentInfo() end
function PlayerProgressBar:GetMostRecentlyShownInfo() end
function PlayerProgressBar:SetFadeAlpha(alpha) end
function PlayerProgressBar:SetSuppressAlpha(alpha) end
function PlayerProgressBar:RefreshAlpha() end
function PlayerProgressBar:SetBarState(state) end
function PlayerProgressBar:SetBarMode(mode) end
function PlayerProgressBar:GetOwner() end
function PlayerProgressBar:SetBaseType(newBaseType) end
function PlayerProgressBar:ClearBaseType() end
function PlayerProgressBar:Show() end
function PlayerProgressBar:UpdateBar(overrideLevel) end
function PlayerProgressBar:Hide() end
function PlayerProgressBar:ShowIncrease(barType, startLevel, start, stop, increaseSound, waitBeforeShowMS, owner) end
function PlayerProgressBar:ShowCurrent(barType) end
function PlayerProgressBar:RefreshCurrentTypeLater(barType) end
function PlayerProgressBar:RefreshCurrentType(barType) end
function PlayerProgressBar:RefreshCurrentBar() end
function PlayerProgressBar:OnUpdate(timeSecs) end
function PlayerProgressBar:RefreshEnlightened(timeSecs) end
function PlayerProgressBar:ForceRefreshEnlightened() end
function PlayerProgressBar:RefreshTemplate() end
function PlayerProgressBar:WaitBeforeShow(waitBeforeShowMS) end
function PlayerProgressBar:OnWaitBeforeShowComplete() end
function PlayerProgressBar:WaitBeforeFill() end
function PlayerProgressBar:OnWaitBeforeFillComplete() end
function PlayerProgressBar:AnimateFillIncrease() end
function PlayerProgressBar:OnFillComplete() end
function PlayerProgressBar:WaitBeforeStopGlowing() end
function PlayerProgressBar:SetLevelLabelText(text) end
function PlayerProgressBar:OnWaitBeforeStopGlowingComplete() end
function PlayerProgressBar:WaitBeforeHide() end
function PlayerProgressBar:OnWaitBeforeHideComplete() end
function PlayerProgressBar:SetHoldBeforeFadeOut(holdBeforeFadeOut) end
function PlayerProgressBar:RefreshDoneShowing() end
function PlayerProgressBar:IsDoneShowing() end
function PlayerProgressBar:OnComplete() end
function PlayerProgressBar:OnDoneShowing() end
function PlayerProgressBar:ClearIncreaseData() end
function PlayerProgressBar:OnBarLevelChange(level) end
function PlayerProgressBar:OnFadeInComplete() end
function PlayerProgressBar:OnFadeOutComplete() end
function PlayerProgressBar:Bar_OnMouseEnter(bar) end
function PlayerProgressBar:Bar_OnMouseExit(self) end
function ZO_PlayerProgressBar_OnMouseEnter(self) end
function ZO_PlayerProgressBar_OnMouseExit(self) end
function ZO_PlayerProgress_OnInitialized(self) end
--ingame\playertoplayer
function ZO_PlayerToPlayer:New(...) end
function ZO_PlayerToPlayer:CreateGamepadRadialMenu() end
function ZO_PlayerToPlayer:CreateKeyboardRadialMenu() end
function ZO_PlayerToPlayer:GetRadialMenu() end
function ZO_PlayerToPlayer:InitializeKeybinds() end
function ZO_PlayerToPlayer:InitializeSoulGemResurrectionEvents() end
function ZO_PlayerToPlayer:InitializeIncomingEvents() end
function ZO_PlayerToPlayer:SetHidden(hidden) end
function ZO_PlayerToPlayer:IsHidden() end
function ZO_PlayerToPlayer:ShowRadialNotificationMenu(data) end
function ZO_PlayerToPlayer:AddIncomingEntry(incomingType, inviterName, targetLabel, displayName, characterName) end
function ZO_PlayerToPlayer:AddPromptToIncomingQueue(interactType, characterName, displayName, targetLabel, acceptCallback, declineCallback, deferDecisionCallback) end
function ZO_PlayerToPlayer:AddDialogToIncomingQueue(incomingType, characterName, displayName, targetLabel, dialogName, mainTextParams) end
function ZO_PlayerToPlayer:RemoveGuildInviteFromIncomingQueue(guildId) end
function ZO_PlayerToPlayer:RemoveQuestShareFromIncomingQueue(questId) end
function ZO_PlayerToPlayer:RemoveScriptedWorldEventFromIncomingQueue(eventId, questName) end
function ZO_PlayerToPlayer:OnStartSoulGemResurrection(duration) end
function ZO_PlayerToPlayer:OnEndSoulGemResurrection() end
function ZO_PlayerToPlayer:SetDelayPromptTime(timeMs) end
function ZO_PlayerToPlayer:TryDisplayingIncomingRequests() end
function ZO_PlayerToPlayer:HasTarget() end
function ZO_PlayerToPlayer:StartInteraction() end
function ZO_PlayerToPlayer:StopInteraction() end
function ZO_PlayerToPlayer:Accept() end
function ZO_PlayerToPlayer:Decline() end
function ZO_PlayerToPlayer:OnPromptAccepted() end
function ZO_PlayerToPlayer:OnPromptDeclined() end
function ZO_PlayerToPlayer:SetTargetIdentification() end
function ZO_PlayerToPlayer:TryShowingResurrectLabel() end
function ZO_PlayerToPlayer:TryShowingStandardInteractLabel() end
function ZO_PlayerToPlayer:TryShowingPromptAfterDelay() end
function ZO_PlayerToPlayer:ShowResponseActionKeybind(keybindText) end
function ZO_PlayerToPlayer:SetupTargetLabel(incomingEntry) end
function ZO_PlayerToPlayer:GetKeyboardStringFromInteractionType(interactionType) end
function ZO_PlayerToPlayer:GetGamepadStringFromInteractionType(interactionType) end
function ZO_PlayerToPlayer:TryShowingResponseLabel() end
function ZO_PlayerToPlayer:IsReticleTargetInteractable() end
function ZO_PlayerToPlayer:OnUpdate() end
function ZO_PlayerToPlayer:AddShowGamerCard(targetDisplayName, targetCharacterName) end
function ZO_PlayerToPlayer:AddMenuEntry(text, icons, enabled, selectedFunction, errorReason) end
function ZO_PlayerToPlayer_Initialize(control) end
--ingame\questtoolmonitor
function ZO_ActiveQuestToolMonitor:New(...) end
function ZO_ActiveQuestToolMonitor:Initialize(control) end
function ZO_ActiveQuestToolMonitor:OnActiveQuestToolChanged(eventCode, journalIndex, toolIndex) end
function ZO_ActiveQuestToolMonitor:OnActiveQuestToolRemoved(eventCode) end
function ZO_ActiveQuestToolMonitor_Initialize(control) end
--ingame\quickchat
function QuickChatManager:New() end
function QuickChatManager:Initialize() end
function QuickChatManager:GetNumQuickChats() end
function QuickChatManager:GetQuickChatIcon() end
function QuickChatManager:IsDefaultQuickChat(id) end
function QuickChatManager:GetQuickChatId(index) end
function QuickChatManager:HasQuickChat(id) end
function QuickChatManager:GetQuickChatName(id) end
function QuickChatManager:GetFormattedQuickChatName(id) end
function QuickChatManager:GetQuickChatMessage(id) end
function QuickChatManager:PlayQuickChat(id) end
function QuickChatManager:BuildQuickChatList() end
--ingame\quickslot
function ZO_GamepadQuickslot:New(control) end
function ZO_GamepadQuickslot:Initialize(control) end
function ZO_GamepadQuickslot:ResetActiveIcon() end
function ZO_GamepadQuickslot:OnSelectionChanged(selectedEntry) end
function ZO_GamepadQuickslot:PerformDeferredInitialization() end
function ZO_GamepadQuickslot:InitializeKeybindStrip() end
function ZO_GamepadQuickslot:InitializeHeader() end
function ZO_GamepadQuickslot:RefreshHeader() end
function ZO_GamepadQuickslot:RefreshQuickslotMenu() end
function ZO_GamepadQuickslot:ShowQuickslotMenu() end
function ZO_GamepadQuickslot:PopulateMenu() end
function ZO_GamepadQuickslot:SetItemToQuickslot(bagId, slotIndex) end
function ZO_GamepadQuickslot:SetCollectibleToQuickslot(collectibleId) end
function ZO_GamepadQuickslot:TryAssignItemToSlot() end
function ZO_GamepadQuickslot:HideScene() end
function ZO_GamepadQuickslot_HideScene() end
function ZO_GamepadQuickslot_Initialize(control) end
function ZO_GamepadQuickslotCooldownSetup(control, slotNum) end
function ZO_QuickslotRadialManager_Gamepad:SetupEntryControl(entryControl, slotNum) end
function ZO_QuickslotRadial_Gamepad_Initialize(control) end
function ZO_QuickslotRadial_Keyboard_Initialize(control) end
function ZO_QuickslotManager:New(container) end
function ZO_QuickslotManager:AreQuickSlotsShowing() end
function ZO_QuickslotManager:InitializeKeybindDescriptor() end
function ZO_QuickslotManager:PerformQuickSlotLayout() end
function ZO_QuickslotManager:SetupQuickslotCount(quickslot, count) end
function ZO_QuickslotManager:CreateQuickSlots() end
function ZO_QuickslotManager:DoQuickSlotUpdate(physicalSlot, animationOption) end
function ZO_QuickslotManager:HideAllQuickSlotDropCallouts() end
function ZO_QuickslotManager:ShowSlotDropCallout(calloutControl, meetsUsageRequirement) end
function ZO_QuickslotManager:ShowAppropriateQuickSlotDropCallouts(bagId, slotIndex) end
function ZO_QuickslotManager:ChangeFilter(filterData) end
function ZO_QuickslotManager:ShouldAddItemToList(itemData) end
function ZO_QuickslotManager:SortData() end
function ZO_QuickslotManager:ApplySort() end
function ZO_QuickslotManager:RefreshCurrency(value) end
function ZO_QuickslotManager:ValidateOrClearAllQuickslots() end
function ZO_QuickslotManager:UpdateList() end
function ZO_QuickslotManager:AppendItemData(scrollData) end
function ZO_QuickslotManager:AppendCollectiblesData(scrollData) end
function ZO_QuickslotManager:SetUpQuickSlot(control, data) end
function ZO_QuickslotManager:SetUpCollectionSlot(control, data) end
function ZO_QuickslotManager:UpdateFreeSlots() end
function ZO_QuickSlot_FilterButtonOnMouseEnter(self) end
function ZO_QuickSlot_FilterButtonOnMouseExit(self) end
function ZO_Quickslot_OnInitialize(control) end
function ZO_QuickslotControl_OnMouseEnter(control) end
function ZO_QuickslotControl_OnMouseExit(control) end
function ZO_QuickslotControl_OnInitialize(control) end
function ZO_QuickslotRadialManager:New(...) end
function ZO_QuickslotRadialManager:PrepareForInteraction() end
function ZO_QuickslotRadialManager:InteractionCanceled() end
function ZO_QuickslotRadialManager:SetupEntryControl(entryControl, slotNum) end
function ZO_QuickslotRadialManager:PopulateMenu() end
function ZO_QuickslotRadialManager:ValidateOrClearQuickslot(slot) end
function QuickslotSlotRadialManager:New() end
function QuickslotSlotRadialManager:StartInteraction() end
function QuickslotSlotRadialManager:StopInteraction() end
--ingame\ram
function ZO_Ram:New(control) end
function ZO_Ram:Initialize(control) end
function ZO_Ram:UpdateRam(numEscorts) end
function ZO_Ram:UpdateNumEscorts(numEscorts) end
function ZO_Ram:UpdateVisibility() end
function ZO_Ram_Initialize(control) end
--ingame\repair
function ZO_RepairKits_Gamepad:New(...) end
function ZO_RepairKits_Gamepad:Initialize(control) end
function ZO_RepairKits_Gamepad:SetupScene() end
function ZO_RepairKits_Gamepad:UpdateTooltipOnSelectionChanged() end
function ZO_RepairKits_Gamepad:PerformItemImprovement() end
function ZO_Gamepad_RepairKits_OnInitialize(control) end
function ZO_RepairKits:New(...) end
function ZO_RepairKits:Initialize(control) end
function ZO_RepairKits:SetupPreviewControls() end
function ZO_RepairKits:SetItemInfo(bag, index) end
function ZO_RepairKits:OnRepairKitSelected(itemBagId, itemSlotIndex, repairKitBagId, repairKitSlotIndex, playSound) end
function ZO_RepairKits:SetupDialog(bag, index) end
function ZO_RepairKits:BeginItemImprovement(bag, index) end
function ZO_RepairKits_OnInitialize(control) end
function ZO_Repair:New(...) end
function ZO_Repair:Initialize(control) end
function ZO_Repair:InitializeList() end
function ZO_Repair:InitializeFilterBar() end
function ZO_Repair:InitializeSortHeader() end
function ZO_Repair:InitializeEvents() end
function ZO_Repair:RefreshAll() end
function ZO_Repair:UpdateMoney() end
function ZO_Repair:UpdateFreeSlots() end
function ZO_Repair:SetupRepairItem(control, data) end
function ZO_Repair:OnShown() end
function ZO_Repair_OnInitialize(control) end
--ingame\resourcewarner
function ZO_ResourceWarner:New(...) end
function ZO_ResourceWarner:Initialize(parent, powerType) end
function ZO_ResourceWarner:SetPaused(paused) end
function ZO_ResourceWarner:OnCombatEvent(result, isError, abilityName, abilityGraphic, abilityActionSlotType, sourceName, sourceType, targetName, targetType, hitValue, powerType, damageType, log) end
function ZO_ResourceWarner:OnPowerUpdate(powerType, currentPower, maxPower) end
function ZO_HealthWarner:New(...) end
function ZO_HealthWarner:Initialize(parent) end
function ZO_HealthWarner:SetPaused(paused) end
function ZO_HealthWarner:UpdateAlphaPulse(healthPerc) end
function ZO_HealthWarner:OnHealthUpdate(health, maxHealth) end
--ingame\reticle
function ZO_Reticle:New(...) end
function ZO_Reticle:SetupReticle() end
function ZO_Reticle:OnStealthStateChanged(newState) end
function ZO_Reticle:OnDisguiseStateChanged(newState) end
function ZO_Reticle:OnReticleTargetChanged() end
function ZO_Reticle:ClearStealingItemTimestamp() end
function ZO_Reticle:TryHandlingStealingTutorial(currentFrameTimeSeconds) end
function ZO_Reticle:TryHandlingQuestInteraction(questInteraction, questTargetBased, questJournalIndex, questToolIndex, questToolOnCooldown) end
function ZO_Reticle:TryHandlingInteraction(interactionPossible, currentFrameTimeSeconds) end
function ZO_Reticle:TryHandlingGroundTargetingError() end
function ZO_Reticle:TryHandlingNonInteractableFixture() end
function ZO_Reticle:UpdateInteractText(currentFrameTimeSeconds) end
function ZO_Reticle:OnUpdate(currentFrameTimeSeconds) end
function ZO_Reticle:RequestHidden(hidden) end
function ZO_Reticle:GetInteractPromptVisible() end
function ZO_Reticle:UpdateHiddenState() end
function ZO_Reticle:OnImpactfulHit() end
function ZO_Reticle:AnimatePickpocketBonus(progress) end
function ZO_Reticle_AnimatePickpocketBonus(progress) end
function ZO_Reticle_Initialize(control) end
function ZO_StealthIcon:New(...) end
function ZO_StealthIcon:AnimateInStealthText(stringId) end
function ZO_StealthIcon:HideStealthText() end
function ZO_StealthIcon:SnapEyeAnimationToPoint(animPoint) end
function ZO_StealthIcon:UpdateStealthEye(stealthState) end
function ZO_StealthIcon:RefreshStealthReticle() end
function ZO_StealthIcon:OnStealthStateChanged(stealthState) end
function ZO_StealthIcon:OnDisguiseStateChanged(disguiseState) end
--ingame\scenes
function ZO_Gamepad_GuildNameFooterFragment:New(...) end
function ZO_Gamepad_GuildNameFooterFragment:Initialize(...) end
function ZO_Gamepad_GuildNameFooterFragment:SetGuildName(guildName) end
function ZO_Gamepad_GuildNameFooterFragment:Show() end
function ZO_HUDFragment:New() end
function ZO_HUDFragment:UpdateVisibility() end
function ZO_HUDFragment:Show() end
function ZO_HUDFragment:Hide() end
function ZO_ReticleModeFragment:New() end
function ZO_ReticleModeFragment:Show() end
function ZO_ReticleModeFragment:Hide() end
function ZO_HUDScene:New() end
function ZO_HUDUIScene:New() end
function ZO_FullscreenEffectFragment:New(effectType, ...) end
function ZO_FullscreenEffectFragment:Show() end
function ZO_FullscreenEffectFragment:Hide() end
function ZO_FramePlayerFragment:New() end
function ZO_FramePlayerFragment:Show() end
function ZO_FramePlayerFragment:Hide() end
function ZO_NormalizedPointFragment:New(normalizedPointCallback, executeCallback) end
function ZO_NormalizedPointFragment:Show() end
function ZO_NormalizedPointFragment:Hide() end
function ZO_CharacterFramingBlur:New(normalizedPointCallback) end
function ZO_CharacterFramingBlur:Hide() end
function ZO_FrameEmoteFragment:New(framingType) end
function ZO_FrameEmoteFragment:Show() end
function ZO_FrameEmoteFragment:Hide() end
function ZO_SkillsActionBarFragment:New() end
function ZO_SkillsActionBarFragment:Show() end
function ZO_SkillsActionBarFragment:Hide() end
function ZO_SkillsActionBarFragment:OnStateChange(oldState, newState) end
function ZO_SetTitleFragment:New(titleStringId) end
function ZO_SetTitleFragment:Show() end
function ZO_SetTitleFragment:Hide() end
function ZO_WindowSoundFragment:New(showSoundId, hideSoundId) end
function ZO_WindowSoundFragment:Show() end
function ZO_WindowSoundFragment:Hide() end
function ZO_TutorialTriggerFragment:New(onShowTutorialTriggerType) end
function ZO_TutorialTriggerFragment:Show() end
function ZO_TutorialTriggerFragment:Hide() end
function ZO_ClearCursorFragment:New() end
function ZO_ClearCursorFragment:Show() end
function ZO_ClearCursorFragment:Hide() end
function ZO_UICombatOverlayFragment:New() end
function ZO_UICombatOverlayFragment:Show() end
function ZO_UICombatOverlayFragment:Hide() end
function ZO_CharacterWindowFragment:New(control, readOnly) end
function ZO_CharacterWindowFragment:OnStateChange(oldState, newState) end
function ZO_EndInWorldInteractionsFragment:New(actionLayerName) end
function ZO_EndInWorldInteractionsFragment:Show() end
function ZO_EndInWorldInteractionsFragment:Hide() end
function ZO_MinimizeChatFragment:New(actionLayerName) end
function ZO_MinimizeChatFragment:Show() end
function ZO_MinimizeChatFragment:Hide() end
function ZO_StopMovementFragment:New() end
function ZO_StopMovementFragment:Show() end
function ZO_StopMovementFragment:Hide() end
function ZO_HideMouseFragment:New() end
function ZO_HideMouseFragment:Show() end
function ZO_HideMouseFragment:Hide() end
function ZO_KeybindStripFragment:New(...) end
function ZO_KeybindStripFragment:Show() end
function ZO_KeybindStripFragment:Hide() end
function ZO_ChampionKeybindStripFragment:New(...) end
function ZO_ChampionKeybindStripFragment:Show() end
function ZO_ChampionKeybindStripFragment:Hide() end
function ZO_GamepadKeybindStripFragment:New(...) end
function ZO_GamepadKeybindStripFragment:Show() end
function ZO_GamepadKeybindStripFragment:Hide() end
function ZO_ItemPreviewFragment:New() end
function ZO_ItemPreviewFragment:Show() end
function ZO_ItemPreviewFragment:Hide() end
function ZO_MarketKeybindStripBackgroundFragment:New(...) end
function ZO_MarketKeybindStripBackgroundFragment:Show() end
function ZO_MarketKeybindStripBackgroundFragment:Hide() end
function ShowMarketFragment:New(...) end
function ShowMarketFragment:Show() end
function ShowMarketFragment:Hide() end
function ZO_CraftingWindowKeybindInterceptLayerFragment:New(actionLayerName) end
function ZO_IngameSceneManager:New() end
function ZO_IngameSceneManager:IsInUIMode() end
function ZO_IngameSceneManager:IsLockedInUIMode() end
function ZO_IngameSceneManager:SetInUIMode(inUI) end
function ZO_IngameSceneManager:UpdateDirectionalInput() end
function ZO_IngameSceneManager:ConsiderExitingUIMode(showingHUDUI) end
function ZO_IngameSceneManager:OnGameFocusChanged() end
function ZO_IngameSceneManager:OnChatInputStart() end
function ZO_IngameSceneManager:OnChatInputEnd() end
function ZO_IngameSceneManager:OnTutorialStart(tutorialIndex) end
function ZO_IngameSceneManager:ClearActionRequiredTutorialBlockers() end
function ZO_IngameSceneManager:OnGamepadPreferredModeChanged() end
function ZO_IngameSceneManager:SafelyAttemptToExitUIMode() end
function ZO_IngameSceneManager:OnGlobalMouseUp() end
function ZO_IngameSceneManager:OnEnterGroundTargetMode() end
function ZO_IngameSceneManager:OnLoadingScreenDropped() end
function ZO_IngameSceneManager:OnLoadingScreenShown() end
function ZO_IngameSceneManager:OnGameCameraActivated() end
function ZO_IngameSceneManager:OnPreSceneStateChange(scene, currentState, nextState) end
function ZO_IngameSceneManager:OnNextSceneRemovedFromQueue(oldNextScene, newNextScene) end
function ZO_IngameSceneManager:OnSceneStateChange(scene, oldState, newState) end
function ZO_IngameSceneManager:OnNewMovementInUIMode() end
function ZO_IngameSceneManager:SetHUDScene(hudSceneName) end
function ZO_IngameSceneManager:RestoreHUDScene() end
function ZO_IngameSceneManager:SetHUDUIScene(hudUISceneName, hidesAutomatically) end
function ZO_IngameSceneManager:RestoreHUDUIScene() end
function ZO_IngameSceneManager:RegisterTopLevel(topLevel, locksUIMode) end
function ZO_IngameSceneManager:HideTopLevel(topLevel) end
function ZO_IngameSceneManager:ShowTopLevel(topLevel) end
function ZO_IngameSceneManager:ToggleTopLevel(topLevel) end
function ZO_IngameSceneManager:OnToggleUIModeBinding() end
function ZO_IngameSceneManager:HideTopLevels() end
function ZO_IngameSceneManager:OnToggleGameMenuBinding() end
function ZO_IngameSceneManager:OnToggleHUDUIBinding() end
function ZO_SceneManager_ToggleUIModeBinding() end
function ZO_SceneManager_ToggleGameMenuBinding() end
function ZO_SceneManager_ToggleHUDUIBinding() end
function ZO_InteractScene:New(...) end
function ZO_InteractScene:Initialize(name, sceneManager, interactionInfo) end
function ZO_InteractScene:GetInteractionInfo() end
function ZO_InteractScene:OnRemovedFromQueue() end
function ZO_InteractScene:SetState(newState) end
--ingame\scriptedworldevents
function ZO_ScriptedWorldEvents_Initialize() end
--ingame\sharedinformationarea
function SharedInformationArea:New(...) end
function SharedInformationArea:Initialize() end
function SharedInformationArea:AddLoot(lootWindow) end
function SharedInformationArea:AddTutorial(tutorial) end
function SharedInformationArea:AddSynergy(synergy) end
function SharedInformationArea:AddRam(ram) end
function SharedInformationArea:AddFlagCapture(flagCapture) end
function SharedInformationArea:AddPlayerToPlayer(playerToPlayer) end
function SharedInformationArea:AddActiveCombatTips(acts) end
function SharedInformationArea:AddInstanceKick(instanceKick) end
function SharedInformationArea:SetHidden(object, hidden) end
function SharedInformationArea:IsHidden(object) end
function SharedInformationArea:SetSupressed(supressed) end
function SharedInformationArea:IsSuppressed() end
--ingame\siegebar
function ZO_SiegeHUDFragment:New() end
function ZO_SiegeHUDFragment:Show() end
function ZO_SiegeHUDFragment:Hide() end
function SiegeBar:New() end
function SiegeBar:CleanDirty() end
function SiegeBar:SetupSceneFragments() end
function SiegeBar:OnBeginSiegeControl() end
function SiegeBar:OnEndSiegeControl() end
function SiegeBar:OnControlledSiegeSocketsChanged() end
function SiegeBar:OnBeginSiegeUpgrade() end
function SiegeBar:OnEnableSiegePackup() end
function SiegeBar:OnDisableSiegePackup() end
function SiegeBar:OnEnableSiegeFire() end
function SiegeBar:OnDisableSiegeFire() end
function ZO_SiegeBar_Initialize() end
--ingame\skills
function ZO_GamepadActionBar:New(...) end
function ZO_GamepadActionBar:Initialize(control) end
function ZO_GamepadActionBar:OnSkillsChanged() end
function ZO_GamepadActionBar:MarkButtonSlotDirty(slotNum) end
function ZO_GamepadActionBar:Activate() end
function ZO_GamepadActionBar:Deactivate() end
function ZO_GamepadActionBar:GetControl() end
function ZO_GamepadActionBar:RefreshAllButtons() end
function ZO_GamepadActionBar:RefreshDirtyButtons() end
function ZO_GamepadActionBar:SetHighlightAll(highlightAll) end
function ZO_GamepadActionBarButton:New(...) end
function ZO_GamepadActionBarButton:Initialize(control, slotId) end
function ZO_GamepadActionBarButton:GetSlotId() end
function ZO_GamepadActionBarButton:IsUltimateSlot() end
function ZO_GamepadActionBarButton:GetControl() end
function ZO_GamepadActionBarButton:GetIconControl() end
function ZO_GamepadActionBarButton:SetSelected(selected, interpolator) end
function ZO_GamepadActionBarButton:Refresh() end
function ZO_GamepadActionBarButton:ClearSlot() end
function ZO_GamepadActionBarButton:SetAbility(skillType, skillLineIndex, abilityIndex) end
function ZO_AssignableActionBar:New(...) end
function ZO_AssignableActionBar:Initialize(control) end
function ZO_AssignableActionBar:UpdateActionButtonSlotAnimation() end
function ZO_AssignableActionBar:OnSkillsChanged() end
function ZO_AssignableActionBar:RefreshDirtyButtons() end
function ZO_AssignableActionBar:Activate() end
function ZO_AssignableActionBar:Deactivate() end
function ZO_AssignableActionBar:SetOnSelectedDataChangedCallback(onSelectedDataChangedCallback) end
function ZO_AssignableActionBar:SetOnAbilityFinalizedCallback(onAbilityFinalizedCallback) end
function ZO_AssignableActionBar:IsUltimateSelected() end
function ZO_AssignableActionBar:UpdateDirectionalInput() end
function ZO_AssignableActionBar:SetSelectedButton(buttonIndex) end
function ZO_AssignableActionBar:SetSelectedButtonBySlotId(slotId) end
function ZO_AssignableActionBar:SetLockMode(lockMode) end
function ZO_AssignableActionBar:SetAbility(skillType, skillLineIndex, abilityIndex) end
function ZO_AssignableActionBar:ClearAbility() end
function ZO_AssignableActionBar:GetSelectedSlotId() end
function ZO_GamepadSkills:New(...) end
function ZO_GamepadSkills:Initialize(control) end
function ZO_GamepadSkills:PerformUpdate() end
function ZO_GamepadSkills:PerformDeferredInitialization() end
function ZO_GamepadSkills:InitializeHeader() end
function ZO_GamepadSkills:RefreshHeader(headerTitle) end
function ZO_GamepadSkills:InitializeKeybindStrip() end
function ZO_GamepadSkills:AddWeaponSwapDescriptor(descriptor) end
function ZO_GamepadSkills:InitializeAssignableActionBar() end
function ZO_GamepadSkills:SelectableActionBarSetup(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadSkills:InitializeCategoryList() end
function ZO_GamepadSkills:InitializeLineFilterList() end
function ZO_GamepadSkills:InitializeBuildPlanner() end
function ZO_GamepadSkills:OnUpdate(currentFrameTimeSeconds) end
function ZO_GamepadSkills:MarkForRefreshVisible() end
function ZO_GamepadSkills:InitializeEvents() end
function ZO_GamepadSkills:TryClearNewStatus() end
function ZO_GamepadSkills:TrySetClearNewFlag(callId) end
function ZO_GamepadSkills:RefreshCategoryList() end
function ZO_GamepadSkills:RefreshLineFilterList(refreshPreviewList) end
function ZO_GamepadSkills:RefreshBuildPlannerList() end
function ZO_GamepadSkills:RefreshPointsDisplay() end
function ZO_GamepadSkills:OnSelectedAbilityChanged(selectedData) end
function ZO_GamepadSkills:SetupTooltipStatusLabel(tooltip, slotId) end
function ZO_GamepadSkills:RefreshSelectedTooltip() end
function ZO_GamepadSkills:SetMode(mode) end
function ZO_GamepadSkills:AssignSelectedBuildPlannerAbility() end
function ZO_GamepadSkills:StartSingleAbilityAssignment(skillType, skillLineIndex, abilityIndex) end
function ZO_GamepadSkills:Back() end
function ZO_GamepadSkills_OnInitialize(control) end
function ZO_GamepadSkillLineXpBar_Setup(skillType, skillLineIndex, xpBar, nameControl, forceInit) end
function ZO_GamepadSkillLineEntryTemplate_Setup(control, skillType, skillLineIndex, selected, activated) end
function ZO_GamepadSkillLineEntryTemplate_OnLevelChanged(xpBar, rank) end
function ZO_GamepadAbilityEntryTemplate_Setup(control, abilityData, selected, activated) end
function ZO_SkillsManager:New(container) end
function ZO_SkillsManager:SetupAbilityEntry(ability, data) end
function ZO_SkillsManager:SetupHeaderEntry(header, data) end
function ZO_SkillsManager:UpdateSkyShards() end
function ZO_SkillsManager:RefreshSkillInfo() end
function ZO_SkillsManager:RefreshList() end
function ZO_SkillsManager:GetSelectedSkillType() end
function ZO_SkillsManager:GetSelectedSkillLineIndex() end
function ZO_SkillsManager:Refresh() end
function ZO_SkillsManager:OnShown() end
function ZO_SkillsManager:ChooseMorph(morphSlot) end
function ZO_Skills_AbilitySlot_OnMouseEnter(control) end
function ZO_Skills_AbilitySlot_OnMouseExit() end
function ZO_Skills_UpgradeAbilitySlot_OnMouseEnter(control) end
function ZO_Skills_UpgradeAbilitySlot_OnMouseExit() end
function ZO_Skills_AbilitySlot_OnDragStart(control) end
function ZO_Skills_AbilitySlot_OnDoubleClick(control) end
function ZO_Skills_AbilitySlot_OnClick(control) end
function ZO_Skills_AbilityAlert_OnClicked(control) end
function ZO_Skills_MorphAbilitySlot_OnMouseEnter(control) end
function ZO_Skills_MorphAbilitySlot_OnClicked(control) end
function ZO_SkillInfoXPBar_OnMouseEnter(control) end
function ZO_SkillInfoXPBar_OnMouseExit(control) end
function ZO_Skills_OnShown(self) end
function ZO_Skills_Initialize(control) end
function ZO_NewSkillCalloutManager:New(...) end
function ZO_NewSkillCalloutManager:Initialize() end
function ZO_NewSkillCalloutManager:InitializeSkillList() end
function ZO_NewSkillCalloutManager:UpdateAbility(skillType, skillLineIndex, abilityIndex) end
function ZO_NewSkillCalloutManager:UpdateSkillLine(skillType, skillLineIndex) end
function ZO_NewSkillCalloutManager:AddSkillLineToList(skillType, skillLineIndex) end
function ZO_NewSkillCalloutManager:AreAnySkillsNew() end
function ZO_NewSkillCalloutManager:IsSkillLineNew(skillType, skillLineIndex) end
function ZO_NewSkillCalloutManager:IsAbilityNew(skillType, skillLineIndex, abilityIndex) end
function ZO_NewSkillCalloutManager:ClearNewStatusOnAbilities(skillType, skillLineIndex, abilityIndex) end
function ZO_Skills_GetIconsForSkillType(skillType) end
function ZO_SkillInfoXPBar_OnLevelChanged(xpBar, level) end
function ZO_SkillInfoXPBar_SetValue(xpBar, level, lastRankXP, nextRankXP, currentXP, forceInit) end
function ZO_Skills_SetAlertButtonTextures(control, styleTable) end
function ZO_Skills_GenerateAbilityName(stringIndex, name, currentUpgradeLevel, maxUpgradeLevel, progressionIndex) end
function ZO_Skills_PurchaseAbility(skillType, skillLineIndex, abilityIndex) end
function ZO_Skills_UpgradeAbility(skillType, skillLineIndex, abilityIndex) end
function ZO_Skills_MorphAbility(progressionIndex, morphChoiceIndex) end
function ZO_Skills_TieSkillInfoHeaderToCraftingSkill(skillInfoHeaderControl, craftingSkillType) end
function ZO_SkillsInfo_OnInitialized(control) end
function ZO_Skills_UntieSkillInfoHeaderToCraftingSkill(skillInfoHeaderControl) end
function ZO_Skills_AbilityFailsWerewolfRequirement(skillType, lineIndex) end
function ZO_Skills_OnlyWerewolfAbilitiesAllowedAlert() end
--ingame\slashcommands
function DoCommand(text) end
function ShowGamepadHelpScreen() end
--ingame\soulgemitemcharger
function ZO_SoulGemItemCharger_Gamepad:New(...) end
function ZO_SoulGemItemCharger_Gamepad:Initialize(control) end
function ZO_SoulGemItemCharger_Gamepad:SetupScene() end
function ZO_SoulGemItemCharger_Gamepad:UpdateTooltipOnSelectionChanged() end
function ZO_SoulGemItemCharger_Gamepad:PerformItemImprovement() end
function ZO_Gamepad_SoulGemItemCharger_OnInitialize(control) end
function ZO_SoulGemItemCharger:New(...) end
function ZO_SoulGemItemCharger:Initialize(control) end
function ZO_SoulGemItemCharger:SetupPreviewControls() end
function ZO_SoulGemItemCharger:SetItemInfo(bag, index) end
function ZO_SoulGemItemCharger:OnSoulGemSelected(itemBagId, itemSlotIndex, soulGemBagId, soulGemSlotIndex) end
function ZO_SoulGemItemCharger:SetupDialog(bag, index) end
function ZO_SoulGemItemCharger:BeginItemImprovement(bag, index) end
function ZO_SoulGemItemCharger_OnInitialize(control) end
--ingame\spamwarning
function OnSpamWarningReceived(eventCode, spamType) end
--ingame\stable
function ZO_Stable_Gamepad:New(...) end
function ZO_Stable_Gamepad:Initialize(control) end
function ZO_Stable_Gamepad:InitializeControls() end
function ZO_Stable_Gamepad:InitializeKeybindStrip() end
function ZO_Stable_Gamepad:UpdateMountInfo() end
function ZO_Stable_Gamepad:RefreshActiveMount() end
function ZO_Stable_Gamepad:CanTrainSelected() end
function ZO_Stable_Gamepad:TrainSelected() end
function ZO_Stable_Gamepad:SetupEntry(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_Stable_Gamepad:OnSelectedItemChanged(data) end
function ZO_Stable_Gamepad:IsPreferredScreen() end
function ZO_Stable_Gamepad:SetHidden(hidden) end
function ZO_Stable_Gamepad:SetupRow(control, trainingType) end
function ZO_Stable_Gamepad_Initialize(control) end
function ZO_Stable_Keyboard:New(...) end
function ZO_Stable_Keyboard:Initialize(control) end
function ZO_Stable_Keyboard:InitializeControls() end
function ZO_Stable_Keyboard:InitializeEvents() end
function ZO_Stable_Keyboard:InitializeTabs() end
function ZO_Stable_Keyboard:RefreshActiveMount() end
function ZO_Stable_Keyboard:UpdateMountInfo() end
function ZO_Stable_Keyboard:UpdateStrips() end
function ZO_Stable_Keyboard:IsPreferredScreen() end
function ZO_Stable_Keyboard:SetupRow(control, trainingType) end
function ZO_Stable_Keyboard_Initialize(control) end
function ZO_Stable_Manager:New(...) end
function ZO_Stable_Manager:Initialize(control) end
function ZO_Stable_Manager:RegisterForEvents() end
function ZO_Stable_Manager:UpdateStats() end
function ZO_Stable_Manager:ProcessRidingSkillAnnouncement(ridingSkill, previous, current, source) end
function ZO_Stable_Manager:ShowRidingSkillAnnouncement(ridingSkill, start, stop) end
function ZO_Stable_Manager:OnUpdate(timeMS) end
function ZO_Stable_Manager:CanAffordTraining() end
function ZO_Stable_Manager:GetStats(trainingType) end
function ZO_Stable_Manager:IsRidingSkillMaxedOut() end
function ZO_Stable_Base:New(...) end
function ZO_Stable_Base:Initialize(control, sceneIdentifier) end
function ZO_Stable_Base:InitializeControls() end
function ZO_Stable_Base:InitializeEvents() end
function ZO_Stable_Base:RegisterUpdateEvents() end
function ZO_Stable_Base:UnregisterUpdateEvents() end
function ZO_Stable_Base:OnStablesInteractStart() end
function ZO_Stable_Base:OnStablesInteractEnd() end
function ZO_Stable_Base:OnMoneyUpdated() end
function ZO_Stable_Base:OnMountInfoUpdate() end
function ZO_Stable_Base:OnActiveMountChanged() end
function ZO_Stable_Base:UpdateMountInfo() end
function ZO_Stable_Base:UpdateStrips() end
function ZO_Stable_Base:IsPreferredScreen() end
function ZO_Stable_Base:RefreshActiveMount() end
function ZO_Stable_Base:SetHidden(hidden) end
function ZO_Stable_Base:SetupRow(control, trainingType) end
function ZO_StablesTrainButton_Refresh(control, canTypeBeTrained) end
function ZO_Stable_TrainButtonClicked(control) end
function ZO_StableTrainingRow_Init(control) end
--ingame\stats
function ZO_BountyDisplay:New(...) end
function ZO_BountyDisplay:Initialize(control, isGamepad) end
function ZO_BountyDisplay:Update(time) end
function ZO_BountyDisplay:OnBountyUpdated() end
function ZO_AttributeSpinner_Gamepad:New(attributeControl, attributeType, attributeManager, valueChangedCallback) end
function ZO_AttributeSpinner_Gamepad:SetActive(active) end
function ZO_GamepadStats:New(...) end
function ZO_GamepadStats:Initialize(control) end
function ZO_GamepadStats:ActivateMainList() end
function ZO_GamepadStats:DeactivateMainList() end
function ZO_GamepadStats:ActivateTitleDropdown() end
function ZO_GamepadStats:OnTitleDropdownDeactivated() end
function ZO_GamepadStats:ResetAttributeData() end
function ZO_GamepadStats:ResetDisplayState() end
function ZO_GamepadStats:TryResetScreenState() end
function ZO_GamepadStats:PerformDeferredInitializationRoot() end
function ZO_GamepadStats:InitializeBattleLevelHeader() end
function ZO_GamepadStats:RefreshBattleLevelHeader() end
function ZO_GamepadStats:InitializeKeybindStripDescriptors() end
function ZO_GamepadStats:SetAddedPoints(attributeType, addedPoints) end
function ZO_GamepadStats:GetAddedPoints(attributeType) end
function ZO_GamepadStats:GetNumPointsAdded() end
function ZO_GamepadStats:PurchaseAttributes() end
function ZO_GamepadStats:UpdateScreenVisibility() end
function ZO_GamepadStats:RefreshConfirmScreen() end
function ZO_GamepadStats:PerformUpdate() end
function ZO_GamepadStats:OnSetAvailablePoints() end
function ZO_GamepadStats:UpdateSpendablePoints() end
function ZO_GamepadStats:InitializeCommitPointsDialog() end
function ZO_GamepadStats:InitializeHeader() end
function ZO_GamepadStats:RefreshHeader() end
function ZO_GamepadStats:RefreshContentHeader(title, dataHeaderText, dataText) end
function ZO_GamepadStats:OnSelectionChanged(list, selectedData, oldSelectedData) end
function ZO_GamepadStats:RefreshMainList() end
function ZO_Stats_Gamepad_BountyDisplay_Initialize(control) end
function ZO_GamepadStats:InitializeCharacterEffects() end
function ZO_GamepadStats:RefreshCharacterEffects() end
function ZO_GamepadStats:InitializeCharacterPanel() end
function ZO_GamepadStats:InitializeAttributesPanel() end
function ZO_GamepadStats:SetBonusText(statType, label) end
function ZO_GamepadStats:SetStatValue(statType, label, formatString) end
function ZO_GamepadStats:RefreshAttributesPanel() end
function ZO_GamepadStats:RefreshCharacterPanel() end
function ZO_GamepadStats:GetEnlightenedPool() end
function ZO_GamepadStats_OnInitialize(control) end
function ZO_GamepadStats:SetCurrentTitleDropdown(dropdown) end
function ZO_GamepadStatTitleRow_Setup(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadStatCharacterRow_Setup(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadStatAttributeRow_Setup(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_StatEntry_Keyboard:New(...) end
function ZO_StatEntry_Keyboard:Initialize(control, statType, statObject) end
function ZO_StatEntry_Keyboard:GetPendingStatBonuses() end
function ZO_StatEntry_Keyboard:GetValue() end
function ZO_StatEntry_Keyboard:GetDisplayValue() end
function ZO_StatEntry_Keyboard:UpdateStatValue() end
function ZO_StatsEntry_OnMouseEnter(control) end
function ZO_StatsEntry_OnMouseExit(control) end
function ZO_AttributeSpinner_Keyboard:New(attributeControl, attributeType, attributeManager, valueChangedCallback) end
function ZO_AttributeSpinner_Keyboard:OnMouseWheel(delta) end
function ZO_AttributeSpinner_Keyboard:SetEnabled(enabled) end
function ZO_Stats:New(...) end
function ZO_Stats:Initialize(control) end
function ZO_Stats:OnShown() end
function ZO_Stats:InitializeKeybindButtons() end
function ZO_Stats:SetUpTitleSection() end
function ZO_Stats:RefreshTitleSection() end
function ZO_Stats:RefreshBattleLevelHeader() end
function ZO_Stats:CreateBackgroundSection() end
function ZO_Stats:CreateAttributesSection() end
function ZO_Stats:UpdateSpendablePoints() end
function ZO_Stats:UpdateAttributesHeader() end
function ZO_Stats:ResetAllAttributes() end
function ZO_Stats:GetAddedPoints() end
function ZO_Stats:PurchaseAttributes() end
function ZO_Stats:RefreshAllAttributes() end
function ZO_Stats:SetSpinnersEnabled(enabled) end
function ZO_Stats:SetUpAttributeControl(attributeControl, statType, attributeType, powerType) end
function ZO_Stats:RefreshSpinnerMaxes() end
function ZO_Stats:OnSetAvailablePoints() end
function ZO_Stats:UpdatePendingStatBonuses(statType, pendingBonus) end
function ZO_Stats:CreateMountSection() end
function ZO_Stats:CreateActiveEffectsSection() end
function ZO_Stats:AddDivider() end
function ZO_Stats:AddHeader(text, optionalTemplate) end
function ZO_Stats:AddDropdownRow(rowName) end
function ZO_Stats:AddIconRow(rowName) end
function ZO_Stats:AddBountyRow(rowName) end
function ZO_Stats:SetNextControlPadding(padding) end
function ZO_Stats:AddRawControl(control) end
function ZO_Stats:CreateControlFromVirtual(controlType, template) end
function ZO_Stats:AddStatRow(statType1, statType2) end
function ZO_Stats:AddLongTermEffects(container, effectsRowPool) end
function ZO_Stats_Initialize(control) end
function ZO_StatsAttribute_OnMouseEnter(control) end
function ZO_StatsAttribute_OnMouseExit() end
function ZO_Stats_InitializeRidingSkills(control) end
function ZO_Stats_BountyDisplay_Initialize(control) end
function ZO_Stats_Common:New(...) end
function ZO_Stats_Common:Initialize() end
function ZO_Stats_Common:GetAvailablePoints() end
function ZO_Stats_Common:SetAvailablePoints(points) end
function ZO_Stats_Common:OnSetAvailablePoints() end
function ZO_Stats_Common:SpendAvailablePoints(points) end
function ZO_Stats_Common:GetTotalSpendablePoints() end
function ZO_Stats_Common:SetPendingStatBonuses(statType, pendingBonus) end
function ZO_Stats_Common:UpdatePendingStatBonuses(statType, pendingBonus) end
function ZO_Stats_Common:GetPendingStatBonuses(statType) end
function ZO_Stats_Common:UpdateTitleDropdownSelection(dropdown) end
function ZO_Stats_Common:UpdateTitleDropdownTitles(dropdown) end
function ZO_Stats_Common:IsPlayerBattleLeveled() end
function ZO_StatsRidingSkillIcon_Initialize(control, trainingType) end
function ZO_AttributeSpinner_Shared:New(attributeControl, attributeType, attributeManager, valueChangedCallback) end
function ZO_AttributeSpinner_Shared:SetSpinner(spinner) end
function ZO_AttributeSpinner_Shared:Reinitialize(attributeType, addedPoints, valueChangedCallback) end
function ZO_AttributeSpinner_Shared:SetValueChangedCallback(fn) end
function ZO_AttributeSpinner_Shared:SetAttributeType(attributeType) end
function ZO_AttributeSpinner_Shared:OnValueChanged(points) end
function ZO_AttributeSpinner_Shared:RefreshSpinnerMax() end
function ZO_AttributeSpinner_Shared:RefreshPoints() end
function ZO_AttributeSpinner_Shared:ResetAddedPoints() end
function ZO_AttributeSpinner_Shared:GetPoints() end
function ZO_AttributeSpinner_Shared:GetAllocatedPoints() end
function ZO_AttributeSpinner_Shared:SetAddedPointsByTotalPoints(totalPoints) end
function ZO_AttributeSpinner_Shared:SetAddedPoints(points, force) end
function ZO_AttributeSpinner_Shared:SetButtonsHidden(hidden) end
--ingame\storewindow
function ZO_GamepadStoreBuyback:New(...) end
function ZO_GamepadStoreBuyback:Initialize(scene) end
function ZO_GamepadStoreBuyback:RegisterEvents() end
function ZO_GamepadStoreBuyback:UnregisterEvents() end
function ZO_GamepadStoreBuyback:InitializeKeybindStrip() end
function ZO_GamepadStoreBuyback:ConfirmBuyBack() end
function ZO_GamepadStoreBuyback:CanBuyBack() end
function ZO_GamepadStoreBuyback:SetupEntry(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadStoreBuyback:OnSelectedItemChanged(buyBackData) end
function ZO_GamepadStoreBuy:New(...) end
function ZO_GamepadStoreBuy:Initialize(scene) end
function ZO_GamepadStoreBuy:RegisterEvents() end
function ZO_GamepadStoreBuy:UnregisterEvents() end
function ZO_GamepadStoreBuy:InitializeKeybindStrip() end
function ZO_GamepadStoreBuy:ConfirmBuy() end
function ZO_GamepadStoreBuy:CanBuy() end
function ZO_GamepadStoreBuy:SelectBuyItem() end
function ZO_GamepadStoreBuy:UnselectBuyItem() end
function ZO_GamepadStoreBuy:SetupEntry(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadStoreBuy:OnSelectedItemChanged(buyData) end
function ZO_GamepadStoreComponent:New(...) end
function ZO_GamepadStoreComponent:Initialize(control, storeMode, tabText) end
function ZO_GamepadStoreComponent:Refresh() end
function ZO_GamepadStoreComponent:GetTabText() end
function ZO_GamepadStoreComponent:Show() end
function ZO_GamepadStoreComponent:Hide() end
function ZO_GamepadStoreComponent:GetStoreMode() end
function ZO_GamepadStoreComponent:GetModeData() end
function ZO_GamepadStoreComponent:CreateModeData(name, mode, icon, fragment, keybind) end
function ZO_GamepadStoreListComponent:New(...) end
function ZO_GamepadStoreListComponent:Initialize(scene, storeMode, tabText, overrideTemplate, overrideHeaderTemplateSetupFunction) end
function ZO_GamepadStoreListComponent:Refresh() end
function ZO_GamepadStoreListComponent:SetupEntry(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadStoreListComponent:SetupStoreItem(control, data, selected, selectedDuringRebuild, enabled, activated, price, forceValid, mode) end
function ZO_GamepadStoreListComponent:SetupPrice(control, price, forceValid, mode, currencyType) end
function ZO_GamepadStoreListComponent:OnSelectedItemChanged(data) end
function ZO_GamepadStoreListComponent:CreateItemList(scene, storeMode, overrideTemplate, overrideHeaderTemplateSetupFunction) end
function ZO_GamepadStoreListComponent:OnExitUnselectItem() end
function ZO_GamepadStoreListComponent:GetCurrencyOptions() end
function ZO_GamepadStoreRepair:New(...) end
function ZO_GamepadStoreRepair:Initialize(scene) end
function ZO_GamepadStoreRepair:RegisterEvents() end
function ZO_GamepadStoreRepair:UnregisterEvents() end
function ZO_GamepadStoreRepair:InitializeKeybindStrip() end
function ZO_GamepadStoreRepair:CanRepair() end
function ZO_GamepadStoreRepair:ConfirmRepair() end
function ZO_GamepadStoreRepair:SetupEntry(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadStoreRepair:OnSelectedItemChanged(inventoryData) end
function ZO_GamepadStoreRepair:GetNumRepairItems() end
function ZO_GamepadStoreSell:New(...) end
function ZO_GamepadStoreSell:Initialize(scene) end
function ZO_GamepadStoreSell:RegisterEvents() end
function ZO_GamepadStoreSell:UnregisterEvents() end
function ZO_GamepadStoreSell:InitializeKeybindStrip() end
function ZO_GamepadStoreSell:CanSell() end
function ZO_GamepadStoreSell:ConfirmSell() end
function ZO_GamepadStoreSell:UnselectSellItem() end
function ZO_GamepadStoreSell:SetupEntry(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_GamepadStoreSell:OnSelectedItemChanged(inventoryData) end
function ZO_GamepadStoreManager:New(...) end
function ZO_GamepadStoreManager:Initialize(control) end
function ZO_GamepadStoreManager:SetDeferredStartingMode(mode) end
function ZO_GamepadStoreManager:GetActiveComponent() end
function ZO_GamepadStoreManager:GetCurrentMode() end
function ZO_GamepadStoreManager:SetActiveComponents(componentTable) end
function ZO_GamepadStoreManager:AddComponent(component) end
function ZO_GamepadStoreManager:OnStateChanged(oldState, newState) end
function ZO_GamepadStoreManager:GetSpinnerValue() end
function ZO_GamepadStoreManager:SetupSpinner(max, value, unitPrice, currencyType) end
function ZO_GamepadStoreManager:SetQuantitySpinnerActive(activate, list, ignoreInvalidCost) end
function ZO_GamepadStoreManager:GetRepairAllKeybind() end
function ZO_GamepadStoreManager:InitializeKeybindStrip() end
function ZO_GamepadStoreManager:RebuildHeaderTabs() end
function ZO_GamepadStoreManager:ShowComponent(component) end
function ZO_GamepadStoreManager:HideActiveComponent() end
function ZO_GamepadStoreManager:UpdateRightTooltip(list, mode) end
function ZO_GamepadStoreManager:SetMode(mode) end
function ZO_GamepadStoreManager:RepairMessageBox(bagId, slotId) end
function ZO_GamepadStoreManager:FailedRepairMessageBox(reason) end
function ZO_GamepadStoreManager:CanAffordAndCanCarry(selectedData) end
function ZO_GamepadStoreManager:Show() end
function ZO_GamepadStoreManager:Hide() end
function ZO_Store_OnInitialize_Gamepad(control) end
function ZO_GamepadStoreList:New(control, mode, setupFunction, overrideTemplate, overrideHeaderTemplateSetupFunction) end
function ZO_GamepadStoreList:SetMode(mode, setupFunction, overrideTemplate, overrideHeaderTemplateSetupFunction) end
function ZO_GamepadStoreList:AddItems(items, prePaddingOverride, postPaddingOverride) end
function ZO_GamepadStoreList:UpdateList() end
function BuyBack:New(...) end
function BuyBack:Initialize(control) end
function BuyBack:InitializeList() end
function BuyBack:InitializeFilterBar() end
function BuyBack:InitializeSortHeader() end
function BuyBack:InitializeEvents() end
function BuyBack:UpdateMoney() end
function BuyBack:UpdateFreeSlots() end
function BuyBack:UpdateList() end
function BuyBack:SetupBuyBackSlot(control, data) end
function BuyBack:OnShown() end
function ZO_BuyBack_OnInitialize(control) end
function ZO_StoreManager:New(container) end
function ZO_StoreManager:InitializeStore(overrideMode) end
function ZO_StoreManager:InitializeTabs() end
function ZO_StoreManager:RebuildTabs() end
function ZO_StoreManager:UpdateFreeSlots() end
function ZO_StoreManager:UpdateColumnText() end
function ZO_StoreManager:ChangeFilter(filterData) end
function ZO_StoreManager:ShouldAddItemToList(itemData) end
function ZO_StoreManager:SortData() end
function ZO_StoreManager:ApplySort() end
function ZO_StoreManager:RefreshCurrency() end
function ZO_StoreManager:UpdateFilters() end
function ZO_StoreManager:GetStoreItems() end
function ZO_StoreManager:UpdateList() end
function ZO_StoreManager:UpdateStatValueControl(control, data) end
function ZO_StoreManager:SetUpBuySlot(control, data) end
function ZO_StoreManager:HasEnoughCurrencyToBuyItem(currencyType, itemCost) end
function ZO_StoreManager:OpenBuyMultiple(entryIndex) end
function ZO_StoreManager:BuyMultiplePurchase() end
function ZO_StoreManager:RefreshBuyMultiple() end
function ZO_StoreManager:GetWindowMode() end
function ZO_BuyMultiple_OpenBuyMultiple(entryIndex) end
function ZO_Store_OnEntryMouseEnter(control) end
function ZO_Store_OnEntryMouseExit(control) end
function ZO_Store_FilterButtonOnMouseEnter(self) end
function ZO_Store_FilterButtonOnMouseExit(self) end
function ZO_Store_OnMouseUp(upInside) end
function ZO_Store_OnReceiveDrag() end
function ZO_Store_IsShopping() end
function ZO_Store_OnInitialize(control) end
function ZO_SharedStoreManager:InitializeStore() end
function ZO_SharedStoreManager:RefreshCurrency() end
function ZO_StoreManager_GetStoreItems() end
function ZO_StoreManager_GetStoreFilterTypes() end
function ZO_StoreManager_OnPurchased(eventId, entryName, entryType, entryQuantity, money, specialCurrencyType1, specialCurrencyInfo1, specialCurrencyQuantity1, specialCurrencyType2, specialCurrencyInfo2, specialCurrencyQuantity2, itemSoundCategory) end
--ingame\stuck
function Stuck:New(...) end
function Stuck:Initialize(...) end
function Stuck:ShowConfirmDialog() end
function Stuck:ShowFixingDialog() end
function Stuck:HideFixingDialog() end
function Stuck:OnPlayerActivated() end
function Stuck:OnStuckBegin() end
function Stuck:OnStuckCanceled() end
function Stuck:OnStuckComplete() end
function Stuck:OnStuckErrorAlreadyInProgress() end
function Stuck:OnStuckErrorInvalidLocation() end
function Stuck:OnStuckErrorInCombat() end
function Stuck:OnStuckErrorOnCooldown() end
function ZO_Stuck_Base:New(...) end
function ZO_Stuck_Base:Initialize() end
function ZO_Stuck_Base:OnPlayerActivated() end
function ZO_Stuck_Base:OnStuckBegin() end
function ZO_Stuck_Base:OnStuckCanceled() end
function ZO_Stuck_Base:OnStuckComplete() end
function ZO_Stuck_Base:OnStuckErrorAlreadyInProgress() end
function ZO_Stuck_Base:OnStuckErrorInvalidLocation() end
function ZO_Stuck_Base:OnStuckErrorInCombat() end
function ZO_Stuck_Base:OnStuckErrorOnCooldown() end
function Stuck_Manager:New(...) end
function Stuck_Manager:Initialize() end
function Stuck_Manager:SetActiveSystem() end
--ingame\subtitles
function ZO_Subtitle:New(...) end
function ZO_Subtitle:GetMessageType() end
function ZO_Subtitle:GetMessage() end
function ZO_Subtitle:GetSpeakerName() end
function ZO_Subtitle:GetFormattedMessage(showSpeakerName) end
function ZO_Subtitle:GetDisplayLength() end
function ZO_Subtitle:GetStartTime() end
function ZO_Subtitle:SetStartTime(startTimeSeconds) end
function ZO_Subtitle:HasExpired(currentTimeSeconds) end
function ZO_SubtitleManager:New(...) end
function ZO_SubtitleManager:Initialize(control) end
function ZO_SubtitleManager:UpdatePlatformStyles(styleTable) end
function ZO_SubtitleManager:InitializePlatformStyles() end
function ZO_SubtitleManager:FadeInSubtitle() end
function ZO_SubtitleManager:FadeOutSubtitle() end
function ZO_SubtitleManager:OnUpdate(currentMS) end
function ZO_Subtitles_OnInitialize(control) end
--ingame\synergy
function ZO_Synergy:New(control) end
function ZO_Synergy:Initialize(control) end
function ZO_Synergy:ApplyTextStyle(constants) end
function ZO_Synergy:OnSynergyAbilityChanged() end
function ZO_Synergy:SetHidden(hidden) end
function ZO_Synergy:IsVisible() end
function ZO_Synergy_OnInitialized(control) end
--ingame\tooltip
function ZO_Tooltip:AddAbilityName(abilityId, hideRank, overrideRank) end
function ZO_Tooltip:AddAbilityProgressBar(currentXP, lastRankXP, nextRankXP, atMorph) end
function ZO_Tooltip:AddAbilityDescription(abilityId, pendingChampionPoints) end
function ZO_Tooltip:AddAbilityUpgrades(...) end
function ZO_Tooltip:AddAbilityNewEffects(...) end
function ZO_Tooltip:LayoutAbility(abilityId, hideRank, overrideRank, pendingChampionPoints, addNewEffects) end
function ZO_Tooltip:LayoutSkillLineAbility(skillType, skillLineIndex, abilityIndex, showNextUpgrade, hideRank, overrideRank, showPurchaseInfo) end
function ZO_Tooltip:LayoutAbilityMorph(progressionIndex, morphIndex) end
function ZO_Tooltip:LayoutActionBarAbility(slotId) end
function ZO_Tooltip:LayoutChampionSkillAbility(disciplineIndex, skillIndex, pendingPoints) end
function ZO_Tooltip:LayoutAchievementFromLink(achievementLink) end
function ZO_Tooltip:LayoutAchievementSummary() end
function ZO_Tooltip:LayoutNoAchievement() end
function ZO_Tooltip:LayoutAchievement(achievementId) end
function ZO_Tooltip:LayoutAchievementCriteria(achievementId) end
function ZO_Tooltip:LayoutAchievementRewards(achievementId) end
function ZO_Tooltip:LayoutAvABonus(data) end
function ZO_Tooltip:LayoutCadwells(progressionLevel, zoneIndex) end
function ZO_Tooltip:LayoutChampionConstellation(attributeName, attributeIcon, constellationName, constellationDescription, numPointsAvailable, numSpentPoints) end
function ZO_Tooltip:LayoutVoiceChatChannel(channelData) end
function ZO_Tooltip:LayoutVoiceChatParticipantHistory(displayName, channelName, lastTimeSpoken) end
function ZO_Tooltip:LayoutVoiceChatParticipant(displayName, speakStatus, isMuted) end
function ZO_Tooltip:LayoutVoiceChatParticipants(channelData, participantDataList) end
function ZO_Tooltip:LayoutGroupTooltip(title, bodyText, errorText) end
function ZO_Tooltip:LayoutDungeonDifficultyTooltip() end
function ZO_Tooltip:LayoutGuildKioskInfo(title, body) end
function ZO_Tooltip:AddItemTitle(itemLink, name) end
function ZO_Tooltip:AddTypeSlotUniqueLine(itemLink, itemType, section, text1, text2) end
function ZO_Tooltip:AddTopSection(itemLink, showPlayerLocked, tradeBoPData) end
function ZO_Tooltip:AddTopLinesToTopSection(topSection, itemLink, showPlayerLocked, tradeBoPData) end
function ZO_Tooltip:AddBaseStats(itemLink, ignoreLevel) end
function ZO_Tooltip:AddConditionBar(itemLink, previewConditionToAdd) end
function ZO_Tooltip:AddEnchantChargeBar(itemLink, forceFullDurability, previewChargeToAdd) end
function ZO_Tooltip:AddPoisonInfo(itemLink, equipSlot) end
function ZO_Tooltip:AddConditionOrChargeBar(itemLink, value, maxValue, previewValueToAdd) end
function ZO_Tooltip:AcquireItemImprovementStatusBar(itemLink, value, maxValue, valueToAdd) end
function ZO_Tooltip:AddEnchant(itemLink, enchantDiffMode, equipSlot) end
function ZO_Tooltip:AddItemAbilityScalingRange(section, minLevel, maxLevel, isChampionPoints) end
function ZO_Tooltip:AddOnUseAbility(itemLink) end
function ZO_Tooltip:AddTrait(itemLink) end
function ZO_Tooltip:AddSet(itemLink, equipped) end
function ZO_Tooltip:AddPoisonSystemDescription() end
function ZO_Tooltip:AddFlavorText(itemLink) end
function ZO_Tooltip:AddCreator(itemLink, creatorName) end
function ZO_Tooltip:AddMaterialLevels(itemLink) end
function ZO_Tooltip:AddItemTags(itemLink) end
function ZO_Tooltip:LayoutGenericItem(itemLink, equipped, creatorName, forceFullDurability, enchantMode, previewValueToAdd, itemName, equipSlot, showPlayerLocked, tradeBoPData) end
function ZO_Tooltip:LayoutVendorTrash(itemLink, itemName) end
function ZO_Tooltip:LayoutBooster(itemLink, itemName) end
function ZO_Tooltip:LayoutGlyph(itemLink, creatorName, itemName, tradeBoPData) end
function ZO_Tooltip:LayoutSiege(itemLink, itemName, tradeBoPData) end
function ZO_Tooltip:LayoutTool(itemLink, itemName, tradeBoPData) end
function ZO_Tooltip:LayoutSoulGem(itemLink, itemName) end
function ZO_Tooltip:LayoutAvARepair(itemLink, itemName) end
function ZO_Tooltip:LayoutBook(itemLink, tradeBoPData) end
function ZO_Tooltip:LayoutLure(itemLink, itemName) end
function ZO_Tooltip:LayoutQuestStartOrFinishItem(itemLink, itemName) end
function ZO_Tooltip:LayoutProvisionerRecipe(itemLink, itemName, tradeBoPData) end
function ZO_Tooltip:LayoutReagent(itemLink, itemName) end
function ZO_Tooltip:LayoutEnchantingRune(itemLink, itemName) end
function ZO_Tooltip:LayoutAlchemyBase(itemLink, itemName) end
function ZO_Tooltip:LayoutIngredient(itemLink, itemName) end
function ZO_Tooltip:LayoutStyleMaterial(itemLink, itemName) end
function ZO_Tooltip:LayoutRawMaterial(itemLink, itemName) end
function ZO_Tooltip:LayoutMaterial(itemLink, itemName) end
function ZO_Tooltip:LayoutArmorTrait(itemLink, itemName) end
function ZO_Tooltip:LayoutWeaponTrait(itemLink, itemName) end
function ZO_Tooltip:LayoutAlchemyPreview(solventBagId, solventSlotIndex, reagent1BagId, reagent1SlotIndex, reagent2BagId, reagent2SlotIndex, reagent3BagId, reagent3SlotIndex) end
function ZO_Tooltip:LayoutEnchantingCraftingItem(itemLink, icon, creator) end
function ZO_Tooltip:LayoutEnchantingPreview(potencyRuneBagId, potencyRuneSlotIndex, essenceRuneBagId, essenceRuneSlotIndex, aspectRuneBagId, aspectRuneSlotIndex) end
function ZO_Tooltip:LayoutStoreItemFromLink(itemLink, icon) end
function ZO_Tooltip:LayoutStoreWindowItem(itemData) end
function ZO_Tooltip:LayoutBuyBackItem(itemIndex, icon) end
function ZO_Tooltip:LayoutQuestRewardItem(rewardIndex, icon) end
function ZO_Tooltip:LayoutUniversalStyleItem(itemLink) end
function ZO_Tooltip:LayoutTradeBoPInfo(tradeBoPData) end
function ZO_Tooltip:SetProvisionerResultItem(recipeListIndex, recipeIndex) end
function ZO_Tooltip:LayoutItemWithStackCount(itemLink, equipped, creatorName, forceFullDurability, enchantMode, previewValueToAdd, customOrBagStackCount, equipSlot, showPlayerLocked, tradeBoPData) end
function ZO_Tooltip:LayoutBagItem(bagId, slotIndex, enchantMode, showCombinedCount) end
function ZO_Tooltip:LayoutTradeItem(who, tradeIndex) end
function ZO_Tooltip:LayoutPendingSmithingItem(patternIndex, materialIndex, materialQuantity, styleIndex, traitIndex) end
function ZO_Tooltip:LayoutPendingEnchantedItem(itemBagId, itemIndex, enchantmentBagId, enchantmentIndex) end
function ZO_Tooltip:LayoutPendingItemChargeOrRepair(itemBagId, itemSlotIndex, improvementKitBagId, improvementKitIndex, improvementFunc, enchantDiffMode) end
function ZO_Tooltip:LayoutPendingItemCharge(itemBagId, itemSlotIndex, improvementKitBagId, improvementKitIndex) end
function ZO_Tooltip:LayoutPendingItemRepair(itemBagId, itemSlotIndex, improvementKitBagId, improvementKitIndex) end
function ZO_Tooltip:LayoutImprovedSmithingItem(itemToImproveBagId, itemToImproveSlotIndex, craftingSkillType) end
function ZO_Tooltip:LayoutResearchSmithingItem(traitType, traitDescription) end
function ZO_Tooltip:LayoutQuestItem(questItem) end
function ZO_Tooltip:LayoutItemStatComparison(bagId, slotId, comparisonSlot) end
function ZO_MapInformationTooltip_Gamepad_Mixin:LayoutIconStringLine(baseSection, icon, string, ...) end
function ZO_MapInformationTooltip_Gamepad_Mixin:LayoutLargeIconStringLine(baseSection, icon, string, ...) end
function ZO_MapInformationTooltip_Gamepad_Mixin:LayoutStringLine(baseSection, string, ...) end
function ZO_MapInformationTooltip_Gamepad_Mixin:LayoutIconStringRightStringLine(baseSection, icon, string, rightString, ...) end
function ZO_MapInformationTooltip_Gamepad_Mixin:LayoutGroupHeader(baseSection, icon, string, ...) end
function ZO_MapInformationTooltip_Gamepad_Mixin:AppendUnitName(unitTag) end
function ZO_MapInformationTooltip_Gamepad_Mixin:AppendQuestEnding(questIndex) end
function ZO_MapInformationTooltip_Gamepad_Mixin:AppendQuestCondition(questIndex, stepIndex, conditionIndex) end
function ZO_MapInformationTooltip_Gamepad_Mixin:AppendMapPing(pinType, unitTag) end
function ZO_MapInformationTooltip_Gamepad_Mixin:AppendAvAObjective(queryType, keepId, objectiveId, isSpawnLocation) end
function ZO_MapInformationTooltip_Gamepad_Mixin:AddMoney(baseSection, amount, reason, notEnough, ...) end
function ZO_MapInformationTooltip_Gamepad_Mixin:AppendWayshrineTooltip(pin) end
function ZO_MapInformationTooltip_Gamepad_Mixin:LayoutKeepUpgrade(name, description) end
function ZO_Tooltip:LayoutNotification(note, messageText) end
function ZO_Tooltip:LayoutFriend(displayName, characterName, class, gender, level, championPoints, alliance, zone, offline, secsSinceLogoff, timeStamp) end
function ZO_Tooltip:LayoutGuildMember(displayName, characterName, class, gender, guildId, guildRankIndex, note, level, championPoints, alliance, zone, offline, secsSinceLogoff, timeStamp) end
function ZO_Tooltip:LayoutRidingSkill(trainingType, bonus, maxBonus) end
function ResetGameTooltipToDefaultLocation() end
function SetTooltipToMountTrain(tooltip, trainType) end
function SetTooltipToActionBarSlot(tooltip, slot) end
function ZO_ItemTooltip_SetMoney(tooltipControl, amount, reason, notEnough) end
function ZO_ItemTooltip_AddMoney(tooltipControl, amount, reason, notEnough) end
function ZO_ItemTooltip_ClearMoney(tooltipControl) end
function ZO_ItemTooltip_ClearCharges(tooltipControl) end
function ZO_ItemTooltip_ClearCondition(tooltipControl) end
function ZO_ItemTooltip_ClearEquippedInfo(tooltipControl) end
function ZO_ItemTooltip_Cleared(tooltipControl) end
function ZO_ItemTooltip_OnAddGameData(tooltipControl, gameDataType, ...) end
function ZO_ItemIconTooltip_Cleared(tooltipControl) end
function ZO_ItemIconTooltip_OnAddGameData(tooltipControl, gameDataType, ...) end
function ZO_PopupTooltip_SetLink(link) end
function ZO_PopupTooltip_Hide() end
function ZO_SkillTooltip_SetSkillUpgrade(tooltipControl, source, dest) end
function ZO_SkillTooltip_ClearSkillUpgrades(tooltipControl) end
function ZO_SkillTooltip_OnAddGameData(tooltipControl, gameDataType, ...) end
function ZO_ItemTooltip_SetCharges(tooltipControl, charges, maxCharges) end
function ZO_ItemTooltip_SetCondition(tooltipControl, condition, maxCondition) end
function ZO_ItemTooltip_SetStolen(tooltipControl, isItemStolen) end
function ZO_AbilityTooltip_OnAddGameData(tooltipControl, gameDataType, ...) end
function ZO_AbilityTooltip_Cleared(tooltipControl) end
function ZO_AbilityTooltip_Initialize(self) end
function ZO_TooltipStyles_GetItemQualityStyle(itemQuality) end
--ingame\tradewindow
function ZO_GamepadTradeWindow:New(control) end
function ZO_GamepadTradeWindow:Initialize(control) end
function ZO_GamepadTradeWindow:PerformDeferredInitialization() end
function ZO_GamepadTradeWindow:InitializeOfferLists() end
function ZO_GamepadTradeWindow:AddOfferListEntry(list, text, icon, callback, modifyTextType) end
function ZO_GamepadTradeWindow:InitializeHeaders() end
function ZO_GamepadTradeWindow:UpdateDirectionalInput() end
function ZO_GamepadTradeWindow:RefreshCanSwitchFocus() end
function ZO_GamepadTradeWindow:SetOfferFocus(listType) end
function ZO_GamepadTradeWindow:InventorySelectionChanged(inventoryData) end
function ZO_GamepadTradeWindow:ShowGoldSliderControl(value, maxValue) end
function ZO_GamepadTradeWindow:HideGoldSliderControl() end
function ZO_GamepadTradeWindow:OnSelectionChanged(list, item) end
function ZO_GamepadTradeWindow:RefreshTooltips() end
function ZO_GamepadTradeWindow:RefreshOfferList(tradetype, list) end
function ZO_GamepadTradeWindow:EnterConfirmation(tradetype) end
function ZO_GamepadTradeWindow:ExitConfirmation(tradetype) end
function ZO_GamepadTradeWindow:PrepareWindowForNewTrade() end
function ZO_GamepadTradeWindow:BeginTrade() end
function ZO_GamepadTradeWindow:SwitchView(view) end
function ZO_GamepadTradeWindow:SwitchToKeybind(keybindStripDescriptor) end
function ZO_GamepadTradeWindow:RefreshKeybind() end
function ZO_GamepadTradeWindow:GetActiveItemSlot() end
function ZO_GamepadTradeWindow:InitializeKeybindDescriptor() end
function ZO_GamepadTradeWindow:OnStateChanged(oldState, newState) end
function ZO_GamepadTradeWindow:OnTradeWindowItemAdded(eventCode, who, tradeSlot, itemSoundCategory) end
function ZO_GamepadTradeWindow:OnTradeWindowItemRemoved(eventCode, who, tradeSlot, itemSoundCategory) end
function ZO_GamepadTradeWindow:OnTradeWindowMoneyChanged(eventCode, who, money) end
function ZO_Trade_Gamepad_OnInitialize(control) end
function ZO_TradeWindow:New(control) end
function ZO_TradeWindow:Initialize(control) end
function ZO_TradeWindow:InitializeScene(name) end
function ZO_TradeWindow:PrepareWindowForNewTrade() end
function ZO_TradeWindow:InitializeKeybindDescriptor() end
function ZO_TradeWindow:HideEmptySlots(who) end
function ZO_TradeWindow:ShowAllSlots(who) end
function ZO_TradeWindow:HideAllSlots(who) end
function ZO_TradeWindow:InitializeSlot(who, index, name, icon, quantity, quality) end
function ZO_TradeWindow:ResetAllSlots(who) end
function ZO_TradeWindow:ResetSlot(who, index) end
function ZO_TradeWindow:UpdateSlotQuantity(who, index, quantity) end
function ZO_TradeWindow:CreateSlots(tradeOwner, slotsParent, slotPrefix, slotType) end
function ZO_TradeWindow:OnTradeWindowItemAdded(eventCode, who, tradeSlot, itemSoundCategory) end
function ZO_TradeWindow:OnTradeWindowItemRemoved(eventCode, who, tradeSlot, itemSoundCategory) end
function ZO_TradeWindow:OnTradeWindowMoneyChanged(eventCode, who, money) end
function ZO_Trade_OnReceiveDrag() end
function ZO_Trade_OnMouseDown() end
function ZO_Trade_BeginChangeMoney(anchorTo) end
function ZO_Trade_OnInitialize(control) end
function ZO_TradeManager:New(...) end
function ZO_TradeManager:Initialize() end
function ZO_TradeManager:InitiateTrade(displayName) end
function ZO_TradeManager:CancelTradeInvite() end
function ZO_TradeManager:AddItemToTrade(bagId, slotIndex) end
function ZO_TradeManager:IsTrading() end
function ZO_TradeManager:IsWaiting() end
function ZO_TradeManager:IsConsidering() end
function ZO_TradeManager:IsIdle() end
function ZO_TradeManager:CanTradeItem(itemData) end
function TradeWindowDebugShow() end
function ZO_IsItemCurrentlyOfferedForTrade(bagId, slotIndex) end
function ZO_SharedTradeWindow:New(...) end
function ZO_SharedTradeWindow:Initialize(control) end
function ZO_SharedTradeWindow:InitializeSharedEvents() end
function ZO_SharedTradeWindow:IsTrading() end
function ZO_SharedTradeWindow:IsReady() end
function ZO_SharedTradeWindow:FindMyNextAvailableSlot() end
function ZO_SharedTradeWindow:CanTradeItem(bagId, slot) end
function ZO_SharedTradeWindow:IsModifyConfirmationLevelEnabled() end
function ZO_SharedTradeWindow:SetConfirmationDelay(delay) end
function ZO_SharedTradeWindow:OnTradeAcceptFailedNotEnoughMoney() end
function ZO_SharedTradeWindow:UpdateConfirmationView(whoID, newLevel) end
--ingame\tradinghouse
function ZO_ArmorFilter_Shared:ApplyCategoryFilterToSearch(search, subType) end
function GamepadArmorFilter:New() end
function GamepadArmorFilter:Initialize(name, traitType, enchantmentType) end
function GamepadArmorFilter:ApplyToSearch(search) end
function GamepadArmorFilter:PopulateSubTypes(comboBox, entryName, entry) end
function GamepadArmorFilter:SetGenericArmorSearch(mode, traitType, enchantmentType, armorType) end
function GamepadArmorFilter:UpdateFilterData() end
function GamepadArmorFilter:SetHidden(hidden) end
function GamepadConsumablesFilter:New() end
function GamepadCraftingFilter:New() end
function GamepadCraftingFilter:Initialize(name, filterData, traitType) end
function GamepadCraftingFilter:SetSubType(entry) end
function GamepadCraftingFilter:SetCategoryTypeAndSubData(entry) end
function GamepadCraftingFilter:ApplyToSearch(search) end
function ZO_GamepadTradingHouse_EnchantmentFilters:New() end
function GamepadGemFilter:New() end
function GamepadGemFilter:Initialize(name, filterData, traitType, enchantmentType) end
function GamepadGemFilter:SetCategoryType(entry) end
function GamepadGuildItemsFilter:New() end
function GamepadGuildItemsFilter:Initialize() end
function GamepadGuildItemsFilter:SetHidden(hidden) end
function GamepadMiscellaneousFilter:New() end
function ZO_GamepadTradingHouse_Filter:New(...) end
function ZO_GamepadTradingHouse_Filter:Initialize(traitType, enchantmentType) end
function ZO_GamepadTradingHouse_Filter:IsInitialized() end
function ZO_GamepadTradingHouse_Filter:SetComboBoxes(filterComboBoxData) end
function ZO_GamepadTradingHouse_Filter:RemoveComboBoxes() end
function ZO_GamepadTradingHouse_Filter:AddMods(filterComboBoxData) end
function ZO_GamepadTradingHouse_Filter:SetTraitType(traitType) end
function ZO_GamepadTradingHouse_Filter:SetEnchantmentType(enchantmentType) end
function ZO_GamepadTradingHouse_Filter:ApplyToSearch(search) end
function ZO_GamepadTradingHouse_Filter:SetHidden(hidden) end
function ZO_GamepadTradingHouse_ModFilter:New(...) end
function ZO_GamepadTradingHouse_ModFilter:Initialize(name, filterDataContainer, modFilterType) end
function ZO_GamepadTradingHouse_ModFilter:IsInitialized() end
function ZO_GamepadTradingHouse_ModFilter:SetVisible(visible) end
function ZO_GamepadTradingHouse_ModFilter:GetComboBoxData() end
function ZO_GamepadTradingHouse_ModFilter:SetType(filterType) end
function ZO_GamepadTradingHouse_ModFilter:OnFilterSelectionChanged(comboBox, entryName, entry) end
function ZO_GamepadTradingHouse_ModFilter:InitializeComboBox(comboBox) end
function ZO_GamepadCategoryFilter:New(...) end
function ZO_GamepadCategoryFilter:Initialize(name, filterData, traitType, enchantmentType) end
function ZO_GamepadCategoryFilter:GetComboBoxData() end
function ZO_GamepadCategoryFilter:InitializeFilterCategoryComboBox(comboBox) end
function ZO_GamepadCategoryFilter:GetFilterData() end
function ZO_GamepadCategoryFilter:SetCategoryType(entry) end
function ZO_GamepadCategoryFilter:OnCategorySelection(comboBox, entryName, entry) end
function ZO_GamepadCategoryFilter:ApplyToSearch(search) end
function ZO_GamepadCategoryFilter:SetComboBoxes(comboBoxes) end
function ZO_CategorySubtypeFilter:New(...) end
function ZO_CategorySubtypeFilter:Initialize(name, filterData, traitType, enchantmentType) end
function ZO_CategorySubtypeFilter:GetComboBoxData() end
function ZO_CategorySubtypeFilter:SetSubType(entry) end
function ZO_CategorySubtypeFilter:SetFilterSubType(comboBox, entryName, entry) end
function ZO_CategorySubtypeFilter:InitializeSubTypeComboBox(comboBox) end
function ZO_CategorySubtypeFilter:InitializeFilterCategoryComboBox(comboBox) end
function ZO_CategorySubtypeFilter:GetFilterData() end
function ZO_CategorySubtypeFilter:SetCategoryTypeAndSubData(entry) end
function ZO_CategorySubtypeFilter:PopulateSubTypes(comboBox, entryName, entry) end
function ZO_CategorySubtypeFilter:SetComboBoxes(comboBoxes) end
function ZO_GamepadTradingHouse_BrowseResults:New(...) end
function ZO_GamepadTradingHouse_BrowseResults:Initialize(control) end
function ZO_GamepadTradingHouse_BrowseResults:InitializeList() end
function ZO_GamepadTradingHouse_BrowseResults:InitializeSortOptions() end
function ZO_GamepadTradingHouse_BrowseResults:NextPageRequest() end
function ZO_GamepadTradingHouse_BrowseResults:PreviousPageRequest() end
function ZO_GamepadTradingHouse_BrowseResults:UpdateRightTooltip(selectedData) end
function ZO_GamepadTradingHouse_BrowseResults:UpdateItemSelectedTooltip(selectedData) end
function ZO_GamepadTradingHouse_BrowseResults:LayoutTooltips(selectedData) end
function ZO_GamepadTradingHouse_BrowseResults:AddGuildSpecificItemsToList(ignoreFiltering, cacheGuildItems) end
function ZO_GamepadTradingHouse_BrowseResults:AddGuildSpecificItems(ignoreFiltering) end
function ZO_GamepadTradingHouse_BrowseResults:OnSearchResultsReceived(_, numItemsOnPage, currentPage, hasMorePages) end
function ZO_GamepadTradingHouse_BrowseResults:InitializeEvents() end
function ZO_GamepadTradingHouse_BrowseResults:AddEntryToList(itemData) end
function ZO_GamepadTradingHouse_BrowseResults:FormatItemDataFields(itemData) end
function ZO_GamepadTradingHouse_BrowseResults:BuildList() end
function ZO_GamepadTradingHouse_BrowseResults:ClearList() end
function ZO_GamepadTradingHouse_BrowseResults:ShowPurchaseItemConfirmation(selectedData) end
function ZO_GamepadTradingHouse_BrowseResults:InitializeKeybindStripDescriptors() end
function ZO_GamepadTradingHouse_BrowseResults:UpdateForGuildChange() end
function ZO_GamepadTradingHouse_BrowseResults:DoSearch() end
function ZO_GamepadTradingHouse_BrowseResults:RequestListUpdate() end
function ZO_GamepadTradingHouse_BrowseResults:GetFragmentGroup() end
function ZO_GamepadTradingHouse_BrowseResults:ResetPageData() end
function ZO_GamepadTradingHouse_BrowseResults:UpdatePageData(numItemsOnPage, currentPage, hasMorePages) end
function ZO_GamepadTradingHouse_BrowseResults:OnHiding() end
function ZO_GamepadTradingHouse_BrowseResults:ShowBrowseFilters() end
function ZO_GamepadTradingHouse_BrowseResults:OnInitialInteraction() end
function ZO_GamepadTradingHouse_BrowseResults:OnEndInteraction() end
function ZO_GamepadTradingHouse_BrowseResults:SetFooterAlpha(alpha) end
function ZO_GamepadTradingHouse_BrowseResults:DeactivateForResponse() end
function ZO_GamepadTradingHouse_BrowseResults:OnSearchCooldownUpdate(cooldownMilliseconds) end
function ZO_GamepadTradingHouse_BrowseResults:UpdateListSortFunction() end
function ZO_GamepadTradingHouse_BrowseResults:RefreshSort() end
function ZO_TradingHouse_BrowseResults_Gamepad_OnInitialize(control) end
function ZO_GamepadTradingHouse_DynamicSetter:New(...) end
function ZO_GamepadTradingHouse_DynamicSetter:Initialize(filterType, GetMinMax) end
function ZO_GamepadTradingHouse_DynamicSetter:GetValues() end
function ZO_GamepadTradingHouse_Browse:New(...) end
function ZO_GamepadTradingHouse_Browse:Initialize(control) end
function ZO_GamepadTradingHouse_Browse:InitializeKeybindStripDescriptors() end
function ZO_GamepadTradingHouse_Browse:InitializeSearchTerms(search) end
function ZO_GamepadTradingHouse_Browse:ValidatePriceSelectorValue(value) end
function ZO_GamepadTradingHouse_Browse:FocusDropDown(dropDown) end
function ZO_GamepadTradingHouse_Browse:UnfocusDropDown() end
function ZO_GamepadTradingHouse_Browse:FocusPriceSelector(selectedPriceAmountControl) end
function ZO_GamepadTradingHouse_Browse:UnfocusPriceSelector() end
function ZO_GamepadTradingHouse_Browse:SetMinPriceAmount(priceAmount) end
function ZO_GamepadTradingHouse_Browse:SetMaxPriceAmount(priceAmount) end
function ZO_GamepadTradingHouse_Browse:SetPriceAmount(amount) end
function ZO_GamepadTradingHouse_Browse:SetMinLevel(minLevel) end
function ZO_GamepadTradingHouse_Browse:SetMaxLevel(maxLevel) end
function ZO_GamepadTradingHouse_Browse:GetLevelStep() end
function ZO_GamepadTradingHouse_Browse:GetMinLevelCap() end
function ZO_GamepadTradingHouse_Browse:GetMaxLevelCap() end
function ZO_GamepadTradingHouse_Browse:UpdateSliderMinMax(slider, min, max) end
function ZO_GamepadTradingHouse_Browse:UpdateLevelSlidersMinMax() end
function ZO_GamepadTradingHouse_Browse:OnTargetChanged(list, selectedData, oldSelectedData) end
function ZO_GamepadTradingHouse_Browse:PopulateCategoryDropDown(dropDown) end
function ZO_GamepadTradingHouse_Browse:PopulateQualityDropDown(dropDown) end
function ZO_GamepadTradingHouse_Browse:PopulateLevelDropDown(dropDown) end
function ZO_GamepadTradingHouse_Browse:GetFilterDropDowns() end
function ZO_GamepadTradingHouse_Browse:AddFilterDropDownEntry(name) end
function ZO_GamepadTradingHouse_Browse:AddLevelSelectorEntry(name, mode) end
function ZO_GamepadTradingHouse_Browse:InitializeFilterData(filters) end
function ZO_GamepadTradingHouse_Browse:ResetList(filters, dontReselect) end
function ZO_GamepadTradingHouse_Browse:PerformDeferredInitialization() end
function ZO_GamepadTradingHouse_Browse:IntializeComboBoxCallBacks() end
function ZO_GamepadTradingHouse_Browse:GetFragmentGroup() end
function ZO_GamepadTradingHouse_Browse:SetupDropDown(control, data, selected, reselectingDuringRebuild, enabled, active) end
function ZO_GamepadTradingHouse_Browse:SetupFilterDropDown(control, data, selected, reselectingDuringRebuild, enabled, active) end
function ZO_GamepadTradingHouse_Browse:SetupPriceSelector(control, data, selected, reselectingDuringRebuild, enabled, active) end
function ZO_GamepadTradingHouse_Browse:SetupSlider(control, data, selected, reselectingDuringRebuild, enabled, active) end
function ZO_GamepadTradingHouse_Browse:InitializeList() end
function ZO_GamepadTradingHouse_Browse:ResetFilterValuesToDefaults() end
function ZO_GamepadTradingHouse_Browse:OnInitialInteraction() end
function ZO_GamepadTradingHouse_Browse:OnHiding() end
function ZO_GamepadTradingHouse_Browse:OnHidden() end
function ZO_GamepadTradingHouse_Browse:OnShowing() end
function ZO_GamepadTradingHouse_Browse:ShowResults() end
function ZO_GamepadTradingHouse_Browse:UpdateForGuildChange() end
function ZO_GuildStoreBrowse_SliderOnValueChanged(control, value) end
function ZO_TradingHouse_Browse_Gamepad_OnInitialize(control) end
function ZO_GamepadTradingHouse_BrowseManager:New() end
function ZO_GamepadTradingHouse_BrowseManager:RegisterForEvents(...) end
function ZO_GamepadTradingHouse_BrowseManager:OnInitialInteraction() end
function ZO_GamepadTradingHouse_BrowseManager:OnEndInteraction() end
function ZO_GamepadTradingHouse_BrowseManager:UpdateForGuildChange() end
function ZO_GamepadTradingHouse_BrowseManager:UpdateKeybind() end
function ZO_GamepadTradingHouse_BrowseManager:Show() end
function ZO_GamepadTradingHouse_BrowseManager:Hide() end
function ZO_GamepadTradingHouse_BrowseManager:Toggle() end
function ZO_GamepadTradingHouse_BrowseManager:NewFilteredSearch() end
function ZO_GamepadTradingHouse_BrowseManager:SetAwaitingResponse(...) end
function ZO_GamepadTradingHouse_CreateListing:New(...) end
function ZO_GamepadTradingHouse_CreateListing:Initialize(control) end
function ZO_GamepadTradingHouse_CreateListing:PerformDeferredInitialization() end
function ZO_GamepadTradingHouse_CreateListing:InitializeKeybindStripDescriptors() end
function ZO_GamepadTradingHouse_CreateListing:InitializeHeader() end
function ZO_GamepadTradingHouse_CreateListing:InitializeControls() end
function ZO_GamepadTradingHouse_CreateListing:OnStateChanged(oldState, newState) end
function ZO_GamepadTradingHouse_CreateListing:Showing() end
function ZO_GamepadTradingHouse_CreateListing:Hiding() end
function ZO_GamepadTradingHouse_CreateListing:FocusPriceSelector() end
function ZO_GamepadTradingHouse_CreateListing:UnfocusPriceSelector() end
function ZO_GamepadTradingHouse_CreateListing:ValidatePriceSelectorValue(price) end
function ZO_GamepadTradingHouse_CreateListing:SetControlAmountLabel(control, amount, hasError) end
function ZO_GamepadTradingHouse_CreateListing:SetListingPrice(price, isPreview) end
function ZO_GamepadTradingHouse_CreateListing:SetupListing(selectedData, bag, index, listingPrice) end
function ZO_GamepadTradingHouse_CreateListing:ShowListItemConfirmation() end
function ZO_TradingHouse_CreateListing_Gamepad_OnInitialize(control) end
function ZO_TradingHouse_CreateListing_Gamepad_BeginCreateListing(selectedData, bag, index, listingPrice) end
function ZO_GamepadTradingHouse_Dialogs_DisplayConfirmationDialog(selectedData, dialogName, displayPrice) end
function ZO_GamepadTradingHouse:New(...) end
function ZO_GamepadTradingHouse:Initialize(control) end
function ZO_GamepadTradingHouse:InitializeHeader() end
function ZO_GamepadTradingHouse:RefreshHeaderData() end
function ZO_GamepadTradingHouse:RefreshGuildNameFooter() end
function ZO_GamepadTradingHouse:OnInitialInteraction() end
function ZO_GamepadTradingHouse:OnEndInteraction() end
function ZO_GamepadTradingHouse:UpdateForGuildChange() end
function ZO_GamepadTradingHouse:InitializeScene() end
function ZO_GamepadTradingHouse:RegisterForSceneEvents() end
function ZO_GamepadTradingHouse:UnregisterForSceneEvents() end
function ZO_GamepadTradingHouse:InitializeTabEvents() end
function ZO_GamepadTradingHouse:InitializeKeybindStripDescriptors() end
function ZO_GamepadTradingHouse:PerformDeferredInitialization() end
function ZO_GamepadTradingHouse:FireTabEvents(event, ...) end
function ZO_GamepadTradingHouse:OpenTradingHouse() end
function ZO_GamepadTradingHouse:CloseTradingHouse() end
function ZO_GamepadTradingHouse:UpdateStatus(...) end
function ZO_GamepadTradingHouse:OnOperationTimeout(...) end
function ZO_GamepadTradingHouse:OnSearchCooldownUpdate(...) end
function ZO_GamepadTradingHouse:OnPendingPostItemUpdated(...) end
function ZO_GamepadTradingHouse:OnAwaitingResponse(...) end
function ZO_GamepadTradingHouse:OnResponseReceived(...) end
function ZO_GamepadTradingHouse:OnSearchResultsReceived(...) end
function ZO_GamepadTradingHouse:ConfirmPendingPurchase(...) end
function ZO_GamepadTradingHouse:InitializeSearchTerms() end
function ZO_GamepadTradingHouse:AddSearchSetter(setterObject) end
function ZO_GamepadTradingHouse:AllowSearch() end
function ZO_GamepadTradingHouse:GetSearchAllowed() end
function ZO_GamepadTradingHouse:SetSearchAllowed(searchAllowed) end
function ZO_GamepadTradingHouse:SetSearchPageData(currentPage, hasMorePages) end
function ZO_GamepadTradingHouse:SearchNextPage() end
function ZO_GamepadTradingHouse:SearchPreviousPage() end
function ZO_GamepadTradingHouse:UpdateSortOption(...) end
function ZO_GamepadTradingHouse:InitializeFilterFactory(entry, filterFactory, filterStringId) end
function ZO_GamepadTradingHouse:AddSearchSetter(setter) end
function ZO_GamepadTradingHouse:AddGuildSpecificItems(...) end
function ZO_TradingHouse_Gamepad_Initialize(control) end
function ZO_TradingHouse_Gamepad_AddSearchSetter(setter) end
function ZO_GamepadTradingHouse_Listings:New(...) end
function ZO_GamepadTradingHouse_Listings:Initialize(control) end
function ZO_GamepadTradingHouse_Listings:InitializeList() end
function ZO_GamepadTradingHouse_Listings:UpdateForGuildChange() end
function ZO_GamepadTradingHouse_Listings:UpdateItemSelectedTooltip(selectedData) end
function ZO_GamepadTradingHouse_Listings:OnResponseReceived(responseType, result) end
function ZO_GamepadTradingHouse_Listings:InitializeEvents() end
function ZO_GamepadTradingHouse_Listings:BuildList() end
function ZO_GamepadTradingHouse_Listings:ShowCancelListingConfirmation(selectedData) end
function ZO_GamepadTradingHouse_Listings:InitializeKeybindStripDescriptors() end
function ZO_GamepadTradingHouse_Listings:RequestListUpdate() end
function ZO_GamepadTradingHouse_Listings:GetFragmentGroup() end
function ZO_GamepadTradingHouse_Listings:OnHiding() end
function ZO_GamepadTradingHouse_Listings:OnInitialInteraction() end
function ZO_GamepadTradingHouse_Listings:OnEndInteraction() end
function ZO_TradingHouse_Listings_Gamepad_OnInitialize(control) end
function ZO_GamepadTradingHouse_Sell:New(...) end
function ZO_GamepadTradingHouse_Sell:Initialize(control) end
function ZO_GamepadTradingHouse_Sell:UpdateItemSelectedTooltip(selectedData) end
function ZO_GamepadTradingHouse_Sell:SetupSelectedSellItem(selectedItem) end
function ZO_GamepadTradingHouse_Sell:UpdateForGuildChange() end
function ZO_GamepadTradingHouse_Sell:UpdateListForCurrentGuild() end
function ZO_GamepadTradingHouse_Sell:OnSelectionChanged(list, selectedData, oldSelectedData) end
function ZO_GamepadTradingHouse_Sell:InitializeList() end
function ZO_GamepadTradingHouse_Sell:OnShowing() end
function ZO_GamepadTradingHouse_Sell:OnShown() end
function ZO_GamepadTradingHouse_Sell:InitializeKeybindStripDescriptors() end
function ZO_GamepadTradingHouse_Sell:GetFragmentGroup() end
function ZO_GamepadTradingHouse_Sell:OnHiding() end
function ZO_GamepadTradingHouse_Sell:DeactivateForResponse() end
function ZO_TradingHouse_Sell_Gamepad_OnInitialize(control) end
function ZO_GamepadTradingHouse_BaseList:New(...) end
function ZO_GamepadTradingHouse_BaseList:Initialize() end
function ZO_GamepadTradingHouse_BaseList:InitializeKeybindStripDescriptors() end
function ZO_GamepadTradingHouse_BaseList:UpdateKeybind() end
function ZO_GamepadTradingHouse_BaseList:Hide() end
function ZO_GamepadTradingHouse_BaseList:Show() end
function ZO_GamepadTradingHouse_BaseList:SetEventCallback(event, callback) end
function ZO_GamepadTradingHouse_BaseList:RegisterForEvents(eventTable) end
function ZO_GamepadTradingHouse_BaseList:DisplayErrorDialog(errorMessage) end
function ZO_GamepadTradingHouse_BaseList:DisplayChangeGuildDialog() end
function ZO_GamepadTradingHouse_BaseList:SetAwaitingResponse(awaitingResponse) end
function ZO_GamepadTradingHouse_BaseList:InitializeList() end
function ZO_GamepadTradingHouse_BaseList:InitializeEvents() end
function ZO_GamepadTradingHouse_BaseList:GetFragmentGroup() end
function ZO_GamepadTradingHouse_BaseList:OnInitialInteraction() end
function ZO_GamepadTradingHouse_BaseList:OnEndInteraction() end
function ZO_GamepadTradingHouse_BaseList:UpdateForGuildChange() end
function ZO_GamepadTradingHouse_BaseList:OnHiding() end
function ZO_GamepadTradingHouse_BaseList:OnHidden() end
function ZO_GamepadTradingHouse_BaseList:OnShowing() end
function ZO_GamepadTradingHouse_BaseList:OnShown() end
function ZO_GamepadTradingHouse_BaseList:DeactivateForResponse() end
function ZO_GamepadTradingHouse_BaseList:ActivateOnResponse() end
function ZO_GamepadTradingHouse_BaseList:HasNoCooldown() end
function ZO_GamepadTradingHouse_ItemList:New(...) end
function ZO_GamepadTradingHouse_ItemList:Initialize(control) end
function ZO_GamepadTradingHouse_ItemList:GetKeyBind() end
function ZO_GamepadTradingHouse_ItemList:SetFragment(fragment) end
function ZO_GamepadTradingHouse_ItemList:InitializeList() end
function ZO_GamepadTradingHouse_ItemList:UpdateList() end
function ZO_GamepadTradingHouse_SortableItemList:New(...) end
function ZO_GamepadTradingHouse_SortableItemList:Initialize(control, initialSortKey, useHighlight) end
function ZO_GamepadTradingHouse_SortableItemList:GetKeyBind() end
function ZO_GamepadTradingHouse_SortableItemList:SetFragment(fragment) end
function ZO_GamepadTradingHouse_SortableItemList:InitializeSortOptions() end
function ZO_GamepadTradingHouse_SortableItemList:ResetSortOptions() end
function ZO_GamepadTradingHouse_SortableItemList:SelectInitialSortOption() end
function ZO_GamepadTradingHouse_SortableItemList:GetTextForCurrentTimePriceKey() end
function ZO_GamepadTradingHouse_SortableItemList:GetTextForToggleTimePriceKey() end
function ZO_GamepadTradingHouse_SortableItemList:ToggleSortOptions() end
function ZO_GamepadTradingHouse_SortableItemList:BuildList() end
function ZO_GamepadTradingHouse_SortableItemList:RequestListUpdate() end
function ZO_TradingHouse_ItemListRow_Gamepad_OnInitialized(control) end
function ZO_GamepadTradingHouse_TraitFilters:New() end
function GamepadWeaponFilter:New() end
function GamepadWeaponFilter:ApplyToSearch(search) end
function ArmorFilter:New(...) end
function ArmorFilter:Initialize(parentControl) end
function ArmorFilter:ApplyToSearch(search) end
function ArmorFilter:SetHidden(hidden) end
function ConsumablesFilter:New(...) end
function ConsumablesFilter:Initialize(parentControl) end
function ConsumablesFilter:ApplyToSearch(search) end
function CraftingFilter:New(...) end
function CraftingFilter:Initialize(parentControl) end
function CraftingFilter:ApplyToSearch(search) end
function CraftingFilter:SetHidden(hidden) end
function ZO_TradingHouse_EnchantmentFilters:New(...) end
function ZO_TradingHouse_EnchantmentFilters:Initialize(parentControl) end
function ZO_TradingHouse_EnchantmentFilters:SetEnchantmentType(enchantmentType) end
function ZO_TradingHouse_EnchantmentFilters:SetAnchor(point, relativeTo, relativePoint, offsetX, offsetY) end
function ZO_TradingHouse_EnchantmentFilters:SetHidden(hidden) end
function GemFilter:New(...) end
function GemFilter:Initialize(parentControl) end
function GemFilter:ApplyToSearch(search) end
function GemFilter:SetHidden(hidden) end
function GuildItemsFilter:New() end
function GuildItemsFilter:Initialize() end
function MiscellaneousFilter:New(...) end
function MiscellaneousFilter:Initialize(parentControl) end
function MiscellaneousFilter:ApplyToSearch(search) end
function ZO_TradingHouse_SortComboBoxEntries(entryData, sortType, sortOrder, anchorFirstEntry, anchorLastEntry) end
function ZO_TradingHouse_InitializeRangeComboBox(control, entryData, callback, interfaceColorType, colorIndex) end
function ZO_TradingHouse_UpdateComboBox(control, entryData, callback) end
function ZO_TradingHouseFilter:New(...) end
function ZO_TradingHouseFilter:Initialize() end
function ZO_TradingHouseFilter:GetControl() end
function ZO_TradingHouseFilter:SetHidden() end
function ZO_TradingHouseFilter:ApplyToSearch() end
function ZO_TradingHouseFilter:Reset() end
function ZO_TradingHouseMultiFilter:New(...) end
function ZO_TradingHouseMultiFilter:Initialize(control) end
function ZO_TradingHouseMultiFilter:GetControl() end
function ZO_TradingHouseMultiFilter:SetHidden(hidden) end
function ZO_TradingHouseMultiFilter:Reset() end
function ZO_TradingHouseManager:New(...) end
function ZO_TradingHouseManager:Initialize(control) end
function ZO_TradingHouseManager:InitializeScene() end
function ZO_TradingHouseManager:InitializeKeybindDescriptor() end
function ZO_TradingHouseManager:InitializeMenuBar(control) end
function ZO_TradingHouseManager:HandleTabSwitch(tabData) end
function ZO_TradingHouseManager:HasValidPendingItemPost() end
function ZO_TradingHouseManager:HasEnoughMoneyToPostPendingItem() end
function ZO_TradingHouseManager:CanPost() end
function ZO_TradingHouseManager:CanPostWithMoneyCheck() end
function ZO_TradingHouseManager:InitializePostItem(control) end
function ZO_TradingHouseManager:InitializeBrowseItems(control) end
function ZO_TradingHouseManager:InitializeSearchSortHeaders(control) end
function ZO_TradingHouseManager:InitializeSearchNavigationBar(control) end
function ZO_TradingHouseManager:ToggleLevelRangeMode() end
function ZO_TradingHouseManager:InitializeSearchTerms() end
function ZO_TradingHouseManager:InitializeSearchResults(control) end
function ZO_TradingHouseManager:InitializeListings(control) end
function ZO_TradingHouseManager:RequestListings() end
function ZO_TradingHouseManager:OnListingsRequestSuccess() end
function ZO_TradingHouseManager:RefreshListingsIfNecessary() end
function ZO_TradingHouseManager:OnPendingPostItemUpdated(slotId, isPending) end
function ZO_TradingHouseManager:OnPostSuccess() end
function ZO_TradingHouseManager:UpdateListingCounts() end
function ZO_TradingHouseManager:SetInvoicePriceColors(color) end
function ZO_TradingHouseManager:SetPendingPostPrice(sellPrice) end
function ZO_TradingHouseManager:GetPendingPostPrice() end
function ZO_TradingHouseManager:SetupPendingPost() end
function ZO_TradingHouseManager:ClearPendingPost() end
function ZO_TradingHouseManager:PostPendingItem() end
function ZO_TradingHouseManager:ChangeSort(key, order) end
function ZO_TradingHouseManager:QueueListingRequest() end
function ZO_TradingHouseManager:OnAwaitingResponse(responseType) end
function ZO_TradingHouseManager:OnResponseReceived(responseType, result) end
function ZO_TradingHouseManager:UpdateItemsLabels(numItems) end
function ZO_TradingHouseManager:RebuildSearchResultsPage() end
function ZO_TradingHouseManager:AddGuildSpecificItems(ignoreFiltering) end
function ZO_TradingHouseManager:OnSearchResultsReceived(guildId, numItemsOnPage, currentPage, hasMorePages) end
function ZO_TradingHouseManager:UpdatePagingButtons() end
function ZO_TradingHouseManager:UpdateSortHeaders() end
function ZO_TradingHouseManager:OnPurchaseSuccess() end
function ZO_TradingHouseManager:ClearSearchResults() end
function ZO_TradingHouseManager:ClearListedItems() end
function ZO_TradingHouseManager:ResetAllSearchData() end
function ZO_TradingHouseManager:OpenTradingHouse() end
function ZO_TradingHouseManager:CloseTradingHouse() end
function ZO_TradingHouseManager:UpdateStatus() end
function ZO_TradingHouseManager:OnOperationTimeout() end
function ZO_TradingHouseManager:OnSearchCooldownUpdate(cooldownMilliseconds) end
function ZO_TradingHouseManager:UpdateForGuildChange() end
function ZO_TradingHouseManager:ConfirmPendingPurchase(pendingPurchaseIndex) end
function ZO_TradingHouseManager:ConfirmPendingGuildSpecificPurchase(guildSpecificItemIndex) end
function ZO_TradingHouseManager:HandleGuildSpecificPurchase(guildSpecificItemIndex) end
function ZO_TradingHouseManager:ShowCancelListingConfirmation(listingIndex) end
function ZO_TradingHouseManager:CanBuyItem(inventorySlot) end
function ZO_TradingHouseManager:VerifyBuyItemAndShowErrors(inventorySlot) end
function ZO_TradingHouseManager:RunInitialSetup(control) end
function ZO_TradingHouseManager:BeginSetPendingPostPrice(anchorTo) end
function ZO_TradingHouseManager:AllowSearch() end
function ZO_TradingHouse_Shared:InitializeFilterFactory(entry, filterFactory) end
function ZO_TradingHouse_OnInitialized(self) end
function ZO_TradingHouse_TraitFilters:New(...) end
function ZO_TradingHouse_TraitFilters:Initialize(parentControl) end
function ZO_TradingHouse_TraitFilters:SetTraitType(traitType) end
function ZO_TradingHouse_TraitFilters:SetAnchor(point, relativeTo, relativePoint, offsetX, offsetY) end
function ZO_TradingHouse_TraitFilters:SetHidden(hidden) end
function WeaponFilter:New(...) end
function WeaponFilter:Initialize(parentControl) end
function WeaponFilter:ApplyToSearch(search) end
function WeaponFilter:SetHidden(hidden) end
function ZO_TradingHouse_SortComboBoxEntries(entryData, sortType, sortOrder, anchorFirstEntry, anchorLastEntry) end
function ZO_TradingHouseFilter_GenerateArmorTypeData(SetGenericArmorSearch) end
function ZO_TradingHouseFilter_Shared_GetCraftingSearches() end
function ZO_TradingHouseFilter_Shared_GetGemHasEnchantments(enchantmentType) end
function ZO_TradingHouseFilter_Shared_InitializeData() end
function ZO_TradingHouse_CreateItemData(index, fn) end
function ZO_TradingHouse_Singleton:New(...) end
function ZO_TradingHouse_Singleton:Initialize() end
function ZO_TradingHouseSearchFieldSetter:New(...) end
function ZO_TradingHouseSearchFieldSetter:Initialize(filterType) end
function ZO_TradingHouseSearchFieldSetter:ApplyToSearch(searchObject) end
function ZO_TradingHouseSearchFieldSetter:GetValues() end
function ZO_TradingHouseComboBoxSetter:Initialize(filterType, comboBoxObject) end
function ZO_TradingHouseComboBoxSetter:ApplyToSearch(searchObject) end
function ZO_TradingHouse_NumericRangeSetter:New(...) end
function ZO_TradingHouse_NumericRangeSetter:Initialize(filterType, minEditControl, maxEditControl) end
function ZO_TradingHouse_NumericRangeSetter:ApplyToSearch(searchObject) end
function ZO_TradingHouse_Shared:New(...) end
function ZO_TradingHouse_Shared:Initialize(control) end
function ZO_TradingHouse_Shared:IsAtTradingHouse() end
function ZO_TradingHouse_Shared:CanDoCommonOperation() end
function ZO_TradingHouse_Shared:CanSearch() end
function ZO_TradingHouse_Shared:GetCurrentMode() end
function ZO_TradingHouse_Shared:SetCurrentMode(mode) end
function ZO_TradingHouse_Shared:IsInSellMode() end
function ZO_TradingHouse_Shared:IsInSearchMode() end
function ZO_TradingHouse_Shared:IsInListingsMode() end
function ZO_TradingHouse_Shared:IsAwaitingResponse() end
function ZO_TradingHouse_Shared:IsWaitingForResponseType(responseType) end
function ZO_TradingHouse_Shared:InitializeSharedEvents() end
function ZO_TradingHouse_Shared:SetSearchItemCategory(_, _, entry, selectionChanged) end
function ZO_TradingHouse_Shared:InitializeCategoryComboBox(comboBox, callback, selectFirstItem) end
function ZO_TradingHouse_Shared:HandleSearchCriteriaChanged(changed) end
function ZO_TradingHouse_Shared:RegisterSearchFilter(factory, stringId) end
function ZO_TradingHouse_Shared:InitializeEntryFilter(entry, filterStringId) end
function ZO_TradingHouse_Shared:GetSearchActiveFilter() end
function ZO_TradingHouse_Shared:SetSearchActiveFilter(filter) end
function ZO_TradingHouse_Shared:GetTraitFilters() end
function ZO_TradingHouse_Shared:GetEnchantmentFilters() end
function ZO_TradingHouse_Shared:DoSearch() end
function ZO_TradingHouse_Shared:CreateGuildSpecificItemData(index, fn) end
function ZO_TradingHouse_Shared:ShouldAddGuildSpecificItemToList(itemData) end
function ZO_TradingHouse_Shared:InitializeSearchTerms() end
function ZO_TradingHouse_Shared:AllowSearch() end
function ZO_TradingHouse_Shared:AddGuildSpecificItems(ignoreFiltering) end
function ZO_TradingHouse_Shared:UpdateForGuildChange() end
function ZO_TradingHouse_Shared:CloseTradingHouse() end
function ZO_TradingHouse_Shared:InitializeFilterFactory(entry, filterFactory, filterStringId) end
function ZO_TradingHouse_FinishLocalString(sString) end
function ZO_TradingHouse_GetComboBoxString(stringData) end
function ZO_TradingHouse_SearchCriteriaChanged(changed) end
function ZO_TradingHouse_InitializeCategoryComboBox(...) end
function ZO_TradingHouse_InitializeColoredComboBox(comboBox, entryData, callback, interfaceColorType, colorIndex, selectFirstItem) end
function ZO_TradingHouse_ComboBoxSelectionChanged(_, _, _, selectionChanged) end
function ZO_TradingHouseSearch:New(...) end
function ZO_TradingHouseSearch:Initialize() end
function ZO_TradingHouseSearch:ResetAllSearchData() end
function ZO_TradingHouseSearch:InitializeOrderingData() end
function ZO_TradingHouseSearch:ResetSearchData() end
function ZO_TradingHouseSearch:SetPageData(currentPage, hasMorePages) end
function ZO_TradingHouseSearch:ResetPageData() end
function ZO_TradingHouseSearch:HasPreviousPage() end
function ZO_TradingHouseSearch:HasNextPage() end
function ZO_TradingHouseSearch:SetFilter(filterType, ...) end
function ZO_TradingHouseSearch:AddSetter(setterObject) end
function ZO_TradingHouseSearch:GetActiveFilter() end
function ZO_TradingHouseSearch:SetActiveFilter(filterObject) end
function ZO_TradingHouseSearch:DoSearch() end
function ZO_TradingHouseSearch:SearchNextPage() end
function ZO_TradingHouseSearch:SearchPreviousPage() end
function ZO_TradingHouseSearch:UpdateSortOption(sortKey, sortOrder) end
function ZO_TradingHouseSearch:ChangeSort(sortKey, sortOrder) end
function ZO_TradingHouseSearch:InternalExecuteSearch() end
--ingame\treasuremap
function TreasureMap:New(...) end
function TreasureMap:Initialize(control) end
function TreasureMap:OnShowTreasureMap(eventCode, treasureMapIndex) end
function ZO_TreasureMap_OnInitialize(control) end
--ingame\trialaccount
function TrialAccountSplashDialog:New(...) end
function TrialAccountSplashDialog:Initialize(control) end
function TrialAccountSplashDialog:RemoveSplash() end
function ZO_TrialAccountSplashDialog_OnInitialized(control) end
function ZO_TrialAccount_GetInfo() end
function ZO_TrialAccount_SetSeenVersion(accountTypeId, seenVersion) end
--ingame\tutorial
function ZO_BriefHudTutorial:Initialize(parent) end
function ZO_BriefHudTutorial:SetHidden(hide) end
function ZO_BriefHudTutorial:GetTutorialType() end
function ZO_BriefHudTutorial:SuppressTutorials(suppress, reason) end
function ZO_BriefHudTutorial:DisplayTutorial(tutorialIndex) end
function ZO_BriefHudTutorial:OnDisplayTutorial(tutorialIndex, priority) end
function ZO_BriefHudTutorial:RemoveTutorial(tutorialIndex) end
function ZO_BriefHudTutorial:OnUpdate() end
function ZO_BriefHudTutorial:ClearAll() end
function ZO_HudInfoTutorial:Initialize(parent) end
function ZO_HudInfoTutorial:SetupTutorial(parent, template, name) end
function ZO_HudInfoTutorial:GetTutorialType() end
function ZO_HudInfoTutorial:DisplayTutorial(tutorialIndex) end
function ZO_HudInfoTutorial:RemoveTutorial(tutorialIndex) end
function ZO_HudInfoTutorial:SetHidden(hide) end
function ZO_HudInfoTutorial:OnUpdate() end
function ZO_HudInfoTutorial:ClearAll() end
function ZO_HudInfoTutorial:ShowHelp() end
function ZO_Tutorials:New(...) end
function ZO_Tutorials:Initialize(control) end
function ZO_Tutorials:DisplayOrQueueTutorial(tutorialIndex, priority) end
function ZO_Tutorials:AddTutorialHandler(handler) end
function ZO_Tutorials:SuppressTutorialType(tutorialType, suppress, reason) end
function ZO_Tutorials:OnTutorialEnabledStateChanged(enabled) end
function ZO_Tutorials:ForceRemoveAll() end
function ZO_Tutorials:OnDisplayTutorial(tutorialIndex) end
function ZO_Tutorials:OnRemoveTutorial(tutorialIndex) end
function ZO_Tutorials:ShowHelp() end
function ZO_Tutorial_Initialize(control) end
function ZO_TutorialHandlerBase:New(...) end
function ZO_TutorialHandlerBase:Initialize(...) end
function ZO_TutorialHandlerBase:GetTutorialType() end
function ZO_TutorialHandlerBase:ClearAll() end
function ZO_TutorialHandlerBase:ShowHelp() end
function ZO_TutorialHandlerBase:SetHidden(hide) end
function ZO_TutorialHandlerBase:SetHiddenForReason(reason, hidden) end
function ZO_TutorialHandlerBase:SuppressTutorials(suppress, reason) end
function ZO_TutorialHandlerBase:CanShowTutorial() end
function ZO_TutorialHandlerBase:OnDisplayTutorial(tutorialIndex, priority) end
function ZO_TutorialHandlerBase:OnRemoveTutorial(tutorialIndex) end
function ZO_TutorialHandlerBase:SetCurrentlyDisplayedTutorialIndex(currentlyDisplayedTutorialIndex) end
function ZO_TutorialHandlerBase:GetCurrentlyDisplayedTutorialIndex() end
function ZO_TutorialHandlerBase:IsTutorialDisplayedOrQueued(tutorialIndex) end
function ZO_TutorialHandlerBase:IsTutorialQueued(tutorialIndex) end
function ZO_TutorialHandlerBase:RemoveFromQueue(tutorialIndex) end
function ZO_Tutorial_GetTriggerHandlers() end
function ZO_UiInfoBoxTutorial:Initialize() end
function ZO_UiInfoBoxTutorial:GetDialog() end
function ZO_UiInfoBoxTutorial:SuppressTutorials(suppress, reason) end
function ZO_UiInfoBoxTutorial:GetTutorialType() end
function ZO_UiInfoBoxTutorial:DisplayTutorial(tutorialIndex) end
function ZO_UiInfoBoxTutorial:OnDisplayTutorial(tutorialIndex, priority) end
function ZO_UiInfoBoxTutorial:OnRemoveTutorial(tutorialIndex) end
function ZO_UiInfoBoxTutorial:RemoveTutorial(tutorialIndex, seen) end
function ZO_UiInfoBoxTutorial:ClearAll() end
--ingame\uicombatoverlay
function UICombatOverlay:New(control) end
function UICombatOverlay:Refresh() end
function ZO_UICombatOverlay_OnInitialized(control) end
--ingame\unitattributevisualizer
function ZO_UnitVisualizer_ArmorDamage:New(...) end
function ZO_UnitVisualizer_ArmorDamage:Initialize(layoutData) end
function ZO_UnitVisualizer_ArmorDamage:CreateInfoTable(control, stat, attribute, power, playIncreaseAnimation, playDecreaseAnimation) end
function ZO_UnitVisualizer_ArmorDamage:OnAdded(healthBarControl, magickaBarControl, staminaBarControl) end
function ZO_UnitVisualizer_ArmorDamage:InitializeBarValues() end
function ZO_UnitVisualizer_ArmorDamage:OnUnitChanged() end
function ZO_UnitVisualizer_ArmorDamage:IsUnitVisualRelevant(visualType, stat, attribute, powerType) end
function ZO_UnitVisualizer_ArmorDamage:OnUnitAttributeVisualAdded(visualType, stat, attribute, powerType, value) end
function ZO_UnitVisualizer_ArmorDamage:OnUnitAttributeVisualUpdated(visualType, stat, attribute, powerType, oldValue, newValue) end
function ZO_UnitVisualizer_ArmorDamage:OnUnitAttributeVisualRemoved(visualType, stat, attribute, powerType, value) end
function ZO_UnitVisualizer_ArmorDamage:PlayArmorIncreaseAnimation(bar, info, instant) end
function ZO_UnitVisualizer_ArmorDamage:PlayArmorDecreaseAnimation(bar, info, instant) end
function ZO_UnitVisualizer_ArmorDamage:UpdateDecreasedArmorEffect(bar, info, instant, decreasedArmorOverlay) end
function ZO_UnitVisualizer_ArmorDamage:PlayPowerIncreaseAnimation(bar, info, instant) end
function ZO_UnitVisualizer_ArmorDamage:PlayPowerDecreaseAnimation(bar, info, instant) end
function ZO_UnitVisualizer_ArmorDamage:OnValueChanged(bar, info, stat, instant) end
function ZO_UnitVisualizer_ArmorDamage:ApplyPlatformStyle() end
function ZO_UnitVisualizer_ArrowRegenerationModule:New(...) end
function ZO_UnitVisualizer_ArrowRegenerationModule:Initialize() end
function ZO_UnitVisualizer_ArrowRegenerationModule:OnAdded(healthBarControl, magickaBarControl, staminaBarControl) end
function ZO_UnitVisualizer_ArrowRegenerationModule:InitializeBarValues() end
function ZO_UnitVisualizer_ArrowRegenerationModule:OnUnitChanged() end
function ZO_UnitVisualizer_ArrowRegenerationModule:IsUnitVisualRelevant(visualType, stat, attribute, powerType) end
function ZO_UnitVisualizer_ArrowRegenerationModule:OnUnitAttributeVisualAdded(visualType, stat, attribute, powerType, value) end
function ZO_UnitVisualizer_ArrowRegenerationModule:OnUnitAttributeVisualUpdated(visualType, stat, attribute, powerType, oldValue, newValue) end
function ZO_UnitVisualizer_ArrowRegenerationModule:OnUnitAttributeVisualRemoved(visualType, stat, attribute, powerType, value) end
function ZO_UnitVisualizer_ArrowRegenerationModule:PlaySound(stat, increasing, hadOppositeEffect, noEffects) end
function ZO_UnitVisualizer_ArrowRegenerationModule:OnValueChanged(info, bar, oldValue, stat) end
function ZO_UnitVisualizer_ArrowRegenerationModule:Pulse() end
function ZO_UnitVisualizer_ArrowRegenerationModule:GetNumArrowsByStat(stat, value) end
function ZO_UnitVisualizer_ArrowRegenerationModule:AcquireArrow(bar) end
function ZO_UnitVisualizer_ArrowRegenerationModule:PlayLeftArrow(bar, forward, widthModifier, takeControl) end
function ZO_UnitVisualizer_ArrowRegenerationModule:PlayRightArrow(bar, forward, widthModifier, takeControl) end
function ZO_UnitVisualizer_ArrowRegenerationModule:PlayArrow(bar, stat, value, takeControl) end
function ZO_UnitVisualizer_ArrowRegenerationModule:ApplyPlatformStyle() end
function ZO_UnitVisualizer_PossessionModule:New(...) end
function ZO_UnitVisualizer_PossessionModule:Initialize(layoutData) end
function ZO_UnitVisualizer_PossessionModule:CreateInfoTable(control, stat, attribute, power, playPossessionAnimation) end
function ZO_UnitVisualizer_PossessionModule:OnAdded(healthBarControl, magickaBarControl, staminaBarControl) end
function ZO_UnitVisualizer_PossessionModule:InitializeBarValues() end
function ZO_UnitVisualizer_PossessionModule:OnUnitChanged() end
function ZO_UnitVisualizer_PossessionModule:IsUnitVisualRelevant(visualType, stat, attribute, powerType) end
function ZO_UnitVisualizer_PossessionModule:OnUnitAttributeVisualAdded(visualType, stat, attribute, powerType, value) end
function ZO_UnitVisualizer_PossessionModule:OnUnitAttributeVisualUpdated(visualType, stat, attribute, powerType, oldValue, newValue) end
function ZO_UnitVisualizer_PossessionModule:OnUnitAttributeVisualRemoved(visualType, stat, attribute, powerType, value) end
function ZO_UnitVisualizer_PossessionModule:PlayPossessionAnimation(bar, info, instant) end
function ZO_UnitVisualizer_PossessionModule:OnValueChanged(bar, info, stat, instant) end
function ZO_UnitVisualizer_PossessionModule:ApplyPlatformStyle() end
function ZO_UnitVisualizer_PowerShieldModule:New(...) end
function ZO_UnitVisualizer_PowerShieldModule:Initialize(layoutData) end
function ZO_UnitVisualizer_PowerShieldModule:CreateInfoTable(control, oldBarInfo, stat, attribute, power) end
function ZO_UnitVisualizer_PowerShieldModule:OnAdded(healthBarControl, magickaBarControl, staminaBarControl) end
function ZO_UnitVisualizer_PowerShieldModule:InitializeBarValues() end
function ZO_UnitVisualizer_PowerShieldModule:OnUnitChanged() end
function ZO_UnitVisualizer_PowerShieldModule:OnUpdate() end
function ZO_UnitVisualizer_PowerShieldModule:IsUnitVisualRelevant(visualType, stat, attribute, powerType) end
function ZO_UnitVisualizer_PowerShieldModule:OnUnitAttributeVisualAdded(visualType, stat, attribute, powerType, value, maxValue) end
function ZO_UnitVisualizer_PowerShieldModule:OnUnitAttributeVisualUpdated(visualType, stat, attribute, powerType, oldValue, newValue, oldMaxValue, newMaxValue) end
function ZO_UnitVisualizer_PowerShieldModule:OnUnitAttributeVisualRemoved(visualType, stat, attribute, powerType, value, maxValue) end
function ZO_UnitVisualizer_PowerShieldModule:PlayAnimation(bar, info) end
function ZO_UnitVisualizer_PowerShieldModule:OnStatusBarValueChanged(bar, info) end
function ZO_UnitVisualizer_PowerShieldModule:UpdateValue(bar, info) end
function ZO_UnitVisualizer_PowerShieldModule:OnValueChanged(bar, info) end
function ZO_UnitVisualizer_PowerShieldModule:ApplyPlatformStyle() end
function ZO_UnitVisualizer_ShrinkExpandModule:New(...) end
function ZO_UnitVisualizer_ShrinkExpandModule:Initialize(normalWidth, expandedWidth, shrunkWidth) end
function ZO_UnitVisualizer_ShrinkExpandModule:CreateAnimation(control, stat) end
function ZO_UnitVisualizer_ShrinkExpandModule:CreateInfoTable(control, oldBarInfo, stat, attribute, power) end
function ZO_UnitVisualizer_ShrinkExpandModule:OnAdded(healthBarControl, magickaBarControl, staminaBarControl) end
function ZO_UnitVisualizer_ShrinkExpandModule:InitializeBarValues() end
function ZO_UnitVisualizer_ShrinkExpandModule:OnUnitChanged() end
function ZO_UnitVisualizer_ShrinkExpandModule:IsUnitVisualRelevant(visualType, stat, attribute, powerType) end
function ZO_UnitVisualizer_ShrinkExpandModule:OnUnitAttributeVisualAdded(visualType, stat, attribute, powerType, value) end
function ZO_UnitVisualizer_ShrinkExpandModule:OnUnitAttributeVisualUpdated(visualType, stat, attribute, powerType, oldValue, newValue) end
function ZO_UnitVisualizer_ShrinkExpandModule:OnUnitAttributeVisualRemoved(visualType, stat, attribute, powerType, value) end
function ZO_UnitVisualizer_ShrinkExpandModule:TryChangingState(bar, info) end
function ZO_UnitVisualizer_ShrinkExpandModule:OnValueChanged(bar, info, stat, instant) end
function ZO_UnitAttributeVisualizerModuleBase:New(...) end
function ZO_UnitAttributeVisualizerModuleBase:GetModuleId() end
function ZO_UnitAttributeVisualizerModuleBase:SetOwner(owner) end
function ZO_UnitAttributeVisualizerModuleBase:GetOwner() end
function ZO_UnitAttributeVisualizerModuleBase:GetUnitTag() end
function ZO_UnitAttributeVisualizerModuleBase:Initialize(...) end
function ZO_UnitAttributeVisualizerModuleBase:IsUnitVisualRelevant(visualType, stat, attribute, powerType) end
function ZO_UnitAttributeVisualizerModuleBase:OnAdded(healthBarControl, magickaBarControl, staminaBarControl) end
function ZO_UnitAttributeVisualizerModuleBase:OnUnitAttributeVisualAdded(visualType, stat, attribute, powerType, value, maxValue) end
function ZO_UnitAttributeVisualizerModuleBase:OnUnitAttributeVisualUpdated(visualType, stat, attribute, powerType, oldValue, newValue, oldMaxValue, newMaxValue) end
function ZO_UnitAttributeVisualizerModuleBase:OnUnitAttributeVisualRemoved(visualType, stat, attribute, powerType, value, maxValue) end
function ZO_UnitAttributeVisualizerModuleBase:OnUnitChanged() end
function ZO_UnitAttributeVisualizerModuleBase:ApplyPlatformStyle() end
function ZO_UnitVisualizer_UnwaveringModule:New(...) end
function ZO_UnitVisualizer_UnwaveringModule:Initialize(layoutData) end
function ZO_UnitVisualizer_UnwaveringModule:CreateInfoTable(control, oldBarInfo, stat, attribute, power) end
function ZO_UnitVisualizer_UnwaveringModule:OnAdded(healthBarControl, magickaBarControl, staminaBarControl) end
function ZO_UnitVisualizer_UnwaveringModule:InitializeBarValues() end
function ZO_UnitVisualizer_UnwaveringModule:OnUnitChanged() end
function ZO_UnitVisualizer_UnwaveringModule:IsUnitVisualRelevant(visualType, stat, attribute, powerType) end
function ZO_UnitVisualizer_UnwaveringModule:OnUnitAttributeVisualAdded(visualType, stat, attribute, powerType, value) end
function ZO_UnitVisualizer_UnwaveringModule:OnUnitAttributeVisualUpdated(visualType, stat, attribute, powerType, oldValue, newValue) end
function ZO_UnitVisualizer_UnwaveringModule:OnUnitAttributeVisualRemoved(visualType, stat, attribute, powerType, value) end
function ZO_UnitVisualizer_UnwaveringModule:PlayAnimation(bar, info, instant) end
function ZO_UnitVisualizer_UnwaveringModule:OnValueChanged(bar, info, instant) end
function ZO_UnitVisualizer_UnwaveringModule:ApplyPlatformStyle() end
function ZO_UnitAttributeVisualizer:New(...) end
function ZO_UnitAttributeVisualizer:Initialize(unitTag, soundTable, healthBarControl, magickaBarControl, staminaBarControl, externalControlCallback) end
function ZO_UnitAttributeVisualizer:OnUnitChanged() end
function ZO_UnitAttributeVisualizer:AddModule(module) end
function ZO_UnitAttributeVisualizer:NotifyTakingControlOf(control) end
function ZO_UnitAttributeVisualizer:NotifyEndingControlOf(control) end
function ZO_UnitAttributeVisualizer:GetUnitTag() end
function ZO_UnitAttributeVisualizer:OnUnitAttributeVisualAdded(unitTag, visualType, stat, attribute, powerType, value, maxValue) end
function ZO_UnitAttributeVisualizer:OnUnitAttributeVisualUpdated(unitTag, visualType, stat, attribute, powerType, oldValue, newValue, oldMaxValue, newMaxValue) end
function ZO_UnitAttributeVisualizer:OnUnitAttributeVisualRemoved(unitTag, visualType, stat, attribute, powerType, value, maxValue) end
function ZO_UnitAttributeVisualizer:PlaySoundFromStat(stat, state) end
function ZO_UnitAttributeVisualizer:ApplyPlatformStyle() end
--ingame\unitframes
function BossBar:New(...) end
function BossBar:Initialize(control) end
function BossBar:ApplyStyle() end
function BossBar:OnGamepadPreferredModeChanged() end
function BossBar:AddBoss(unitTag) end
function BossBar:RemoveBoss(unitTag) end
function BossBar:RefreshBossHealth(unitTag) end
function BossBar:RefreshBossHealthBar(smoothAnimate) end
function BossBar:RefreshAllBosses() end
function BossBar:OnPowerUpdate(unitTag, powerType) end
function BossBar:OnPlayerActivated() end
function BossBar:OnInterfaceSettingChanged(settingSystem, settingId) end
function ZO_BossBar_OnInitialized(self) end
function UnitFramesManager:New() end
function UnitFramesManager:ApplyVisualStyle() end
function UnitFramesManager:GetUnitFrameLookupTable(unitTag) end
function UnitFramesManager:GetFrame(unitTag) end
function UnitFramesManager:CreateFrame(unitTag, anchors, showBarText, style) end
function UnitFramesManager:SetFrameHiddenForReason(unitTag, reason, hidden) end
function UnitFramesManager:SetGroupSize(groupSize) end
function UnitFramesManager:GetFirstDirtyGroupIndex() end
function UnitFramesManager:GetIsDirty() end
function UnitFramesManager:SetGroupIndexDirty(groupIndex) end
function UnitFramesManager:ClearDirty() end
function UnitFramesManager:DisableGroupAndRaidFrames() end
function UnitFramesManager:SetGroupAndRaidFramesHiddenForReason(reason, hidden) end
function UnitFramesManager:UpdateGroupAnchorFrames() end
function UnitFramesManager:IsTargetOfTargetEnabled() end
function UnitFramesManager:SetEnableTargetOfTarget(enableFlag) end
function UnitFrameBar:New(baseBarName, parent, showFrameBarText, style, mechanic) end
function UnitFrameBar:Update(barType, cur, max, forceInit) end
function UnitFrameBar:UpdateText(updateBarType, updateValue) end
function UnitFrameBar:SetMouseInside(inside) end
function UnitFrameBar:SetColor(barType) end
function UnitFrameBar:Hide(hidden) end
function UnitFrameBar:SetAlpha(alpha) end
function UnitFrameBar:GetBarControls() end
function UnitFrameBar:SetBarTextMode(alwaysShow) end
function UnitFrame:New(unitTag, anchors, showBarText, style) end
function UnitFrame:ApplyVisualStyle() end
function UnitFrame:SetAnimateShowHide(animate) end
function UnitFrame:AddFadeComponent(name, setColor) end
function UnitFrame:SetTextIndented(isIndented) end
function UnitFrame:SetAnchor(anchors) end
function UnitFrame:SetBuffTracker(buffTracker) end
function UnitFrame:SetHiddenForReason(reason, hidden) end
function UnitFrame:SetHasTarget(hasTarget) end
function UnitFrame:ComputeHidden() end
function UnitFrame:RefreshVisible(instant) end
function UnitFrame:RefreshControls() end
function UnitFrame:RefreshUnit(unitChanged) end
function UnitFrame:SetBarsHidden(hidden) end
function UnitFrame:IsHidden() end
function UnitFrame:GetUnitTag() end
function UnitFrame:GetPrimaryControl() end
function UnitFrame:DoAlphaUpdate(isNearby, isOnline, isLeader) end
function UnitFrame:GetBuffTracker() end
function UnitFrame:UpdatePowerBar(index, powerType, cur, max, forceInit) end
function UnitFrame:ShouldShowLevel() end
function UnitFrame:UpdateLevel() end
function UnitFrame:UpdateRank() end
function UnitFrame:UpdateRole() end
function UnitFrame:SetPlatformDifficultyTextures(difficulty) end
function UnitFrame:UpdateDifficulty() end
function UnitFrame:UpdateUnitReaction() end
function UnitFrame:UpdateName() end
function UnitFrame:UpdateCaption() end
function UnitFrame:UpdateStatus(isDead, isOnline) end
function UnitFrame:SetBarMouseInside(inside) end
function UnitFrame:HandleMouseEnter() end
function UnitFrame:HandleMouseExit() end
function UnitFrame:SetBarTextMode(alwaysShow) end
function UnitFrame:CreateAttributeVisualizer(soundTable) end
function ZO_UnitFrames_UpdateWindow(unitTag, unitChanged) end
function UnitFrame_HandleMouseReceiveDrag(frame) end
function UnitFrame_HandleMouseUp(frame, button, upInside) end
function UnitFrame_HandleMouseEnter(frame) end
function UnitFrame_HandleMouseExit(frame) end
function ZO_UnitFrames_GetUnitFrame(unitTag) end
function ZO_UnitFrames_SetEnableTargetOfTarget(enabled) end
function ZO_UnitFrames_IsTargetOfTargetEnabled() end
function ZO_UnitFrames_Initialize() end
function ZO_UnitFrames_OnUpdate() end
--ingame\utility
function RunHandlers(handlerTable, slot, ...) end
function RunClickHandlers(handlerTable, slot, buttonId, ...) end
--ingame\voicechat
function ZO_VoiceChatChannelsGamepad:New(...) end
function ZO_VoiceChatChannelsGamepad:Initialize(control) end
function ZO_VoiceChatChannelsGamepad:InitializeHeaders() end
function ZO_VoiceChatChannelsGamepad:InitializeFragment(control) end
function ZO_VoiceChatChannelsGamepad:InitializeEvents() end
function ZO_VoiceChatChannelsGamepad:PopulateChannels() end
function ZO_VoiceChatChannelsGamepad:PopulateHistory() end
function ZO_VoiceChatChannelsGamepad:RefreshHeaderData() end
function ZO_VoiceChatChannelsGamepad:UpdateKeybinds() end
function ZO_VoiceChatChannelsGamepad:UpdateParticipantsPanel() end
function ZO_VoiceChatChannelsGamepad:IsHidden() end
function ZO_VoiceChatChannelsGamepad:SetupList(list) end
function ZO_VoiceChatChannelsGamepad:OnSelectionChanged(list, selectedData, oldSelectedData) end
function ZO_VoiceChatChannelsGamepad:OnShowing() end
function ZO_VoiceChatChannelsGamepad:OnHiding() end
function ZO_VoiceChatHUD_Gamepad:RegisterForProgressBarEvents() end
function ZO_VoiceChatHUDGamepad_OnInitialize(control) end
function ZO_VoiceChatHUDGamepad_OnUpdate(control) end
function ZO_VoiceChatParticipantsGamepad:New(...) end
function ZO_VoiceChatParticipantsGamepad:Initialize(control) end
function ZO_VoiceChatParticipantsGamepad:InitializeHeader() end
function ZO_VoiceChatParticipantsGamepad:InitializeFragment(control) end
function ZO_VoiceChatParticipantsGamepad:InitializeEvents() end
function ZO_VoiceChatParticipantsGamepad:SetChannel(channel) end
function ZO_VoiceChatParticipantsGamepad:IsHidden() end
function ZO_VoiceChatParticipantsGamepad:SetupList(list) end
function ZO_VoiceChatParticipantsGamepad:OnSelectionChanged(list, selectedData, oldSelectedData) end
function ZO_VoiceChatParticipantsGamepad:OnShowing() end
function ZO_VoiceChatParticipantsGamepad:PerformUpdate() end
function ZO_VoiceChatSocialOptions_Gamepad:New(...) end
function ZO_VoiceChatSocialOptions_Gamepad:Initialize(control) end
function ZO_VoiceChatSocialOptions_Gamepad:BuildInviteToGuildOption(guildIndex) end
function ZO_VoiceChatSocialOptions_Gamepad:SetupOptions(data) end
function ZO_VoiceChatSocialOptions_Gamepad:BuildOptionsList() end
function ZO_VoiceChat_Gamepad:New(...) end
function ZO_VoiceChat_Gamepad:Initialize(control) end
function ZO_VoiceChat_Gamepad:InitializeEventAlerts() end
function ZO_VoiceChatGamepad_OnInitialize(control) end
function ZO_VoiceChat_GetChannelDataFromName(channelName) end
function ZO_VoiceChat_IsNameLocalPlayers(displayName) end
function HistoryData:New() end
function HistoryData:UpdateUser(displayName) end
function HistoryData:UpdateUserMute(displayName, isMuted) end
function HistoryData:UpdateMutes(mutedUsers) end
function HistoryData:RemoveUser(displayName) end
function ParticipantsData:New(sortByOccurrence) end
function ParticipantsData:AddOrUpdateParticipant(displayName, speakStatus, isMuted) end
function ParticipantsData:RemoveParticipant(displayName) end
function ParticipantsData:GetParticipant(displayName) end
function ParticipantsData:GetParticipantIndex(displayName) end
function ParticipantsData:UpdateParticipantStatus(displayName, speakStatus, isMuted) end
function ParticipantsData:UpdateMutes(mutedUsers) end
function ParticipantsData:Size() end
function ParticipantsData:ClearParticipants() end
function ZO_VoiceChat_Manager:New() end
function ZO_VoiceChat_Manager:Initialize() end
function ZO_VoiceChat_Manager:RegisterForEvents() end
function ZO_VoiceChat_Manager:JoinChannel(channel) end
function ZO_VoiceChat_Manager:TransmitChannel(channel, skipDelay) end
function ZO_VoiceChat_Manager:LeaveChannel(channel) end
function ZO_VoiceChat_Manager:UpdateMutes() end
function ZO_VoiceChat_Manager:OnUpdate() end
function ZO_VoiceChat_Manager:AddGuildChannelRoom(channelName, guildId, guildRoomNumber) end
function ZO_VoiceChat_Manager:RemoveGuildChannelRoom(channelName, guildId, guildRoomNumber) end
function ZO_VoiceChat_Manager:RefreshGuildChannelIds() end
function ZO_VoiceChat_Manager:DoesChannelExist(channelData) end
function ZO_VoiceChat_Manager:GetGuildChannelByName(guildName, guildRoomNumber) end
function ZO_VoiceChat_Manager:SetDesiredPassiveChannel(channel) end
function ZO_VoiceChat_Manager:SetDesiredActiveChannel(channel) end
function ZO_VoiceChat_Manager:GetChannel(channelData) end
function ZO_VoiceChat_Manager:GetParticipantData(channel) end
function ZO_VoiceChat_Manager:GetParticipantDataList(channel) end
function ZO_VoiceChat_Manager:GetChannelData() end
function ZO_VoiceChat_Manager:AreRequestsAllowed() end
function ZO_VoiceChat_Manager:StartRequestDelay() end
function ZO_VoiceChat_Manager:HasChannelData() end
function ZO_VoiceChat_Manager:ClearAndSwapChannel(channel) end
function ZO_VoiceChat_Manager:SetAndSwapDesiredActiveChannel(desiredActiveChannel) end
function ZO_VoiceChat_Manager:GetDesiredActiveChannelType() end
--ingame\zo_currencyinput
function ZO_CurrencyInputObject:New(...) end
function ZO_CurrencyInputObject:Initialize(control, pulseAnimTemplate) end
function ZO_CurrencyInputObject:Reset() end
function ZO_CurrencyInputObject:SetUsePlayerCurrencyAsMax(usePlayerCurrencyAsMax) end
function ZO_CurrencyInputObject:IsUsingPlayerCurrencyAsMax() end
function ZO_CurrencyInputObject:SetMaxCurrency(maxCurrency) end
function ZO_CurrencyInputObject:GetMaxCurrency() end
function ZO_CurrencyInputObject:GetTotalCurrency() end
function ZO_CurrencyInputObject:GetTotalCurrencyAsText() end
function ZO_CurrencyInputObject:DoCallback(eventType) end
function ZO_CurrencyInputObject:SetCurrencyAmount(currency, eventType) end
function ZO_CurrencyInputObject:OnKeyDown(key, ctrl, alt, shift) end
function ZO_CurrencyInputObject:Show(callback, playerCurrencyAsMaxOrMaxCurrency, initialCurrencyAmount, currencyType, anchorTo, offsetX, offsetY) end
function ZO_CurrencyInputObject:SetContext(context) end
function ZO_CurrencyInputObject:GetContext() end
function ZO_CurrencyInputObject:Hide() end
function ZO_CurrencyInputObject:Confirm() end
function ZO_CurrencyInputObject:Cancel() end
function ZO_CurrencyInputObject:DecrementRefCount() end
function ZO_DefaultCurrencyInputField_Initialize(self, onCurrencyChanged, currencyType) end
function ZO_DefaultCurrencyInputField_SetUsePlayerCurrencyAsMax(self, usePlayerCurrencyAsMax) end
function ZO_DefaultCurrencyInputField_SetCurrencyMax(self, currencyMax) end
function ZO_DefaultCurrencyInputField_SetCurrencyMin(self, currencyMin) end
function ZO_DefaultCurrencyInputField_SetCurrencyAmount(self, currencyAmount) end
function ZO_DefaultCurrencyInputField_GetCurrency(self) end
--ingame\zo_loot
function ZO_Loot_Gamepad_Base:InitializeKeybindStripDescriptorsMixin(areEthereal) end
function ZO_Loot_Gamepad_Base:OnSelectionChanged(list, selectedData, oldSelectedData) end
function ZO_Loot_Gamepad_Base:HideTooltip() end
function ZO_Loot_Gamepad_Base:ShowTooltip(selectedData) end
function ZO_Loot_Gamepad_Base:LootTargeted() end
function ZO_Loot_Gamepad_Base:Show() end
function ZO_Loot_Gamepad_Base:HasLootItems() end
function ZO_Loot_Gamepad_Base:UpdateList() end
function ZO_Loot_Gamepad_Base:UpdateListAddLootCurrency(currencyType, currencyFormatString, currencyIcon, currencyAmount, isCurrencyStolen) end
function ZO_Loot_Gamepad_Base:UpdateListAddLootItems(numLootItems, addStolenItems) end
function ZO_Loot_Gamepad_Base:UpdateLootWindow(name, actionName, isOwned) end
function ZO_Loot_Gamepad_Base:EnoughRoomToTakeAll() end
function ZO_Loot_Gamepad_Base:UpdateButtonTextOnSelection(selectedData) end
function ZO_Loot_Gamepad_Base:UpdateAllControlText() end
function ZO_Loot_Common_Gamepad:UpdateLootWindow(name, actionName, isOwned) end
function ZO_Loot_Common_Gamepad:Hide() end
function ZO_Loot_Common_Gamepad:AreNonStolenItemsPresent() end
function ZO_LootHistory_Gamepad:New(...) end
function ZO_LootHistory_Gamepad:Initialize(control) end
function ZO_LootHistory_Gamepad:InitializeFragment() end
function ZO_LootHistory_Gamepad:InitializeFadingControlBuffer(control) end
function ZO_LootHistory_Gamepad:SetEntryTemplate() end
function ZO_LootHistory_Gamepad:CanShowItemsInHistory() end
function ZO_LootHistory_Gamepad:OnLootReceived(...) end
function ZO_LootHistory_Gamepad:OnGoldUpdate(...) end
function ZO_LootHistory_Gamepad:OnTelvarStoneUpdate(...) end
function ZO_LootHistory_Gamepad_OnInitialized(control) end
function ZO_LootInventory_Gamepad:New(...) end
function ZO_LootInventory_Gamepad:Initialize(control) end
function ZO_LootInventory_Gamepad:SetupList(list) end
function ZO_LootInventory_Gamepad:OnSelectionChanged(list, selectedData, oldSelectedData) end
function ZO_LootInventory_Gamepad:DeferredInitialize() end
function ZO_LootInventory_Gamepad:OnHide() end
function ZO_LootInventory_Gamepad:OnShow() end
function ZO_LootInventory_Gamepad:Hide() end
function ZO_LootInventory_Gamepad:Show() end
function ZO_LootInventory_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_LootInventory_Gamepad:SetTitle(title) end
function ZO_LootInventory_Gamepad:UpdateKeybindDescriptor() end
function ZO_LootInventory_Gamepad:PerformUpdate() end
function ZO_Gamepad_LootInventory_OnInitialize(control) end
function ZO_LootPickup_Gamepad:New(...) end
function ZO_LootPickup_Gamepad:Initialize(control) end
function ZO_LootPickup_Gamepad:DeferredInitialize() end
function ZO_LootPickup_Gamepad:OnShowing() end
function ZO_LootPickup_Gamepad:OnHide() end
function ZO_LootPickup_Gamepad:SetTitle(title) end
function ZO_LootPickup_Gamepad:UpdateButtonTextOnSelection(selectedData) end
function ZO_LootPickup_Gamepad:UpdateAllControlText() end
function ZO_LootPickup_Gamepad:Update(isOwned) end
function ZO_LootPickup_Gamepad:Hide() end
function ZO_LootPickup_Gamepad:Show() end
function ZO_LootPickup_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_LootPickup_Gamepad:InitializeHeader(title) end
function ZO_LootPickup_Gamepad_Initialize(control) end
function ZO_LootHistory_Keyboard:New(...) end
function ZO_LootHistory_Keyboard:Initialize(control) end
function ZO_LootHistory_Keyboard:InitializeFragment() end
function ZO_LootHistory_Keyboard:InitializeFadingControlBuffer(control) end
function ZO_LootHistory_Keyboard:SetEntryTemplate() end
function ZO_LootHistory_Shared:CanShowItemsInHistory() end
function ZO_LootHistory_Keyboard:OnLootReceived(...) end
function ZO_LootHistory_Keyboard:OnGoldUpdate(...) end
function ZO_LootHistory_Keyboard:OnTelvarStoneUpdate(...) end
function ZO_LootHistory_Keyboard_OnInitialized(control) end
function ZO_LootSceneFragment:New(control) end
function ZO_LootSceneFragment:AnimateNextShow() end
function ZO_LootSceneFragment:Show() end
function ZO_LootSceneFragment:Hide() end
function ZO_Loot:Initialize(control) end
function ZO_Loot:InitializeKeybindDescriptors() end
function ZO_Loot:SetUpLootItem(control, data) end
function ZO_Loot:SetUpBlankLootItem(control, data) end
function ZO_Loot:UpdateList() end
function ZO_Loot:UpdateListAddLootCurrency(scrollData, currencyType, currencyIcon, currencyAmount, isCurrencyStolen) end
function ZO_Loot:UpdateListAddLootItems(scrollData, numLootItems, addStolenItems) end
function ZO_Loot:Hide() end
function ZO_Loot:UpdateLootWindow(name, actionName, isOwned) end
function ZO_Loot:GetButtonByKeybind(keybind) end
function ZO_Loot:OnMouseOverUpdated(control, state) end
function ZO_Loot:UpdateAllControlText() end
function ZO_Loot:GetMouseOverLootItem() end
function ZO_Loot:LootSingleItem() end
function ZO_Loot:AreNonStolenItemsPresent() end
function ZO_Loot_Initialize(control) end
function ZO_LootActionButtonCallback_LootAll() end
function ZO_LootActionButtonCallback_LootItem() end
function ZO_Loot_ButtonKeybindPressed(keybind) end
function ZO_LootItemSlot_OnMouseEnter(control) end
function ZO_LootItemSlot_OnMouseExit(control) end
function LootHistory_Singleton:New(...) end
function LootHistory_Singleton:Initialize() end
function ZO_LootHistory_Shared:New(...) end
function ZO_LootHistory_Shared:Initialize(control) end
function ZO_LootHistory_Shared:CreateLootEntry(lootData) end
function ZO_LootHistory_Shared:AddLootEntry(lootEntry) end
function ZO_LootHistory_Shared:QueueLootEntry(lootEntry) end
function ZO_LootHistory_Shared:InsertOrQueue(lootEntry) end
function ZO_LootHistory_Shared:DisplayLootQueue() end
function ZO_LootHistory_Shared:HideLootQueue() end
function ZO_LootHistory_Shared:OnNewItemReceived(itemLinkOrName, stackCount, itemSound, lootType, questItemIcon, itemId, isVirtual) end
function ZO_LootHistory_Shared:OnGoldUpdate(newGold, oldGold, reason) end
function ZO_LootHistory_Shared:OnGoldPickpocket(goldAmount) end
function ZO_LootHistory_Shared:OnAlliancePointUpdate(currentAlliancePoints, playSound, difference) end
function ZO_LootHistory_Shared:OnTelvarStoneUpdate(newTelvarStones, oldTelvarStones, reason) end
function ZO_LootHistory_Shared:OnExperienceGainUpdate(reason, level, previousExperience, currentExperience) end
function ZO_LootHistory_Shared:SetEntryTemplate() end
function ZO_LootHistory_Shared:InitializeFragment() end
function ZO_LootHistory_Shared:InitializeFadingControlBuffer(control) end
function ZO_LootHistory_Shared:CanShowItemsInHistory() end
function ZO_LootHistory_Shared_OnInitialized(control) end
function ZO_LootScene:New(...) end
function ZO_LootScene:OnRemovedFromQueue() end
function ZO_Loot_Shared:New(...) end
function ZO_Loot_Shared:Initialize(control) end
function ZO_Loot_Shared:Hide() end
function ZO_Loot_Shared:LootAllItems() end
function ZO_PlayMonsterLootSound(isOpen) end
--ingame\zo_quest
function ZO_FocusedQuestTracker:New(...) end
function ZO_FocusedQuestTracker:RegisterCallbacks() end
function ZO_FocusedQuestTracker:InitialTrackingUpdate() end
function ZO_FocusedQuestTracker:UpdateVisibility() end
function ZO_FocusedQuestTracker:BeginTracking(trackType, arg1, arg2) end
function ZO_FocusedQuestTracker:OnQuestAdded(questIndex) end
function ZO_FocusedQuestTracker:OnQuestRemoved(questIndex, completed) end
function ZO_FocusedQuestTracker:StopTracking(trackType, arg1, arg2, completed) end
function ZO_FocusedQuestTracker:SetTrackTypeAssisted(trackType, show, arg1, arg2) end
function ZO_FocusedQuestTracker:OnQuestAssistStateChanged(unassistedData, assistedData) end
function ZO_FocusedQuestTracker:UpdateAssistedVisibility() end
function ZO_FocusedQuestTracker:RefreshQuestPins(journalIndex, tracked) end
function ZO_FocusedQuestTracker:ClearTracker() end
function ZO_FocusedQuestTracker:GetContainerControl() end
function ZO_FocusedQuestTracker:ApplyPlatformStyle() end
function ZO_FocusedQuestTracker_OnInitialized(control) end
function ZO_QuestJournal_Gamepad:New(...) end
function ZO_QuestJournal_Gamepad:Initialize(control) end
function ZO_QuestJournal_Gamepad:RegisterIcons() end
function ZO_QuestJournal_Gamepad:RegisterTooltips() end
function ZO_QuestJournal_Gamepad:GetQuestDataString() end
function ZO_QuestJournal_Gamepad:PerformDeferredInitialization() end
function ZO_QuestJournal_Gamepad:OnTargetChanged(...) end
function ZO_QuestJournal_Gamepad:SetupList(list) end
function ZO_QuestJournal_Gamepad:SetupOptionsList(list) end
function ZO_QuestJournal_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_QuestJournal_Gamepad:InitializeScenes() end
function ZO_QuestJournal_Gamepad:GetSceneName() end
function ZO_QuestJournal_Gamepad:GetSelectedQuestData() end
function ZO_QuestJournal_Gamepad:SelectFocusedQuest() end
function ZO_QuestJournal_Gamepad:PerformUpdate() end
function ZO_QuestJournal_Gamepad:RefreshQuestCount() end
function ZO_QuestJournal_Gamepad:RefreshDetails() end
function ZO_QuestJournal_Gamepad:RefreshOptionsList() end
function ZO_QuestJournal_Gamepad:RefreshQuestMasterList() end
function ZO_QuestJournal_Gamepad:RefreshQuestList() end
function ZO_QuestJournal_Gamepad:GetNextSortedQuestForQuestIndex(questIndex) end
function ZO_QuestJournal_Gamepad:FocusQuestWithIndex(index) end
function ZO_QuestJournal_Gamepad:SetKeybindButtonGroup(descriptor) end
function ZO_QuestJournal_Gamepad_OnInitialized(control) end
function ZO_QuestJournal_Keyboard:New(...) end
function ZO_QuestJournal_Keyboard:Initialize(control) end
function ZO_QuestJournal_Keyboard:RegisterIcons() end
function ZO_QuestJournal_Keyboard:RegisterTooltips() end
function ZO_QuestJournal_Keyboard:SetIconTexture(iconControl, iconData, selected) end
function ZO_QuestJournal_Keyboard:InitializeQuestList() end
function ZO_QuestJournal_Keyboard:InitializeKeybindStripDescriptors() end
function ZO_QuestJournal_Keyboard:InitializeScenes() end
function ZO_QuestJournal_Keyboard:GetSceneName() end
function ZO_QuestJournal_Keyboard:GetSelectedQuestData() end
function ZO_QuestJournal_Keyboard:FocusQuestWithIndex(index) end
function ZO_QuestJournal_Keyboard:RefreshQuestCount() end
function ZO_QuestJournal_Keyboard:RefreshQuestMasterList() end
function ZO_QuestJournal_Keyboard:RefreshQuestList() end
function ZO_QuestJournal_Keyboard:RefreshDetails() end
function ZO_QuestJournal_Keyboard:GetNextSortedQuestForQuestIndex(questIndex) end
function ZO_QuestJournalNavigationEntry_GetTextColor(self) end
function ZO_QuestJournalNavigationEntry_OnMouseUp(label, button, upInside) end
function ZO_QuestJournal_Keyboard_OnInitialized(control) end
function ZO_QuestJournal_OnQuestIconMouseEnter(texture) end
function ZO_QuestJournal_OnQuestIconMouseExit() end
function ZO_QuestJournal_Manager:New(...) end
function ZO_QuestJournal_Manager:Initialize(control) end
function ZO_QuestJournal_Manager:RegisterForEvents() end
function ZO_QuestJournal_Manager:BuildTextForConditions(questIndex, stepIndex, numConditions, questStrings) end
function ZO_QuestJournal_Manager:BuildTextForTasks(stepOverrideText, questIndex, questStrings) end
function ZO_QuestJournal_Manager:DoesShowMultipleOrSteps(stepOverrideText, stepType, questIndex) end
function ZO_QuestJournal_Manager:GetQuestListData() end
function ZO_QuestJournal_Manager:ConfirmAbandonQuest(questIndex) end
function ZO_QuestJournal_Manager:ShareQuest(questIndex) end
function ZO_QuestJournal_Manager:UpdateFocusedQuest() end
function ZO_QuestJournal_Manager:GetFocusedQuestIndex() end
function ZO_QuestJournal_Shared:New() end
function ZO_QuestJournal_Shared:Initialize(control) end
function ZO_QuestJournal_Shared:RegisterIconTexture(questType, instanceDisplayType, texturePath) end
function ZO_QuestJournal_Shared:GetIconTexture(questType, instanceDisplayType) end
function ZO_QuestJournal_Shared:RegisterTooltipText(questType, instanceDisplayType, stringIdOrText) end
function ZO_QuestJournal_Shared:GetTooltipText(questType, instanceDisplayType) end
function ZO_QuestJournal_Shared:InitializeQuestList() end
function ZO_QuestJournal_Shared:InitializeKeybindStripDescriptors() end
function ZO_QuestJournal_Shared:InitializeScenes() end
function ZO_QuestJournal_Shared:GetSelectedQuestData() end
function ZO_QuestJournal_Shared:RefreshQuestList() end
function ZO_QuestJournal_Shared:RegisterIcons() end
function ZO_QuestJournal_Shared:RegisterTooltips() end
function ZO_QuestJournal_Shared:OnLevelUpdated(unitTag) end
function ZO_QuestJournal_Shared:BuildTextForStepVisibility(questIndex, visibilityType) end
function ZO_QuestJournal_Shared:GetSelectedQuestIndex() end
function ZO_QuestJournal_Shared:CanAbandonQuest() end
function ZO_QuestJournal_Shared:CanShareQuest() end
function ZO_QuestJournal_Shared:RefreshDetails() end
function ZO_QuestJournal_Shared:RefreshQuestCount() end
function ZO_QuestJournal_Shared:RefreshQuestMasterList() end
function ZO_QuestJournal_Shared:OnQuestsUpdated() end
function ZO_QuestJournal_Shared:OnQuestAdvanced(questIndex) end
function ZO_QuestJournal_Shared:OnQuestConditionCounterChanged(questIndex) end
function ZO_QuestJournal_Shared:ShowOnMap() end
function QuestTimer:New(...) end
function QuestTimer:Initialize(control) end
function QuestTimer:InitializeEvents() end
function QuestTimer:InitializePooling() end
function QuestTimer:OnQuestTimerUpdated(index) end
function QuestTimer:OnQuestTimerPaused(index, isPaused) end
function QuestTimer:AcquireTimer(index) end
function QuestTimer:RemoveTimerByIndex(index, suppressLayout) end
function QuestTimer:UpdateTimer(timer, now) end
function QuestTimer:CreateTimerFromIndex(index, suppressLayout) end
function QuestTimer:StartExistingTimers() end
function ZO_QuestTimer_OnMouseUp(control) end
function ZO_QuestTimer_OnUpdate(control, time) end
function ZO_QuestTimer_CreateInContainer(control) end
function ZO_TrackedData:New(trackType, arg1, arg2) end
function ZO_TrackedData:GetJournalIndex() end
function ZO_TrackedData:Equals(trackType, arg1, arg2) end
function ZO_Tracker:New(trackerPanel, trackerControl) end
function ZO_Tracker:CreatePlatformAnchors() end
function ZO_Tracker:ApplyPlatformStyle() end
function ZO_Tracker:InitialTrackingUpdate() end
function ZO_Tracker:SetEnabled(enabled) end
function ZO_Tracker:UpdateVisibility() end
function ZO_Tracker:SetTracked(questIndex, tracked) end
function ZO_Tracker:ToggleTracking(questIndex) end
function ZO_Tracker:ForceAssist(questIndex) end
function ZO_Tracker:AssistClosestTracked() end
function ZO_Tracker:AssistNext(ignoreSceneRestriction) end
function ZO_Tracker:SetFaded(faded) end
function ZO_Tracker:GetFaded() end
function ZO_Tracker:RefreshQuestPins(journalIndex, tracked) end
function ZO_Tracker:CreateQuestHeader(data, questName, questType, isComplete) end
function ZO_Tracker:InitializeQuestHeader(questName, questType, questHeader, isComplete) end
function ZO_Tracker:InitializeQuestCondition(questCondition, parentQuestHeader, questConditionKey, treeNode) end
function ZO_Tracker:PopulateStepQuestConditions(questIndex, stepIndex, questHeader, treeNode, desiredVisibility, entryType) end
function ZO_Tracker:PopulateOptionalStepQuestConditionsForVisibility(questIndex, questHeader, treeNode, desiredVisibility, entryType) end
function ZO_Tracker:PopulateQuestConditions(questIndex, questName, stepType, stepTrackerText, isComplete, tracked, questHeader, treeNode) end
function ZO_Tracker:RebuildConditions(questIndex, questHeader, questName, stepType, stepTrackerText, isComplete, tracked) end
function ZO_Tracker:RefreshHeaderConColors() end
function ZO_Tracker:RemoveAndReleaseConditionsFromHeader(questHeader) end
function ZO_Tracker:OnQuestConditionUpdated(questIndex) end
function ZO_Tracker:OnQuestAdded(questIndex) end
function ZO_Tracker:OnQuestRemoved(questIndex, completed, questID) end
function ZO_Tracker:OnQuestAdvanced(questIndex, questName, isPushed, isComplete, mainStepChanged) end
function ZO_Tracker:OnQuestAssistStateChanged(unassistedData, assistedData, applyPlatformConstants) end
function ZO_Tracker:OnLevelUpdated(tag) end
function ZO_Tracker:GetHeaderForIndex(trackType, arg1, arg2) end
function ZO_Tracker:GetNumTracked() end
function ZO_Tracker:IsFull() end
function ZO_Tracker:GetTrackedByIndex(index) end
function ZO_Tracker:GetLastTracked() end
function ZO_Tracker:IsTrackTypeAssisted(trackType, arg1, arg2) end
function ZO_Tracker:SetTrackTypeAssisted(trackType, show, arg1, arg2) end
function ZO_Tracker:GetTrackingIndex(trackType, arg1, arg2) end
function ZO_Tracker:SetTrackedQuestComplete(questIndex, isComplete) end
function ZO_Tracker:IsOnTracker(trackType, arg1, arg2) end
function ZO_Tracker:AddQuest(data) end
function ZO_Tracker:BeginTracking(trackType, arg1, arg2) end
function ZO_Tracker:StopTracking(trackType, arg1, arg2, completed) end
function ZO_Tracker:ClearTracker() end
function ZO_Tracker:UpdateTreeView() end
function ZO_Tracker:SetAssisted(header, showArrows) end
function ZO_Tracker:DoHeaderNameHighlight(label, state) end
function ZO_TrackedHeader_MouseEnter(label) end
function ZO_TrackedHeader_MouseExit(label) end
function ZO_TrackedHeader_MouseUp(label, button, upInside) end
function ZO_QuestTracker_ShowTrackedHeaderTooltip(trackedLabel) end
function ZO_QuestTracker_HideTrackedHeaderTooltip(trackedLabel) end
function ZO_QuestTracker_SetEnabled(enabled) end
function ZO_QuestTracker_OnInitialized(self) end
--ingame\zo_tooltip
function ZO_GamepadTooltip:New(...) end
function ZO_GamepadTooltip:Initialize(control, dialogControl) end
function ZO_GamepadTooltip:InitializeTooltip(tooltipType, baseControl, prefix, autoShowBg, scrollIndicatorSide) end
function ZO_GamepadTooltip:ClearTooltip(tooltipType, retainFragment) end
function ZO_GamepadTooltip:ResetScrollTooltipToTop(tooltipType) end
function ZO_GamepadTooltip:ClearStatusLabel(tooltipType) end
function ZO_GamepadTooltip:SetStatusLabelText(tooltipType, stat, value, visualLayer) end
function ZO_GamepadTooltip:SetMovableTooltipVerticalRules(leftHidden, rightHidden) end
function ZO_GamepadTooltip:SetMovableTooltipAnchors(anchorTable) end
function ZO_GamepadTooltip:SetScrollIndicatorSide(tooltipType, side) end
function ZO_GamepadTooltip:ShowBg(tooltipType) end
function ZO_GamepadTooltip:HideBg(tooltipType) end
function ZO_GamepadTooltip:SetAutoShowBg(tooltipType, autoShowBg) end
function ZO_GamepadTooltip:SetBgType(tooltipType, bgType) end
function ZO_GamepadTooltip:SetBgAlpha(tooltipType, alpha) end
function ZO_GamepadTooltip:SetTooltipResetScrollOnClear(tooltipType, resetScroll) end
function ZO_GamepadTooltip:ShowGenericHeader(tooltipType, data) end
function ZO_GamepadTooltip:Reset(tooltipType) end
function ZO_GamepadTooltip:GetTooltip(tooltipType) end
function ZO_GamepadTooltip:GetTooltipContainer(tooltipType) end
function ZO_GamepadTooltip:GetTooltipFragment(tooltipType) end
function ZO_GamepadTooltip:GetTooltipBgFragment(tooltipType) end
function ZO_GamepadTooltip:DoesAutoShowTooltipBg(tooltipType) end
function ZO_GamepadTooltip:GetTooltipInfo(tooltipType) end
function ZO_GamepadTooltip_OnInitialized(control, dialogControl) end
function ZO_Tooltip:LayoutTitleAndDescriptionTooltip(title, description) end
function ZO_Tooltip:LayoutTitleAndMultiSectionDescriptionTooltip(title, ...) end
--ingamelocalization
function SafeAddVersion(stringId, stringVersion) end
function SafeAddString(stringId, stringValue, stringVersion) end
function ZO_CreateStringId(stringId, stringToAdd) end
--internalingame\globals
function ZO_MarketPurchaseConfirmationDialog_OnInitialized(self) end
function ZO_MarketPurchasingDialog_OnInitialized(self) end
--internalingame\market
function ZO_GamepadMarketProduct:New(...) end
function ZO_GamepadMarketProduct:Initialize(controlId, parent, owner, controlName) end
function ZO_GamepadMarketProduct:InitializeControls(control) end
function ZO_GamepadMarketProduct:GetTemplate() end
function ZO_GamepadMarketProduct:GetFocusData() end
function ZO_GamepadMarketProduct:SetListIndex(listIndex) end
function ZO_GamepadMarketProduct:GetListIndex() end
function ZO_GamepadMarketProduct:SetPreviewIndex(previewIndex) end
function ZO_GamepadMarketProduct:GetPreviewIndex() end
function ZO_GamepadMarketProduct:GetProductForSell() end
function ZO_GamepadMarketProductBundleAttachment:New(...) end
function ZO_GamepadMarketProductBundleAttachment:GetTemplate() end
function ZO_GamepadMarketProductBundleAttachment:Show(...) end
function ZO_GamepadMarketProductBundleAttachment:SetBundle(bundle) end
function ZO_GamepadMarketProductBundleAttachment:IsPurchaseLocked() end
function ZO_GamepadMarketProductBundleAttachment:GetProductForSell() end
function ZO_GamepadMarketProductBundleAttachment:Reset() end
function ZO_GamepadMarketBlankProduct:New(...) end
function ZO_GamepadMarketBlankProduct:Initialize(...) end
function ZO_GamepadMarketBlankProduct:InitializeControls(control) end
function ZO_MarketBlankProductBase:LayoutBackground() end
function ZO_MarketBlankProductBase:UpdateProductStyle() end
function ZO_GamepadMarketBlankProduct:GetTemplate() end
function ZO_GamepadMarketPurchaseManager:New(...) end
function ZO_GamepadMarketPurchaseManager:Initialize() end
function ZO_GamepadMarketPurchaseManager:EndPurchase(isNoChoice) end
function ZO_GamepadMarketPurchaseManager:EndPurchaseAndLogout() end
function ZO_GamepadMarketPurchaseManager:ResetState() end
function ZO_GamepadMarketPurchaseManager:SetFlowPosition(position, dialogParams) end
function ZO_GamepadMarket_ShowBuyCrownsDialog() end
function ZO_GamepadMarket_ShowBuyPlusDialog() end
function ZO_GamepadMarketKeybindStrip_RefreshStyle() end
function GamepadGridFocus:New(...) end
function GamepadGridFocus:Initialize(control, gridWidth, gridHeight, leftBoundCallBack, rightBoundCallBack, topBoundCallBack, bottomBoundCallBack) end
function GamepadGridFocus:InitializeMovementController() end
function GamepadGridFocus:GetSelectedIndex() end
function ZO_GamepadMarketPageFragment:New(...) end
function ZO_GamepadMarketPageFragment:GetBackgroundFragment() end
function ZO_GamepadMarketPageFragment:SetDirection(direction) end
function GamepadMarket_TabBarScrollList:New(...) end
function GamepadMarket_TabBarScrollList:Activate() end
function GamepadMarket_TabBarScrollList:Deactivate() end
function GamepadMarket_TabBarScrollList:InitializeKeybindStripDescriptors() end
function ZO_GamepadMarket_GridScreen:Initialize(control, gridWidth, gridHeight, initialTabBarEntries) end
function ZO_GamepadMarket_GridScreen:CalculateScrollToCenterOffsetY() end
function ZO_GamepadMarket_GridScreen:Activate() end
function ZO_GamepadMarket_GridScreen:Deactivate() end
function ZO_GamepadMarket_GridScreen:ClearGridList() end
function ZO_GamepadMarket_GridScreen:SetGridDimensions(gridWidth, gridHeight) end
function ZO_GamepadMarket_GridScreen:PrepareGridForBuild(itemsPerRow, itemsPerColumn, itemWidth, itemHeight, itemPadding) end
function ZO_GamepadMarket_GridScreen:ResetGrid() end
function ZO_GamepadMarket_GridScreen:AddEntry(marketProduct, control) end
function ZO_GamepadMarket_GridScreen:AcquireBlankTile() end
function ZO_GamepadMarket_GridScreen:FinishRowWithBlankTiles() end
function ZO_GamepadMarket_GridScreen:InitializeHeader(initialTabBarEntries) end
function ZO_GamepadMarket_GridScreen:RefreshHeader() end
function ZO_GamepadMarket_GridScreen:BeginPreview() end
function ZO_GamepadMarket_GridScreen:EndCurrentPreview() end
function ZO_GamepadMarket_GridScreen:HasMultiplePreviewProducts() end
function ZO_GamepadMarket_GridScreen:GetCurrentPreviewProduct() end
function ZO_GamepadMarket_GridScreen:MoveToPreviousPreviewProduct() end
function ZO_GamepadMarket_GridScreen:MoveToNextPreviewProduct() end
function ZO_GamepadMarket_GridScreen:OnShowing() end
function ZO_GamepadMarket_GridScreen:SelectAfterPreview() end
function ZO_GamepadMarket_GridScreen:ClearPreviewVars() end
function ZO_GamepadMarket_GridScreen:PerformDeferredInitialization() end
function ZO_GamepadMarket_GridScreen:InitializeBlankProductPool() end
function ZO_GamepadMarket_GridScreen:InitializeMarketProductPool() end
function ZO_GamepadMarket_GridScreen:ReleaseAllProducts() end
function ZO_GamepadMarket_GridScreen:ClearProducts() end
function ZO_GamepadMarket_GridScreen:RefreshProducts() end
function ZO_GamepadMarket_GridScreen:UpdateTooltip() end
function ZO_GamepadMarket_GridScreen:UpdatePreviousAndNewlySelectedProducts(previousSelectedProduct, newlySelectedProduct) end
function ZO_GamepadMarket_GridScreen:ScrollToPosition(scrollPosition, scrollInstantly) end
function ZO_GamepadMarket_GridScreen:ScrollToGridEntry(entryData, scrollInstantly) end
function ZO_GamepadMarket_GridScreen:ScrollToGridScrollYPosition() end
function ZO_GamepadMarket_GridScreen:UpdateScrollbarAlpha() end
function ZO_GamepadMarket_GridScreen:OnSelectionChanged(selectedData) end
function ZO_GamepadMarket_GridScreen:SetQueuedTutorial(queuedTutorial) end
function ZO_GamepadMarket_GridScreen:HasQueuedTutorial() end
function ZO_GamepadMarket_GridScreen:OnShown() end
function ZO_GamepadMarket_GridScreen:LayoutSelectedMarketProduct() end
function GamepadMarketPreview:New(...) end
function GamepadMarketPreview:Initialize(control) end
function GamepadMarketPreview:InitializeKeybindDescriptors() end
function GamepadMarketPreview:HasMultiplePreviewProducts() end
function GamepadMarketPreview:LayoutPreviewedProduct() end
function GamepadMarketPreview:UpdatePreviewedProduct(marketProduct) end
function GamepadMarketPreview:SetCanChangePreview(canChangePreview) end
function GamepadMarketPreview:MoveToPreviousPreviewProduct() end
function GamepadMarketPreview:MoveToNextPreviewProduct() end
function GamepadMarketPreview:SetPreviewProductsContainer(previewProductsContainer) end
function GamepadMarketPreview:PreviewNextVariation() end
function GamepadMarketPreview:PreviewPreviousVariation() end
function GamepadMarketPreview:UpdateDirectionalInput() end
function GamepadMarketPreview:OnShown() end
function GamepadMarketPreview:OnHidden() end
function GamepadMarketPreview:OnStateChanged(oldState, newState) end
function GamepadMarketPreview:OnUpdate(ms) end
function GamepadMarketPreview:Activate() end
function GamepadMarketPreview:Deactivate() end
function GamepadMarketPreview:SetMultiVariationPreviewIconsHidden(shouldHide) end
function GamepadMarket:New(...) end
function GamepadMarket:Initialize(control) end
function GamepadMarket:SetupSceneGroupCallback() end
function GamepadMarket:PerformDeferredInitialization() end
function GamepadMarket:GetLabeledGroupLabelTemplate() end
function GamepadMarket:LayoutSelectedMarketProduct() end
function GamepadMarket:OnSelectionChanged(selectedData) end
function GamepadMarket:OnStateChanged(oldState, newState) end
function GamepadMarket:OnInitialInteraction() end
function GamepadMarket:OnEndInteraction() end
function GamepadMarket:OnShowing() end
function GamepadMarket:OnShown() end
function GamepadMarket:OnHiding() end
function GamepadMarket:InitializeKeybindDescriptors() end
function GamepadMarket:GetPrimaryButtonDescriptor() end
function GamepadMarket:BeginPreview() end
function GamepadMarket:OnCategorySelected(data) end
function GamepadMarket:UpdateCurrencyBalance(currentCurrency) end
function GamepadMarket:CreateMarketScene() end
function GamepadMarket:AcquireBlankTile() end
function GamepadMarket:InitializeBlankProductPool() end
function GamepadMarket:InitializeMarketProductPool() end
function GamepadMarket:ReleaseAllProducts() end
function GamepadMarket:ReleasePreviousCategoryProducts() end
function GamepadMarket:AnchorCurrentCategoryControlToScrollChild() end
function GamepadMarket:BuildMarketProductList(data) end
function GamepadMarket:GetCategoryProductIds(data, currentSubCategory, numSubCategories, ...) end
function GamepadMarket:GetMarketProductIds(categoryIndex, subCategoryIndex, index, ...) end
function GamepadMarket:FinishBuild() end
function GamepadMarket:EndCurrentPreview() end
function GamepadMarket:AddBlankTile(blankTile) end
function GamepadMarket:FinishCurrentLabeledGroup() end
function GamepadMarket:AddLabeledGroupTable(labeledGroupName, labeledGroupTable, ignoreHasPreview) end
function GamepadMarket:FindOrCreateSubCategoryLabeledGroupTable(subCategoryData) end
function GamepadMarket:FindSubCategoryLabeledGroupTable(categoryIndex) end
function GamepadMarket:AddMarketProductToLabeledGroupOrGeneralGroup(name, marketProduct, id) end
function GamepadMarket:ClearMarketProducts() end
function GamepadMarket:UpdateCategoryAnimationDirection() end
function GamepadMarket:SetCurrentKeybinds(keybindDescriptor) end
function GamepadMarket:DisplayEsoPlusOffer() end
function GamepadMarket:LayoutMarketProducts(...) end
function GamepadMarket:OnMarketOpen() end
function GamepadMarket:OnMarketLocked() end
function GamepadMarket:OnMarketLoading() end
function GamepadMarket:OnMarketPurchaseResult() end
function GamepadMarket:ShowBundleContents(bundle) end
function GamepadMarket:OnTutorialShowing() end
function GamepadMarket:OnTutorialHidden() end
function GamepadMarket:RestoreActionLayerForTutorial() end
function GamepadMarket:RemoveActionLayerForTutorial() end
function GamepadMarket:ClearProducts() end
function GamepadMarket:GetCategoryDataFromId(productId) end
function GamepadMarket:RequestShowMarketProduct(id) end
function GamepadMarket:ShowMarketProduct(id) end
function GamepadMarket:GetCategoryData(categoryIndex) end
function GamepadMarket:AddKeybinds() end
function GamepadMarket:RemoveKeybinds() end
function GamepadMarket:RefreshKeybinds() end
function GamepadMarketBundleContents:New(...) end
function GamepadMarketBundleContents:Initialize(control) end
function GamepadMarketBundleContents:InitializeMarketProductPool() end
function GamepadMarketBundleContents:OnStateChanged(oldState, newState) end
function GamepadMarketBundleContents:PerformDeferredInitialization() end
function GamepadMarketBundleContents:SetBundle(bundle) end
function GamepadMarketBundleContents:LayoutBundleProducts(bundle) end
function GamepadMarketBundleContents:OnShowing() end
function GamepadMarketBundleContents:OnShown() end
function GamepadMarketBundleContents:OnHiding() end
function GamepadMarketBundleContents:LayoutSelectedMarketProduct() end
function GamepadMarketBundleContents:OnSelectionChanged(selectedData) end
function GamepadMarketBundleContents:OnInitialInteraction() end
function GamepadMarketBundleContents:OnEndInteraction() end
function GamepadMarketBundleContents:ReleaseAllProducts() end
function GamepadMarketBundleContents:AddKeybinds() end
function GamepadMarketBundleContents:RemoveKeybinds() end
function GamepadMarketBundleContents:RefreshKeybinds() end
function GamepadMarketBundleContents:FinishBuild() end
function GamepadMarketBundleContents:EndCurrentPreview() end
function GamepadMarketBundleContents:RefreshActions() end
function GamepadMarketLockedScreen:New(...) end
function GamepadMarketLockedScreen:Initialize(control) end
function GamepadMarketLockedScreen:OnStateChanged(oldState, newState) end
function GamepadMarketLockedScreen:OnMarketOpen() end
function GamepadMarketPreScene:New(...) end
function GamepadMarketPreScene:Initialize(control) end
function GamepadMarketPreScene:OnStateChanged(oldState, newState) end
function GamepadMarketPreScene:OnShown() end
function GamepadMarketPreScene:OnHiding() end
function GamepadMarketPreScene:OnMarketStateUpdated(marketState) end
function GamepadMarketPreScene:OnUpdate(currentMs) end
function GamepadMarketPreScene:SwapToMarketScene() end
function ZO_Market_Gamepad_OnInitialize(control) end
function ZO_GamepadMarket_BundleContents_OnInitialize(control) end
function ZO_GamepadMarket_Preview_OnInitialize(control) end
function ZO_GamepadMarket_Locked_OnInitialize(control) end
function ZO_GamepadMarket_PreScene_OnInitialize(control) end
function KeyboardMarketProduct:New(...) end
function KeyboardMarketProduct:Initialize(controlId, controlTemplate, parent, iconPool, owner, name, ...) end
function KeyboardMarketProduct:LayoutBackground(background) end
function KeyboardMarketProduct:LayoutCostAndText(description, cost, discountPercent, discountedCost, isNew) end
function KeyboardMarketProduct:Purchase() end
function KeyboardMarketProduct:Reset() end
function KeyboardMarketProduct:Refresh() end
function KeyboardMarketProduct:InitializeMarketProductIcon(marketProductId, purchased) end
function KeyboardMarketProduct:EndPreview() end
function KeyboardMarketProduct:OnIconMouseEnter(activeIcon) end
function KeyboardMarketProduct:OnMouseEnter() end
function KeyboardMarketProduct:OnMouseExit() end
function KeyboardMarketProduct:OnClicked(button) end
function KeyboardMarketProduct:OnDoubleClicked(button) end
function KeyboardMarketProduct:DisplayTooltip(anchorControl, productId) end
function KeyboardMarketProduct:ClearTooltip() end
function KeyboardMarketProduct:GetBackground() end
function KeyboardMarketProduct:IsActivelyPreviewing() end
function ZO_MarketProductBundle:New(...) end
function ZO_MarketProductBundle:Initialize(controlId, parent, iconPool, owner) end
function ZO_MarketProductBundle:PerformLayout(description, cost, discountedCost, discountPercent, icon, background, isNew, isFeatured) end
function ZO_MarketProductBundle:CreateIconControlTable(purchased) end
function ZO_MarketProductBundle:LayoutIcons(iconControls) end
function ZO_MarketProductBundle:IsActivelyPreviewing() end
function ZO_MarketProductBundle:HasPreview() end
function ZO_MarketProductBundle:Preview(icon) end
function ZO_MarketProductBundle:EndPreview() end
function ZO_MarketProductBundle:GetPreviewVariationDisplayName() end
function ZO_MarketProductBundle:PreviewNextVariation() end
function ZO_MarketProductBundle:PreviewPreviousVariation() end
function ZO_MarketProductIndividual:New(...) end
function ZO_MarketProductIndividual:Initialize(controlId, parent, iconPool, owner) end
function ZO_MarketProductIndividual:PerformLayout(description, cost, discountedCost, discountPercent, icon, background, isNew, isFeatured) end
function ZO_MarketProductIndividual:IsActivelyPreviewing() end
function ZO_MarketProductIndividual:Preview() end
function ZO_MarketProductIndividual:Reset() end
function ZO_MarketProductIcon:New(...) end
function ZO_MarketProductIcon:Initialize(controlId, parent) end
function ZO_MarketProductIcon:Show(marketProduct, marketProductId, showAsPurchased) end
function ZO_MarketProductIcon:GetControl() end
function ZO_MarketProductIcon:GetParentMarketProduct() end
function ZO_MarketProductIcon:GetMarketProductId() end
function ZO_MarketProductIcon:Reset() end
function ZO_MarketProductIcon:SetDimensions(length) end
function ZO_MarketProductIcon:SetIcon(icon) end
function ZO_MarketProductIcon:SetActive(isActive) end
function ZO_MarketProductIcon:SetFrameHidden(isHidden) end
function ZO_MarketProductIcon:SetHidden(isHidden) end
function ZO_MarketProductIcon:GetDisplayName() end
function ZO_MarketProductIcon:OnMouseEnter() end
function ZO_MarketProductIcon:OnMouseExit() end
function ZO_MarketProductIcon:OnClicked(button) end
function ZO_MarketProduct_OnMouseEnter(control) end
function ZO_MarketProduct_OnMouseExit(control) end
function ZO_MarketProductIcon_OnMouseEnter(control) end
function ZO_MarketProductIcon_OnMouseExit(control) end
function Market:New(...) end
function Market:Initialize(control) end
function Market:GetLabeledGroupLabelTemplate() end
function Market:UpdateCurrencyBalance(currency) end
function Market:InitializeKeybindDescriptors() end
function Market:CreateMarketScene() end
function Market:InitializeCategories() end
function Market:InitializeMarketList() end
function Market:BuildCategories() end
function Market:RefreshVisibleCategoryFilter() end
function Market:GetMarketProductIds(categoryIndex, subCategoryIndex, index, ...) end
function Market:ClearMarketProducts() end
function Market:DisplayEsoPlusOffer() end
function Market:LayoutMarketProducts(...) end
function Market:ShowMarket(showMarket) end
function Market:ShowNoMatchesMessage(showMessage) end
function Market:OnMarketUpdate() end
function Market:OnMarketLocked() end
function Market:OnMarketLoading() end
function Market:MarketProductSelected(marketProduct) end
function Market:RefreshActions() end
function Market:GetCanBeginPreview() end
function Market:OnShown() end
function Market:OnHidden() end
function Market:RefreshProducts() end
function Market:RestoreActionLayerForTutorial() end
function Market:RemoveActionLayerForTutorial() end
function Market:ResetSearch() end
function Market:EndCurrentPreview() end
function Market:SetCurrentMultiVariationPreviewProduct(marketProduct) end
function Market:CyclePreviewVariations(direction) end
function ZO_Market_OnInitialize(self) end
function ZO_Market_BeginSearch(editBox) end
function ZO_Market_EndSearch(editBox) end
function ZO_Market_OnSearchTextChanged(editBox) end
function ZO_Market_OnSearchEnterKeyPressed(editBox) end
function ZO_MarketCurrency_OnMouseEnter(control) end
function ZO_MarketCurrency_OnMouseExit(control) end
function ZO_MarketCurrencyBuyCrowns_OnClicked(control) end
function ZO_MarketCurrencyBuySubscription_OnClicked(control) end
function ZO_Market_PreviewArrowOnMouseClicked(control, direction) end
function ZO_LargeSingleMarketProduct_Base:New(...) end
function ZO_LargeSingleMarketProduct_Base:Initialize(...) end
function ZO_LargeSingleMarketProduct_Base:InitializeControls(control) end
function ZO_LargeSingleMarketProduct_Base:PerformLayout(description, cost, discountedCost, discountPercent, icon, background, isNew, isFeatured) end
function ZO_LargeSingleMarketProduct_Base:LayoutCostAndText(description, cost, discountPercent, discountedCost, isNew) end
function ZO_LargeSingleMarketProduct_Base:SetHidden(hidden) end
function ZO_LargeSingleMarketProduct_Base:GetBackground() end
function ZO_LargeSingleMarketProduct_Base:GetStackCount() end
function ZO_LargeSingleMarketProduct_Base:SetTitle(title) end
function ZO_LargeSingleMarketProduct_Base:SetIsFocused(isFocused) end
function ZO_LargeSingleMarketProduct_Base:Reset() end
function ZO_LargeSingleMarketProduct_Base:LayoutTooltip(tooltip) end
function ZO_LargeSingleMarketProduct_Base:UpdateProductStyle() end
function ZO_MarketProductBase:New(...) end
function ZO_MarketProductBase:Initialize(control, owner) end
function ZO_MarketProductBase:InitializeControls(control) end
function ZO_MarketProductBase:GetId() end
function ZO_MarketProductBase:GetMarketProductInfo() end
function ZO_MarketProductBase:GetMarketProductType() end
function ZO_MarketProductBase:GetNumChildren() end
function ZO_MarketProductBase:GetChildMarketProductId(childIndex) end
function ZO_MarketProductBase:GetNumAttachedCollectibles() end
function ZO_MarketProductBase:GetNumAttachedItems() end
function ZO_MarketProductBase:GetProductType() end
function ZO_MarketProductBase:GetHidesChildProducts() end
function ZO_MarketProductBase:GetTimeLeftInSeconds() end
function ZO_MarketProductBase:GetPurchaseState() end
function ZO_MarketProductBase:IsPurchaseLocked() end
function ZO_MarketProductBase:HasBeenPartiallyPurchased() end
function ZO_MarketProductBase:HasSubscriptionUnlockedAttachments() end
function ZO_MarketProductBase:GetBackgroundSaturation(isPurchased) end
function ZO_MarketProductBase:IsLimitedTimeProduct() end
function ZO_MarketProductBase:UpdateRemainingTimeCalloutText() end
function ZO_MarketProductBase:SetId(marketProductId) end
function ZO_MarketProductBase:Show(marketProductId) end
function ZO_MarketProductBase:GetControl() end
function ZO_MarketProductBase:Reset() end
function ZO_MarketProductBase:Refresh() end
function ZO_MarketProductBase:SetHighlightHidden(hidden) end
function ZO_MarketProductBase:PlayHighlightAnimationToEnd() end
function ZO_MarketProductBase:HasActiveIcon() end
function ZO_MarketProductBase:SetTitle(title) end
function ZO_MarketProductBase:HasPreview() end
function ZO_MarketProductBase:Preview() end
function ZO_MarketProductBase:EndPreview() end
function ZO_MarketProductBase:GetPreviewVariationDisplayName() end
function ZO_MarketProductBase:GetNumPreviewVariations() end
function ZO_MarketProductBase:PreviewNextVariation() end
function ZO_MarketProductBase:PreviewPreviousVariation() end
function ZO_MarketProductBase:Purchase() end
function ZO_MarketProductBase:PerformLayout(name, description, cost, discountedCost, discountPercent, icon, background, isNew, isFeatured) end
function ZO_MarketProductBase:IsBundle() end
function ZO_MarketProductBase:IsBlank() end
function ZO_MarketProductBase:LayoutBackground(background) end
function ZO_MarketProductBase:GetBackground() end
function ZO_MarketBlankProductBase:New(...) end
function ZO_MarketBlankProductBase:IsBlank() end
function ZO_MarketBlankProductBase:HasPreview() end
function ZO_MarketBlankProductBase:GetBackground() end
function ZO_MarketBlankProductBase:Show() end
function ZO_MarketDialogs_Shared_OpenURLByType(dialog) end
function Market_Singleton:New(...) end
function Market_Singleton:Initialize() end
function Market_Singleton:InitializeEvents() end
function Market_Singleton:RequestOpenMarket() end
function Market_Singleton:InitializePlatformErrors() end
function Market_Singleton:GetMarketProductPurchaseErrorInfo(marketProductId) end
function ZO_Market_Shared:New(...) end
function ZO_Market_Shared:Initialize() end
function ZO_Market_Shared:OnInitialInteraction() end
function ZO_Market_Shared:OnEndInteraction() end
function ZO_Market_Shared:OnStateChanged(oldState, newState) end
function ZO_Market_Shared:RegisterSceneStateChangeCallback() end
function ZO_Market_Shared:ResetCategoryData() end
function ZO_Market_Shared:OnMarketStateUpdated(marketState) end
function ZO_Market_Shared:OnMarketCurrencyUpdated(currentCurrency, difference) end
function ZO_Market_Shared:OnMarketPurchaseResult() end
function ZO_Market_Shared:OnMarketSearchResultsReady() end
function ZO_Market_Shared:UpdateCurrentCategory() end
function ZO_Market_Shared:OnCollectibleUpdated(justUnlocked) end
function ZO_Market_Shared:OnCollectiblesUpdated(numJustUnlocked) end
function ZO_Market_Shared:OnShowMarketProduct(marketProductId) end
function ZO_Market_Shared:OnShowMarketAndSearch(marketProductSearchString) end
function ZO_Market_Shared:UpdateMarket(marketState) end
function ZO_Market_Shared:GetState() end
function ZO_Market_Shared:SetMarketScene(scene) end
function ZO_Market_Shared:BeginPreview() end
function ZO_Market_Shared:EndCurrentPreview() end
function ZO_Market_Shared:OnMarketOpen() end
function ZO_Market_Shared:OnCategorySelected(data) end
function ZO_Market_Shared:FlagMarketCategoriesForRefresh() end
function ZO_Market_Shared:AddKeybinds() end
function ZO_Market_Shared:RemoveKeybinds() end
function ZO_Market_Shared:RefreshKeybinds() end
function ZO_Market_Shared:GetCategoryIndices(data, parentData) end
function ZO_Market_Shared:BuildMarketProductList(data) end
function ZO_Market_Shared:GetPreviewState() end
function ZO_Market_Shared:IsReadyToPreview() end
function ZO_Market_Shared:ShouldAddMarketProduct(filterType, id) end
function ZO_Market_Shared:ShowTutorial(tutorial) end
function ZO_Market_Shared:OnShowing() end
function ZO_Market_Shared:OnShown() end
function ZO_Market_Shared:OnHiding() end
function ZO_Market_Shared:InitializeLabeledGroups() end
function ZO_Market_Shared:AddLabel(labeledGroupName, parentControl, yPadding) end
function ZO_Market_Shared:ClearLabeledGroups() end
function ZO_Market_Shared:AddLabeledGroupTable(labeledGroupName, labeledGroupTable) end
function ZO_Market_Shared:GetCurrentLabeledGroupData() end
function ZO_Market_Shared:GetCurrentLabeledGroupNumProducts() end
function ZO_Market_Shared:GetCurrentLabeledGroupName() end
function ZO_Market_Shared:GetCurrentLabeledGroupProducts() end
function ZO_Market_Shared:AddProductToLabeledGroupTable(labeledGroupTable, productName, product) end
function ZO_Market_Shared:ShowMarket(show) end
function ZO_Market_Shared:OnHidden() end
function ZO_Market_Shared:UpdateCurrencyBalance(currency) end
function ZO_Market_Shared:InitializeKeybindDescriptors() end
function ZO_Market_Shared:InitializeCategories() end
function ZO_Market_Shared:InitializeMarketList() end
function ZO_Market_Shared:InitializeFilters() end
function ZO_Market_Shared:CreateMarketScene() end
function ZO_Market_Shared:BuildCategories() end
function ZO_Market_Shared:OnMarketUpdate() end
function ZO_Market_Shared:OnMarketLoading() end
function ZO_Market_Shared:OnMarketLocked() end
function ZO_Market_Shared:RefreshVisibleCategoryFilter() end
function ZO_Market_Shared:RefreshProducts() end
function ZO_Market_Shared:OnTutorialShowing() end
function ZO_Market_Shared:OnTutorialHidden() end
function ZO_Market_Shared:DisplayEsoPlusOffer() end
function ZO_Market_Shared:GetCategoryData(targetId) end
function ZO_Market_Shared:RequestShowMarketWithSearchString(searchString) end
function ZO_Market_Shared:ResetSearch() end
function ZO_Market_Shared:RemoveActionLayerForTutorial() end
function ZO_Market_Shared:RestoreActionLayerForTutorial() end
function ZO_Market_Shared:GetMarketProductIds(categoryIndex, subCategoryIndex, index, ...) end
function ZO_Market_Shared:GetLabeledGroupLabelTemplate() end
function ZO_Market_Shared:RefreshActions() end
function ZO_Market_Shared:RequestShowMarketProduct(id) end
function ZO_Market_Shared:SearchStart(searchString) end
--internalingame\marketannouncement
function MarketProductCarousel_Gamepad:New(...) end
function MarketProductCarousel_Gamepad:Initialize(...) end
function MarketAnnouncement_Gamepad:New(...) end
function MarketAnnouncement_Gamepad:Initialize(control) end
function MarketAnnouncement_Gamepad:InitializeKeybindButtons() end
function MarketAnnouncement_Gamepad:CreateMarketProduct(productId) end
function ZO_MarketAnnouncement_Gamepad_OnInitialize(control) end
function ZO_MarketAnnouncement_Gamepad_PlayArrowAnimation(control, animation, playForward) end
function MarketAnnouncementMarketProduct_Keyboard:New(...) end
function MarketAnnouncementMarketProduct_Keyboard:Initialize(...) end
function MarketAnnouncementMarketProduct_Keyboard:LayoutCostAndText(description, cost, discountPercent, discountedCost, isNew) end
function MarketAnnouncement_Keyboard:New(...) end
function MarketAnnouncement_Keyboard:Initialize(control) end
function MarketAnnouncement_Keyboard:InitializeKeybindButtons() end
function MarketAnnouncement_Keyboard:CreateMarketProduct(productId) end
function ZO_MarketAnnouncement_Keyboard_OnInitialize(control) end
function ZO_MarketAnnouncementMarketProduct_Base:New(...) end
function ZO_MarketAnnouncementMarketProduct_Base:Initialize(...) end
function ZO_MarketAnnouncementMarketProduct_Base:IsPurchaseLocked() end
function ZO_MarketAnnouncementMarketProduct_Base:GetPurchaseState() end
function ZO_MarketProductCarousel:New(...) end
function ZO_MarketProductCarousel:Initialize(...) end
function ZO_MarketAnnouncement_Base:New(...) end
function ZO_MarketAnnouncement_Base:InitializeKeybindButtons() end
function ZO_MarketAnnouncement_Base:Initialize(control, fragmentConditionFunction) end
function ZO_MarketAnnouncement_Base:OnStateChanged(oldState, newState) end
function ZO_MarketAnnouncement_Base:UpdateLabels(productData) end
function ZO_MarketAnnouncement_Base:SetProductDescription(description) end
function ZO_MarketAnnouncement_Base:UpdatePositionLabel(index) end
function ZO_MarketAnnouncement_Base:GetFragment() end
function ZO_MarketAnnouncement_Base:OnShown() end
function ZO_MarketAnnouncement_Base:OnHiding() end
function ZO_MarketAnnouncement_Base:OnHidden() end
function ZO_MarketAnnouncement_Base:OnMarketAnnouncementCloseKeybind() end
function ZO_MarketAnnouncement_Base:OnMarketAnnouncementViewCrownStoreKeybind() end
function ZO_MarketAnnouncement_Base:CreateMarketProduct(productId) end
function MarketAnnouncement_Manager:New(...) end
function MarketAnnouncement_Manager:Initialize() end
function MarketAnnouncement_Manager:OnPlayerActivated() end
function MarketAnnouncement_Manager:OnStateChanged(oldState, newState) end
--internalingame\scenes
function ZO_GamepadKeybindStripFragment:New(...) end
function ZO_GamepadKeybindStripFragment:Show() end
function ZO_GamepadKeybindStripFragment:Hide() end
function ZO_GamepadMarketKeybindStripFragment:New(...) end
function ZO_GamepadMarketKeybindStripFragment:Show() end
function ZO_GamepadMarketKeybindStripFragment:Hide() end
function ZO_KeybindStripFragment:New(...) end
function ZO_KeybindStripFragment:Show() end
function ZO_KeybindStripFragment:Hide() end
function ZO_ActionLayerFragment:New(actionLayerName) end
function ZO_ActionLayerFragment:Show() end
function ZO_ActionLayerFragment:Hide() end
function ZO_WindowSoundFragment:New(showSoundId, hideSoundId) end
function ZO_WindowSoundFragment:Show() end
function ZO_WindowSoundFragment:Hide() end
function ZO_InternalIngameSceneManager:New(...) end
function ZO_InternalIngameSceneManager:Initialize() end
function ZO_InternalIngameSceneManager:OnRemoteSceneSwap(sceneName) end
function ZO_InternalIngameSceneManager:OnRemoteScenePush(sceneName) end
function ZO_InternalIngameSceneManager:OnScenesLoaded() end
function ZO_InternalIngameSceneManager:Push(sceneName) end
function ZO_InternalIngameSceneManager:SwapCurrentScene(newCurrentScene) end
function ZO_InternalIngameSceneManager:RegisterTopLevel(topLevel, locksUIMode) end
function ZO_InternalIngameSceneManager:HideTopLevel(topLevel) end
function ZO_InternalIngameSceneManager:ShowTopLevel(topLevel) end
function ZO_InternalIngameSceneManager:ToggleTopLevel(topLevel) end
function ZO_InternalIngameSceneManager:HideTopLevels() end
--internalingame\sounds
function ZO_SoundEvents_GetHandlers() end
function ZO_SoundEvent(eventId, ...) end
function ZO_SoundEvents_OnInitialized() end
--internalingamelocalization
function SafeAddVersion(stringId, stringVersion) end
function SafeAddString(stringId, stringValue, stringVersion) end
function ZO_CreateStringId(stringId, stringToAdd) end
--libraries\globals
function ZO_Animation_PlayForwardOrInstantlyToEnd(timeline, instant) end
function ZO_Animation_PlayFromStartOrInstantlyToEnd(timeline, instant) end
function ZO_Animation_PlayBackwardOrInstantlyToStart(timeline, instant) end
function d(...) end
function df(formatter, ...) end
function countGlobals(desiredType) end
function eventArgumentDebugger(...) end
function ZO_Debug_EventNotification(eventCode, register, allEvents) end
function all() e(0, true, true) end end
function ZO_Debug_MultiEventRegister(...) end
function ExecutePatternedChatCommand(commandBase, startId, endId) end
function mon() end
function moc() end
function ZO_TranslateFromLeftSceneAnimation_OnPlay(self, animatingControl) end
function ZO_TranslateFromRightSceneAnimation_OnPlay(self, animatingControl) end
function ZO_TranslateFromBottomSceneAnimation_OnPlay(self, animatingControl) end
function ZO_TranslateFromTopSceneAnimation_OnPlay(self, animatingControl) end
function GetConColor(otherLevel, playerLevel) end
function GetColorForCon(con) end
function GetColorDefForCon(con) end
function GetAllianceColor(alliance) end
function GetColoredAllianceName(alliance) end
function GetBuffColor(effectType) end
function GetStatColor(baseValue, currentValue, defaultOverride) end
function GetStatusEffectColor(statusEffectType) end
function zo_insecurePairs(t) end
function zo_sign(value) end
function zo_binarysearch(searchData, dataList, comparator) end
function zo_binaryinsert(item, searchData, dataList, comparator) end
function zo_binaryremove(searchData, dataList, comparator) end
function zo_clamp(value, minimum, maximum) end
function zo_saturate(value) end
function zo_round(value) end
function zo_roundToZero(value) end
function zo_roundToNearest(value, nearest) end
function zo_strjoin(separator, ...) end
function zo_lerp(from, to, amount) end
function zo_frameDeltaNormalizedForTargetFramerate() end
function zo_deltaNormalizedLerp(from, to, amount) end
function zo_percentBetween(startValue, endValue, value) end
function zo_clampedPercentBetween(startValue, endValue, value) end
function zo_floatsAreEqual(a, b, epsilon) end
function zo_iconFormat(path, width, height) end
function zo_iconFormatInheritColor(path, width, height) end
function zo_iconTextFormat(path, width, height, text) end
function zo_iconTextFormatNoSpace(path, width, height, text) end
function zo_bulletFormat(label, text) end
function zo_callHandler(object, handler, ...) end
function zo_callLater(func, ms) end
function zo_mixin(object, ...) end
function zo_forwardArcSize(startAngle, angle) end
function zo_backwardArcSize(startAngle, angle) end
function zo_arcSize(startAngle, angle) end
function zo_getSafeId64Key(id) end
function NormalizePointToControl(x, y, control) end
function NormalizeMousePositionToControl(control) end
function NormalizeUICanvasPoint(x, y) end
function IgnoreMouseDownEditFocusLoss() end
function SetupEditControlForNameValidation(editControl, maxNameLength) end
function ZO_ResizeControlForBestScreenFit(control) end
function ZO_ReanchorControlForLeftSidePanel(control) end
function ZO_ResizeTextureWidthAndMaintainAspectRatio(texture, width) end
function ZO_StripGrammarMarkupFromCharacterName(characterName) end
function ZO_AbbreviateNumber(amount, precision, useUppercaseSuffixes) end
function ZO_GetSpecializedItemTypeText(itemType, specializedItemType) end
function ZO_GetSpecializedItemTypeTextBySlot(bagId, slotIndex) end
function ZO_GetCraftingSkillName(craftingType) end
function CreateTopLevelWindow(name) end
function CreateControl(name, parent, controlType) end
function CreateControlFromVirtual(name, parent, templateName, optionalNameSuffix) end
function ApplyTemplateToControl(control, templateName) end
function CreateControlRangeFromVirtual(name, parent, templateName, rangeMinSuffix, rangeMaxSuffix) end
function GetControl(name, suffix) end
function CreateSimpleAnimation(animationType, controlToAnimate, delay) end
function zo_strformat(formatString, ...) end
function zo_strtrim(str) end
function ZO_GenerateCommaSeparatedList(argumentTable) end
function ZO_FormatTime(seconds, formatStyle, precision, direction) end
function ZO_FormatTimeMilliseconds(milliseconds, formatType, precisionType, direction) end
function ZO_FormatCountdownTimer(seconds) end
function ZO_FormatTimeLargestTwo(seconds, format) end
function ZO_FormatDurationAgo(seconds) end
function ZO_FormatRelativeTimeStamp(timestamp, precisionType) end
function ZO_FormatClockTime() end
function ZO_SetClockFormat(clockFormat) end
function ZO_NormalizeSecondsPositive(secs) end
function ZO_NormalizeSecondsNegative(secs) end
function ZO_NormalizeSecondsSince(secsSinceRequest) end
function ZO_NormalizeSecondsUntil(secsUntilExpiry) end
--libraries\refresh
function ZO_Refresh:New() end
function ZO_Refresh:AddRefreshGroup(refreshGroup, data) end
function ZO_Refresh:RefreshAll(refreshGroup) end
function ZO_Refresh:RefreshSingle(refreshGroup, ...) end
function ZO_Refresh:UpdateRefreshGroups() end
--libraries\utility
function ZO_Object:New(template) end
function ZO_Object:Subclass() end
function ZO_Object.MultiSubclass(...) end
function A:InitializeA() end
function B:InitializeB() end
function C:New() end
function C:Initialize() end
function ZO_AlphaAnimation_GetAnimation(control) end
function ZO_AlphaAnimation:New(animatedControl) end
function ZO_AlphaAnimation:GetControl() end
function ZO_AlphaAnimation:SetMinMaxAlpha(minAlpha, maxAlpha) end
function ZO_AlphaAnimation:Stop(stopOption) end
function ZO_AlphaAnimation:IsPlaying() end
function ZO_AlphaAnimation:FadeIn(delay, duration, fadeOption, callback, shownOption) end
function ZO_AlphaAnimation:FadeOut(delay, duration, fadeOption, callback, shownOption) end
function ZO_AlphaAnimation:PingPong(initial, final, duration, loopCount, callback) end
function ZO_AlphaAnimation:SetPlaybackLoopsRemaining(loopCount) end
function ZO_AlphaAnimation:SetPlaybackLoopCount(loopCount) end
function ZO_AlphaAnimation:GetPlaybackLoopsRemaining() end
function ZO_Anchor:New(pointOnMe, target, pointOnTarget, offsetX, offsetY) end
function ZO_Anchor:ResetToAnchor(anchorObj) end
function ZO_Anchor:SetFromControlAnchor(control, anchorIndex) end
function ZO_Anchor:GetTarget() end
function ZO_Anchor:SetTarget(control) end
function ZO_Anchor:GetMyPoint() end
function ZO_Anchor:SetMyPoint(myPoint) end
function ZO_Anchor:GetRelativePoint() end
function ZO_Anchor:SetRelativePoint(relPoint) end
function ZO_Anchor:GetOffsets() end
function ZO_Anchor:GetOffsetX() end
function ZO_Anchor:GetOffsetY() end
function ZO_Anchor:SetOffsets(offsetX, offsetY) end
function ZO_Anchor:AddOffsets(offsetX, offsetY) end
function ZO_Anchor:Set(control) end
function ZO_Anchor:AddToControl(control) end
function ZO_Anchor_BoxLayout(currentAnchor, control, controlIndex, containerStride, padX, padY, controlWidth, controlHeight, initialX, initialY, growDirection) end
function ZO_Anchor_DynamicAnchorTo(control, anchorTo, offsetX, offsetY) end
function ZO_Anchor_ToCenteredLabel(control, anchor, labelWidth) end
function ZO_Anchor_OnRing(control, anchorToControl, x, y, radiusArg) end
function ZO_Anchor_ByAngle(control, anchorToControl, theta, radiusArg) end
function ZO_Anchor_LineInContainer(line, container, startX, startY, endX, endY) end
function ZO_AutoComplete:New(...) end
function ZO_AutoComplete:Initialize(editControl, includeFlags, excludeFlags, onlineOnly, maxResults, mode, allowArrows, dontCallHookedHandlers) end
function ZO_AutoComplete:SetEnabled(enabled) end
function ZO_AutoComplete:SetIncludeFlags(includeFlags) end
function ZO_AutoComplete:SetExcludeFlags(excludeFlags) end
function ZO_AutoComplete:SetOnlineOnly(onlineOnly) end
function ZO_AutoComplete:SetMaxResults(maxResults) end
function ZO_AutoComplete:SetEditControl(editControl) end
function ZO_AutoComplete:SetOwner(owner) end
function ZO_AutoComplete:SetKeepFocusOnCommit(keepFocus) end
function ZO_AutoComplete:Show(text) end
function ZO_AutoComplete:Hide() end
function ZO_AutoComplete:IsOpen() end
function ZO_AutoComplete:SetUseCallbacks(useCallbacks) end
function ZO_AutoComplete:SetAnchorStyle(style) end
function ZO_AutoComplete:GetAutoCompletionResults(text) end
function ZO_AutoComplete:ApplyAutoCompletionResults(...) end
function ZO_AutoComplete:OnTextChanged() end
function ZO_AutoComplete:ChangeAutoCompleteIndex(offset) end
function ZO_AutoComplete:GetNumAutoCompleteEntries() end
function ZO_AutoComplete:GetAutoCompleteIndex() end
function ZO_AutoComplete:OnCommit(commitBehavior, commitMethod) end
function ZO_CallbackObject:New() end
function ZO_CallbackObject:RegisterCallback(eventName, callback, arg) end
function ZO_CallbackObject:UnregisterCallback(eventName, callback) end
function ZO_CallbackObject:UnregisterAllCallbacks(eventName) end
function ZO_CallbackObject:FireCallbacks(eventName, ...) end
function ZO_CallbackObject:Clean(eventName) end
function ZO_CategoryManager:New() end
function ZO_CategoryManager:GetCategoryCache() end
function ZO_CategoryManager:GetCategoryCacheData(catId) end
function ZO_CategoryManager:GetCategoryData() end
function ZO_CategoryManager:ClearCategoryCache() end
function ZO_CategoryManager:ClearCategoryData() end
function ZO_CategoryManager:AddCategory(catId, parentId, data) end
function ZO_CategoryManager:HasCategory(catId) end
function ZO_CategoryManager:InsertData(parentCatId, data, comparator) end
function ZO_CategoryManager:InsertDataHelper(nodeList, comparator, level) end
function ZO_CategoryManager:InsertAtLevel(node, comparator, level) end
function ZO_CircularBuffer:New(maxSize) end
function ZO_CircularBuffer:Add(item) end
function ZO_CircularBuffer:CalculateIndex(index) end
function ZO_CircularBuffer:At(index) end
function ZO_CircularBuffer:Clear() end
function ZO_CircularBuffer:Size() end
function ZO_CircularBuffer:MaxSize() end
function ZO_CircularBuffer:IsFull() end
function ZO_CircularBuffer:SetMaxSize(maxSize) end
function ZO_CircularBuffer:GetEnumerator() end
function ZO_ColorDef:New(r, g, b, a) end
function ZO_ColorDef:FromInterfaceColor(colorType, fieldValue) end
function ZO_ColorDef:UnpackRGB() end
function ZO_ColorDef:UnpackRGBA() end
function ZO_ColorDef:SetRGB(r, g, b) end
function ZO_ColorDef:SetRGBA(r, g, b, a) end
function ZO_ColorDef:SetAlpha(a) end
function ZO_ColorDef:IsEqual(other) end
function ZO_ColorDef:Clone() end
function ZO_ColorDef:ToHex() end
function ZO_ColorDef:Colorize(text) end
function ZO_ColorDef:Lerp(colorToLerpTorwards, amount) end
function ZO_LinearEase(progress) end
function ZO_EaseInQuadratic(progress) end
function ZO_EaseOutQuadratic(progress) end
function ZO_EaseInOutQuadratic(progress) end
function ZO_EaseInCubic(progress) end
function ZO_EaseOutCubic(progress) end
function ZO_EaseInOutCubic(progress) end
function ZO_EaseInQuartic(progress) end
function ZO_EaseOutQuartic(progress) end
function ZO_EaseInOutQuartic(progress) end
function ZO_EaseInQuintic(progress) end
function ZO_EaseOutQuintic(progress) end
function ZO_EaseInOutQuintic(progress) end
function ZO_GenerateCubicBezierEase(x1, y1, x2, y2) end
function ZO_EditControlGroup:New() end
function ZO_EditControlGroup:Initialize() end
function ZO_EditControlGroup:OnTabPressed(control) end
function ZO_EditControlGroup:AddEditControl(control, autoCompleteObject) end
function ZO_FadingControlBuffer_GetEntryControl(entry) end
function ZO_FadingControlBuffer_GetHeaderControl(header) end
function ZO_FadingControlBuffer_GetLineControl(line) end
function ZO_FadingControlBuffer:New(...) end
function ZO_FadingControlBuffer:Initialize(control, maxDisplayedEntries, maxHeight, maxLinesPerEntry, fadeAnimationName, translateAnimationName, anchor) end
function ZO_FadingControlBuffer:SetTranslateDuration(translateDuration) end
function ZO_FadingControlBuffer:SetHoldTimes(...) end
function ZO_FadingControlBuffer:SetHoldDisplayingEntries(holdEntries) end
function ZO_FadingControlBuffer:SetAdditionalVerticalSpacing(additionalVerticalSpacing) end
function ZO_FadingControlBuffer:SetFadesInImmediately(fadesInImmediately) end
function ZO_FadingControlBuffer:SetPushDirection(pushDirection) end
function ZO_FadingControlBuffer:AddTemplate(templateName, templateData) end
function ZO_FadingControlBuffer:HasTemplate(templateName) end
function ZO_FadingControlBuffer:AddEntry(templateName, entry) end
function ZO_FadingControlBuffer:ClearAll() end
function ZO_FadingControlBuffer:HasEntries() end
function ZO_FadingControlBuffer:FadeAll() end
function ZO_FadingControlBuffer:GetEntryIndex(entryControl) end
function ZO_FadingControlBuffer:GetLineIndex(entryControl, lineControl) end
function ZO_FadingControlBuffer:TryHandlingExistingEntry(templateName, templateData, entry) end
function ZO_FadingControlBuffer:GetEntryHoldTime(alertEntry) end
function ZO_FadingControlBuffer:UpdateFadeOutDelayAndPlayFromOffset(alertEntry, adjustType) end
function ZO_FadingControlBuffer:UpdateFadeInDelay(alertEntry, fadeInDelayFactor) end
function ZO_FadingControlBuffer:ReleaseControl(alertControl) end
function ZO_FadingControlBuffer:CalcHeightOfEntryAfterPrepending(entryControl, newLines) end
function ZO_FadingControlBuffer:CalcHeightOfEntry(templateName, entry, maxLines) end
function ZO_FadingControlBuffer:CalcHeightOfActiveEntries() end
function ZO_FadingControlBuffer:CanDisplayEntry(templateName, entry, prependToEntryControl) end
function ZO_FadingControlBuffer:HasQueuedEntry() end
function ZO_FadingControlBuffer:EnqueueEntry(templateName, entry) end
function ZO_FadingControlBuffer:DisplayNextQueuedEntry() end
function ZO_FadingControlBuffer:PrependLinesToExistingEntry(entryControl, newLines) end
function ZO_FadingControlBuffer:DisplayEntry(templateName, entry) end
function ZO_FadingControlBuffer:MoveEntriesOrLines(entriesOrLines, preserveFade) end
function ZO_FadingControlBuffer:TryCondenseBuffer() end
function ZO_FadingControlBuffer:MoveEntriesOrLinesCalculations(control, targetBottomY, topY, preserveFade) end
function ZO_FadingStationaryControlBuffer:New(...) end
function ZO_FadingStationaryControlBuffer:Initialize(control, maxDisplayedEntries, fadeAnimationName, iconAnimationName, containerAnimationName, anchor, controllerType) end
function ZO_FadingStationaryControlBuffer:OnUpdateBuffer(timeMs) end
function ZO_FadingStationaryControlBuffer:AddEntry(templateName, entry) end
function ZO_FadingStationaryControlBuffer:SetContainerShowTime(time) end
function ZO_FadingStationaryControlBuffer:AddTemplate(templateName, templateData) end
function ZO_FadingStationaryControlBuffer:SetAdditionalEntrySpacingY(additionalSpacingY) end
function ZO_FadingStationaryControlBuffer:GetActiveEntryIndex(entryControl) end
function ZO_FadingStationaryControlBuffer:ReleaseAllControls() end
function ZO_FadingStationaryControlBuffer:RefreshBatchAfterRelease() end
function ZO_FadingStationaryControlBuffer:RefreshBatchAfterFading() end
function ZO_FadingStationaryControlBuffer:ReleaseControl(alertControl) end
function ZO_FadingStationaryControlBuffer:TryConcatWithExistingEntry(templateName, entry, tableLocation) end
function ZO_FadingStationaryControlBuffer:CanDisplayMore() end
function ZO_FadingStationaryControlBuffer:CanDisplayEntry() end
function ZO_FadingStationaryControlBuffer:FadeAll() end
function ZO_FadingStationaryControlBuffer:UpdateFadeInDelay(entryControl, fadeInDelayFactor) end
function ZO_FadingStationaryControlBuffer:DisplayEntry(templateName, entry, entryNumber, hasCurrentEntries) end
function ZO_FadingStationaryControlBuffer:FlushEntries() end
function ZO_FadingStationaryControlBuffer:AddToBatch(templateName, queuedEntry, batch) end
function ZO_FadingStationaryControlBuffer:DisplayBatches() end
function ZO_Gamepad_GetLeftStickEasedX() end
function ZO_Gamepad_GetLeftStickEasedY() end
function ZO_Gamepad_GetRightStickEasedX() end
function ZO_Gamepad_GetRightStickEasedY() end
function ZO_Gamepad_CreateListTriggerKeybindDescriptors(list, optionalHeaderComparator) end
function ZO_Gamepad_AddListTriggerKeybindDescriptors(descriptor, list, optionalHeaderComparator) end
function ZO_Gamepad_AddForwardNavigationKeybindDescriptors(descriptor, navigationType, callback, name, visible, enabled, sound) end
function ZO_Gamepad_AddForwardNavigationKeybindDescriptorsWithSound(descriptor, navigationType, callback, name, visible, enabled) end
function ZO_Gamepad_AddBackNavigationKeybindDescriptors(descriptor, navigationType, callback, name, sound) end
function ZO_Gamepad_AddBackNavigationKeybindDescriptorsWithSound(descriptor, navigationType, callback, name) end
function ZO_Gamepad_TempVirtualKeyboardGenRandomString(prefix, totalLength) end
function ZO_PreHook(objectTable, existingFunctionName, hookFunction) end
function ZO_PreHookHandler(control, handlerName, hookFunction) end
function ZO_LinkHandler_InsertLink(link) end
function ZO_LinkHandler_OnLinkClicked(link, button, control) end
function ZO_LinkHandler_OnLinkMouseUp(link, button, control) end
function ZO_LinkHandler_CreateLinkWithFormat(text, color, linkType, linkStyle, stringFormat, ...) end
function ZO_LinkHandler_CreateLink(text, color, linkType, ...) end
function ZO_LinkHandler_CreateLinkWithoutBrackets(text, color, linkType, ...) end
function ZO_LinkHandler_ParseLink(link) end
function ZO_LinkHandler_CreatePlayerLink(displayOrCharacterName) end
function ZO_LinkHandler_CreateDisplayNameLink(displayName) end
function ZO_LinkHandler_CreateCharacterLink(characterName) end
function ZO_LinkHandler_CreateChannelLink(channelName) end
function ZO_LinkHandler_CreateURLLink(url, displayText) end
function ZO_LinkHandler_CreateChatLink(linkFunction, ...) end
function ZO_ListBox:New(rowTemplate, container, displayedRowCount, maxRowCount, rowPopulationFunction, scrollUpdateFunction, rowPadding) end
function ZO_ListBox:SetScrollUpdateFunction(updateFunction) end
function ZO_ListBox:SetPopulatorFunction(populatorFunction) end
function ZO_ListBox:GetScrollExtents() end
function ZO_ListBox:ScrollTo(newScrollPosition) end
function ZO_ListBox:Scroll(scrollByRows) end
function ZO_ListBox:Refresh() end
function ZO_ListBox:SetMaxRows(maxRows) end
function ZO_ObjectPool:New(factoryFunction, resetFunction) end
function ZO_ObjectPool:GetNextFree() end
function ZO_ObjectPool:GetNextControlId() end
function ZO_ObjectPool:GetTotalObjectCount() end
function ZO_ObjectPool:GetActiveObjectCount() end
function ZO_ObjectPool:GetActiveObjects() end
function ZO_ObjectPool:GetFreeObjectCount() end
function ZO_ObjectPool:AcquireObject(objectKey) end
function ZO_ObjectPool:GetExistingObject(objectKey) end
function ZO_ObjectPool:ReleaseObject(objectKey) end
function ZO_ObjectPool:ReleaseAllObjects() end
function ZO_ObjectPool_CreateControl(templateName, objectPool, parentControl) end
function ZO_ObjectPool_CreateNamedControl(name, templateName, objectPool, parentControl) end
function ZO_ObjectPool_DefaultResetControl(control) end
function ZO_FormatUserFacingDisplayName(name) end
function ZO_FormatUserFacingCharacterOrDisplayName(characterOrDisplayName) end
function ZO_FormatManualNameEntry(name) end
function ZO_GetPlatformAccountLabel() end
function ZO_GetPlatformUserFacingName(characterName, displayName) end
function ZO_SavePlayerConsoleProfile() end
function ZO_ShouldPreferUserId() end
function ZO_GetPrimaryPlayerNameFromUnitTag(unitTag, useInternalFormat) end
function ZO_GetSecondaryPlayerNameFromUnitTag(unitTag, useInternalFormat) end
function ZO_GetPrimaryPlayerName(displayName, characterName, useInternalFormat) end
function ZO_GetSecondaryPlayerName(displayName, characterName, useInternalFormat) end
function ZO_GetSecondaryPlayerNameWithTitleFromUnitTag(unitTag) end
function ZO_GetPrimaryPlayerNameWithSecondary(displayName, characterName) end
function ZO_PrioritizedVisibility:New(...) end
function ZO_PrioritizedVisibility:Initialize() end
function ZO_PrioritizedVisibility:Add(objectToControl, priority) end
function ZO_PrioritizedVisibility:SetHidden(objectToControl, hidden) end
function ZO_PrioritizedVisibility:IsHidden(objectToControl) end
function ZO_PrioritizedVisibility:SetSupressed(supressed) end
function ZO_PrioritizedVisibility:IsSuppressed() end
function ZO_QueuedSoundPlayer:New(...) end
function ZO_QueuedSoundPlayer:Initialize(soundPaddingMs) end
function ZO_QueuedSoundPlayer:SetFinishedAllSoundsCallback(finishedAllSoundsCallback) end
function ZO_QueuedSoundPlayer:PlaySound(soundName, soundLength) end
function ZO_QueuedSoundPlayer:IsPlaying() end
function ZO_QueuedSoundPlayer:StartSound(soundName, soundLength) end
function ZO_QueuedSoundPlayer:OnSoundFinished() end
function ZO_RadioButtonGroup:New() end
function ZO_RadioButtonGroup:HandleClick(button, buttonId) end
function ZO_RadioButtonGroup:Add(button) end
function ZO_RadioButtonGroup:SetEnabled(enabled) end
function ZO_RadioButtonGroup:SetButtonIsValidOption(button, isValidOption) end
function ZO_RadioButtonGroup:Clear() end
function ZO_RadioButtonGroup:SetClickedButton(button) end
function ZO_RadioButtonGroup:GetClickedButton() end
function ZO_RadioButtonGroup:UpdateFromData(isPressedQueryFn) end
function ZO_SavedVars:New(savedVariableTable, version, namespace, defaults, profile, displayName, characterName, characterId, characterKeyType) end
function ZO_SavedVars:NewCharacterNameSettings(savedVariableTable, version, namespace, defaults, profile) end
function ZO_SavedVars:NewCharacterIdSettings(savedVariableTable, version, namespace, defaults, profile) end
function ZO_SavedVars:NewAccountWide(savedVariableTable, version, namespace, defaults, profile, displayName) end
function GetNewSavedVars(savedVariableTable, version, namespace, defaults, profile, displayName, characterName, characterId, characterKeyType) end
function CopyDefaults(sv, defaults) end
function CreateExposedInterface(rawSavedTable, version, namespace, defaults, profile, displayName, playerName, cachedInterfaces) end
function ZO_SetSliderValueAnimated(self, targetValue) end
function ZO_UpdateScrollFade(useFadeGradient, scroll, scrollDirection, maxFadeGradientSize) end
function ZO_OnAnimationStop(animationObject, control) end
function ZO_OnAnimationUpdate(animationObject, progress) end
function ZO_GetScrollMaxFadeGradientSize(scrollObject) end
function ZO_SetScrollMaxFadeGradientSize(scrollObject, maxFadeGradientSize) end
function ZO_CreateScrollAnimation(scrollObject) end
function ZO_ScrollRelative(self, verticalDelta) end
function ZO_ScrollAnimation_MoveWindow(self, value) end
function ZO_ScrollAnimation_OnExtentsChanged(self) end
function ZO_TabButton_Select(self, callbackOptions) end
function ZO_TabButton_Unselect(self, callbackOptions) end
function ZO_TabButton_Text_SetFont(self, font) end
function ZO_TabButton_Text_Initialize(self, tabType, initialText, pressedCallback, unpressedCallback, tabSizeChangedCallback) end
function ZO_TabButtonOverrideIconSizeConstant(overrideValue) end
function ZO_TabButtonResetIconSizeConstant() end
function ZO_CreateUniformIconTabData(sharedDataTable, icon, width, height, pressedIcon, unpressedIcon, mouseoverIcon, disabledIcon) end
function ZO_TabButton_Icon_Initialize(self, tabType, visualData, pressedCallback, unpressedCallback) end
function ZO_TabButton_SetTooltipText(tabButton, text, position) end
function ZO_TabButton_SetMouseEnterHandler(tabButton, mouseEnterHandler) end
function ZO_TabButton_SetMouseExitHandler(tabButton, mouseExitHandler) end
function ZO_TabButton_OnMouseEnter(self) end
function ZO_TabButton_OnMouseExit(self) end
function ZO_TabButton_IsDisabled(self) end
function ZO_TabButton_SetDisabled(self, disabled) end
function ZO_TabButton_Text_SetText(self, text) end
function ZO_TabButton_Text_GetText(self) end
function ZO_TabButton_Text_SetTextColor(self, color) end
function ZO_TabButton_Text_AllowColorChanges(self, allow) end
function ZO_TabButton_Text_RestoreDefaultColors(self) end
function ZO_TabButtonGroup:New() end
function ZO_TabButtonGroup:HandleMouseDown(tabButton, buttonId) end
function ZO_TabButtonGroup:Add(tabButton) end
function ZO_TabButtonGroup:Remove(tabButton) end
function ZO_TabButtonGroup:Clear() end
function ZO_TabButtonGroup:SetClickedButton(tabButton) end
function ZO_TabButtonGroup:GetClickedButton() end
function NonContiguousCount(tableObject) end
function ZO_TableOrderingFunction(entry1, entry2, sortKey, sortKeys, sortOrder) end
function ZO_ClearNumericallyIndexedTable(t) end
function ZO_ClearTable(t) end
function ZO_ShallowTableCopy(source, dest) end
function ZO_DeepTableCopy(source, dest) end
function ZO_IsElementInNumericallyIndexedTable(table, element) end
function ZO_TreeNode:New(myTree, controlData, myParent, childIndent) end
function ZO_TreeNode:SetExpandedCallback(callback) end
function ZO_TreeNode:ToggleExpanded(expanded) end
function ZO_TreeNode:IsExpanded() end
function ZO_TreeNode:IsShowing() end
function ZO_TreeNode:HasChildren() end
function ZO_TreeNode:GetNestingLevel() end
function ZO_TreeNode:GetControl() end
function ZO_TreeNode:GetOwningTree() end
function ZO_TreeNode:GetNextSibling() end
function ZO_TreeNode:GetParent() end
function ZO_TreeNode:GetChildIndent() end
function ZO_TreeNode:SetOffsetY(offsetY) end
function ZO_TreeControl:New(initialAnchor, indentXOffset, verticalSpacing) end
function ZO_TreeControl:AddChild(atNode, insertedControl, childIndent) end
function ZO_TreeControl:AddSibling(atNode, insertedControl, childIndent) end
function ZO_TreeControl:AddSiblingAfterNode(atNode, insertedControl, childIndent) end
function ZO_TreeControl:RemoveNode(node) end
function ZO_TreeControl:Clear() end
function ZO_TreeControl:Update(updateFromNode, indent, anchor, firstControl) end
function ZO_TreeControl:SetRelativePoint(relativePoint) end
function ZO_TreeControl:SetIndent(indentX) end
--libraries\zo_bulletlist
function ZO_BulletList:New(control, labelTemplate, bulletTemplate, secondaryBulletTemplate) end
function ZO_BulletList:SetLinePaddingY(padding) end
function ZO_BulletList:SetBulletPaddingX(padding) end
function ZO_BulletList:AddLine(text, useSecondaryBullet) end
function ZO_BulletList:Clear() end
--libraries\zo_buttontabbar
function ZO_GamepadButtonTabBar:New(...) end
function ZO_GamepadButtonTabBar:Initialize(control, onSelectedCallback, onUnselectedCallback, onPressedCallback) end
function ZO_GamepadButtonTabBar:AddButton(control, data) end
function ZO_GamepadButtonTabBar:Activate() end
function ZO_GamepadButtonTabBar:Deactivate() end
function ZO_GamepadButtonTabBar:UpdateDirectionalInput() end
function ZO_GamepadButtonTabBar:SetSelectedButton(index) end
function ZO_GamepadButtonTabBar:IsActivated() end
--libraries\zo_colorpicker
function ZO_ColorPicker:New(control) end
function ZO_ColorPicker:Initialize(control) end
function ZO_ColorPicker:UpdateColors(r, g, b, a) end
function ZO_ColorPicker:OnColorSet(r, g, b) end
function ZO_ColorPicker:OnValueSet(value) end
function ZO_ColorPicker:OnAlphaSet(value) end
function ZO_ColorPicker:SetColor(r, g, b, a) end
function ZO_ColorPicker:GetColors() end
function ZO_ColorPicker:Confirm() end
function ZO_ColorPicker:Cancel() end
function ZO_ColorPicker:Show(colorSelectedCallback, r, g, b, a) end
function ZO_ColorPicker:IsShown() end
function ZO_ColorPicker:UpdateLayout() end
function ZO_ColorPicker:SetAlphaLimits(alphaLowerLimit, alphaUpperLimit) end
function ZO_ColorPicker_OnInitialized(self) end
--libraries\zo_colorswatchpicker
function ZO_PaletteButtonManager:New() end
function ZO_ColorSwatchPicker:New(control) end
function ZO_ColorSwatchPicker:AddEntry(paletteIndex, r, g, b) end
function ZO_ColorSwatchPicker:Clear() end
function ZO_ColorSwatchPicker:SetClickedCallback(callback) end
function ZO_ColorSwatchPicker:OnClicked(entry) end
function ZO_ColorSwatchPicker:SetEntryPressed(entry) end
function ZO_ColorSwatchPicker:SetSelected(index) end
function ZO_ColorSwatchPicker:SetEnabled(enabled) end
function ZO_ColorSwatchPicker_Create(colorPicker) end
function ZO_ColorSwatchPicker_OnEntryClicked(entry) end
function ZO_ColorSwatchPicker_SetClickedCallback(colorPicker, callback) end
function ZO_ColorSwatchPicker_AddColor(colorPicker, paletteIndex, r, g, b) end
function ZO_ColorSwatchPicker_Clear(colorPicker) end
function ZO_ColorSwatchPicker_SetSelected(colorPicker, index) end
function ZO_ColorSwatchPicker_SetEnabled(colorPicker, enabled) end
--libraries\zo_combobox
function ZO_ComboBox_Gamepad:New(...) end
function ZO_ComboBox_Gamepad:Initialize(control) end
function ZO_ComboBox_Gamepad:ShowDropdownInternal() end
function ZO_ComboBox_Gamepad:HideDropdownInternal() end
function ZO_ComboBox_Gamepad:OnClearItems() end
function ZO_ComboBox_Gamepad:OnItemAdded() end
function ZO_ComboBox_Gamepad:GetNormalColor(item) end
function ZO_ComboBox_Gamepad:GetHighlightColor(item) end
function ZO_ComboBox_Gamepad:SetItemTemplate(template) end
function ZO_ComboBox_Gamepad:GetHeight() end
function ZO_ComboBox_Gamepad:AddMenuItems() end
function ZO_ComboBox_Gamepad:OnItemSelected(control, data) end
function ZO_ComboBox_Gamepad:OnItemDeselected(control, data) end
function ZO_ComboBox_Gamepad:ClearMenuItems() end
function ZO_ComboBox_Gamepad:SetActive(active) end
function ZO_ComboBox_Gamepad:HighlightSelectedItem() end
function ZO_ComboBox_Gamepad:SelectHighlightedItem() end
function ZO_ComboBox_Gamepad:SelectItemByIndex(index, ignoreCallback) end
function ZO_ComboBox_Gamepad:SetHighlightedItem(highlightIndex, reselectIndex) end
function ZO_ComboBox_Gamepad:TrySelectItemByData(itemData) end
function ZO_ComboBox_Gamepad:Activate() end
function ZO_ComboBox_Gamepad:Deactivate(blockCallback) end
function ZO_ComboBox_Gamepad:IsActive() end
function ZO_ComboBox_Gamepad:SetDeactivatedCallback(callback, args) end
function ZO_ComboBox_Gamepad:InitializeKeybindStripDescriptors() end
function ZO_ComboBox_Gamepad:UpdateAnchors(selectedControl) end
function ZO_GamepadComboBoxDropdown:New(...) end
function ZO_GamepadComboBoxDropdown:Initialize(control) end
function ZO_GamepadComboBoxDropdown:SetPadding(padding) end
function ZO_GamepadComboBoxDropdown:Show() end
function ZO_GamepadComboBoxDropdown:Hide() end
function ZO_GamepadComboBoxDropdown:AnchorToControl(control, offsetY) end
function ZO_GamepadComboBoxDropdown:AcquireControl(item, relativeControl) end
function ZO_GamepadComboBoxDropdown:AddHeight(height) end
function ZO_GamepadComboBoxDropdown:AddItem(data) end
function ZO_GamepadComboBoxDropdown:Clear() end
function ZO_ComboBox_Gamepad_Dropdowm_Initialize(control) end
function ZO_ComboBox:New(container) end
function ZO_ComboBox:AddMenuItems() end
function ZO_ComboBox:ShowDropdownInternal() end
function ZO_ComboBox:HideDropdownInternal() end
function ZO_ComboBox_DropdownClicked(container) end
function ZO_ScrollableComboBox:New(container) end
function ZO_ScrollableComboBox:Initialize(container) end
function ZO_ScrollableComboBox:SetupScrollList() end
function ZO_ScrollableComboBox:OnGlobalMouseUp(eventCode, button) end
function ZO_ScrollableComboBox:SetSpacing(spacing) end
function ZO_ScrollableComboBox:SetHeight(height) end
function ZO_ScrollableComboBox:IsDropdownVisible() end
function ZO_ScrollableComboBox:AddMenuItems() end
function ZO_ScrollableComboBox:ShowDropdownOnMouseUp() end
function ZO_ScrollableComboBox:SetSelected(index) end
function ZO_ScrollableComboBox:ShowDropdownInternal() end
function ZO_ScrollableComboBox:HideDropdownInternal() end
function ZO_ScrollableComboBox_Entry_OnMouseEnter(entry) end
function ZO_ScrollableComboBox_Entry_OnMouseExit(entry) end
function ZO_ScrollableComboBox_Entry_OnSelected(entry) end
function ZO_ComboBox_Base:ShowDropdownInternal() end
function ZO_ComboBox_Base:HideDropdownInternal() end
function ZO_ComboBox_Base:OnClearItems() end
function ZO_ComboBox_Base:OnItemAdded() end
function ZO_ComboBox_Base:New(...) end
function ZO_ComboBox_Base:Initialize(container) end
function ZO_ComboBox_Base:GetContainer() end
function ZO_ComboBox_Base:SetPreshowDropdownCallback(fn) end
function ZO_ComboBox_Base:SetFont(font) end
function ZO_ComboBox_Base:SetDropdownFont(font) end
function ZO_ComboBox_Base:SetSelectedItemFont(font) end
function ZO_ComboBox_Base:SetSpacing(spacing) end
function ZO_ComboBox_Base:SetSelectedColor(color, colorG, colorB, colorA) end
function ZO_ComboBox_Base:SetNormalColor(color, colorG, colorB, colorA) end
function ZO_ComboBox_Base:SetHighlightedColor(color, colorG, colorB, colorA) end
function ZO_ComboBox_Base:SetSortsItems(sortsItems) end
function ZO_ComboBox_Base:SetSortOrder(sortOrder, sortType) end
function ZO_ComboBox_Base:IsDropdownVisible() end
function ZO_ComboBox_Base:SetVisible(visible) end
function ZO_ComboBox_Base:CreateItemEntry(name, callback) end
function ZO_ComboBox_Base:AddItem(itemEntry, updateOptions) end
function ZO_ComboBox_Base:ShowDropdown() end
function ZO_ComboBox_Base:HideDropdown() end
function ZO_ComboBox_Base:ClearItems() end
function ZO_ComboBox_Base:GetItems() end
function ZO_ComboBox_Base:GetNumItems() end
function ZO_ComboBox_Base:AddItems(items) end
function ZO_ComboBox_Base:UpdateItems() end
function ZO_ComboBox_Base:SetDontSetSelectedTextOnSelection(dontSetSelectedTextOnSelection) end
function ZO_ComboBox_Base:SetSelectedItemText(itemText) end
function ZO_ComboBox_Base:SetSelectedItem(itemText) end
function ZO_ComboBox_Base:ItemSelectedClickHelper(item, ignoreCallback) end
function ZO_ComboBox_Base_ItemSelectedClickHelper(comboBox, item, ignoreCallback) end
function ZO_ComboBox_Base:SelectItem(item, ignoreCallback) end
function ZO_ComboBox_Base:SelectItemByIndex(index, ignoreCallback) end
function ZO_ComboBox_Base:SelectFirstItem() end
function ZO_ComboBox_Base:SetSelectedItemByEval(eval, ignoreCallback) end
function ZO_ComboBox_Base:GetSelectedItem() end
function ZO_ComboBox_Base:GetSelectedItemData() end
function ZO_ComboBox_Base:EnumerateEntries(functor) end
function ZO_ComboBox_Base:GetSelectedTextColor(enabledState) end
function ZO_ComboBox_Base:SetEnabled(enabled) end
function ZO_ComboBox_Base:GetControl() end
function ZO_ComboBox_ObjectFromContainer(container) end
function ZO_ComboBox_OpenDropdown(container) end
function ZO_ComboBox_HideDropdown(container) end
function ZO_ComboBox_Enable(container) end
function ZO_ComboBox_Disable(container) end
--libraries\zo_contextmenus
function ClearMenu() end
function IsMenuVisisble() end
function SetMenuMinimumWidth(minWidth) end
function SetMenuSpacing(spacing) end
function SetMenuPad(menuPad) end
function GetMenuOwner(menu) end
function MenuOwnerClosed(potentialOwner) end
function ShowMenu(owner, initialRefCount, menuType) end
function AnchorMenu(control, offsetY) end
function SetAddMenuItemCallback(itemAddedCallback) end
function SetMenuHiddenCallback(menuHiddenCallback) end
function GetMenuPadding() end
function AddMenuItem(mytext, myfunction, itemType, myFont, normalColor, highlightColor, itemYPad) end
function UpdateMenuItemState(item, state) end
function ZO_Menu_SelectItem(control) end
function ZO_Menu_UnselectItem(control) end
function ZO_Menu_SetSelectedIndex(index) end
function ZO_Menu_GetNumMenuItems() end
function ZO_Menu_GetSelectedIndex() end
function ZO_Menu_GetSelectedText() end
function ZO_Menu_EnterItem(control) end
function ZO_Menu_ExitItem(control) end
function ZO_Menu_ClickItem(control, button) end
function ZO_Menu_OnHide(control) end
function ZO_Menu_Initialize() end
function ZO_Menu_WasLastCommandFromMenu() end
function ZO_Menu_SetLastCommandWasFromMenu(menuCommand) end
--libraries\zo_crossfadebg
function Crossfade:New(...) end
function Crossfade:Initialize(control) end
function Crossfade:InitializeBuffer(control, startingTexture, initialDrawLevel) end
function Crossfade:OnComplete() end
function Crossfade:InitializeBufferImages(frontBufferImage, backBufferImage) end
function Crossfade:DoCrossfade(newBG) end
function Crossfade:PlaySlideShow(delay, ...) end
function Crossfade:StopSlideShow() end
function ZO_CrossfadeBG_OnInitialized(self) end
function ZO_CrossfadeBG_GetObject(control) end
function ZO_CrossfadeBG_OnCrossfadeComplete(timeline, completedPlaying) end
--libraries\zo_dialog
function DialogKeybindStripDescriptor:New() end
function DialogKeybindStripDescriptor:Initialize() end
function DialogKeybindStripDescriptor:Reset() end
function DialogKeybindStripDescriptor:SetAlignment(alignment) end
function DialogKeybindStripDescriptor:SetButtonCallback(buttonCallback) end
function DialogKeybindStripDescriptor:SetText(text) end
function DialogKeybindStripDescriptor:SetDialog(dialog) end
function DialogKeybindStripDescriptor:SetVisible(visible) end
function DialogKeybindStripDescriptor:SetEthereal(ethereal) end
function DialogKeybindStripDescriptor:SetEnabled(enabled) end
function DialogKeybindStripDescriptor:SetHandlesKeyUp(handlesKeyUp) end
function DialogKeybindStripDescriptor:SetKeybind(keybind, index) end
function DialogKeybindStripDescriptor:SetSound(sound) end
function DialogKeybindStripDescriptor:SetOnShowCooldown(timeMs) end
function DialogKeybindStripDescriptor:GetOnShowCooldown() end
function DialogKeybindStripDescriptor:SetDefaultSoundFromKeybind(twoOrMoreButtons) end
function ZO_GenericGamepadDialog_RefreshKeybinds(dialog) end
function ZO_GenericGamepadDialog_UpdateDirectionalInput(dialog) end
function ZO_GenericGamepadDialog_GetControl(dialogType) end
function ZO_GenericGamepadDialog_BaseSetup(dialog, title, mainText) end
function ZO_GenericGamepadDialog_DefaultSetup(dialog, data) end
function ZO_GenericGamepadDialog_OnInitialized(dialog) end
function ZO_GenericGamepadDialog_Show(dialog) end
function ZO_GenericGamepadDialog_IsShowing() end
function ZO_GenericGamepadDialog_ShowTooltip(dialog) end
function ZO_GenericGamepadDialog_HideTooltip(dialog) end
function ZO_GenericParametricListGamepadDialogTemplate_OnInitialized(dialog) end
function ZO_GenericCooldownGamepadDialogTemplate_OnInitialized(dialog) end
function ZO_GenericCooldownGamepadDialogTemplate_Setup(dialog) end
function ZO_GenericCenteredGamepadDialogTemplate_OnInitialized(dialog) end
function ZO_GenericCenteredGamepadDialogTemplate_Setup(dialog) end
function ZO_GenericGamepadStaticListDialogTemplate_OnInitialized(dialog) end
function ZO_GenericStaticListGamepadDialogTemplate_Setup(dialog, data) end
function ZO_GenericGamepadItemSliderDialogTemplate_OnInitialized(dialog) end
function ZO_GenericGamepadItemSliderDialogTemplate_GetSliderValue(dialog) end
function ZO_GenericGamepadDialog_Parametric_TextFieldFocusLost(control) end
function ZO_Dialogs_SetupCustomButton(button, text, keybind, clickSound, callback) end
function ZO_Dialogs_SetDialogLoadingIcon(loadingIcon, textControl, showLoadingIconData) end
function ZO_Dialogs_FindDialog(name) end
function ZO_Dialogs_ShowPlatformDialog(...) end
function ZO_Dialogs_RefreshDialogText(name, dialog, textParams) end
function ZO_Dialogs_ShowGamepadDialog(name, data, textParams) end
function ZO_Dialogs_ShowDialog(name, data, textParams, isGamepad) end
function ZO_TwoButtonDialog_OnInitialized(self, id) end
function ZO_Dialogs_InitializeDialog(dialog, isGamepad) end
function ZO_Dialogs_IsShowingDialog() end
function ZO_Dialogs_ReleaseAllDialogsOfName(name) end
function ZO_Dialogs_ReleaseAllDialogsExcept(...) end
function ZO_Dialogs_ReleaseDialogOnButtonPress(nameOrDialog) end
function ZO_Dialogs_ReleaseDialog(nameOrDialog, releasedFromButton) end
function ZO_CompleteReleaseDialogOnDialogHidden(dialog, releasedFromButton) end
function ZO_Dialogs_ReleaseAllDialogs(forceAll) end
function ZO_Dialogs_IsDialogHiding(dialog) end
function ZO_Dialogs_UpdateDialogMainText(dialog, textTable, params) end
function ZO_Dialogs_UpdateDialogTitleText(dialog, textTable, params) end
function ZO_Dialogs_GetEditBoxText(dialog) end
function ZO_Dialogs_GetSelectedRadioButtonData(dialog) end
function ZO_Dialogs_UpdateButtonState(dialog, buttonNumber, buttonState) end
function ZO_Dialogs_UpdateButtonText(dialog, buttonNumber, text) end
function ZO_Dialogs_UpdateButtonExtraText(dialog, buttonNumber, textTable, params) end
function ZO_Dialogs_UpdateButtonCost(dialog, buttonNumber, cost) end
function ZO_Dialogs_IsShowing(name) end
function ZO_Dialogs_IsDialogRegistered(name) end
function ZO_Dialogs_RegisterCustomDialog(name, info) end
function ZO_Dialogs_CloseKeybindPressed() end
function ZO_Dialogs_HandleButtonForKeybind(dialog, keybind) end
function ZO_Dialogs_ButtonKeybindPressed(keybind) end
function ZO_Dialogs_ButtonKeybindReleased(keybind) end
function ZO_DialogButton_OnInitialized(self) end
function ZO_CustomDialogButton_OnInitialized(self) end
function ZO_TwoButtonDialogEditBox_OnTextChanged(control) end
function ZO_ListDialog:New(...) end
function ZO_ListDialog:Initialize(listTemplate, listItemHeight, listSetupFunction) end
function ZO_ListDialog:SetAboveText(text) end
function ZO_ListDialog:SetBelowText(text) end
function ZO_ListDialog:GetButton(index) end
function ZO_ListDialog:SetFirstButtonEnabled(enabled) end
function ZO_ListDialog:SetSecondButtonEnabled(enabled) end
function ZO_ListDialog:SetEmptyListText(text) end
function ZO_ListDialog:ClearList() end
function ZO_ListDialog:CommitList(sortFunction) end
function ZO_ListDialog:AddListItem(itemData) end
function ZO_ListDialog:AddCustomControl(control, location) end
function ZO_ListDialog:GetCustomContainerFromLocation(location) end
function ZO_ListDialog:GetSelectedItem() end
function ZO_ListDialog:SetOnSelectedCallback(selectedCallback) end
function ZO_ListDialog:SetHidden(hidden) end
function ZO_ListDialog:GetControl() end
function ZO_ListDialog:OnHide() end
function ZO_ListDialog_OnHide(dialog) end
--libraries\zo_directionalinput
function ClientInput:New() end
function ClientInput:Initialize() end
function ClientInput:UpdateDirectionalInput() end
function DirectionalInput:New(...) end
function DirectionalInput:Initialize() end
function DirectionalInput:Activate(object, control) end
function DirectionalInput:Deactivate(object) end
function DirectionalInput:QueueActivation(object, control) end
function DirectionalInput:QueueDeactivation(object) end
function DirectionalInput:PerformQueuedActivationOperation(op) end
function DirectionalInput:Consume(...) end
function DirectionalInput:ConsumeAll() end
function DirectionalInput:AreAllInputDevicesConsumed() end
function DirectionalInput:OnUpdate() end
function DirectionalInput:IsAvailable(inputDevice) end
function DirectionalInput:GetX(...) end
function DirectionalInput:GetY(...) end
function DirectionalInput:GetXY(...) end
function DirectionalInput:GetXFromInputDevice(inputDevice) end
function DirectionalInput:GetYFromInputDevice(inputDevice) end
--libraries\zo_focus
function ZO_GamepadFocus:New(...) end
function ZO_GamepadFocus:Initialize(control, movementController, direction) end
function ZO_GamepadFocus:InitializeMovementController(movementController, direction) end
function ZO_GamepadFocus:SetActive(active, retainFocus) end
function ZO_GamepadFocus:SetFocusChangedCallback(onFocusChangedFunction) end
function ZO_GamepadFocus:SetLeaveFocusAtBeginningCallback(onLeaveFocusAtBeginningFunction) end
function ZO_GamepadFocus:Activate(retainFocus) end
function ZO_GamepadFocus:Deactivate(retainFocus) end
function ZO_GamepadFocus:AddEntry(entry) end
function ZO_GamepadFocus:RemoveMatchingEntries(compareItem, equalityFunction) end
function ZO_GamepadFocus:RemoveAllEntries() end
function ZO_GamepadFocus:GetFocusItem(includeSavedFocus) end
function ZO_GamepadFocus:GetItem(index) end
function ZO_GamepadFocus:GetItemCount() end
function ZO_GamepadFocus:IsFocused(control) end
function ZO_GamepadFocus:SetFocusToMatchingEntry(compareItem, equalityFunction) end
function ZO_GamepadFocus:SetFocusToFirstEntry(setIfInactive) end
function ZO_GamepadFocus:SetFocusByIndex(newIndex, setIfInactive) end
function ZO_GamepadFocus:SetSelectedIndex(newIndex, setIfInactive) end
function ZO_GamepadFocus:GetFocus(includeSavedFocus) end
function ZO_GamepadFocus:ClearFocus() end
function ZO_GamepadFocus:MovePrevious() end
function ZO_GamepadFocus:MoveNext() end
function ZO_GamepadFocus:UpdateDirectionalInput() end
function ZO_GamepadFocus:SetPlaySoundFunction(fn) end
function ZO_GamepadFocus:SetDirectionalInputEnabled(enabled) end
function ZO_GamepadPassiveFocus:New(...) end
function ZO_GamepadPassiveFocus:Initialize(manager, activateCallback, deactivateCallback) end
function ZO_GamepadPassiveFocus:SetupSiblings(previous, next) end
function ZO_GamepadPassiveFocus:SetKeybindDescriptor(keybindDescriptor) end
function ZO_GamepadPassiveFocus:AppendKeybind(keybind) end
function ZO_GamepadPassiveFocus:UpdateKeybinds() end
function ZO_GamepadPassiveFocus:Activate() end
function ZO_GamepadPassiveFocus:Deactivate() end
function ZO_GamepadPassiveFocus:MovePrevious() end
function ZO_GamepadPassiveFocus:MoveNext() end
function ZO_GamepadPassiveFocus:Move(nextFocus) end
function ZO_GamepadPassiveFocus:IsFocused() end
--libraries\zo_gamepadslider
function ZO_GamepadSlider:Initialize() end
function ZO_GamepadSlider:Activate() end
function ZO_GamepadSlider:Deactivate() end
function ZO_GamepadSlider:SetActive(active) end
function ZO_GamepadSlider:UpdateDirectionalInput() end
function ZO_GamepadSlider:MoveLeft() end
function ZO_GamepadSlider:MoveRight() end
function ZO_GamepadSlider_OnInitialized(control) end
function ZO_GamepadSlider_OnValueChanged(control, value) end
function ZO_GamepadPairedSlider:SetMinPair(slider) end
function ZO_GamepadPairedSlider:SetMaxPair(slider) end
function ZO_GamepadPairedSlider:MoveLeft() end
function ZO_GamepadPairedSlider:MoveRight() end
function ZO_GamepadPairedSlider_OnInitialized(control) end
--libraries\zo_hiddenreasons
function ZO_HiddenReasons:New() end
function ZO_HiddenReasons:AddShowReason(reason) end
function ZO_HiddenReasons:RemoveShowReason(reason) end
function ZO_HiddenReasons:StoreReason(reasonTable, reason, value) end
function ZO_HiddenReasons:SetHiddenForReason(reason, hidden) end
function ZO_HiddenReasons:IsHiddenForReason(reason, hidden) end
function ZO_HiddenReasons:SetShownForReason(reason, shown) end
function ZO_HiddenReasons:IsHidden() end
--libraries\zo_horizontalscrolllist
function ZO_HorizontalScrollList_Gamepad:New(...) end
function ZO_HorizontalScrollList_Gamepad:Initialize(control, templateName, numVisibleEntries, setupFunction, equalityFunction, onCommitWithItemsFunction, onClearedFunction) end
function ZO_HorizontalScrollList_Gamepad:SetOnActivatedChangedFunction(onActivatedChangedFunction) end
function ZO_HorizontalScrollList_Gamepad:Commit() end
function ZO_HorizontalScrollList_Gamepad:SetActive(active) end
function ZO_HorizontalScrollList_Gamepad:UpdateArrows() end
function ZO_HorizontalScrollList_Gamepad:Activate() end
function ZO_HorizontalScrollList_Gamepad:Deactivate() end
function ZO_HorizontalScrollList_Gamepad:UpdateDirectionalInput() end
function ZO_HorizontalScrollListPlaySound(type) end
function ZO_HorizontalScrollList:New(...) end
function ZO_HorizontalScrollList:Initialize(control, templateName, numVisibleEntries, setupFunction, equalityFunction, onCommitWithItemsFunction, onClearedFunction) end
function ZO_HorizontalScrollList:SetAllowWrapping(allowWrapping) end
function ZO_HorizontalScrollList:SetOnMovementChangedCallback(onMovementChangedCallback) end
function ZO_HorizontalScrollList:SetEnabled(enabled) end
function ZO_HorizontalScrollList:SetScaleExtents(minScale, maxScale) end
function ZO_HorizontalScrollList:SetNoItemText(text) end
function ZO_HorizontalScrollList:SetDisplayEntryType(displayEntryType) end
function ZO_HorizontalScrollList:SetOffsetBetweenEntries(offsetBetweenEntries) end
function ZO_HorizontalScrollList:IsMoving() end
function ZO_HorizontalScrollList:SetSelectionHighlightInfo(selectionHighlightControl, selectionHighlightAnimation) end
function ZO_HorizontalScrollList:SetEntryWidth(entryWidth) end
function ZO_HorizontalScrollList:RefreshVisible() end
function ZO_HorizontalScrollList:AddEntry(data) end
function ZO_HorizontalScrollList:MoveLeft() end
function ZO_HorizontalScrollList:MoveRight() end
function ZO_HorizontalScrollList:SetSelectedIndex(selectedIndex, allowEvenIfDisabled, withoutAnimation, reselectingDuringRebuild) end
function ZO_HorizontalScrollList:SetSelectedDataIndex(dataIndex, allowEvenIfDisabled, withoutAnimation) end
function ZO_HorizontalScrollList:Clear() end
function ZO_HorizontalScrollList:FindIndexFromData(oldSelectedData, equalityFunction) end
function ZO_HorizontalScrollList:Commit() end
function ZO_HorizontalScrollList:GetSelectedData() end
function ZO_HorizontalScrollList:GetControl() end
function ZO_HorizontalScrollList:GetSelectedIndex() end
function ZO_HorizontalScrollList:GetCenterControl() end
function ZO_HorizontalScrollList:GetNumItems() end
function ZO_HorizontalScrollList:ApplyTemplateToControls(template) end
function ZO_HorizontalScrollList:SetMouseEnabled(mouseEnabled) end
function ZO_HorizontalScrollList:OnUpdate() end
function ZO_HorizontalScrollList:CalculateSelectedIndexOffset() end
function ZO_HorizontalScrollList:CalculateSelectedIndexOffsetWithDrag() end
function ZO_HorizontalScrollList:CalculateOffsetIndex(controlIndex, newVisibleIndex) end
function ZO_HorizontalScrollList:CalculateControlIndexFromOffset(offsetIndex, newVisibleIndex) end
function ZO_HorizontalScrollList:CalculateDataIndexFromOffset(offsetIndex) end
function ZO_HorizontalScrollList:SetOnSelectedDataChangedCallback(onSelectedDataChangedCallback) end
function ZO_HorizontalScrollList:SetOnTargetDataChangedCallback(onTargetDataChangedCallback) end
function ZO_HorizontalScrollList:UpdateAnchors(primaryControlOffsetX, initialUpdate, reselectingDuringRebuild) end
function ZO_HorizontalScrollList:SetDefaultEntryAnchor(control, offsetX) end
function ZO_HorizontalScrollList:AnchorEntryAtFixedOffset(control, offsetX, index, newVisibleIndex) end
function ZO_HorizontalScrollList:SelectControl(controlToSelect) end
function ZO_HorizontalScrollList:SelectControlFromCondition(conditionFunction) end
function ZO_HorizontalScrollList:SetMoving(isMoving) end
function ZO_HorizontalScrollList:SetSelectedFromParent(selected) end
function ZO_HorizontalScrollList:SetPlaySoundFunction(fn) end
--libraries\zo_keybindbutton
function ZO_KeybindButtonMixin:GetKeybind() end
function ZO_KeybindButtonMixin:UpdateEnabledState() end
function ZO_KeybindButtonMixin:SetEnabled(enabled) end
function ZO_KeybindButtonMixin:SetState(buttonState, locked) end
function ZO_KeybindButtonMixin:SetKeybindEnabled(enabled) end
function ZO_KeybindButtonMixin:IsEnabled() end
function ZO_KeybindButtonMixin:SetClickSound(clickSound) end
function ZO_KeybindButtonMixin:SetText(text) end
function ZO_KeybindButtonMixin:SetCustomKeyText(keyText) end
function ZO_KeybindButtonMixin:SetCustomKeyIcon(keyIcon) end
function ZO_KeybindButtonMixin:ShowKeyIcon() end
function ZO_KeybindButtonMixin:HideKeyIcon() end
function ZO_KeybindButtonMixin:SetupStyle(styleInfo) end
function ZO_KeybindButtonMixin:SetKeybindEnabledInEdit(enabled) end
function ZO_KeybindButtonMixin:SetMouseOverEnabled(enabled) end
function ZO_KeybindButtonMixin:SetNormalTextColor(color) end
function ZO_KeybindButtonMixin:SetNameFont(font) end
function ZO_KeybindButtonMixin:SetKeyFont(font) end
function ZO_KeybindButtonMixin:AdjustBindingAnchors(wideSpacing) end
function ZO_KeybindButtonMixin:SetUsingCustomAnchors(useCustom) end
function ZO_KeybindButtonMixin:GetUsingCustomAnchors() end
function ZO_KeybindButtonMixin:SetKeybind(keybind, showUnbound, gamepadPreferredKeybind, alwaysPreferGamepadMode) end
function ZO_KeybindButtonMixin:SetCallback(callback) end
function ZO_KeybindButtonMixin:OnClicked() end
function ZO_KeybindButtonTemplate_OnMouseUp(self, button, upInside) end
function ZO_KeybindButtonTemplate_AddGlobalDisableReference() end
function ZO_KeybindButtonTemplate_RemoveGlobalDisableReference() end
function ZO_KeybindButtonTemplate_OnInitialized(self) end
function ZO_KeybindButtonTemplate_Setup(self, keybind, callbackFunction, text) end
--libraries\zo_keybindstrip
function ZO_KeybindStrip:New(...) end
function ZO_KeybindStrip:Initialize(control, keybindButtonTemplate, styleInfo) end
function ZO_KeybindStrip:PushKeybindGroupState() end
function ZO_KeybindStrip:PopKeybindGroupState() end
function ZO_KeybindStrip:RemoveAllKeyButtonGroups(stateIndex) end
function ZO_KeybindStrip:ClearKeybindGroupStateStack() end
function ZO_KeybindStrip:SetDrawOrder(tier, layer, level) end
function ZO_KeybindStrip:SetBackgroundDrawOrder(tier, layer, level) end
function ZO_KeybindStrip:GetKeybindState(stateIndex) end
function ZO_KeybindStrip:GetTopKeybindStateIndex() end
function ZO_KeybindStrip.RemoveKeybindButtonGroupStack(keybindButtonGroupDescriptor, state) end
function ZO_KeybindStrip.RemoveAllKeyButtonGroupsStack(state) end
function ZO_KeybindStrip:AddKeybindButton(keybindButtonDescriptor, stateIndex) end
function ZO_KeybindStrip:RemoveKeybindButton(keybindButtonDescriptor, stateIndex) end
function ZO_KeybindStrip:UpdateKeybindButton(keybindButtonDescriptor, stateIndex) end
function ZO_KeybindStrip:HasKeybindButton(keybindButtonDescriptor) end
function ZO_KeybindStrip:AddKeybindButtonGroup(keybindButtonGroupDescriptor, stateIndex) end
function ZO_KeybindStrip:RemoveKeybindButtonGroup(keybindButtonGroupDescriptor, stateIndex) end
function ZO_KeybindStrip:UpdateCurrentKeybindButtonGroups(stateIndex) end
function ZO_KeybindStrip:UpdateKeybindButtonGroup(keybindButtonGroupDescriptor, stateIndex) end
function ZO_KeybindStrip:HasKeybindButtonGroup(keybindButtonGroupDescriptor) end
function ZO_KeybindStrip:FilterSceneHiding(keybindButtonDescriptor) end
function ZO_KeybindStrip:TryHandlingKeybindDown(keybind) end
function ZO_KeybindStrip:TryHandlingKeybindUp(keybind) end
function ZO_KeybindStrip:TriggerCooldown(keybindButtonDescriptor, duration, stateIndex, shouldCooldownPersist) end
function ZO_KeybindStrip:UpdateCooldowns(time) end
function ZO_KeybindStrip:SetHidden(hidden) end
function ZO_KeybindStrip:SetStyle(styleInfo) end
function ZO_KeybindStrip:SetBackgroundStyle(styleInfo) end
function ZO_KeybindStrip:GetStyle() end
function ZO_KeybindStrip:SetOnStyleChangedCallback(onStyleChanged) end
function ZO_KeybindStrip:RemoveButtonFromAnchors(button) end
function ZO_KeybindStrip:AddButtonToAnchors(button) end
function ZO_KeybindStrip:SetupButtonStyle(button, styleInfo) end
function ZO_KeybindStrip:GetAnchorTableFromAlignment(alignment) end
--libraries\zo_lerpinterpolator
function ZO_LerpInterpolator:New(...) end
function ZO_LerpInterpolator:Initialize(initialValue) end
function ZO_LerpInterpolator:SetLerpRate(lerpRate) end
function ZO_LerpInterpolator:SetParams(params) end
function ZO_LerpInterpolator:SetCurrentValue(currentValue) end
function ZO_LerpInterpolator:SetTargetBase(targetBase) end
function ZO_LerpInterpolator:Update(timeSecs, frameDeltaSecs) end
--libraries\zo_matrix
function zo_setToIdentityMatrix33(m : Matrix33) end
function zo_setToRotationMatrix2D(m : Matrix33, radians) end
function zo_setToTranslationMatrix2D(m : Matrix33, x, y) end
function zo_setToScaleMatrix2D(m : Matrix33, scale) end
function zo_matrixMultiply33x33(a : Matrix33, b : Matrix33, result : Matrix33) end
--libraries\zo_menubar
function MenuBarButton:New(...) end
function MenuBarButton:Initialize(button) end
function MenuBarButton:Reset() end
function MenuBarButton:UpdateTexturesFromState() end
function MenuBarButton:GetState() end
function MenuBarButton:SetState(state, adjustSizeInstant) end
function MenuBarButton:SetHighlightHidden(hidden) end
function MenuBarButton:CreateAnim(sizingUp) end
function MenuBarButton:SizeUp() end
function MenuBarButton:SizeDown() end
function MenuBarButton:SetData(owner, buttonData) end
function MenuBarButton:MouseEnter() end
function MenuBarButton:MouseExit() end
function MenuBarButton:Press(adjustSizeInstant) end
function MenuBarButton:UnPress(adjustSizeInstant) end
function MenuBarButton:SetEnabled(enabled, adjustSizeInstant) end
function MenuBarButton:SetLocked(locked) end
function MenuBarButton:Release(upInside, skipAnimation, playerDriven) end
function MenuBarButton:RefreshStatus() end
function MenuBarButton:GetDescriptor() end
function MenuBarButton:GetControl() end
function MenuBarButton:GetAnimationData() end
function MenuBar:New(...) end
function MenuBar:Initialize(control) end
function MenuBar:GetClickSound() end
function MenuBar:SetClickSound(clickSound) end
function MenuBar:ClearClickSound() end
function MenuBar:SelectFirstVisibleButton(skipAnimation) end
function MenuBar:SelectLastVisibleButton(skipAnimation) end
function MenuBar:UpdateButtons(forceSelection) end
function MenuBar:AddButton(buttonData) end
function MenuBar:GetButtonControl(descriptor) end
function MenuBar:ClearButtons() end
function MenuBar:SetAllButtonsEnabled(enabled, skipAnimation) end
function MenuBar:GetSelectedDescriptor() end
function MenuBar:SetClickedButton(buttonObject, skipAnimation) end
function MenuBar:RestoreLastClickedButton(skipAnimation) end
function MenuBar:SetData(data) end
function MenuBar:ButtonObjectForDescriptor(descriptor) end
function MenuBar:SelectDescriptor(descriptor, skipAnimation) end
function MenuBar:ClearSelection() end
function MenuBar:SetDescriptorEnabled(descriptor, enabled) end
function MenuBar:GetAnimationData() end
function ZO_MenuBarButtonTemplate_OnInitialized(self) end
function ZO_MenuBarButtonTemplate_OnMouseEnter(self) end
function ZO_MenuBarButtonTemplate_OnMouseExit(self) end
function ZO_MenuBarButtonTemplate_OnPress(self, button) end
function ZO_MenuBarButtonTemplate_OnMouseUp(self, button, upInside) end
function ZO_MenuBarButtonTemplate_GetData(self) end
function ZO_MenuBar_OnInitialized(self) end
function ZO_MenuBar_SetData(self, data) end
function ZO_MenuBar_AddButton(self, buttonData) end
function ZO_MenuBar_GetButtonControl(self, descriptor) end
function ZO_MenuBar_UpdateButtons(self, forceSelection) end
function ZO_MenuBar_ClearButtons(self) end
function ZO_MenuBar_SelectDescriptor(self, descriptor, skipAnimation) end
function ZO_MenuBar_SelectFirstVisibleButton(self, skipAnimation) end
function ZO_MenuBar_SelectLastVisibleButton(self, skipAnimation) end
function ZO_MenuBar_SetDescriptorEnabled(self, descriptor, enabled) end
function ZO_MenuBar_GetSelectedDescriptor(self) end
function ZO_MenuBar_ClearSelection(self) end
function ZO_MenuBar_SetAllButtonsEnabled(self, enabled, skipAnimation) end
function ZO_MenuBar_SetClickSound(self, clickSound) end
function ZO_MenuBar_ClearClickSound(self) end
function ZO_MenuBar_RestoreLastClickedButton(self, skipAnimation) end
function ZO_MenuBarTooltipButton_OnMouseEnter(self) end
function ZO_MenuBarTooltipButton_OnMouseExit(self) end
function ZO_MenuBarButtonTemplateWithTooltip_OnMouseEnter(self) end
function ZO_MenuBarButtonTemplateWithTooltip_OnMouseExit(self) end
function ZO_SceneFragmentBar:New(...) end
function ZO_SceneFragmentBar:Initialize(menuBar) end
function ZO_SceneFragmentBar:SelectFragment(name) end
function ZO_SceneFragmentBar:SetStartingFragment(name) end
function ZO_SceneFragmentBar:ShowLastFragment() end
function ZO_SceneFragmentBar:GetLastFragment() end
function ZO_SceneFragmentBar:RemoveActiveKeybind() end
function ZO_SceneFragmentBar:UpdateActiveKeybind() end
function ZO_SceneFragmentBar:Clear() end
function ZO_SceneFragmentBar:RemoveAll() end
function ZO_SceneFragmentBar:Add(name, fragmentGroup, buttonData, keybindButton) end
--libraries\zo_mouseinputgroup
function ZO_MouseInputGroup:New(...) end
function ZO_MouseInputGroup:Initialize(rootControl) end
function ZO_MouseInputGroup:GetInputTypeGroup(inputType) end
function ZO_MouseInputGroup:Add(control, inputType) end
function ZO_MouseInputGroup:AddControlAndAllChildren(control, inputType) end
function ZO_MouseInputGroup:IsControlInGroup(searchControl, inputType) end
function ZO_MouseInputGroup:RefreshMouseOver() end
function ZO_MouseOverGroupFromChildren_OnInitialized(self) end
--libraries\zo_movementcontroller
function ZO_MovementController:New(...) end
function ZO_MovementController:Initialize(direction, accumulationPerSecondForChange, magnitudeQueryFunctionOverride) end
function ZO_MovementController:SetAllowAcceleration(allowAcceleration) end
function ZO_MovementController:SetNumTicksToStartAccelerating(numTicks) end
function ZO_MovementController:SetAccelerationMagnitudeFactor(accelerationMagnitudeFactor) end
function ZO_MovementController:CheckMovement() end
function ZO_MovementController:GetMagnitude() end
--libraries\zo_multiicon
function MultiIconTimer:New() end
function MultiIconTimer:SetupMultiIconTexture(multiIcon) end
function MultiIconTimer:AddMultiIcon(multiIcon) end
function MultiIconTimer:RemoveMultiIcon(multiIcon) end
function MultiIconTimer:SetAlphas(alpha) end
function MultiIconTimer:OnAnimationComplete() end
function ZO_MultiIconAnimation_SetAlpha(animation, alpha) end
function ZO_MultiIconAnimation_OnStop(timeline) end
--libraries\zo_pagedlist
function ZO_PagedListPlaySound(type) end
function ZO_PagedListSetupFooter(footerControl) end
function ZO_PagedList:New(...) end
function ZO_PagedList:BuildMasterList() end
function ZO_PagedList:FilterList() end
function ZO_PagedList:SortList() end
function ZO_PagedList:OnListChanged() end
function ZO_PagedList:OnPageChanged() end
function ZO_PagedList:Initialize(control, movementController) end
function ZO_PagedList:TakeFocus() end
function ZO_PagedList:ClearFocus() end
function ZO_PagedList:Activate() end
function ZO_PagedList:Deactivate(retainFocus) end
function ZO_PagedList:ActivateHeader() end
function ZO_PagedList:DeactivateHeader() end
function ZO_PagedList:SetupSort(sortKeys, initialKey, initialDirection) end
function ZO_PagedList:SetSelectionChangedCallback(callback) end
function ZO_PagedList:SetLeaveListAtBeginningCallback(callback) end
function ZO_PagedList:OnEnterRow(control, data) end
function ZO_PagedList:OnLeaveRow(control, data) end
function ZO_PagedList:RefreshData() end
function ZO_PagedList:RefreshSort() end
function ZO_PagedList:RefreshFilters() end
function ZO_PagedList:RefreshVisible() end
function ZO_PagedList:CommitList() end
function ZO_PagedList:AddDataTemplate(templateName, height, setupCallback, controlPoolPrefix) end
function ZO_PagedList:AddEntry(templateName, data) end
function ZO_PagedList:Clear() end
function ZO_PagedList:GetSelectedData() end
function ZO_PagedList:IsSelected(data) end
function ZO_PagedList:SetPage(pageNum) end
function ZO_PagedList:PreviousPage() end
function ZO_PagedList:NextPage() end
function ZO_PagedList:AcquireControl(dataIndex, relativeControl) end
function ZO_PagedList:ReleaseControl(control) end
function ZO_PagedList:BuildPages() end
function ZO_PagedList:BuildPage(pageNum) end
function ZO_PagedList:RefreshSelectedRow() end
function ZO_PagedList:OnSortHeaderClicked(key, order) end
function ZO_PagedList:CompareSortEntries(listEntry1, listEntry2) end
function ZO_PagedList:SetEmptyText(emptyText, template) end
function ZO_PagedList:RefreshFooter() end
function ZO_PagedList:SetAlternateRowBackgrounds(alternate) end
function ZO_PagedList:SetPlaySoundFunction(fn) end
function ZO_PagedList:SetRememberSpotInList(rememberSpot) end
--libraries\zo_parametricscrolllist
function ZO_ParametricScrollList:New(...) end
function ZO_ParametricScrollList:Initialize(control, mode, onActivatedChangedFunction, onCommitWithItemsFunction, onClearedFunction) end
function ZO_ParametricScrollList:HasDataTemplate(templateName) end
function ZO_ParametricScrollList:AddDataTemplate(templateName, setupFunction, parametricFunction, equalityFunction, controlPoolPrefix, controlPoolResetFunction) end
function ZO_ParametricScrollList:SetDataTemplateReleaseFunction(templateName, releaseFunction) end
function ZO_ParametricScrollList:SetDataTemplateWithHeaderReleaseFunction(templateName, releaseFunction) end
function ZO_ParametricScrollList_DefaultMenuEntryWithHeaderSetup(control, data, selected, selectedDuringRebuild, enabled, activated) end
function ZO_ParametricScrollList:AddDataTemplateWithHeader(templateName, setup*, parametricFunction, equalityFunction, headerTemplateName, optionalHeaderSetupFunction, controlPoolPrefix) end
function ZO_ParametricScrollList:AddEntry(templateName, data, prePadding, postPadding, preSelectedOffsetAdditionalPadding, postSelectedOffsetAdditionalPadding, selectedCenterOffset) end
function ZO_ParametricScrollList:GetNumEntries() end
function ZO_ParametricScrollList:GetEntryData(index) end
function ZO_ParametricScrollList:AddEntryWithHeader(templateName, ...) end
function ZO_ParametricScrollList:SetOnMovementChangedCallback(onMovementChangedCallback) end
function ZO_ParametricScrollList:RemoveOnMovementChangedCallback(onMovementChangedCallback) end
function ZO_ParametricScrollList:SetOnTargetDataChangedCallback(onTargetDataChangedCallback) end
function ZO_ParametricScrollList:RemoveOnTargetDataChangedCallback(onTargetDataChangedCallback) end
function ZO_ParametricScrollList:SetOnSelectedDataChangedCallback(onSelectedDataChangedCallback) end
function ZO_ParametricScrollList:RemoveOnSelectedDataChangedCallback(onSelectedDataChangedCallback) end
function ZO_ParametricScrollList:RemoveAllOnSelectedDataChangedCallbacks() end
function ZO_ParametricScrollList:SetDrawScrollArrows(drawScrollArrows) end
function ZO_ParametricScrollList:SetAnchorOppositeSide(anchorOppositeSide) end
function ZO_ParametricScrollList:UpdateScrollArrows() end
function ZO_ParametricScrollList:SetSortFunction(sortFunction) end
function ZO_ParametricScrollList:SetFixedCenterOffset(fixedCenterOffset) end
function ZO_ParametricScrollList:SetAlignToScreenCenter(alignToScreenCenter, expectedEntryHeight) end
function ZO_ParametricScrollList:SetActive(active, fireActivatedCallback) end
function ZO_ParametricScrollList:SetOnActivatedChangedFunction(func) end
function ZO_ParametricScrollList:GetOnActivatedChangedFunction() end
function ZO_ParametricScrollList:IsActive() end
function ZO_ParametricScrollList:Activate() end
function ZO_ParametricScrollList:ActivateWithoutChangedCallback() end
function ZO_ParametricScrollList:Deactivate() end
function ZO_ParametricScrollList:DeactivateWithoutChangedCallback() end
function ZO_ParametricScrollList:SetEnabled(enabled) end
function ZO_ParametricScrollList:SetSelectedItemOffsets(minOffset, maxOffset) end
function ZO_ParametricScrollList:SetAdditionalBottomSelectedItemOffsets(additonalMinBottomOffset, additonalMaxBottomOffset) end
function ZO_ParametricScrollList:SetUniversalPrePadding(universalPrePadding) end
function ZO_ParametricScrollList:SetUniversalPostPadding(universalPostPadding) end
function ZO_ParametricScrollList:SetNoItemText(text) end
function ZO_ParametricScrollList:IsMoving() end
function ZO_ParametricScrollList:RefreshVisible() end
function ZO_ParametricScrollList:CanSelect(newIndex) end
function ZO_ParametricScrollList:MovePrevious() end
function ZO_ParametricScrollList:MoveNext() end
function ZO_ParametricScrollList:GetNumItems() end
function ZO_ParametricScrollList:IsControlIndexFullyVisible(index) end
function ZO_ParametricScrollList:GetSelectedIndex() end
function ZO_ParametricScrollList:SetSelectedIndexWithoutAnimation(selectedIndex, allowEvenIfDisabled, forceAnimation) end
function ZO_ParametricScrollList:SetSelectedIndex(selectedIndex, allowEvenIfDisabled, forceAnimation, jumpType) end
function ZO_ParametricScrollList:SetLastIndexSelected(jumpType) end
function ZO_ParametricScrollList:SetFirstIndexSelected(jumpType) end
function ZO_ParametricScrollList:SetDefaultIndexSelected(animate, allowEvenIfDisabled, forceAnimation, jumpType) end
function ZO_ParametricScrollList:CalculateFirstSelectableIndex() end
function ZO_ParametricScrollList:CalculateLastSelectableIndex() end
function ZO_ParametricScrollList:SetSelectedDataByEval(eval) end
function ZO_ParametricScrollList:SetPreviousSelectedDataByEval(eval, jumpType) end
function ZO_ParametricScrollList:SetNextSelectedDataByEval(eval, jumpType) end
function ZO_ParametricScrollList:GetNextSelectableIndex(currentIndex) end
function ZO_ParametricScrollList:SetSelectedDataByRangedEval(eval, startIndex, endIndex, jumpType) end
function ZO_ParametricScrollList:Clear() end
function ZO_ParametricScrollList:SetKeyForNextCommit(key) end
function ZO_ParametricScrollList:CommitWithoutReselect() end
function ZO_ParametricScrollList:Commit(dontReselect, blockSelectionChangedCallback) end
function ZO_ParametricScrollList:GetSelectedData() end
function ZO_ParametricScrollList:GetTargetData() end
function ZO_ParametricScrollList:GetTargetIndex() end
function ZO_ParametricScrollList:GetTargetControl() end
function ZO_ParametricScrollList:GetControl() end
function ZO_ParametricScrollList:GetScrollControl() end
function ZO_ParametricScrollList:SetPlaySoundFunction(fn) end
function ZO_ParametricScrollList:SetMouseEnabled(mouseEnabled) end
function ZO_ParametricScrollList:CalculateSelectedIndexOffsetWithDrag() end
function ZO_ParametricScrollList:OnUpdate() end
function ZO_ParametricScrollList:CalculateNextLerpedContinousOffset(continousTargetOffset) end
function ZO_ParametricScrollList:GetSelectedControl() end
function ZO_ParametricScrollList:EnableAnimation(enabled) end
function ZO_ParametricScrollList:IsDirectionalInputEnabled() end
function ZO_ParametricScrollList:SetDirectionalInputEnabled(enabled) end
function ZO_ParametricScrollList:UpdateDirectionalInput() end
function ZO_ParametricScrollList:SetCustomDirectionInputHandler(handler) end
function ZO_ParametricScrollList:SetHideUnselectedControls(state) end
function ZO_ParametricScrollList:SetAnchorForEntryControl(control, anchor1, anchor2, offsetX, offsetY) end
function ZO_ParametricScrollList:GetDesiredEntryAnchors() end
function ZO_ParametricScrollList:GetEntryFixedCenterOffset() end
function ZO_ParametricScrollList:UpdateAnchors(continousTargetOffset, initialUpdate, reselectingDuringRebuild, blockSelectionChangedCallback) end
function ZO_ParametricScrollList:RefreshNoItemLabelPosition() end
function ZO_ParametricScrollList:CalculateParametricOffset(startAdditionalPadding, endAdditionalPadding, distanceFromCenter, continuousParametricOffset, additionalPaddingEasingFunc) end
function ZO_ParametricScrollList:CalculateAdditionalBottomParametricOffset(distanceFromCenter, continuousParametricOffset, additionalPaddingEasingFunc) end
function ZO_ParametricScrollList:GetSetupFunctionForDataIndex(dataIndex) end
function ZO_ParametricScrollList:RunSetupOnControl(control, dataIndex, selected, reselectingDuringRebuild, enabled, active) end
function ZO_ParametricScrollList:GetParametricFunctionForDataIndex(dataIndex) end
function ZO_ParametricScrollList:GetDataForDataIndex(dataIndex) end
function ZO_ParametricScrollList:SetHeaderPadding(defaultPadding, selectedPadding) end
function ZO_ParametricScrollList:GetHasHeaderForDataIndex(dataIndex) end
function ZO_ParametricScrollList:GetSelectedAdditionalPaddingForDataIndex(dataIndex) end
function ZO_ParametricScrollList:GetPaddingForDataIndex(dataIndex, distanceFromCenter, continousParametricOffset) end
function ZO_ParametricScrollList:AcquireControlAtDataIndex(dataIndex) end
function ZO_ParametricScrollList:ReleaseControl(control) end
function ZO_ParametricScrollList:AcquireAndSetupControl(dataIndex, selectedDataChanged, initialUpdate, oldSelectedData, selected) end
function ZO_ParametricScrollList:SetMoving(isMoving) end
function ZO_ParametricScrollList:DoesTemplateHaveEditBox(dataIndex) end
function ZO_ParametricScrollList:SetValidateGradient(validate) end
function ZO_ParametricScrollList:EnsureValidGradient() end
function ZO_ParametricScrollList:IsEmpty() end
function ZO_ParametricScrollList:SetJumping(isJumping) end
function ZO_ParametricScrollList:SetSoundEnabled(isSoundEnabled) end
function ZO_ParametricScrollList:SetDefaultSelectedIndex(defaultSelectedIndex) end
function ZO_ParametricScrollList:WhenInactiveSetTargetControlHidden(hidden) end
--libraries\zo_pixelunits
function ZO_PixelUnitControl:New(control, pixelSource, baseObject) end
function ZO_PixelUnitControl:Initialize(control, pixelSource) end
function ZO_PixelUnitControl:ConvertToUIUnits(measurement) end
function ZO_PixelUnitControl:OnScreenResized() end
function ZO_PixelUnitControl:ClearAnchors() end
function ZO_PixelUnitControl:AddAnchor(point, anchorTo, relativePoint, offsetX, offsetY, anchorConstrains) end
function ZO_PixelUnitControl:SetWidth(width) end
function ZO_PixelUnitControl:SetHeight(height) end
function ZO_PixelUnitControl:SetDimensions(width, height) end
function ZO_PixelUnitControl:SetDimensionConstraints(minWidth, minHeight, maxWidth, maxHeight) end
function ZO_PixelUnitControl:SetScale(scale) end
function ZO_PixelUnitControl:IsDimensionConstrainedByAnchors(side1, side2, checkDirection1, checkDirection2) end
function ZO_PixelUnitControl:ScrapeFromXML() end
function ZO_PixelUnitControl:LockApply() end
function ZO_PixelUnitControl:UnlockApply() end
function ZO_PixelUnitControl:ApplyToControl() end
function ZO_PixelUnits:New(namespace, baseObject) end
function ZO_PixelUnits:Initialize(namespace, baseObject) end
function ZO_PixelUnits:OnScreenResized() end
function ZO_PixelUnits:Get(control) end
function ZO_PixelUnits:Add(control, pixelSource) end
function ZO_PixelUnits:Remove(...) end
function ZO_PixelUnits:AddControlAndAllChildren(control) end
function ZO_PixelUnits:AddAnchor(control, point, relativeTo, relativePoint, offsetX, offsetY, anchorConstrains) end
function ZO_PixelUnits:SetDimensionConstraints(control, minWidth, minHeight, maxWidth, maxHeight) end
function ZO_PixelUnits:SetDimensions(control, width, height) end
function ZO_PixelUnits:SetWidth(control, width) end
function ZO_PixelUnits:SetHeight(control, height) end
function ZO_PixelUnits:SetScale(control, scale) end
function ZO_PixelUnitsFromChildren_OnInitialized(self) end
--libraries\zo_platformstyle
function ZO_PlatformStyleManager:New() end
function ZO_PlatformStyleManager:Initialize() end
function ZO_PlatformStyleManager:Add(object) end
function ZO_PlatformStyleManager:OnGamepadPreferredModeChanged() end
function ZO_PlatformStyle:New(...) end
function ZO_PlatformStyle:Initialize(applyFunction, keyboardStyle, gamepadStyle) end
function ZO_PlatformStyle:Apply() end
--libraries\zo_radialmenu
function ZO_RadialMenu:New(...) end
function ZO_RadialMenu.ForceActiveMenuClosed() end
function ZO_RadialMenu:Initialize(control, entryTemplate, animationTemplate, entryAnimationTemplate, actionLayerName, directionInputs, enableMouse, selectIfCentered) end
function ZO_RadialMenu:SetActivateOnShow(activateOnShow) end
function ZO_RadialMenu:SetOnClearCallback(callback) end
function ZO_RadialMenu:SetOnSelectionChangedCallback(callback) end
function ZO_RadialMenu:SetCustomControlSetUpFunction(setupFunction) end
function ZO_RadialMenu:SelectCurrentEntry() end
function ZO_RadialMenu:FindSelectedEntry(x, y, suppressSound) end
function ZO_RadialMenu:SetOnUpdateRotationFunction(rotationFunc) end
function ZO_RadialMenu:AddEntry(name, inactiveIcon, activeIcon, callback, data) end
function ZO_RadialMenu:UpdateEntry(name, inactiveIcon, activeIcon, callback, data) end
function ZO_RadialMenu:OnAnimationStopped() end
function ZO_RadialMenu:Clear(entrySelected) end
function ZO_RadialMenu:Activate() end
function ZO_RadialMenu:Deactivate() end
function ZO_RadialMenu:ClearSelection() end
function ZO_RadialMenu:FinalizeClear() end
function ZO_RadialMenu:Show(suppressSound) end
function ZO_RadialMenu:ResetData() end
function ZO_RadialMenu:Refresh() end
function ZO_RadialMenu:IsShown() end
function ZO_RadialMenuController:New(...) end
function ZO_RadialMenuController:Initialize(control, entryTemplate, animationTemplate, entryAnimationTemplate) end
function ZO_RadialMenuController:ShowMenu() end
function ZO_RadialMenuController:SetupEntryControl(control, data) end
function ZO_RadialMenuController:OnSelectionChangedCallback(selectedEntry) end
function ZO_RadialMenuController:PopulateMenu() end
function ZO_InteractiveRadialMenuController:New(...) end
function ZO_InteractiveRadialMenuController:Initialize(control, entryTemplate, animationTemplate, entryAnimationTemplate ) end
function ZO_InteractiveRadialMenuController:StartInteraction() end
function ZO_InteractiveRadialMenuController:StopInteraction() end
function ZO_InteractiveRadialMenuController:OnUpdate() end
function ZO_InteractiveRadialMenuController:ShowMenu() end
function ZO_InteractiveRadialMenuController:PrepareForInteraction() end
function ZO_InteractiveRadialMenuController:SetupEntryControl(control, data) end
function ZO_InteractiveRadialMenuController:OnSelectionChangedCallback(selectedEntry) end
function ZO_InteractiveRadialMenuController:PopulateMenu() end
function ZO_InteractiveRadialMenuController:InteractionCanceled() end
--libraries\zo_recentmessages
function ZO_RecentMessages:New(...) end
function ZO_RecentMessages:Initialize(expiryDelayMilliseconds) end
function ZO_RecentMessages:AddRecent(message) end
function ZO_RecentMessages:IsRecent(message) end
function ZO_RecentMessages:Update(timeNowMilliseconds) end
function ZO_RecentMessages:ShouldDisplayMessage(message) end
--libraries\zo_savingeditbox
function ZO_SavingEditBox:New(control) end
function ZO_SavingEditBox:SetDefaultText(defaultText) end
function ZO_SavingEditBox:SetEmptyText(emptyText) end
function ZO_SavingEditBox:SetEditing(editing) end
function ZO_SavingEditBox:SetEnabled(enabled) end
function ZO_SavingEditBox:SetHidden(hidden) end
function ZO_SavingEditBox:SetCustomTextValidator(validator) end
function ZO_SavingEditBox:SetPutTextInQuotes(putTextInQuotes) end
function ZO_SavingEditBox:GetText() end
function ZO_SavingEditBox:SetText(text) end
function ZO_SavingEditBox:GetControl() end
function ZO_SavingEditBox:GetEditControl() end
function ZO_SavingEditBox:ResetText() end
function ZO_SavingEditBox:OnTextChanged() end
function ZO_SavingEditBox:OnEnter() end
function ZO_SavingEditBox:OnSaveClicked() end
function ZO_SavingEditBox:Cancel() end
function ZO_SavingEditBox:OnCancelClicked() end
function ZO_SavingEditBox:OnModifyClicked() end
function ZO_SavingEditBox:RefreshButtons() end
function ZO_SavingEditBoxGroup:New() end
function ZO_SavingEditBoxGroup:Add(savingEditBox) end
--libraries\zo_scene
function ZO_StackFragmentGroup:New(fragment, object) end
function ZO_StackFragmentGroup:Add(fragment, object) end
function ZO_StackFragmentGroup:SetOnActivatedCallback(onActivatedCallback) end
function ZO_StackFragmentGroup:SetOnDeactivatedCallback(onDeactivatedCallback) end
function ZO_StackFragmentGroup:SetActivateAll(activateAll) end
function ZO_StackFragmentGroup:GetFragments() end
function ZO_StackFragmentGroup:SetActive(active) end
function ZO_Scene:New(...) end
function ZO_Scene:Initialize(name, sceneManager) end
function ZO_Scene:AddFragment(fragment) end
function ZO_Scene:RemoveFragment(fragment) end
function ZO_Scene:HasFragment(fragment) end
function ZO_Scene:AddTemporaryFragment(fragment) end
function ZO_Scene:RemoveTemporaryFragment(fragment) end
function ZO_Scene:HasStackFragmentGroup(stackFragmentGroup) end
function ZO_Scene:PushStackFragmentGroup(stackFragmentGroup, isBase) end
function ZO_Scene:PushBaseStackFragmentGroup(stackFragmentGroup) end
function ZO_Scene:PopStackFragmentGroup() end
function ZO_Scene:AddFragmentGroup(fragments) end
function ZO_Scene:RemoveFragmentGroup(fragments) end
function ZO_Scene:GetName() end
function ZO_Scene:GetState() end
function ZO_Scene:IsShowing() end
function ZO_Scene:HasFragmentWithCategory(category) end
function ZO_Scene:GetFragmentWithCategory(category) end
function ZO_Scene:SetState(newState) end
function ZO_Scene:OnRemovedFromQueue() end
function ZO_Scene:RemoveTemporaryFragments() end
function ZO_Scene:RemoveStackFragmentGroups() end
function ZO_Scene:RefreshFragmentsHelper(...) end
function ZO_Scene:RefreshFragments() end
function ZO_Scene:OnSceneFragmentStateChange(fragment, oldState, newState) end
function ZO_Scene:HideAllHideOnSceneEndFragments(...) end
function ZO_Scene:IsTransitionComplete() end
function ZO_Scene:DetermineIfTransitionIsComplete() end
function ZO_Scene:GetSceneGroup() end
function ZO_Scene:SetSceneGroup(sceneGroup) end
function ZO_Scene:WasShownInGamepadPreferredMode() end
function ZO_Scene:IsRemoteScene() end
function ZO_RemoteScene:New(...) end
function ZO_RemoteScene:Initialize(name, sceneManager) end
function ZO_RemoteScene:SetState(newState) end
function ZO_RemoteScene:SetSendsStateChanges(sendsState) end
function ZO_RemoteScene:GetSendsStateChanges() end
function ZO_RemoteScene:IsRemoteScene() end
function ZO_RemoteScene:PushRemoteScene() end
function ZO_RemoteScene:SwapRemoteScene() end
function ZO_SceneFragment:New() end
function ZO_SceneFragment:SetSceneManager(sceneManager) end
function ZO_SceneFragment:GetCategory() end
function ZO_SceneFragment:SetCategory(category) end
function ZO_SceneFragment:GetForceRefresh() end
function ZO_SceneFragment:SetForceRefresh(forceRefresh) end
function ZO_SceneFragment:AddDependency(fragment) end
function ZO_SceneFragment:AddDependencies(...) end
function ZO_SceneFragment:IsDependentOn(fragment) end
function ZO_SceneFragment:HasDependencies() end
function ZO_SceneFragment:GetHideOnSceneHidden() end
function ZO_SceneFragment:SetHideOnSceneHidden(hideOnSceneHidden) end
function ZO_SceneFragment:Show() end
function ZO_SceneFragment:Hide() end
function ZO_SceneFragment:GetState() end
function ZO_SceneFragment:IsShowing() end
function ZO_SceneFragment:IsHidden() end
function ZO_SceneFragment:SetConditional(conditional) end
function ZO_SceneFragment:HasConditional() end
function ZO_SceneFragment:SetAllowShowHideTimeUpdates(allow) end
function ZO_SceneFragment:SetState(newState) end
function ZO_SceneFragment:OnShown() end
function ZO_SceneFragment:OnHidden() end
function ZO_SceneFragment:ShouldBeShown(customShowParam) end
function ZO_SceneFragment:ShouldBeHidden(customHideParam) end
function ZO_SceneFragment:Refresh(customShowParam, customHideParam) end
function ZO_SimpleSceneFragment:New(control) end
function ZO_SimpleSceneFragment:Show() end
function ZO_SimpleSceneFragment:Hide() end
function ZO_AnimatedSceneFragment:New(...) end
function ZO_AnimatedSceneFragment:Initialize(animationTemplate, control, alwaysAnimate, duration) end
function ZO_AnimatedSceneFragment:GetAnimation() end
function ZO_AnimatedSceneFragment:GetControl() end
function ZO_AnimatedSceneFragment:AddInstantScene(scene) end
function ZO_AnimatedSceneFragment:IsAnimatedInCurrentScene() end
function ZO_AnimatedSceneFragment:Show() end
function ZO_AnimatedSceneFragment:Hide() end
function ZO_FadeSceneFragment:New(control, alwaysAnimate, duration) end
function ZO_TranslateFromLeftSceneFragment:New(control, alwaysAnimate, duration) end
function ZO_TranslateFromRightSceneFragment:New(control, alwaysAnimate, duration) end
function ZO_TranslateFromBottomSceneFragment:New(control, alwaysAnimate, duration) end
function ZO_TranslateFromTopSceneFragment:New(control, alwaysAnimate, duration) end
function ZO_ConveyorSceneFragment:New(...) end
function ZO_ConveyorSceneFragment:Initialize(control, alwaysAnimate, inAnimation, outAnimation) end
function ZO_ConveyorSceneFragment:ComputeOffsets() end
function ZO_ConveyorSceneFragment:GetAnimationXOffsets(index, animationTemplate) end
function ZO_ConveyorSceneFragment:GetAnimationYOffset(index) end
function ZO_ConveyorSceneFragment:ConfigureTranslateAnimation(index) end
function ZO_ConveyorSceneFragment:GetAnimation() end
function ZO_ConveyorSceneFragment:GetControl() end
function ZO_ConveyorSceneFragment:AddInstantScene(scene) end
function ZO_ConveyorSceneFragment:IsAnimatedInCurrentScene() end
function ZO_ConveyorSceneFragment:GetBackgroundFragment() end
function ZO_ConveyorSceneFragment:ChooseAndPlayAnimation() end
function ZO_ConveyorSceneFragment:Show() end
function ZO_ConveyorSceneFragment:Hide() end
function ZO_HUDFadeSceneFragment:New(control, showDuration, hideDuration) end
function ZO_HUDFadeSceneFragment:GetAnimation() end
function ZO_HUDFadeSceneFragment:SetHiddenForReason(reason, hidden, customShowDuration, customHideDuration) end
function ZO_HUDFadeSceneFragment:IsHiddenForReason(reason) end
function ZO_HUDFadeSceneFragment:Show(customShowDuration) end
function ZO_HUDFadeSceneFragment:Hide(customHideDuration) end
function ZO_HUDFadeSceneFragment:OnShown() end
function ZO_HUDFadeSceneFragment:OnHidden() end
function ZO_AnchorSceneFragment:New(control, anchor) end
function ZO_AnchorSceneFragment:Show() end
function ZO_BackgroundFragment:ResetOnHiding() end
function ZO_BackgroundFragment:ResetOnHidden() end
function ZO_BackgroundFragment:Mixin(baseFragment) end
function ZO_BackgroundFragment:TakeFocus() end
function ZO_BackgroundFragment:ClearFocus() end
function ZO_BackgroundFragment:SetFocus(focused) end
function ZO_BackgroundFragment:ClearHighlight() end
function ZO_BackgroundFragment:SetHighlightHidden(hidden) end
function ZO_BackgroundFragment:FadeRightDivider(fadeIn, instant) end
function ZO_ActionLayerFragment:New(actionLayerName) end
function ZO_ActionLayerFragment:Show() end
function ZO_ActionLayerFragment:Hide() end
function ZO_SceneGroup:New(...) end
function ZO_SceneGroup:Initialize(...) end
function ZO_SceneGroup:AddScene(sceneName) end
function ZO_SceneGroup:GetNumScenes() end
function ZO_SceneGroup:GetSceneName(index) end
function ZO_SceneGroup:GetActiveScene() end
function ZO_SceneGroup:SetActiveScene(scene) end
function ZO_SceneGroup:GetSceneIndexFromScene(scene) end
function ZO_SceneGroup:SetState(newState) end
function ZO_SceneGroup:GetState() end
function ZO_SceneGroup:IsShowing() end
function ZO_SceneManager:New() end
function ZO_SceneManager:Initialize() end
function ZO_SceneManager:OnRemoteSceneChange(sceneName, sceneChangeType, sceneChangeOrigin) end
function ZO_SceneManager:OnRemoteSceneSwap(sceneName) end
function ZO_SceneManager:OnRemoteSceneHide(sceneName) end
function ZO_SceneManager:OnRemoteScenePush(sceneName) end
function ZO_SceneManager:OnRemoteSceneShow(sceneName) end
function ZO_SceneManager:Add(scene) end
function ZO_SceneManager:GetScene(sceneName) end
function ZO_SceneManager:AddSceneGroup(sceneGroupName, sceneGroup) end
function ZO_SceneManager:GetSceneGroup(sceneGroupName) end
function ZO_SceneManager:IsSceneGroupShowing(sceneGroupName) end
function ZO_SceneManager:SetBaseScene(sceneName) end
function ZO_SceneManager:AddFragment(fragment) end
function ZO_SceneManager:RemoveFragment(fragment) end
function ZO_SceneManager:AddFragmentGroup(fragmentGroup) end
function ZO_SceneManager:RemoveFragmentGroup(fragmentGroup) end
function ZO_SceneManager:IsSceneOnStack(sceneName) end
function ZO_SceneManager:WasSceneOnStack(sceneName) end
function ZO_SceneManager:IsSceneOnTopOfStack(sceneName) end
function ZO_SceneManager:WasSceneOnTopOfStack(sceneName) end
function ZO_SceneManager:PushOnSceneStack(sceneName) end
function ZO_SceneManager:PopScenesFromStack(numScenes) end
function ZO_SceneManager:ClearSceneStack() end
function ZO_SceneManager:ShowScene(scene) end
function ZO_SceneManager:HideScene(scene) end
function ZO_SceneManager:SetNextScene(nextScene, push, nextSceneClearsSceneStack, numScenesNextScenePops) end
function ZO_SceneManager:ClearNextScene() end
function ZO_SceneManager:Push(sceneName) end
function ZO_SceneManager:Show(sceneName, push, nextSceneClearsSceneStack, numScenesNextScenePops) end
function ZO_SceneManager:SwapCurrentScene(newCurrentScene) end
function ZO_SceneManager:OnNextSceneRemovedFromQueue(oldNextScene, newNextScene) end
function ZO_SceneManager:Hide(sceneName) end
function ZO_SceneManager:HideCurrentScene() end
function ZO_SceneManager:PopScenes(numberOfScenes) end
function ZO_SceneManager:PopScenesAndShow(numberOfScenes, sceneToShow) end
function ZO_SceneManager:Toggle(sceneName) end
function ZO_SceneManager:ShowBaseScene() end
function ZO_SceneManager:IsShowing(sceneName) end
function ZO_SceneManager:IsShowingNext(sceneName) end
function ZO_SceneManager:GetBaseScene() end
function ZO_SceneManager:GetCurrentScene() end
function ZO_SceneManager:GetNextScene() end
function ZO_SceneManager:IsShowingBaseScene() end
function ZO_SceneManager:IsShowingBaseSceneNext() end
function ZO_SceneManager:CallWhen(sceneName, state, func) end
function ZO_SceneManager:TriggerCallWhens(sceneName, state) end
function ZO_SceneManager:GetPreviousSceneName() end
function ZO_SceneManager:GetCurrentSceneName() end
function ZO_SceneManager:OnSceneStateChange(scene, oldState, newState) end
function ZO_SceneManager:OnPreSceneStateChange(scene, currentState, nextState) end
function ZO_SceneManager:CopySceneStackIntoPrevious() end
function ZO_SceneManager:IsCurrentSceneGamepad() end
function ZO_SceneManager:CreateStackFromScratch(...) end
--libraries\zo_scenegraph
function ZO_SceneGraph:New(...) end
function ZO_SceneGraph:Initialize(canvasControl, debugModeEnabled) end
function ZO_SceneGraph:IsHidden() end
function ZO_SceneGraph:GetCameraX() end
function ZO_SceneGraph:AddCameraX(dx) end
function ZO_SceneGraph:SetCameraX(x) end
function ZO_SceneGraph:GetCameraY() end
function ZO_SceneGraph:AddCameraY(dy) end
function ZO_SceneGraph:SetCameraY(y) end
function ZO_SceneGraph:AddCameraRotation(radians) end
function ZO_SceneGraph:SetCameraRotation(radians) end
function ZO_SceneGraph:GetCameraZ() end
function ZO_SceneGraph:AddCameraZ(z) end
function ZO_SceneGraph:SetCameraZ(z) end
function ZO_SceneGraph:GetCameraNode() end
function ZO_SceneGraph:GetCanvasControl() end
function ZO_SceneGraph:GetNode(name) end
function ZO_SceneGraph:CreateNode(name) end
function ZO_SceneGraph:OnSceneNodeDirty() end
function ZO_SceneGraph:OnUpdate() end
function ZO_SceneGraph:Render(node, dirtyUpstream) end
function ZO_SceneGraphNode:New(...) end
function ZO_SceneGraphNode:InitializeStaticBehavior() end
function ZO_SceneGraphNode:Initialize(sceneGraph, name) end
function ZO_SceneGraphNode:GetSceneGraph() end
function ZO_SceneGraphNode:GetName() end
function ZO_SceneGraphNode:SetParent(parent) end
function ZO_SceneGraphNode:GetChildren() end
function ZO_SceneGraphNode:SetDirty(dirty) end
function ZO_SceneGraphNode:GetX() end
function ZO_SceneGraphNode:AddX(dx) end
function ZO_SceneGraphNode:SetX(x) end
function ZO_SceneGraphNode:GetY() end
function ZO_SceneGraphNode:AddY(dy) end
function ZO_SceneGraphNode:SetY(y) end
function ZO_SceneGraphNode:GetZ() end
function ZO_SceneGraphNode:SetZ(z) end
function ZO_SceneGraphNode:GetRotation() end
function ZO_SceneGraphNode:AddRotation(radians) end
function ZO_SceneGraphNode:SetRotation(radians) end
function ZO_SceneGraphNode:SetScale(scale) end
function ZO_SceneGraphNode:ComputeSizeForDepth(x, y, z) end
function ZO_SceneGraphNode:IsDirty() end
function ZO_SceneGraphNode:AcquireWorkingMatrix() end
function ZO_SceneGraphNode:AcquireResultMatrix() end
function ZO_SceneGraphNode:BuildWorldViewMatrix() end
function ZO_SceneGraphNode:Render() end
function ZO_SceneGraphNode:OnChildAdded(child) end
function ZO_SceneGraphNode:ComputeDrawLevel(z) end
function ZO_SceneGraphNode:AddControl(control, x, y, z) end
function ZO_SceneGraphNode:RemoveControl(control) end
function ZO_SceneGraphNode:GetControlIndex(control) end
function ZO_SceneGraphNode:RefreshControlIndices() end
function ZO_SceneGraphNode:GetControl(i) end
function ZO_SceneGraphNode:SetControlPosition(control, x, y, z) end
function ZO_SceneGraphNode:SetControlHidden(control, hidden) end
function ZO_SceneGraphNode:SetControlScale(control, scale) end
function ZO_SceneGraphNode:GetControlScale(control, scale) end
function ZO_SceneGraphNode:SetControlAnchorPoint(control, anchorPoint) end
function ZO_SceneGraphNode:SetControlUseRotation(control, useRotation) end
--libraries\zo_scenenodering
function ZO_SceneNodeRing:New(...) end
function ZO_SceneNodeRing:Initialize(rootNode) end
function ZO_SceneNodeRing:SetRadius(radius) end
function ZO_SceneNodeRing:GetNodePadding(node) end
function ZO_SceneNodeRing:SetNodePadding(node, radians) end
function ZO_SceneNodeRing:RefreshNodePositions() end
function ZO_SceneNodeRing:AddNode(node) end
function ZO_SceneNodeRing:SetAngularVelocity(radiansPerSecond) end
function ZO_SceneNodeRing:GetAngle() end
function ZO_SceneNodeRing:SetAngle(angle) end
function ZO_SceneNodeRing:GetNodeAtAngle(radians) end
function ZO_SceneNodeRing:GetNextNode(node) end
function ZO_SceneNodeRing:GetPreviousNode(node) end
function ZO_SceneNodeRing:GetAngularVelocity() end
function ZO_SceneNodeRing:Update(delta) end
--libraries\zo_smoothslider
function ZO_SmoothSlider:New(...) end
function ZO_SmoothSlider:Initialize(control, buttonTemplate, buttonWidth, buttonHeight, buttonPadding, buttonScaleFactor) end
function ZO_SmoothSlider:EnableHighlight(normalTexture, highlightTexture) end
function ZO_SmoothSlider:SetMinMax(min, max) end
function ZO_SmoothSlider:SetValue(value) end
function ZO_SmoothSlider:SetClickedCallback(clickedCallback) end
function ZO_SmoothSlider:SetNumDivisions(numDivisions) end
function ZO_SmoothSlider:NormalizeIndex(index) end
function ZO_SmoothSlider:NormalizeValue(value) end
function ZO_SmoothSlider:ComputeScale(normalizedDiff) end
function ZO_SmoothSlider:IsHighlightEnabled() end
function ZO_SmoothSlider:RefreshScales() end
function ZO_SmoothSlider:GetValueFromButtonIndex(index) end
function ZO_SmoothSlider:GetButtonIndexFromValue(value) end
function ZO_SmoothSlider:GetStepValue(value, amount) end
function ZO_SmoothSlider:Button_OnClicked(button) end
function ZO_SmoothSliderButton_OnClicked(self) end
--libraries\zo_sortableparametriclist
function ZO_SortableParametricList:New(...) end
function ZO_SortableParametricList:Initialize(control, useHighlight) end
function ZO_SortableParametricList:SetSortOptions(sortOptions) end
function ZO_SortableParametricList:Activate() end
function ZO_SortableParametricList:Deactivate() end
function ZO_SortableParametricList:OnSortHeaderClicked(key, order) end
function ZO_SortableParametricList:SortFunc(data1, data2) end
function ZO_SortableParametricList:UpdateListSortFunction() end
function ZO_SortableParametricList:UpdateSortOption() end
function ZO_SortableParametricList:GetList() end
function ZO_SortableParametricList:SortBySelected() end
function ZO_SortableParametricList:SelectHeaderByKey(key) end
function ZO_SortableParametricList:SelectAndResetSortForKey(key) end
function ZO_SortableParametricList:SetHeaderNameForKey(key, name) end
function ZO_SortableParametricList:ReplaceKey(curKey, newKey, newText, selectNewKey) end
function ZO_SortableParametricList:CommitList(dontReselect) end
function ZO_SortableParametricList:ClearList() end
function ZO_SortableParametricList:RefreshVisible() end
function ZO_SortableParametricList:RefreshSort() end
function ZO_SortableParametricList:RefreshFilters() end
function ZO_SortableParametricList:RefreshData(dontReselect) end
function ZO_SortableParametricList:InitializeList() end
function ZO_SortableParametricList:BuildList() end
function ZO_SortableParametricList_InitSortHeader(header, stringId, textAlignment, sortKey) end
--libraries\zo_sortfilterlist
function GamepadInteractiveSortFilterFocus:New(...) end
function GamepadInteractiveSortFilterFocus:Initialize(manager, activateCallback, deactivateCallback) end
function GamepadInteractiveSortFilterFocus:SetupSiblings(previous, next) end
function GamepadInteractiveSortFilterFocus:SetKeybind(keybindDescriptor) end
function GamepadInteractiveSortFilterFocus:AppendKeybind(keybind) end
function GamepadInteractiveSortFilterFocus:UpdateKeybinds() end
function GamepadInteractiveSortFilterFocus:Activate() end
function GamepadInteractiveSortFilterFocus:Deactivate() end
function GamepadInteractiveSortFilterFocus:HandleMovePrevious() end
function GamepadInteractiveSortFilterFocus:HandleMoveNext() end
function GamepadInteractiveSortFilterFocus_Headers:HandleMoveNext() end
function GamepadInteractiveSortFilterFocus_Panel:HandleMovePrevious() end
function GamepadInteractiveSortFilterFocus_Panel:HandleMoveNext() end
function ZO_GamepadInteractiveSortFilterList:New(...) end
function ZO_GamepadInteractiveSortFilterList:Initialize(control) end
function ZO_GamepadInteractiveSortFilterList:InitializeSortFilterList(control) end
function ZO_GamepadInteractiveSortFilterList:SetupFoci() end
function ZO_GamepadInteractiveSortFilterList:InitializeHeader(headerData) end
function ZO_GamepadInteractiveSortFilterList:InitializeFilters() end
function ZO_GamepadInteractiveSortFilterList:InitializeDropdownFilter() end
function ZO_GamepadInteractiveSortFilterList:InitializeSearchFilter() end
function ZO_GamepadInteractiveSortFilterList:InitializeKeybinds() end
function ZO_GamepadInteractiveSortFilterList:AddUniversalKeybind(keybind) end
function ZO_GamepadInteractiveSortFilterList:GetBackKeybindCallback() end
function ZO_GamepadInteractiveSortFilterList:SetupSort(sortKeys, initialKey, initialDirection) end
function ZO_GamepadInteractiveSortFilterList:EntrySelectionCallback(oldData, newData) end
function ZO_GamepadInteractiveSortFilterList:OnShowing() end
function ZO_GamepadInteractiveSortFilterList:OnShown() end
function ZO_GamepadInteractiveSortFilterList:OnHiding() end
function ZO_GamepadInteractiveSortFilterList:OnHidden() end
function ZO_GamepadInteractiveSortFilterList:Activate() end
function ZO_GamepadInteractiveSortFilterList:Deactivate() end
function ZO_GamepadInteractiveSortFilterList:IsActivated() end
function ZO_GamepadInteractiveSortFilterList:MovePrevious() end
function ZO_GamepadInteractiveSortFilterList:MoveNext() end
function ZO_GamepadInteractiveSortFilterList:OnFilterDeactivated() end
function ZO_GamepadInteractiveSortFilterList:SetTitle(titleName) end
function ZO_GamepadInteractiveSortFilterList:RefreshHeader() end
function ZO_GamepadInteractiveSortFilterList:SetEmptyText(emptyText) end
function ZO_GamepadInteractiveSortFilterList:SetMasterList(list) end
function ZO_GamepadInteractiveSortFilterList:GetMasterList() end
function ZO_GamepadInteractiveSortFilterList:GetHeaderControl(headerName) end
function ZO_GamepadInteractiveSortFilterList:GetContentHeaderData() end
function ZO_GamepadInteractiveSortFilterList:GetCurrentSearch() end
function ZO_GamepadInteractiveSortFilterList:HasEntries(ignoreFilters) end
function ZO_GamepadInteractiveSortFilterList:GetListFragment() end
function ZO_GamepadInteractiveSortFilterList:UpdateKeybinds() end
function ZO_GamepadInteractiveSortFilterList:FilterScrollList() end
function ZO_GamepadInteractiveSortFilterList:SortScrollList() end
function ZO_GamepadInteractiveSortFilterList:CompareSortEntries(listEntry1, listEntry2) end
function ZO_GamepadInteractiveSortFilterList:ResetSelectedEntry() end
function ZO_GamepadInteractiveSortFilterList:RefreshFilters() end
function ZO_GamepadInteractiveSortFilterList:RefreshData() end
function ZO_GamepadInteractiveSortFilterList:CommitScrollList() end
function ZO_GamepadInteractiveSortFilterList:IsMatch(searchTerm, data) end
function ZO_GamepadInteractiveSortFilterList:ProcessNames(stringSearch, data, searchTerm, cache) end
function ZO_GamepadInteractiveSortFilterHeader_Initialize(control, text, sortKey, textAlignment) end
function ZO_SortFilterList_Gamepad:New(...) end
function ZO_SortFilterList_Gamepad:Initialize(...) end
function ZO_SortFilterList_Gamepad:InitializeSortFilterList(control, magnitudeQueryFunction, scrollListAsBlock) end
function ZO_SortFilterList_Gamepad:SetDirectionalInputEnabled(enabled) end
function ZO_SortFilterList_Gamepad:UpdateDirectionalInput() end
function ZO_SortFilterList_Gamepad:MovePrevious() end
function ZO_SortFilterList_Gamepad:MoveNext() end
function ZO_SortFilterList_Gamepad:MovePreviousAsBlock() end
function ZO_SortFilterList_Gamepad:MoveNextAsBlock() end
function ZO_SortFilterList_Gamepad:SetEmptyText(emptyText) end
function ZO_SortFilterList:New(...) end
function ZO_SortFilterList:Initialize(control, ...) end
function ZO_SortFilterList:BuildMasterList() end
function ZO_SortFilterList:FilterScrollList() end
function ZO_SortFilterList:SortScrollList() end
function ZO_SortFilterList:InitializeSortFilterList(control) end
function ZO_SortFilterList:ClearUpdateInterval() end
function ZO_SortFilterList:SetUpdateInterval(updateIntervalSecs) end
function ZO_SortFilterList:SetAlternateRowBackgrounds(alternate) end
function ZO_SortFilterList:SetEmptyText(emptyText) end
function ZO_SortFilterList:ShowMenu(...) end
function ZO_SortFilterList:UpdatePendingUpdateLevel(pendingUpdate) end
function ZO_SortFilterList:RefreshVisible() end
function ZO_SortFilterList:RefreshSort() end
function ZO_SortFilterList:RefreshFilters() end
function ZO_SortFilterList:RefreshData() end
function ZO_SortFilterList:CommitScrollList() end
function ZO_SortFilterList:SetLockedForUpdates(locked) end
function ZO_SortFilterList:IsLockedForUpdates() end
function ZO_SortFilterList:LockSelection() end
function ZO_SortFilterList:UnlockSelection() end
function ZO_SortFilterList:OnSortHeaderClicked(key, order) end
function ZO_SortFilterList:SetHighlightedRow(row) end
function ZO_SortFilterList:EnterRow(row) end
function ZO_SortFilterList:ExitRow(row) end
function ZO_SortFilterList:SelectRow(row) end
function ZO_SortFilterList:OnSelectionChanged(previouslySelected, selected) end
function ZO_SortFilterList:GetRowColors(data, mouseIsOver, control) end
function ZO_SortFilterList:ColorRow(control, data, mouseIsOver) end
function ZO_SortFilterList:SetupRow(control, data) end
function ZO_SortFilterList:GetSelectedData() end
function ZO_SortFilterList:HasEntries() end
function ZO_SortFilterList:SetKeybindStripDescriptor(keybindStripDescriptor) end
function ZO_SortFilterList:AddKeybinds() end
function ZO_SortFilterList:RemoveKeybinds() end
function ZO_SortFilterList:UpdateKeybinds() end
function ZO_SortFilterList:Row_OnMouseEnter(control) end
function ZO_SortFilterList:Row_OnMouseExit(control) end
--libraries\zo_sortfilterlistbase
function ZO_SortFilterListBase:New(...) end
function ZO_SortFilterListBase:Initialize() end
function ZO_SortFilterListBase:RefreshVisible() end
function ZO_SortFilterListBase:RefreshSort() end
function ZO_SortFilterListBase:RefreshFilters() end
function ZO_SortFilterListBase:RefreshData() end
--libraries\zo_sortheadergroup
function ZO_SortHeaderGroup:New(headerContainer, showArrows) end
function ZO_SortHeaderGroup:AddHeader(header) end
function ZO_SortHeaderGroup:AddHeadersFromContainer() end
function ZO_SortHeaderGroup:SetColors(selected, normal, highlight, disabled) end
function ZO_SortHeaderGroup:SelectHeader(header) end
function ZO_SortHeaderGroup:DeselectHeader() end
function ZO_SortHeaderGroup:IsCurrentSelectedHeader(header) end
function ZO_SortHeaderGroup:OnHeaderClicked(header, suppressCallbacks, forceReselect) end
function ZO_SortHeaderGroup:HeaderForKey(key) end
function ZO_SortHeaderGroup:SelectHeaderByKey(key, suppressCallbacks, forceReselect) end
function ZO_SortHeaderGroup:SetHeaderHiddenForKey(key, hidden) end
function ZO_SortHeaderGroup:ReplaceKey(curKey, newKey, newText, selectNewKey) end
function ZO_SortHeaderGroup:SelectAndResetSortForKey(key) end
function ZO_SortHeaderGroup:SetHeadersHiddenFromKeyList(keyList, hidden) end
function ZO_SortHeaderGroup:SetHeaderNameForKey(key, name) end
function ZO_SortHeader_Initialize(control, name, key, initialDirection, alignment, font, highlightTemplate) end
function ZO_SortHeader_InitializeIconHeader(control, icon, sortUpIcon, sortDownIcon, mouseoverIcon, key, initialDirection) end
function ZO_SortHeader_InitializeIconWithArrowHeader(control, icon, mouseoverIcon, arrowOffset, key, initialDirection) end
function ZO_SortHeader_InitializeArrowHeader(control, key, initialDirection) end
function ZO_SortHeader_SetTooltip(control, tooltipText, point, offsetX, offsetY) end
function ZO_SortHeader_OnMouseEnter(control) end
function ZO_SortHeader_OnMouseExit(control) end
function ZO_SortHeader_OnMouseUp(control, upInside) end
function ZO_SortHeaderGroup:SetEnabled(enabled) end
function ZO_SortHeaderGroup:IsEnabled() end
function ZO_SortHeaderGroup:EnableSelection(enabled) end
function ZO_SortHeaderGroup:EnableHighlight(highlightTemplate, highlightCallback) end
function ZO_SortHeaderGroup:SetDirectionalInputEnabled(enabled) end
function ZO_SortHeaderGroup:UpdateDirectionalInput() end
function ZO_SortHeaderGroup:SetSelectedIndex(selectedIndex) end
function ZO_SortHeaderGroup:MakeSelectedSortHeaderSelectedIndex() end
function ZO_SortHeaderGroup:MovePrevious() end
function ZO_SortHeaderGroup:MoveNext() end
function ZO_SortHeaderGroup:GetSelectedData() end
function ZO_SortHeaderGroup:GetCurrentSortKey() end
function ZO_SortHeaderGroup:GetSortDirection() end
function ZO_SortHeaderGroup:SortBySelected() end
--libraries\zo_spinner
function ZO_Spinner_Gamepad:New(...) end
function ZO_Spinner_Gamepad:Initialize(control, min, max, stickDirection, spinnerMode, accelerationTime, magnitudeQueryFunction) end
function ZO_Spinner_Gamepad:SetActive(active) end
function ZO_Spinner_Gamepad:Activate() end
function ZO_Spinner_Gamepad:Deactivate() end
function ZO_Spinner_Gamepad:UpdateDirectionalInput() end
function ZO_Spinner:New(...) end
function ZO_Spinner:Initialize(control, min, max, isGamepad, spinnerMode, accelerationTime) end
function ZO_Spinner:InitializeHandlers() end
function ZO_Spinner:SetNormalColor(normalColor) end
function ZO_Spinner:SetErrorColor(errorColor) end
function ZO_Spinner:SetFont(fontString) end
function ZO_Spinner:OnMouseWheel(delta) end
function ZO_Spinner:OnFocusLost(delta) end
function ZO_Spinner:OnButtonUp(direction) end
function ZO_Spinner:AllowUnknownQuantities(unknownCharacter) end
function ZO_Spinner:SetValidValuesFunction(validValuesFunction) end
function ZO_Spinner:SetStep(step) end
function ZO_Spinner:GetStep() end
function ZO_Spinner:SetMinMax(min, max) end
function ZO_Spinner:GetMin() end
function ZO_Spinner:GetMax() end
function ZO_Spinner:GetControl() end
function ZO_Spinner:GetValue() end
function ZO_Spinner:SetSoftMax(softMax) end
function ZO_Spinner:GetSoftMax() end
function ZO_Spinner:UpdateButtons() end
function ZO_Spinner:SetMouseEnabled(mouseEnabled) end
function ZO_Spinner:SetValue(value, forceSet) end
function ZO_Spinner:UpdateDisplay() end
function ZO_Spinner:ModifyValue(change) end
function ZO_Spinner:SetEnabled(enabled) end
function ZO_Spinner:SetButtonsHidden(hideButtons) end
function ZO_Spinner:SetSounds(upSound, downSound) end
--libraries\zo_stringsearch
function ZO_StringSearch:New(doCaching) end
function ZO_StringSearch:AddProcessor(typeId, processingFunction) end
function ZO_StringSearch:Insert(data) end
function ZO_StringSearch:Remove(data) end
function ZO_StringSearch:RemoveAll() end
function ZO_StringSearch:ClearCache() end
function ZO_StringSearch:Process(data, searchTerms) end
function ZO_StringSearch:GetSearchTerms(str) end
function ZO_StringSearch:IsMatch(str, data) end
function ZO_StringSearch:GetFromCache(data, cache, dataFunction, ...) end
--libraries\zo_systems
function ZO_Systems:New() end
function ZO_Systems:Initialize() end
function ZO_Systems:GetSystem(systemName) end
function ZO_Systems:RegisterKeyboardObject(systemName, object) end
function ZO_Systems:RegisterGamepadObject(systemName, object) end
function ZO_Systems:RegisterKeyboardRootScene(systemName, scene) end
function ZO_Systems:RegisterGamepadRootScene(systemName, scene) end
function ZO_Systems:GetKeyboardObject(systemName) end
function ZO_Systems:GetGamepadObject(systemName) end
function ZO_Systems:GetKeyboardRootScene(systemName) end
function ZO_Systems:GetGamepadRootScene(systemName) end
function ZO_Systems:GetObject(systemName) end
function ZO_Systems:GetObjectBasedOnCurrentScene(systemName) end
function ZO_Systems:GetRootScene(systemName) end
function ZO_Systems:GetRootSceneName(systemName) end
function ZO_Systems:ShowScene(systemName) end
function ZO_Systems:PushScene(systemName) end
function ZO_Systems:HideScene(systemName) end
function ZO_Systems:IsShowing(systemName) end
--libraries\zo_templates
function ZO_ToggleButton_Initialize(toggleButton, type, initialState) end
function ZO_ToggleButton_Toggle(toggleButton) end
function ZO_ToggleButton_SetState(toggleButton, state) end
function ZO_ToggleButton_GetState(toggleButton) end
function ZO_CheckButtonLabel_SetDefaultColors(label, defaultNormalColor, defaultHighlightColor) end
function ZO_CheckButtonLabel_ColorText(label, over) end
function ZO_CheckButtonLabel_SetTextColor(button, r, g, b) end
function ZO_CheckButton_SetLabelText(button, labelText) end
function ZO_CheckButton_SetLabelWrapMode(button, wrapMode, labelWidth) end
function ZO_CheckButton_SetLabelWidth(button, labelWidth) end
function ZO_CheckButton_OnClicked(buttonControl) end
function ZO_CheckButton_SetEnableState(buttonControl, enabled) end
function ZO_CheckButton_Disable(buttonControl) end
function ZO_CheckButton_Enable(buttonControl) end
function ZO_CheckButton_SetChecked(buttonControl) end
function ZO_CheckButton_SetUnchecked(buttonControl) end
function ZO_CheckButton_IsChecked(buttonControl) end
function ZO_CheckButton_SetCheckState(buttonControl, checkState) end
function ZO_CheckButton_SetToggleFunction(checkButtonControl, toggleFunction) end
function ZO_TriStateCheckButton_SetState(buttonControl, checkState, callStateChangeFunction) end
function ZO_TriStateCheckButton_GetState(buttonControl) end
function ZO_TriStateCheckButton_OnClicked(buttonControl, mouseButton) end
function ZO_TriStateCheckButton_SetStateChangeFunction(buttonControl, stateChangeFunction) end
function ZO_MenuDropDownTextButton_SetSelectedState(buttonControl, selected) end
function ZO_WeaponSwap_OnInitialized(self, hideWhenUnearned) end
function ZO_WeaponSwap_OnMouseEnter(self, anchorPoint, xOffset, yOffset) end
function ZO_WeaponSwap_OnMouseExit(self) end
function ZO_WeaponSwap_SetExternallyLocked(self, locked) end
function ZO_WeaponSwap_SetPermanentlyHidden(self, hidden) end
function EditContainerSizerManager:New() end
function EditContainerSizerManager:Initialize() end
function EditContainerSizerManager:Add(sizer) end
function EditContainerSizerManager:OnAllGuiScreensResized() end
function ZO_EditContainerSizer:New(...) end
function ZO_EditContainerSizer:Initialize(bufferTop, bufferBottom) end
function ZO_EditContainerSizer:Add(backdrop) end
function ZO_EditContainerSizer.GetHeight(backdrop, bufferTop, bufferBottom) end
function ZO_EditContainerSizer:RefreshSize(backdrop) end
function ZO_EditContainerSizer.ForceRefreshSize(backdrop, bufferTop, bufferBottom) end
function ZO_EditContainerSizer:OnAllGuiScreensResized() end
function ZO_DefaultEdit_SetEnabled(editBox, enabled) end
function ZO_SingleLineEditContainerSize_Gamepad_OnInitialized(self) end
function ZO_SingleLineEditContainerSize_Keyboard_OnInitialized(self) end
function ZO_SingleLineEditContainerDarkSize_Keyboard_OnInitialized(self) end
function ZO_ScrollAreaBarBehavior_OnEffectivelyShown_Gamepad(self) end
function ZO_ScrollAreaBarBehavior_OnEffectivelyHidden_Gamepad(self) end
function ZO_ScrollSharedInput_Gamepad:New() end
function ZO_ScrollSharedInput_Gamepad:Initialize() end
function ZO_ScrollSharedInput_Gamepad:Activate(control) end
function ZO_ScrollSharedInput_Gamepad:Deactivate() end
function ZO_ScrollSharedInput_Gamepad:Consume() end
function ZO_ScrollSharedInput_Gamepad:UpdateDirectionalInput() end
function ZO_ScrollSharedInput_Gamepad:GetY() end
function ZO_Scroll_Initialize_Gamepad(control) end
function ZO_ScrollContainer_Gamepad:DisableUpdateHandler() end
function ZO_ScrollContainer_Gamepad:RefreshDirectionalInputActivation() end
function ZO_ScrollContainer_Gamepad:OnEffectivelyShown() end
function ZO_ScrollContainer_Gamepad:OnEffectivelyHidden() end
function ZO_ScrollContainer_Gamepad:OnScrollExtentsChanged(control, horizontalExtents, verticalExtents) end
function ZO_Scroll_Gamepad_SetScrollIndicatorSide(scrollIndicator, background, anchorSide, customOffsetX, customOffsetY, anchorsToBackground) end
function ZO_GamepadEditBox_FocusGained(editControl) end
function ZO_GamepadEditBox_FocusLost(editControl) end
function ZO_AnimationPool:SetCustomResetBehavior(customResetBehavior) end
function ZO_ControlPool:New(templateName, parent, prefix) end
function ZO_ControlPool:SetCustomFactoryBehavior(customFactoryBehavior) end
function ZO_ControlPool:SetCustomResetBehavior(customResetBehavior) end
function ZO_ControlPool:SetCustomAcquireBehavior(customAcquireBehavior) end
function ZO_ControlPool:AcquireObject(objectKey) end
function ZO_MetaPool:New(sourcePool) end
function ZO_MetaPool:AcquireObject() end
function ZO_MetaPool:GetExistingObject(objectKey) end
function ZO_MetaPool:GetActiveObjectCount() end
function ZO_MetaPool:ReleaseAllObjects() end
function ZO_MetaPool:ReleaseObject(objectKey) end
function ZO_MetaPool:SetCustomAcquireBehavior(customAcquireBehavior) end
function ZO_Options_SetOptionActive(control) end
function ZO_Options_SetOptionInactive(control) end
function ZO_Options_SetOptionActiveOrInactive(control, active) end
function ZO_Options_ShowAssociatedWarning(control) end
function ZO_Options_HideAssociatedWarning(control) end
function ZO_Options_ShowOrHideAssociatedWarning(control, hidden) end
function ZO_Options_SetWarningText(control, text) end
function ZO_Options_UpdateOption(control) end
function ZO_Options_SliderOnValueChanged(sliderControl, value, eventReason) end
function ZO_Options_SliderOnSliderReleased(sliderControl, value) end
function ZO_Options_SetupSlider(control, selected) end
function ZO_Options_SetupDropdown(control) end
function ZO_Options_InvokeCallback(control) end
function ZO_Options_SetupScrollList(control, selected) end
function ZO_Options_SetupCheckBox(control) end
function ZO_Options_CheckBoxOnMouseEnter(control) end
function ZO_Options_CheckBoxOnMouseExit(control) end
function ZO_Options_OnMouseEnter(control) end
function ZO_Options_OnMouseExit(control) end
function ZO_Options_OnShow(control) end
function ZO_VerticalScrollbarBase_OnInitialized(self) end
function ZO_VerticalScrollbarBase_OnMouseEnter(self) end
function ZO_VerticalScrollbarBase_OnMouseExit(self) end
function ZO_VerticalScrollbarBase_OnMouseDown(self) end
function ZO_VerticalScrollbarBase_OnMouseUp(self) end
function ZO_VerticalScrollbarBase_OnEffectivelyHidden(self) end
function ZO_VerticalScrollbarBase_OnScrollAreaEnter(self) end
function ZO_VerticalScrollbarBase_OnScrollAreaExit(self) end
function ZO_ScrollAreaBarBehavior_OnEffectivelyShown(self) end
function ZO_ScrollAreaBarBehavior_OnEffectivelyHidden(self) end
function ZO_Scroll_Initialize(self) end
function ZO_Scroll_ResetToTop(self) end
function ZO_Scroll_ScrollAbsolute(self, value) end
function ZO_Scroll_ScrollAbsoluteInstantly(self, value) end
function ZO_Scroll_ScrollRelative(self, verticalDelta) end
function ZO_Scroll_MoveWindow(self, value) end
function ZO_Scroll_GetScrollDistanceToControl(self, otherControl) end
function ZO_Scroll_ScrollToControl(self, otherControl) end
function ZO_Scroll_ScrollControlToTop(self, otherControl) end
function ZO_Scroll_ScrollControlIntoView(self, otherControl) end
function ZO_Scroll_ScrollControlIntoCentralView(self, otherControl, scrollInstantly) end
function ZO_Scroll_OnExtentsChanged(self) end
function ZO_Scroll_UpdateScrollBar(self) end
function ZO_Scroll_GetScrollIndicator(self) end
function ZO_Scroll_SetHideScrollbarOnDisable(self, hide) end
function ZO_Scroll_SetUseFadeGradient(self, useFadeGradient) end
function ZO_Scroll_SetupGutterTexture(self, textureControl) end
function ZO_Scroll_SetResetScrollbarOnShow(self, resetOnShow) end
function ZO_ScrollList_Initialize(self) end
function ZO_ScrollList_SetHeight(self, height) end
function ZO_ScrollList_GetHeight(self) end
function ZO_ScrollList_AddResizeOnScreenResize(self) end
function ZO_ScrollList_AddDataType(self, typeId, templateName, height, setupCallback, hideCallback, dataTypeSelectSound, resetControlCallback) end
function ZO_ScrollList_GetDataTypeTable(self, typeId) end
function ZO_ScrollList_UpdateDataTypeHeight(self, typeId, newHeight) end
function ZO_ScrollList_SetTypeSelectable(self, typeId, selectable) end
function ZO_ScrollList_SetEqualityFunction(self, typeId, equalityFunction) end
function ZO_ScrollList_SetDeselectOnReselect(self, deselectOnReselect) end
function ZO_ScrollList_SetAutoSelect(self, autoSelect) end
function ZO_ScrollList_SetScrollBarHiddenCallback(self, callback) end
function ZO_ScrollList_AddCategory(self, categoryId, parentId) end
function ZO_ScrollList_Clear(self) end
function ZO_ScrollList_GetCategoryHidden(self, categoryId) end
function ZO_ScrollList_CreateDataEntry(typeId, data, categoryId) end
function ZO_ScrollList_GetDataEntryData(entry) end
function ZO_ScrollList_GetData(control) end
function ZO_ScrollList_GetDataList(self) end
function ZO_ScrollList_HasVisibleData(self) end
function ZO_ScrollList_GetSelectedData(self) end
function ZO_ScrollList_GetSelectedControl(self) end
function ZO_ScrollList_SetLockScrolling(self, lock) end
function ZO_ScrollList_GetMouseOverControl(self) end
function ZO_ScrollList_SetLockHighlight(self, lock) end
function ZO_ScrollList_MouseEnter(self, control) end
function ZO_ScrollList_MouseExit(self, control) end
function ZO_ScrollList_MouseClick(self, control) end
function ZO_ScrollList_EnableHighlight(self, highlightTemplate, highlightCallback) end
function ZO_ScrollList_SetHideScrollbarOnDisable(self, hideOnDisable) end
function ZO_ScrollList_SetUseFadeGradient(self, useFadeGradient) end
function ZO_ScrollList_EnableSelection(self, selectionTemplate, selectionCallback) end
function ZO_ScrollList_IsDataSelected(self, data) end
function ZO_ScrollList_GetDataControl(self, data) end
function ZO_ScrollList_SelectData(self, data, control, reselectingDuringRebuild) end
function ZO_ScrollList_ScrollDataIntoView(self, dataIndex) end
function ZO_ScrollList_ScrollDataToCenter(self, dataIndex) end
function ZO_ScrollList_SelectNextData(self) end
function ZO_ScrollList_SelectPreviousData(self) end
function ZO_ScrollList_TrySelectFirstData(self) end
function ZO_ScrollList_TrySelectLastData(self) end
function ZO_ScrollList_AutoSelectData(self) end
function ZO_ScrollList_ResetAutoSelectIndex(self) end
function ZO_ScrollList_Commit(self) end
function ZO_ScrollList_RefreshVisible(self, data, overrideSetupCallback) end
function ZO_ScrollList_HideData(self, index) end
function ZO_ScrollList_HideCategory(self, categoryId) end
function ZO_ScrollList_ShowData(self, index) end
function ZO_ScrollList_HideAllCategories(self) end
function ZO_ScrollList_ShowCategory(self, categoryId) end
function ZO_ScrollList_UpdateScroll(self) end
function ZO_ScrollList_ResetToTop(self) end
function ZO_ScrollList_ScrollRelative(self, delta) end
function ZO_ScrollList_ScrollAbsolute(self, value) end
function ZO_ScrollList_MoveWindow(self, value) end
function ZO_ScrollList_CanScrollUp(self) end
function ZO_ScrollList_CanScrollDown(self) end
function ZO_ScrollList_AtTopOfVisible(self) end
function ZO_ScrollList_AtBottomOfVisible(self) end
function ZO_ScrollList_AtTopOfList(self) end
function ZO_ScrollList_AtBottomOfList(self) end
function ZO_ScrollList_SelectDataAndScrollIntoView(self, data) end
function ZO_ScrollList_EnoughEntriesToScroll(self) end
function ZO_StatusBar_SetGradientColor(statusBar, gradientColorTable) end
function ZO_StatusBar_InitializeDefaultColors(statusBar) end
function ZO_WrappingStatusBar:New(...) end
function ZO_WrappingStatusBar:Initialize(statusBar, onLevelChangedCallback) end
function ZO_WrappingStatusBar:SetOnLevelChangeCallback(onLevelChangedCallback) end
function ZO_WrappingStatusBar:SetOnCompleteCallback(onCompleteCallback) end
function ZO_WrappingStatusBar:GetControl() end
function ZO_WrappingStatusBar:SetHidden(hidden) end
function ZO_WrappingStatusBar:GetValue() end
function ZO_WrappingStatusBar:Reset() end
function ZO_WrappingStatusBar:SetAnimationTime(time) end
function ZO_WrappingStatusBar:SetValue(level, value, max, noWrap) end
function ZO_WrappingStatusBar:OnAnimationFinished() end
function ZO_InventoryItemImprovementStatusBar:Initialize(control) end
function ZO_InventoryItemImprovementStatusBar:SetMinMax(min, max) end
function ZO_InventoryItemImprovementStatusBar:SetValueAndPreviewValue(value, previewValue) end
function ZO_InventoryItemImprovementStatusBar:SetGradientColors(...) end
function ZO_StableTrainingBar_Gamepad:Initialize(control) end
function ZO_StableTrainingBar_Gamepad:SetMinMax(min, max) end
function ZO_StableTrainingBar_Gamepad:SetValue(value, maxValue, format) end
function ZO_StableTrainingBar_Gamepad:SetGradientColors(...) end
function ClearTooltip(tooltip) end
function ClearTooltipImmediately(tooltip) end
function SetTooltipText(tooltip, text, color, colorG, colorB) end
function InitializeTooltip(tooltip, owner, point, offsetX, offsetY, relativePoint) end
function ZO_Tooltips_SetupDynamicTooltipAnchors(tooltip, owner, comparativeTooltip1, comparativeTooltip2) end
function ZO_Tooltips_ShowTruncatedTextTooltip(labelControl) end
function ZO_Tooltips_HideTruncatedTextTooltip() end
function ZO_Tooltips_ShowTextTooltip(control, side, ...) end
function ZO_Tooltips_HideTextTooltip() end
function ZO_Tooltip_AddDivider(tooltipControl) end
function ZO_Tooltip_OnAddGameData(tooltipControl, gameDataType) end
function ZO_Tooltip_OnCleared(tooltipControl) end
function ZO_LabelHeader_Setup(control, open) end
function ZO_IconHeader_OnMouseEnter(control) end
function ZO_IconHeader_OnMouseExit(control) end
function ZO_IconHeader_OnMouseUp(control, upInside) end
function ZO_IconHeader_Setup(control, open, enabled, disableScaling) end
function ZO_IconHeader_UpdateSize(control) end
function ZO_IconHeader_OnInitialized(self) end
function ZO_IconHeader_SetAnimation(self, animationTemplate) end
function ZO_IconHeader_SetMaxLines(self, maxLines) end
function ZO_SelectionHighlight_SetColor(highlight, r, g, b) end
function ZO_SelectionHighlight_Highlight(highlight, control, leftOffset, topOffset, rightOffset, bottomOffset) end
function ZO_CreateSparkleAnimation(slotControl) end
function ZO_PlaySparkleAnimation(slotControl) end
function ZO_PanelBackgroundHorizontalDoRotations(control) end
function ZO_SetupSelectableItemRadialMenuEntryTemplate(template, selected, itemCount) end
function ZO_RequiredTextFields:SetMatchingString(string) end
function ZO_SimpleControlScaleInterpolator:New(...) end
function ZO_SimpleControlScaleInterpolator:Initialize(minScale, maxScale) end
function ZO_SimpleControlScaleInterpolator:ScaleUp(control) end
function ZO_SimpleControlScaleInterpolator:ScaleDown(control) end
function ZO_SimpleControlScaleInterpolator:ResetToMax(control) end
function ZO_SimpleControlScaleInterpolator:ResetToMin(control) end
function ZO_SimpleControlScaleInterpolator:ResetAll() end
function ZO_SimpleControlScaleInterpolator:OnUpdate() end
function ZO_SelectableItemRadialMenuEntryTemplate_OnInitialized(self) end
function ZO_ScalableBackgroundWithEdge_SetSize(background, width, height) end
--libraries\zo_timelockeddialog
function ZO_TimeLockedDialog:New(...) end
function ZO_TimeLockedDialog:Initialize(dialogName, dialogInfo, cooldownFunction) end
function ZO_TimeLockedDialog:IsLocked() end
function ZO_TimeLockedDialog:GetSecondsUntilUnlocked() end
function ZO_TimeLockedDialog:GetData() end
function ZO_TimeLockedDialog:GetControl() end
function ZO_TimeLockedDialog:Show(data) end
function ZO_TimeLockedDialog:Hide() end
function ZO_TimeLockedDialog:InitializeDialog(data) end
function ZO_TimeLockedDialog:Refresh() end
function ZO_TimeLockedDialog:SetupUnlocked(data) end
function ZO_TimeLockedDialog:SetupLocked(data) end
--libraries\zo_timerbar
function ZO_TimerBar:New(control) end
function ZO_TimerBar:SetLabel(text) end
function ZO_TimerBar:SetDirection(direction) end
function ZO_TimerBar:SetTimeFormatParameters(timeFormatStyle, timePrecision) end
function ZO_TimerBar:SetFades(fades, duration) end
function ZO_TimerBar:IsStarted() end
function ZO_TimerBar:IsPaused() end
function ZO_TimerBar:GetTimeLeft() end
function ZO_TimerBar:Start(starts, ends) end
function ZO_TimerBar:SetPaused(paused) end
function ZO_TimerBar:Stop() end
function ZO_TimerBar:Update(time) end
--libraries\zo_tooltip
function ZO_ScrollTooltip_Gamepad:Initialize(control, styleNamespace, style) end
function ZO_ScrollTooltip_Gamepad:SetInputEnabled(enabled) end
function ZO_ScrollTooltip_Gamepad:OnEffectivelyShown() end
function ZO_ScrollTooltip_Gamepad:RefreshDirectionalInputActivation() end
function ZO_ScrollTooltip_Gamepad:OnEffectivelyHidden() end
function ZO_ScrollTooltip_Gamepad:OnScrollExtentsChanged(scroll, horizontalExtents, verticalExtents) end
function ZO_ScrollTooltip_Gamepad:SetMagnitude(magnitude) end
function ZO_ScrollTooltip_Gamepad:OnUpdate() end
function ZO_ScrollTooltip_Gamepad:ResetToTop() end
function ZO_ScrollTooltip_Gamepad:ClearLines(resetScroll) end
function ZO_ScrollTooltip_Gamepad:HasControls() end
function ZO_ScrollTooltip_Gamepad:LayoutItem(itemLink) end
function ZO_ScrollTooltip_Gamepad:LayoutBagItem(bagId, slotIndex) end
function ZO_ScrollTooltip_Gamepad:LayoutTradeItem(tradeType, tradeIndex) end
function ZO_Tooltip_CopyStyle(style) end
function ZO_TooltipStyledObject:Initialize(parent) end
function ZO_TooltipStyledObject:GetParent() end
function ZO_TooltipStyledObject:GetProperty(propertyName, ...) end
function ZO_TooltipStyledObject:GetPropertyNoChain(propertyName, ...) end
function ZO_TooltipStyledObject:GetFontString(...) end
function ZO_TooltipStyledObject:FormatLabel(label, text, ...) end
function ZO_TooltipStyledObject:FormatTexture(texture, path, ...) end
function ZO_TooltipStyledObject:GetWidthProperty(...) end
function ZO_TooltipStyledObject:GetHeightProperty(...) end
function ZO_TooltipStyledObject:GetStyles() end
function ZO_TooltipStyledObject:SetStyles(...) end
function ZO_TooltipStyledObject:ApplyStyles() end
function ZO_TooltipStatValuePair:Initialize(parent) end
function ZO_TooltipStatValuePair:SetStat(statText, ...) end
function ZO_TooltipStatValuePair:SetValue(valueText, ...) end
function ZO_TooltipStatValuePair:ComputeDimensions() end
function ZO_TooltipStatValuePair:UpdateFontOffset() end
function ZO_TooltipStatValueSlider:Initialize(parent) end
function ZO_TooltipStatValueSlider:SetStat(statText, ...) end
function ZO_TooltipStatValueSlider:SetValue(value, maxValue, valueText, ...) end
function ZO_TooltipStatValueSlider:ComputeDimensions() end
function ZO_TooltipStatusBar:ApplyStyles() end
function ZO_TooltipSection.InitializeStaticPools(class) end
function ZO_TooltipSection:CreateMetaControlPool(sourcePool) end
function ZO_TooltipSection:Initialize(parent) end
function ZO_TooltipSection:ApplyPadding() end
function ZO_TooltipSection:ApplyLayoutVariables() end
function ZO_TooltipSection:ApplyStyles() end
function ZO_TooltipSection:SetupPrimaryDimension() end
function ZO_TooltipSection:SetupSecondaryDimension() end
function ZO_TooltipSection:Reset() end
function ZO_TooltipSection:IsVertical() end
function ZO_TooltipSection:IsPrimaryDimensionFixed() end
function ZO_TooltipSection:IsSecondaryDimensionFixed() end
function ZO_TooltipSection:SetNextSpacing(spacing) end
function ZO_TooltipSection:GetNextSpacing(...) end
function ZO_TooltipSection:GetDimensionWithContraints(base, useHeightContraint) end
function ZO_TooltipSection:GetPrimaryDimension() end
function ZO_TooltipSection:GetInnerPrimaryDimension() end
function ZO_TooltipSection:SetPrimaryDimension(size) end
function ZO_TooltipSection:AddToPrimaryDimension(amount) end
function ZO_TooltipSection:GetSecondaryDimension() end
function ZO_TooltipSection:GetInnerSecondaryDimension() end
function ZO_TooltipSection:SetSecondaryDimension(size) end
function ZO_TooltipSection:AddToSecondaryDimension(amount) end
function ZO_TooltipSection:GetNumControls() end
function ZO_TooltipSection:HasControls() end
function ZO_TooltipSection:SetPoolKey(poolKey) end
function ZO_TooltipSection:GetPoolKey() end
function ZO_TooltipSection:ShouldAdvanceSecondaryCursor(primarySize, spacingSize) end
function ZO_TooltipSection:AddControl(control, primarySize, secondarySize, ...) end
function ZO_TooltipSection:AddDimensionedControl(control) end
function ZO_TooltipSection:AddLine(text, ...) end
function ZO_TooltipSection:AddCustom(customFunction, ...) end
function ZO_TooltipSection:AddSimpleCurrency(currencyType, amount, options, showAll, notEnough, ...) end
function ZO_TooltipSection:BasicTextureSetup(texture, ...) end
function ZO_TooltipSection:AddTexture(path, ...) end
function ZO_TooltipSection:AddColorSwatch(r, g, b, a, ...) end
function ZO_TooltipSection:AddColorAndTextSwatch(r, g, b, a, text, ...) end
function ZO_TooltipSection:AddSectionEvenIfEmpty(section) end
function ZO_TooltipSection:AddSection(section) end
function ZO_TooltipSection:AcquireSection(...) end
function ZO_TooltipSection:ReleaseSection(section) end
function ZO_TooltipSection:AcquireStatValuePair(...) end
function ZO_TooltipSection:AcquireStatValueSlider(...) end
function ZO_TooltipSection:AddStatValuePair(statValuePair) end
function ZO_TooltipSection:AcquireStatusBar(...) end
function ZO_TooltipSection:AddStatusBar(statusBar) end
function ZO_Tooltip:Initialize(control, styleNamespace, style) end
function ZO_Tooltip:SetClearOnHidden(clearOnHidden) end
function ZO_Tooltip:SetOwner(owner, point, offsetX, offsetY, relativePoint) end
function ZO_Tooltip:ClearLines() end
function ZO_Tooltip:GetStyle(styleName) end
--libraries\zo_tree
function ZO_Tree:New(control, defaultIndent, defaultSpacing, width) end
function ZO_Tree:Reset() end
function ZO_Tree:SelectAnything() end
function ZO_Tree:SelectFirstChild(parentNode) end
function ZO_Tree:SetSelectionHighlight(template) end
function ZO_Tree:SetOpenAnimation(animationTemplate) end
function ZO_Tree:SetExclusive(exclusive) end
function ZO_Tree:SetSuspendAnimations(suspendAnimations) end
function ZO_Tree:GetWidth() end
function ZO_Tree:AddTemplate(template, setupFunction, selectionFunction, equalityFunction, childIndent, childSpacing) end
function ZO_Tree:AddNode(template, data, parentNode, selectSound, open) end
function ZO_Tree:Commit(nodeToSelect) end
function ZO_Tree:SetEnabled(enabled) end
function ZO_Tree:IsEnabled() end
function ZO_Tree:RefreshVisible() end
function ZO_Tree:ToggleNode(treeNode) end
function ZO_Tree:SetNodeOpen(treeNode, open, userRequested) end
function ZO_Tree:SelectNode(treeNode, reselectingDuringRebuild) end
function ZO_Tree:ClearSelectedNode() end
function ZO_Tree:GetSelectedData() end
function ZO_Tree:GetSelectedNode() end
function ZO_Tree:GetSelectionHighlight() end
function ZO_Tree:ExecuteOnSubTree(treeRoot, func) end
function ZO_Tree:AcquireNewChildContainer() end
function ZO_Tree:OnOpenAnimationStopped(timeline) end
function ZO_Tree:AcquireOpenAnimation(treeNode) end
function ZO_Tree:GetControl() end
function ZO_Tree:IsAnimated() end
function ZO_TreeNode:New(tree, templateInfo, parentNode, data, childIndent, childSpacing, open) end
function ZO_TreeNode:ComputeTotalIndentFrom(treeNode) end
function ZO_TreeNode:AddChild(treeNode) end
function ZO_TreeNode:AttachNext(nextTreeNode) end
function ZO_TreeNode:IsAnimated() end
function ZO_TreeNode:IsSelected() end
function ZO_TreeNode:SetEnabled(enabled) end
function ZO_TreeNode:IsEnabled() end
function ZO_TreeNode:RefreshVisible(userRequested) end
function ZO_TreeNode:IsOpen() end
function ZO_TreeNode:SetOpen(open, userRequested) end
function ZO_TreeNode:SetOpenPercentage(openPercentage) end
function ZO_TreeNode:OnSelected(reselectingDuringRebuild) end
function ZO_TreeNode:OnUnselected() end
function ZO_TreeNode:GetHeight() end
function ZO_TreeNode:GetCurrentHeight() end
function ZO_TreeNode:GetWidth() end
function ZO_TreeNode:GetTotalWidth() end
function ZO_TreeNode:GetChildContainer() end
function ZO_TreeNode:IsLeaf() end
function ZO_TreeNode:GetTree() end
function ZO_TreeNode:UpdateChildrenHeightsToRoot() end
function ZO_TreeNode:UpdateCurrentChildrenHeightsToRoot() end
function ZO_TreeNode:GetControl() end
function ZO_TreeNode:GetParent() end
function ZO_TreeNode:GetChildren() end
function ZO_TreeNode:GetChildSpacing() end
function ZO_TreeNode:GetChildIndent() end
function ZO_TreeNode:GetData() end
function ZO_TreeNode:RefreshControl(userRequested) end
function ZO_TreeHeader_OnMouseUp(self, upInside) end
function ZO_TreeEntry_OnMouseUp(self, upInside) end
--libraries\zo_trianglepicker
function ZO_TrianglePoints_SetPoint(points, index, p, isMirrored) end
function ZO_Triangle:New(points, isMirrored) end
function ZO_Triangle:SetPoints(points) end
function ZO_Triangle:GetPoint(pointIndex) end
function ZO_Triangle:GetPreviousPoint(pointIndex) end
function ZO_Triangle:GetClosestPointOnTriangle(x, y) end
function ZO_Triangle:ContainsPoint(x, y) end
function ZO_Triangle:GetTriangleParams(x, y) end
function ZO_Triangle:PointFromParams(a, b) end
function ZO_TrianglePicker:New(...) end
function ZO_TrianglePicker:UpdateTriangle() end
function ZO_TrianglePicker:SetThumb(control) end
function ZO_TrianglePicker:SetEnabled(enabled) end
function ZO_TrianglePicker:SetUpdateCallback(callback) end
function ZO_TrianglePicker:GetControl() end
function ZO_TrianglePicker:GetThumbPosition() end
function ZO_TrianglePicker:SetThumbPosition(x, y) end
function ZO_TrianglePicker:OnUpdate() end
function ZO_TrianglePicker:SetThumbMoving(moving) end
function ZO_TrianglePicker:SetUpdateHandlerEnabled(enableUpdates) end
function ZO_TrianglePicker:OnMouseDown() end
function ZO_TrianglePicker:OnMouseUp() end
function ZO_TrianglePicker:OnMouseEnter() end
function ZO_TrianglePicker:OnMouseExit() end
function ZO_TrianglePicker_OnMouseDown(control) end
function ZO_TrianglePicker_OnMouseUp(control) end
function ZO_TrianglePicker_OnMouseEnter(control) end
function ZO_TrianglePicker_OnMouseExit(control) end
--libraries\zo_validnameinstructions
function ZO_ValidTextInstructions:New(...) end
function ZO_ValidTextInstructions:Initialize(control, template) end
function ZO_ValidTextInstructions:GetControl() end
function ZO_ValidTextInstructions:AddInstructions() end
function ZO_ValidTextInstructions:AddInstruction(instructionEnum) end
function ZO_ValidTextInstructions:UpdateViolations(ruleViolations) end
function ZO_ValidTextInstructions:SetPreferredAnchor(point, relativeTo, relativePoint, offsetX, offsetY) end
function ZO_ValidTextInstructions:Show(editControl, ruleViolations) end
function ZO_ValidTextInstructions:Hide() end
function ZO_ValidNameInstructions:New(...) end
function ZO_ValidNameInstructions:AddInstructions() end
function ZO_ValidNameInstructions_GetViolationString(name, ruleViolations, hideUnviolatedRules, format) end
function ZO_ValidAccountNameInstructions:New(...) end
function ZO_ValidAccountNameInstructions:AddInstructions() end